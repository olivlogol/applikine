@echo off
setlocal enabledelayedexpansion
title Installation de Cabinet Kine
chcp 65001 >nul
echo ============================================================
echo    Installation de Cabinet Kine (Windows)
echo ============================================================
echo.

REM --- 1) Trouver Python ---
set "PYEXE="
py -3 --version >nul 2>&1 && set "PYEXE=py -3"
if not defined PYEXE (
  python --version >nul 2>&1 && set "PYEXE=python"
)
if not defined PYEXE (
  echo Python n'est pas installe sur ce PC.
  echo.
  echo  1. La page de telechargement va s'ouvrir.
  echo  2. Telechargez Python puis COCHEZ bien la case
  echo     "Add Python to PATH" en bas de l'installeur Python.
  echo  3. Une fois Python installe, relancez CE programme.
  echo.
  start "" https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
echo Python detecte : %PYEXE%
echo.

REM --- 2) Dossier d'installation ---
set "APP=%USERPROFILE%\cabinet-kine"
if not exist "%APP%" mkdir "%APP%"

REM --- 3) Copier les fichiers de l'application ---
echo Copie des fichiers...
xcopy /E /Y /I /Q "%~dp0app\*" "%APP%\" >nul

REM --- 4) Environnement Python + dependances ---
cd /d "%APP%"
if not exist "venv" (
  echo Creation de l'environnement Python (premiere fois)...
  %PYEXE% -m venv venv
)
call "venv\Scripts\activate.bat"
echo Installation des composants (peut prendre quelques minutes)...
python -m pip install --upgrade pip >nul 2>&1
pip install flask reportlab cryptography
if errorlevel 1 (
  echo.
  echo ERREUR pendant l'installation des composants.
  echo Verifiez votre connexion Internet et relancez.
  pause
  exit /b 1
)

REM --- 5) Lanceur demarrer.bat ---
> "%APP%\demarrer.bat" (
  echo @echo off
  echo title Cabinet Kine
  echo cd /d "%%USERPROFILE%%\cabinet-kine"
  echo call "venv\Scripts\activate.bat"
  echo start "" /b cmd /c "timeout /t 5 ^>nul ^& start "" https://localhost:5001"
  echo echo ============================================================
  echo echo    Cabinet Kine - serveur demarre.
  echo echo    Laissez CETTE fenetre ouverte pendant l'utilisation.
  echo echo    Pour arreter : fermez cette fenetre.
  echo echo ============================================================
  echo python app.py
)

REM --- 6) Raccourci "Cabinet Kine" sur le Bureau ---
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d=[Environment]::GetFolderPath('Desktop'); $w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut($d+'\Cabinet Kine.lnk'); $s.TargetPath=$env:USERPROFILE+'\cabinet-kine\demarrer.bat'; $s.WorkingDirectory=$env:USERPROFILE+'\cabinet-kine'; $s.IconLocation=$env:USERPROFILE+'\cabinet-kine\cabinet.ico'; $s.Save()" 2>nul

echo.
echo ============================================================
echo    Installation terminee.
echo    Une icone "Cabinet Kine" a ete creee sur le Bureau.
echo.
echo    Double-cliquez-la pour demarrer (le navigateur s'ouvre seul).
echo    Au 1er acces : acceptez l'avertissement de certificat
echo    (Avance puis Continuer), connectez-vous avec  admin / admin
echo    puis changez le mot de passe dans "Securite".
echo.
echo    IMPORTANT : au 1er demarrage, Windows demandera d'autoriser
echo    l'acces reseau -> cliquez "Autoriser l'acces" (reseaux prives)
echo    pour que la synchronisation entre postes fonctionne.
echo ============================================================
echo.
pause
