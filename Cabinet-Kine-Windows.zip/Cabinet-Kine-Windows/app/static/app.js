/* Fiche patient : calendrier mensuel, graphique douleur (SVG), modale séance.
   Aucune dépendance externe : tout est fait main pour rester hors-ligne. */
(function () {
  "use strict";

  var MOIS = ["janvier","février","mars","avril","mai","juin","juillet","août",
              "septembre","octobre","novembre","décembre"];
  var JOURS = ["Lun","Mar","Mer","Jeu","Ven","Sam","Dim"];

  var seances = {};        // "AAAA-MM-JJ" -> {fait, douleur}
  var seancesIds = {};     // "AAAA-MM-JJ" -> id (pour la suppression)
  var vue = new Date();    // mois affiché
  vue.setDate(1);

  var grille = document.getElementById("calGrille");
  var moisLabel = document.getElementById("calMois");
  var overlay = document.getElementById("overlay");

  function iso(d) {
    return d.getFullYear() + "-" +
           String(d.getMonth() + 1).padStart(2, "0") + "-" +
           String(d.getDate()).padStart(2, "0");
  }
  function couleurDouleur(n) {
    if (!n) return null;
    if (n <= 3) return getCss("--ok");
    if (n <= 6) return getCss("--warn");
    return getCss("--danger");
  }
  function getCss(v) {
    return getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  }

  /* ---------------- Calendrier ---------------- */
  function dessinerCalendrier() {
    moisLabel.textContent = MOIS[vue.getMonth()] + " " + vue.getFullYear();
    grille.innerHTML = "";
    JOURS.forEach(function (j) {
      var c = document.createElement("div");
      c.className = "cal-jour-nom";
      c.textContent = j;
      grille.appendChild(c);
    });
    var premier = new Date(vue.getFullYear(), vue.getMonth(), 1);
    var decalage = (premier.getDay() + 6) % 7; // lundi = 0
    var nbJours = new Date(vue.getFullYear(), vue.getMonth() + 1, 0).getDate();
    var ajdIso = iso(new Date());

    for (var i = 0; i < decalage; i++) {
      var v = document.createElement("div");
      v.className = "cal-case vide-case";
      grille.appendChild(v);
    }
    for (var jour = 1; jour <= nbJours; jour++) {
      var d = new Date(vue.getFullYear(), vue.getMonth(), jour);
      var key = iso(d);
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cal-case" + (key === ajdIso ? " ajd" : "");
      btn.textContent = jour;
      var s = seances[key];
      if (s) {
        if (s.fait) {
          var fd = document.createElement("span");
          fd.className = "fait-dot";
          btn.appendChild(fd);
        }
        if (s.douleur) {
          var pt = document.createElement("span");
          pt.className = "pt";
          pt.style.background = couleurDouleur(s.douleur);
          pt.textContent = s.douleur;
          btn.appendChild(pt);
        }
      }
      (function (k) {
        btn.addEventListener("click", function () { ouvrirModale(k); });
      })(key);
      grille.appendChild(btn);
    }
  }

  /* ---------------- Graphique douleur (SVG) ---------------- */
  function dessinerGraphique() {
    var wrap = document.getElementById("graphWrap");
    var vide = document.getElementById("graphVide");
    var points = Object.keys(seances)
      .filter(function (k) { return seances[k].douleur; })
      .sort()
      .map(function (k) { return { date: k, d: seances[k].douleur }; });

    var ancien = wrap.querySelector("svg.graph");
    if (ancien) ancien.remove();

    if (points.length === 0) { vide.style.display = "block"; return; }
    vide.style.display = "none";

    var W = Math.max(560, points.length * 60 + 80);
    var H = 240, padL = 38, padR = 20, padT = 18, padB = 46;
    var plotW = W - padL - padR, plotH = H - padT - padB;
    var svgns = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(svgns, "svg");
    svg.setAttribute("class", "graph");
    svg.setAttribute("viewBox", "0 0 " + W + " " + H);
    svg.setAttribute("width", W);
    svg.setAttribute("height", H);

    function x(i) {
      return padL + (points.length === 1 ? plotW / 2 : (i / (points.length - 1)) * plotW);
    }
    function y(v) { return padT + plotH - (v / 10) * plotH; }

    // Grille horizontale 0,2,4,6,8,10
    [0, 2, 4, 6, 8, 10].forEach(function (lvl) {
      var yy = y(lvl);
      var ligne = document.createElementNS(svgns, "line");
      ligne.setAttribute("x1", padL); ligne.setAttribute("x2", W - padR);
      ligne.setAttribute("y1", yy); ligne.setAttribute("y2", yy);
      ligne.setAttribute("stroke", getCss("--line"));
      ligne.setAttribute("stroke-width", lvl === 0 ? 1.5 : 1);
      svg.appendChild(ligne);
      var t = document.createElementNS(svgns, "text");
      t.setAttribute("x", padL - 8); t.setAttribute("y", yy + 4);
      t.setAttribute("text-anchor", "end");
      t.textContent = lvl;
      svg.appendChild(t);
    });

    // Aire + ligne
    var dPath = "", dArea = "";
    points.forEach(function (p, i) {
      dPath += (i === 0 ? "M" : "L") + x(i) + " " + y(p.d) + " ";
    });
    dArea = dPath + "L" + x(points.length - 1) + " " + y(0) + " L" + x(0) + " " + y(0) + " Z";

    var aire = document.createElementNS(svgns, "path");
    aire.setAttribute("d", dArea);
    aire.setAttribute("fill", getCss("--accent"));
    aire.setAttribute("opacity", "0.08");
    svg.appendChild(aire);

    var ligne2 = document.createElementNS(svgns, "path");
    ligne2.setAttribute("d", dPath);
    ligne2.setAttribute("fill", "none");
    ligne2.setAttribute("stroke", getCss("--accent"));
    ligne2.setAttribute("stroke-width", "2.5");
    ligne2.setAttribute("stroke-linejoin", "round");
    ligne2.setAttribute("stroke-linecap", "round");
    svg.appendChild(ligne2);

    // Points + dates
    points.forEach(function (p, i) {
      var c = document.createElementNS(svgns, "circle");
      c.setAttribute("cx", x(i)); c.setAttribute("cy", y(p.d));
      c.setAttribute("r", "5");
      c.setAttribute("fill", couleurDouleur(p.d));
      c.setAttribute("stroke", "#fff");
      c.setAttribute("stroke-width", "2");
      var titre = document.createElementNS(svgns, "title");
      titre.textContent = p.date + " — EVA " + p.d;
      c.appendChild(titre);
      svg.appendChild(c);

      if (points.length <= 14 || i % 2 === 0) {
        var t = document.createElementNS(svgns, "text");
        t.setAttribute("x", x(i)); t.setAttribute("y", H - 24);
        t.setAttribute("text-anchor", "middle");
        t.setAttribute("font-size", "10");
        t.textContent = p.date.slice(5); // MM-JJ
        svg.appendChild(t);
      }
    });

    wrap.appendChild(svg);
  }

  /* ---------------- Modale ---------------- */
  function ouvrirModale(key) {
    var s = seances[key] || { fait: "", douleur: 0, heure: "", praticien: "" };
    document.getElementById("fDate").value = key;
    document.getElementById("fHeure").value = s.heure || "";
    document.getElementById("fPraticien").value = s.praticien || "";
    document.getElementById("fFait").value = s.fait || "";
    var d = s.douleur || 0;
    document.getElementById("fDouleur").value = d;
    majEva(d);
    document.getElementById("modDate").textContent = formaterDate(key);
    var supBtn = document.getElementById("modSupprimer");
    supBtn.style.visibility = seances[key] ? "visible" : "hidden";
    supBtn.dataset.key = key;
    overlay.classList.add("ouvert");
    if (window.__resetReform) window.__resetReform();
    document.getElementById("fFait").focus();
  }
  function fermerModale() { overlay.classList.remove("ouvert"); }

  function majEva(v) {
    document.getElementById("evaVal").textContent = (v > 0) ? v : "—";
  }
  function formaterDate(key) {
    var p = key.split("-");
    return p[2] + " " + MOIS[parseInt(p[1], 10) - 1] + " " + p[0];
  }

  /* ---------------- Données ---------------- */
  function charger() {
    fetch(window.SEANCES_URL)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        seances = {};
        seancesIds = {};
        data.forEach(function (s) {
          seances[s.date_seance] = { fait: s.fait || "", douleur: s.douleur || 0, heure: s.heure || "", praticien: s.praticien || "" };
          seancesIds[s.date_seance] = s.id;
        });
        dessinerCalendrier();
        dessinerGraphique();
      });
  }

  /* ---------------- Événements ---------------- */
  document.getElementById("calPrev").addEventListener("click", function () {
    vue.setMonth(vue.getMonth() - 1); dessinerCalendrier();
  });
  document.getElementById("calNext").addEventListener("click", function () {
    vue.setMonth(vue.getMonth() + 1); dessinerCalendrier();
  });
  document.getElementById("fDouleur").addEventListener("input", function (e) {
    majEva(parseInt(e.target.value, 10));
  });
  document.getElementById("modFermer").addEventListener("click", fermerModale);
  overlay.addEventListener("click", function (e) { if (e.target === overlay) fermerModale(); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && overlay.classList.contains("ouvert")) fermerModale();
  });

  document.getElementById("modSupprimer").addEventListener("click", function () {
    if (!confirm("Supprimer cette séance ?")) return;
    var key = this.dataset.key;
    var sid = seancesIds[key];
    if (!sid) { fermerModale(); return; }
    var f = document.createElement("form");
    f.method = "post";
    f.action = window.SUPPR_BASE.replace(/\/0\/supprimer$/, "/" + sid + "/supprimer");
    document.body.appendChild(f);
    f.submit();
  });

  // Bouton « Modifier » dans la liste des séances
  Array.prototype.forEach.call(document.querySelectorAll(".js-edit"), function (b) {
    b.addEventListener("click", function () {
      ouvrirModale(b.dataset.date);
    });
  });

  // Reformulation IA du champ « ce qui a été fait »
  var reformBtn = document.getElementById("reformBtn");
  if (reformBtn) {
    var reformUndo = document.getElementById("reformUndo");
    var reformStatus = document.getElementById("reformStatus");
    var avantReform = "";
    window.__resetReform = function () {
      reformUndo.style.display = "none";
      reformStatus.textContent = "";
      reformStatus.className = "reform-status";
      avantReform = "";
    };
    reformBtn.addEventListener("click", function () {
      var f = document.getElementById("fFait");
      var t = f.value.trim();
      if (!window.AUDIO_DISPO) {
        reformStatus.className = "reform-status err";
        reformStatus.textContent = "Module IA non installé. Relancez : bash installer.sh --avec-audio";
        return;
      }
      if (!t) { reformStatus.className = "reform-status"; reformStatus.textContent = "Rien à reformuler."; return; }
      reformBtn.disabled = true;
      reformStatus.className = "reform-status";
      reformStatus.innerHTML = '<span class="spin"></span> Reformulation en local…';
      var fd = new FormData();
      fd.append("texte", t);
      fetch(window.REFORM_URL, { method: "POST", body: fd })
        .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
        .then(function (res) {
          reformBtn.disabled = false;
          if (!res.ok) throw new Error(res.d.erreur || "Erreur.");
          if (res.d.moteur === "indisponible") {
            reformStatus.className = "reform-status err";
            reformStatus.textContent = "Modèle injoignable (Ollama éteint) : texte inchangé.";
            return;
          }
          avantReform = t;
          f.value = res.d.texte || t;
          reformUndo.style.display = "";
          reformStatus.className = "reform-status";
          reformStatus.textContent = "Reformulé. Relisez avant d'enregistrer.";
        })
        .catch(function (e) {
          reformBtn.disabled = false;
          reformStatus.className = "reform-status err";
          reformStatus.textContent = "Échec : " + e.message;
        });
    });
    reformUndo.addEventListener("click", function () {
      if (!avantReform) return;
      document.getElementById("fFait").value = avantReform;
      reformUndo.style.display = "none";
      reformStatus.className = "reform-status";
      reformStatus.textContent = "Texte d'origine rétabli.";
    });
  }

  charger();
})();

/* ===================== Bilan oral ===================== */
(function () {
  "use strict";
  var recBtn = document.getElementById("recBtn");
  if (!recBtn) return; // module audio non installé

  var meter = document.getElementById("meter");
  var bars = Array.prototype.slice.call(meter.querySelectorAll(".bar"));
  var timerEl = document.getElementById("timer");
  var recHint = document.getElementById("recHint");
  var statusEl = document.getElementById("bilanStatus");
  var resEl = document.getElementById("bilanRes");
  var resumeEl = document.getElementById("bilanResume");
  var brutEl = document.getElementById("bilanBrut");
  var moteurTag = document.getElementById("moteurTag");
  var btnSeance = document.getElementById("bilanSeance");
  var btnNote = document.getElementById("bilanNote");
  var dateEl = document.getElementById("bilanDate");
  var dateInfo = document.getElementById("dateInfo");

  var mediaRecorder = null, chunks = [], stream = null;
  var audioCtx = null, analyser = null, rafId = null;
  var startTime = 0, timerInt = null, douleurDetectee = 0;

  function fmt(sec) {
    var m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m + ":" + String(s).padStart(2, "0");
  }
  function setStatus(html, err) {
    statusEl.className = "status" + (err ? " err" : "");
    statusEl.innerHTML = html;
  }
  function startMeter() {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    var src = audioCtx.createMediaStreamSource(stream);
    analyser = audioCtx.createAnalyser();
    analyser.fftSize = 64;
    src.connect(analyser);
    var data = new Uint8Array(analyser.frequencyBinCount);
    meter.classList.add("live");
    (function loop() {
      analyser.getByteFrequencyData(data);
      bars.forEach(function (bar, i) {
        var v = data[i * 2] || 0;
        bar.style.height = (6 + (v / 255) * 34).toFixed(0) + "px";
      });
      rafId = requestAnimationFrame(loop);
    })();
  }
  function stopMeter() {
    if (rafId) cancelAnimationFrame(rafId);
    if (audioCtx) audioCtx.close();
    meter.classList.remove("live");
    bars.forEach(function (b) { b.style.height = "6px"; });
  }

  function start() {
    navigator.mediaDevices.getUserMedia({ audio: true }).then(function (s) {
      stream = s;
      chunks = [];
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.ondataavailable = function (e) { if (e.data.size) chunks.push(e.data); };
      mediaRecorder.onstop = function () {
        var blob = new Blob(chunks, { type: mediaRecorder.mimeType || "audio/webm" });
        envoyer(blob);
      };
      mediaRecorder.start();
      recBtn.classList.add("live");
      timerEl.classList.add("live");
      recHint.textContent = "Dictée en cours… Re-cliquez pour arrêter.";
      startTime = Date.now();
      timerEl.textContent = "0:00";
      timerInt = setInterval(function () {
        timerEl.textContent = fmt((Date.now() - startTime) / 1000);
      }, 250);
      startMeter();
    }).catch(function () {
      setStatus("Accès au micro refusé. Autorisez le micro pour cette page.", true);
    });
  }
  function stop() {
    if (mediaRecorder && mediaRecorder.state !== "inactive") mediaRecorder.stop();
    if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
    clearInterval(timerInt);
    stopMeter();
    recBtn.classList.remove("live");
    timerEl.classList.remove("live");
    recHint.textContent = "Cliquez pour dicter. Re-cliquez pour arrêter et lancer la transcription.";
  }
  recBtn.addEventListener("click", function () {
    if (recBtn.classList.contains("live")) stop(); else start();
  });

  function envoyer(blob) {
    resEl.style.display = "none";
    setStatus('<span class="spin"></span> Transcription puis résumé en local… (calcul CPU, patientez)');
    var fd = new FormData();
    fd.append("audio", blob, "bilan.webm");
    fetch(window.BILAN_URL, { method: "POST", body: fd })
      .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error(res.d.erreur || "Erreur inconnue.");
        resumeEl.value = res.d.resume || "(résumé vide)";
        brutEl.textContent = res.d.transcription || "(rien transcrit)";
        douleurDetectee = res.d.douleur || 0;
        var moteur = res.d.moteur === "ollama" ? "résumé : IA locale (Ollama)" :
                     res.d.moteur === "règles" ? "résumé : mise en forme locale (Ollama injoignable)" : "";
        var dl = douleurDetectee ? " · douleur détectée : EVA " + douleurDetectee : "";
        moteurTag.textContent = moteur + dl;
        dateEl.value = window.AUJOURDHUI;
        dateEl.max = window.AUJOURDHUI;
        verifDate();
        resEl.style.display = "block";
        setStatus("Terminé. Choisissez la date puis insérez.");
      })
      .catch(function (e) { setStatus("Échec : " + e.message, true); });
  }

  function soumettre(action, champs) {
    var f = document.createElement("form");
    f.method = "post";
    f.action = action;
    Object.keys(champs).forEach(function (k) {
      var i = document.createElement("input");
      i.type = "hidden"; i.name = k; i.value = champs[k];
      f.appendChild(i);
    });
    document.body.appendChild(f);
    f.submit();
  }

  function verifDate() {
    dateInfo.textContent = "";
    var d = dateEl.value;
    if (!d) return;
    fetch(window.SEANCES_URL)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var existe = data.filter(function (s) { return s.date_seance === d; })[0];
        if (existe) {
          dateInfo.textContent = "Une séance existe déjà ce jour-là : son contenu sera remplacé.";
        } else if (d !== window.AUJOURDHUI) {
          dateInfo.textContent = "Séance antérieure : le résumé sera enregistré à cette date.";
        }
      })
      .catch(function () {});
  }
  dateEl.addEventListener("change", verifDate);

  btnSeance.addEventListener("click", function () {
    if (!resumeEl.value.trim()) return;
    soumettre(window.SEANCE_URL, {
      date_seance: dateEl.value || window.AUJOURDHUI,
      fait: resumeEl.value.trim(),
      douleur: douleurDetectee || 0,
    });
  });

  btnNote.addEventListener("click", function () {
    if (!resumeEl.value.trim()) return;
    var noteEl = document.querySelector('textarea[name="note_libre"]');
    var ancienne = noteEl ? noteEl.value.trim() : "";
    var ajout = "[" + (dateEl.value || window.AUJOURDHUI) + "] " + resumeEl.value.trim();
    soumettre(window.NOTE_URL, {
      note_libre: ancienne ? (ancienne + "\n" + ajout) : ajout,
    });
  });
})();
