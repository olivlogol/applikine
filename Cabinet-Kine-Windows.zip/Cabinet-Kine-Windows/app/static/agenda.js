/* Calendrier général : vues Jour, Semaine et Mois.
   - Jour : grille de créneaux de 30 min ; on assigne un patient à un créneau.
   - Semaine : 7 colonnes listant tous les patients de chaque jour.
   - Mois : grille classique (jusqu'à 3 noms + N…).
   Clic sur un patient -> sa fiche. */
(function () {
  "use strict";

  var MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
              "août", "septembre", "octobre", "novembre", "décembre"];
  var JOURS = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
  var JOURS_LONG = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"];
  var H_DEBUT = 7, H_FIN = 20;   // créneaux de 7:00 à 19:30

  var agenda = {};            // "AAAA-MM-JJ" -> [ {patient_id, prenom, nom, douleur, heure, archive} ]
  var patients = [];          // [{id, prenom, nom}]
  var mode = "mois";          // "jour" | "semaine" | "mois"
  var ancre = new Date();
  var selection = null;

  var grille = document.getElementById("calGrille");
  var moisLabel = document.getElementById("calMois");
  var overlay = document.getElementById("jourOverlay");
  var jourTitre = document.getElementById("jourTitre");
  var jourSous = document.getElementById("jourSous");
  var jourListe = document.getElementById("jourListe");
  var btnJour = document.getElementById("vueJour");
  var btnSemaine = document.getElementById("vueSemaine");
  var btnMois = document.getElementById("vueMois");

  // Fenêtre d'ajout de créneau
  var crOverlay = document.getElementById("creneauOverlay");
  var crQuand = document.getElementById("creneauQuand");
  var crSelect = document.getElementById("creneauPatient");
  var crPrat = document.getElementById("creneauPraticien");
  var crDateHeure = { date: null, heure: null };

  function iso(d) {
    return d.getFullYear() + "-" +
           String(d.getMonth() + 1).padStart(2, "0") + "-" +
           String(d.getDate()).padStart(2, "0");
  }
  function getCss(v) {
    return getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  }
  function couleur(n) {
    if (!n) return getCss("--muted");
    if (n <= 3) return getCss("--ok");
    if (n <= 6) return getCss("--warn");
    return getCss("--danger");
  }
  function couleurPrat(nom) {
    return (window.PRAT_COULEURS || {})[nom] || "#8A93A6";
  }
  function jolie(key) {
    var p = key.split("-");
    return p[2] + " " + MOIS[parseInt(p[1], 10) - 1] + " " + p[0];
  }
  function urlPatient(id) { return window.PATIENT_BASE.replace(/\/0$/, "/" + id); }
  function lundi(d) {
    var x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    x.setDate(x.getDate() - ((x.getDay() + 6) % 7));
    return x;
  }
  function ligneNom(it) {
    var dot = document.createElement("span");
    dot.className = "nm-dot";
    dot.style.background = couleurPrat(it.praticien);
    var txt = document.createElement("span");
    txt.className = "nom-txt";
    txt.textContent = it.nom + " " + it.prenom;
    return [dot, txt];
  }

  /* ---------------- Vue jour ---------------- */
  function dessinerJour() {
    grille.className = "jour-vue";
    grille.innerHTML = "";
    var key = iso(ancre);
    var items = agenda[key] || [];
    var parHeure = {};
    var sansHeure = [];
    items.forEach(function (it) {
      if (it.heure) (parHeure[it.heure] = parHeure[it.heure] || []).push(it);
      else sansHeure.push(it);
    });

    if (sansHeure.length) {
      var bloc = document.createElement("div");
      bloc.className = "jour-sans";
      var t = document.createElement("div");
      t.className = "jour-sans-tete";
      t.textContent = "Sans horaire";
      bloc.appendChild(t);
      var corps = document.createElement("div");
      corps.className = "creneau-corps";
      sansHeure.forEach(function (it) { corps.appendChild(chipPatient(it)); });
      bloc.appendChild(corps);
      grille.appendChild(bloc);
    }

    for (var min = H_DEBUT * 60; min < H_FIN * 60; min += 30) {
      var hh = String(Math.floor(min / 60)).padStart(2, "0");
      var mm = String(min % 60).padStart(2, "0");
      var slot = hh + ":" + mm;
      var rang = document.createElement("div");
      rang.className = "creneau";
      var lab = document.createElement("div");
      lab.className = "creneau-h";
      lab.textContent = slot;
      rang.appendChild(lab);
      var corps2 = document.createElement("div");
      corps2.className = "creneau-corps";
      (parHeure[slot] || []).forEach(function (it) { corps2.appendChild(chipPatient(it)); });
      var add = document.createElement("button");
      add.type = "button";
      add.className = "creneau-add";
      add.textContent = "+";
      add.title = "Ajouter un patient à " + slot;
      (function (s) {
        add.addEventListener("click", function () { ouvrirCreneau(key, s); });
      })(slot);
      corps2.appendChild(add);
      rang.appendChild(corps2);
      grille.appendChild(rang);
    }
  }

  function chipPatient(it) {
    var a = document.createElement("a");
    a.className = "creneau-pat";
    a.href = urlPatient(it.patient_id);
    ligneNom(it).forEach(function (e) { a.appendChild(e); });
    if (it.praticien) {
      var b = document.createElement("span");
      b.className = "chip-prat";
      b.textContent = it.praticien;
      b.style.background = couleurPrat(it.praticien);
      a.appendChild(b);
    }
    return a;
  }

  /* ---------------- Vue mois ---------------- */
  function dessinerMois() {
    grille.className = "cal-grille agenda-grille";
    grille.innerHTML = "";
    JOURS.forEach(function (j) {
      var c = document.createElement("div");
      c.className = "cal-jour-nom";
      c.textContent = j;
      grille.appendChild(c);
    });
    var an = ancre.getFullYear(), mo = ancre.getMonth();
    var premier = new Date(an, mo, 1);
    var decalage = (premier.getDay() + 6) % 7;
    var nbJours = new Date(an, mo + 1, 0).getDate();
    var ajd = iso(new Date());
    for (var i = 0; i < decalage; i++) {
      var v = document.createElement("div");
      v.className = "cal-case vide-case";
      grille.appendChild(v);
    }
    for (var jour = 1; jour <= nbJours; jour++) {
      var key = iso(new Date(an, mo, jour));
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cal-case" + (key === ajd ? " ajd" : "") +
                      (key === selection ? " sel" : "");
      var numero = document.createElement("span");
      numero.className = "cal-jour-num";
      numero.textContent = jour;
      btn.appendChild(numero);
      var items = agenda[key];
      if (items && items.length) {
        var noms = document.createElement("div");
        noms.className = "cal-noms";
        var MAX = 3;
        items.slice(0, MAX).forEach(function (it) {
          var l = document.createElement("span");
          l.className = "nom-mini";
          ligneNom(it).forEach(function (e) { l.appendChild(e); });
          noms.appendChild(l);
        });
        if (items.length > MAX) {
          var plus = document.createElement("span");
          plus.className = "nom-plus";
          plus.textContent = "+" + (items.length - MAX) + "…";
          noms.appendChild(plus);
        }
        btn.appendChild(noms);
      }
      (function (k) {
        btn.addEventListener("click", function () { ouvrirJour(k); });
      })(key);
      grille.appendChild(btn);
    }
  }

  /* ---------------- Vue semaine ---------------- */
  function dessinerSemaine() {
    grille.className = "cal-grille semaine-grille";
    grille.innerHTML = "";
    var debut = lundi(ancre);
    var ajd = iso(new Date());
    for (var i = 0; i < 7; i++) {
      var d = new Date(debut);
      d.setDate(debut.getDate() + i);
      var key = iso(d);
      var col = document.createElement("div");
      col.className = "sem-col" + (key === ajd ? " ajd" : "");
      var tete = document.createElement("button");
      tete.type = "button";
      tete.className = "sem-tete";
      var jn = document.createElement("span"); jn.className = "sem-jour"; jn.textContent = JOURS[i];
      var nm = document.createElement("span"); nm.className = "sem-num"; nm.textContent = d.getDate();
      tete.appendChild(jn); tete.appendChild(nm);
      (function (k) { tete.addEventListener("click", function () { ouvrirJour(k); }); })(key);
      col.appendChild(tete);
      var liste = document.createElement("div");
      liste.className = "sem-liste";
      var items = agenda[key] || [];
      if (!items.length) {
        var vide = document.createElement("div");
        vide.className = "sem-vide"; vide.textContent = "—";
        liste.appendChild(vide);
      } else {
        items.forEach(function (it) {
          var a = document.createElement("a");
          a.className = "sem-item";
          a.href = urlPatient(it.patient_id);
          if (it.heure) {
            var h = document.createElement("span");
            h.className = "sem-h"; h.textContent = it.heure;
            a.appendChild(h);
          }
          ligneNom(it).forEach(function (e) { a.appendChild(e); });
          liste.appendChild(a);
        });
      }
      col.appendChild(liste);
      grille.appendChild(col);
    }
  }

  function majLabel() {
    if (mode === "mois") {
      moisLabel.textContent = MOIS[ancre.getMonth()] + " " + ancre.getFullYear();
    } else if (mode === "semaine") {
      var d = lundi(ancre), f = new Date(d); f.setDate(d.getDate() + 6);
      if (d.getMonth() === f.getMonth()) {
        moisLabel.textContent = d.getDate() + " – " + f.getDate() + " " + MOIS[d.getMonth()] + " " + d.getFullYear();
      } else {
        moisLabel.textContent = d.getDate() + " " + MOIS[d.getMonth()] + " – " + f.getDate() + " " + MOIS[f.getMonth()] + " " + f.getFullYear();
      }
    } else {
      var jl = JOURS_LONG[(ancre.getDay() + 6) % 7];
      moisLabel.textContent = jl.charAt(0).toUpperCase() + jl.slice(1) + " " +
                              ancre.getDate() + " " + MOIS[ancre.getMonth()] + " " + ancre.getFullYear();
    }
  }

  function dessiner() {
    if (mode === "mois") dessinerMois();
    else if (mode === "semaine") dessinerSemaine();
    else dessinerJour();
    majLabel();
    btnJour.classList.toggle("actif", mode === "jour");
    btnSemaine.classList.toggle("actif", mode === "semaine");
    btnMois.classList.toggle("actif", mode === "mois");
  }

  /* ---------------- Fenêtre du jour (liste) ---------------- */
  function ouvrirJour(key) {
    selection = key;
    if (mode === "mois") dessiner();
    var items = agenda[key] || [];
    jourTitre.textContent = "Séances du " + jolie(key);
    jourSous.textContent = items.length ? (items.length + " patient" + (items.length > 1 ? "s" : "")) : "";
    jourListe.innerHTML = "";
    if (!items.length) {
      var vide = document.createElement("div");
      vide.className = "vide"; vide.style.padding = "26px";
      vide.textContent = "Aucune séance ce jour-là.";
      jourListe.appendChild(vide);
    } else {
      items.forEach(function (it) {
        var a = document.createElement("a");
        a.className = "agenda-item";
        a.href = urlPatient(it.patient_id);
        var gauche = document.createElement("div"); gauche.style.minWidth = "0";
        var who = document.createElement("div"); who.className = "who";
        who.textContent = (it.heure ? it.heure + " · " : "") + it.nom + " " + it.prenom + (it.archive ? "  · archivé" : "");
        gauche.appendChild(who);
        if (it.fait) {
          var ex = document.createElement("div"); ex.className = "extrait";
          var t = it.fait.replace(/\s+/g, " ").trim();
          ex.textContent = t.length > 90 ? t.slice(0, 90) + "…" : t;
          gauche.appendChild(ex);
        }
        a.appendChild(gauche);
        if (it.praticien) {
          var past = document.createElement("span"); past.className = "pastille";
          var pip = document.createElement("span"); pip.className = "pip"; pip.style.background = couleurPrat(it.praticien);
          past.appendChild(pip); past.appendChild(document.createTextNode(it.praticien));
          a.appendChild(past);
        }
        jourListe.appendChild(a);
      });
    }
    overlay.classList.add("ouvert");
  }
  function fermerJour() { overlay.classList.remove("ouvert"); }

  /* ---------------- Ajout de créneau ---------------- */
  function ouvrirCreneau(date, heure) {
    crDateHeure = { date: date, heure: heure };
    crQuand.textContent = jolie(date) + " à " + heure;
    crSelect.innerHTML = "";
    if (!patients.length) {
      var o = document.createElement("option");
      o.textContent = "Aucun patient actif"; o.disabled = true;
      crSelect.appendChild(o);
    } else {
      patients.forEach(function (p) {
        var o = document.createElement("option");
        o.value = p.id; o.textContent = p.nom + " " + p.prenom;
        crSelect.appendChild(o);
      });
    }
    crOverlay.classList.add("ouvert");
  }
  function fermerCreneau() { crOverlay.classList.remove("ouvert"); }

  function ajouterCreneau() {
    var pid = crSelect.value;
    if (!pid) { fermerCreneau(); return; }
    var fd = new FormData();
    fd.append("date", crDateHeure.date);
    fd.append("heure", crDateHeure.heure);
    fd.append("praticien", crPrat ? crPrat.value : "");
    fetch(window.CRENEAU_BASE.replace(/\/0\/creneau$/, "/" + pid + "/creneau"),
          { method: "POST", body: fd })
      .then(function () { return charger(); })
      .then(function () { fermerCreneau(); dessiner(); })
      .catch(function () { fermerCreneau(); });
  }

  /* ---------------- Données ---------------- */
  function charger() {
    return fetch(window.AGENDA_URL)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        agenda = {};
        data.forEach(function (s) {
          (agenda[s.date_seance] = agenda[s.date_seance] || []).push(s);
        });
      });
  }

  /* ---------------- Navigation & événements ---------------- */
  document.getElementById("calPrev").addEventListener("click", function () {
    if (mode === "mois") ancre.setMonth(ancre.getMonth() - 1);
    else if (mode === "semaine") ancre.setDate(ancre.getDate() - 7);
    else ancre.setDate(ancre.getDate() - 1);
    dessiner();
  });
  document.getElementById("calNext").addEventListener("click", function () {
    if (mode === "mois") ancre.setMonth(ancre.getMonth() + 1);
    else if (mode === "semaine") ancre.setDate(ancre.getDate() + 7);
    else ancre.setDate(ancre.getDate() + 1);
    dessiner();
  });
  btnJour.addEventListener("click", function () { mode = "jour"; dessiner(); });
  btnSemaine.addEventListener("click", function () { mode = "semaine"; dessiner(); });
  btnMois.addEventListener("click", function () { mode = "mois"; dessiner(); });

  document.getElementById("jourFermer").addEventListener("click", fermerJour);
  overlay.addEventListener("click", function (e) { if (e.target === overlay) fermerJour(); });
  document.getElementById("creneauAnnuler").addEventListener("click", fermerCreneau);
  document.getElementById("creneauOk").addEventListener("click", ajouterCreneau);
  crOverlay.addEventListener("click", function (e) { if (e.target === crOverlay) fermerCreneau(); });
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    if (overlay.classList.contains("ouvert")) fermerJour();
    if (crOverlay.classList.contains("ouvert")) fermerCreneau();
  });

  function construireLegende() {
    var el = document.getElementById("calLegende");
    if (!el) return;
    el.innerHTML = "";
    (window.PRATICIENS || []).forEach(function (nom) {
      var s = document.createElement("span");
      var dot = document.createElement("span");
      dot.className = "lg";
      dot.style.background = couleurPrat(nom);
      s.appendChild(dot);
      s.appendChild(document.createTextNode(" " + nom));
      el.appendChild(s);
    });
  }
  function remplirPraticiens() {
    if (!crPrat) return;
    crPrat.innerHTML = "";
    (window.PRATICIENS || []).forEach(function (nom) {
      var o = document.createElement("option");
      o.value = nom; o.textContent = nom;
      crPrat.appendChild(o);
    });
  }
  construireLegende();
  remplirPraticiens();

  Promise.all([
    charger(),
    fetch(window.PATIENTS_URL).then(function (r) { return r.json(); })
      .then(function (d) { patients = d; }).catch(function () { patients = []; })
  ]).then(function () { dessiner(); })
    .catch(function () {
      grille.innerHTML = '<div class="vide" style="padding:30px;">Impossible de charger l\'agenda.</div>';
    });
})();
