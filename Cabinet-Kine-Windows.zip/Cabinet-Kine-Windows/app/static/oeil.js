// Ajoute un bouton « oeil » a chaque champ mot de passe pour l'afficher/masquer.
(function () {
  var OUVERT = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>';
  var BARRE = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l18 18"/><path d="M10.6 5.1A10.8 10.8 0 0 1 12 5c6.5 0 10 7 10 7a13.2 13.2 0 0 1-2.2 3M6.6 6.6A13.3 13.3 0 0 0 2 12s3.5 7 10 7a10.6 10.6 0 0 0 3.5-.6"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';

  function equiper(inp) {
    if (inp.dataset.oeil) return;          // deja equipe
    inp.dataset.oeil = "1";

    var wrap = document.createElement("span");
    wrap.className = "champ-mdp";
    inp.parentNode.insertBefore(wrap, inp);
    wrap.appendChild(inp);

    var btn = document.createElement("button");
    btn.type = "button";                    // ne soumet pas le formulaire
    btn.className = "oeil-mdp";
    btn.tabIndex = -1;                       // ne gene pas la tabulation
    btn.setAttribute("aria-label", "Afficher le mot de passe");
    btn.innerHTML = OUVERT;
    wrap.appendChild(btn);

    btn.addEventListener("click", function () {
      var montrer = inp.type === "password";
      inp.type = montrer ? "text" : "password";
      btn.innerHTML = montrer ? BARRE : OUVERT;
      btn.setAttribute("aria-label", montrer ? "Masquer le mot de passe" : "Afficher le mot de passe");
      inp.focus();
    });
  }

  function init() {
    var champs = document.querySelectorAll('input[type="password"]');
    for (var i = 0; i < champs.length; i++) equiper(champs[i]);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
