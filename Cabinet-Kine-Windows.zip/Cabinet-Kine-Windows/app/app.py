#!/usr/bin/env python3
"""Cabinet kiné — socle de gestion (espace kiné uniquement).

Application web LOCALE pour un cabinet de kinésithérapie :
  - dossiers patients (pathologie, objectifs court/long terme, note libre),
  - calendrier par patient avec annotation des séances,
  - niveau de douleur (EVA 1-10) par séance + graphique d'évolution.

Tout reste sur la machine : base SQLite locale, aucun envoi en ligne.
Sert une interface sur http://127.0.0.1:5001
"""
import os
import io
import sqlite3
import secrets
import tempfile
import random
import calendar
import re
import socket
from datetime import datetime, date, timedelta, timezone
from functools import wraps

from flask import (
    Flask, request, session, redirect, url_for,
    render_template, jsonify, abort, flash, g, send_file,
)
from werkzeug.security import generate_password_hash as _gen_hash, check_password_hash


def generate_password_hash(secret):
    """Hachage portable. pbkdf2 plutôt que scrypt : certains Python de macOS
    n'ont pas hashlib.scrypt (compilés sans le scrypt d'OpenSSL)."""
    return _gen_hash(secret, method="pbkdf2:sha256")

ICI = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ICI, "cabinet.db")
SECRET_FILE = os.path.join(ICI, ".secret")

import sync  # moteur de synchronisation multi-postes
import reseau  # decouverte des postes sur le reseau local

# Le module de transcription vocale est optionnel (installé séparément).
try:
    import transcription
    import resume
    AUDIO_DISPO = True
except Exception:
    AUDIO_DISPO = False


def cle_secrete():
    """Clé de session persistante (pour rester connecté entre redémarrages)."""
    if os.path.exists(SECRET_FILE):
        with open(SECRET_FILE) as f:
            return f.read().strip()
    cle = secrets.token_hex(32)
    with open(SECRET_FILE, "w") as f:
        f.write(cle)
    os.chmod(SECRET_FILE, 0o600)
    return cle


app = Flask(__name__)
app.secret_key = cle_secrete()


# --------------------------------------------------------------------------
#  Base de données
# --------------------------------------------------------------------------
def co():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
        g.db.execute("PRAGMA busy_timeout = 8000")
    return g.db


@app.teardown_appcontext
def fermer_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


ADMIN_DEFAUT_ID = "admin"
ADMIN_DEFAUT_MDP = "admin"
QUESTION_DEFAUT = "Quelle est la marque de ma première voiture ?"
REPONSE_DEFAUT = "citroen"


def init_db():
    db = sqlite3.connect(DB)
    try:
        db.execute("PRAGMA journal_mode=WAL")
    except sqlite3.Error:
        pass
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS kine (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            identifiant TEXT UNIQUE NOT NULL,
            mdp_hash    TEXT NOT NULL,
            cree_le     TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS patients (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            prenom          TEXT NOT NULL,
            nom             TEXT NOT NULL,
            naissance       TEXT,
            pathologie      TEXT,
            objectif_court  TEXT,
            objectif_long   TEXT,
            note_libre      TEXT,
            archive         INTEGER NOT NULL DEFAULT 0,
            cree_le         TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS seances (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id  INTEGER NOT NULL,
            date_seance TEXT NOT NULL,
            heure       TEXT,
            fait        TEXT,
            douleur     INTEGER,
            cree_le     TEXT NOT NULL,
            UNIQUE(patient_id, date_seance),
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS praticiens (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            nom     TEXT UNIQUE NOT NULL,
            cree_le TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS config (
            cle    TEXT PRIMARY KEY,
            valeur TEXT
        );
        """
    )
    db.commit()
    # Migration : marqueur des patients de démonstration
    cols = [r[1] for r in db.execute("PRAGMA table_info(patients)").fetchall()]
    if "demo" not in cols:
        db.execute("ALTER TABLE patients ADD COLUMN demo INTEGER NOT NULL DEFAULT 0")
        db.commit()
    # Migration : heure des séances (créneaux)
    cols_s = [r[1] for r in db.execute("PRAGMA table_info(seances)").fetchall()]
    if "heure" not in cols_s:
        db.execute("ALTER TABLE seances ADD COLUMN heure TEXT")
        db.commit()
    if "praticien" not in cols_s:
        db.execute("ALTER TABLE seances ADD COLUMN praticien TEXT")
        db.commit()
    # Migration : rôle des comptes
    cols_k = [r[1] for r in db.execute("PRAGMA table_info(kine)").fetchall()]
    if "role" not in cols_k:
        db.execute("ALTER TABLE kine ADD COLUMN role TEXT NOT NULL DEFAULT 'praticien'")
        db.commit()
    if "question" not in cols_k:
        db.execute("ALTER TABLE kine ADD COLUMN question TEXT")
        db.commit()
    if "reponse_hash" not in cols_k:
        db.execute("ALTER TABLE kine ADD COLUMN reponse_hash TEXT")
        db.commit()
    # Compte administrateur par défaut : garanti tant que son mot de passe
    # est encore celui par défaut (sinon on respecte le mot de passe choisi).
    rep_def = generate_password_hash(REPONSE_DEFAUT.strip().upper())
    admin = db.execute(
        "SELECT mdp_hash FROM kine WHERE identifiant = ?", (ADMIN_DEFAUT_ID,)
    ).fetchone()
    if admin is None:
        db.execute(
            "INSERT INTO kine (identifiant, mdp_hash, role, question, reponse_hash, cree_le) "
            "VALUES (?,?,?,?,?,?)",
            (ADMIN_DEFAUT_ID, generate_password_hash(ADMIN_DEFAUT_MDP), "admin",
             QUESTION_DEFAUT, rep_def, datetime.now().isoformat(timespec="seconds")),
        )
        db.commit()
    elif check_password_hash(admin[0], ADMIN_DEFAUT_MDP):
        db.execute(
            "UPDATE kine SET role = 'admin', question = ?, reponse_hash = ? "
            "WHERE identifiant = ?",
            (QUESTION_DEFAUT, rep_def, ADMIN_DEFAUT_ID),
        )
        db.commit()
    # Un seul administrateur : tout autre compte est un praticien
    db.execute(
        "UPDATE kine SET role = 'praticien' WHERE identifiant <> ? AND role = 'admin'",
        (ADMIN_DEFAUT_ID,),
    )
    db.commit()
    try:
        sync.assurer_schema(db)
    except Exception as _e:
        print("  (synchro : initialisation differee : %s)" % _e)
    db.close()


def normaliser_heure(v):
    """Renvoie 'HH:00' ou 'HH:30' (créneaux de 30 min), ou None."""
    v = (v or "").strip()
    if not v:
        return None
    try:
        parts = v.split(":")
        h, m = int(parts[0]), int(parts[1])
        if 0 <= h <= 23:
            return "%02d:%02d" % (h, 0 if m < 30 else 30)
    except (ValueError, IndexError):
        pass
    return None


PALETTE_PRAT = ["#5A4FE3", "#1F9D6B", "#E0A100", "#2563EB", "#D6409F",
                "#0E8FA8", "#C2410C", "#7C3AED"]


def liste_praticiens():
    return [r["identifiant"] for r in co().execute(
        "SELECT identifiant FROM kine WHERE role = 'praticien' ORDER BY id"
    ).fetchall()]


def praticiens_couleurs():
    rows = co().execute(
        "SELECT id, identifiant FROM kine WHERE role = 'praticien' ORDER BY id"
    ).fetchall()
    return {r["identifiant"]: PALETTE_PRAT[(r["id"] - 1) % len(PALETTE_PRAT)] for r in rows}


def praticien_valide(v):
    v = (v or "").strip()
    return v if v in liste_praticiens() else None


# -- Administration (réservée au compte de rôle « admin ») --
def est_admin():
    return bool(session.get("est_admin"))


def _norm_reponse(v):
    return (v or "").strip().upper()


def admin_requise(vue):
    @wraps(vue)
    def wrap(*a, **kw):
        if not session.get("kine_id"):
            return redirect(url_for("connexion"))
        if not est_admin():
            flash("Cette section est réservée à l'administrateur.")
            return redirect(url_for("dashboard"))
        return vue(*a, **kw)
    return wrap


def maintenant():
    return datetime.now().isoformat(timespec="seconds")


# --------------------------------------------------------------------------
#  Authentification
# --------------------------------------------------------------------------
def compte_existe():
    return co().execute("SELECT 1 FROM kine LIMIT 1").fetchone() is not None


def connexion_requise(vue):
    @wraps(vue)
    def wrap(*a, **kw):
        if not session.get("kine_id"):
            return redirect(url_for("connexion"))
        return vue(*a, **kw)
    return wrap


@app.route("/")
def accueil():
    if not compte_existe():
        return redirect(url_for("setup"))
    if not session.get("kine_id"):
        return redirect(url_for("connexion"))
    return redirect(url_for("dashboard"))


@app.route("/bienvenue", methods=["GET", "POST"])
def setup():
    """Création du premier (et unique) compte kiné. Pas de mot de passe par défaut."""
    if compte_existe():
        return redirect(url_for("connexion"))
    if request.method == "POST":
        ident = (request.form.get("identifiant") or "").strip()
        mdp = request.form.get("mdp") or ""
        mdp2 = request.form.get("mdp2") or ""
        question = (request.form.get("question") or "").strip()
        reponse = (request.form.get("reponse") or "").strip()
        if len(ident) < 3:
            flash("L'identifiant doit faire au moins 3 caractères.")
        elif len(mdp) < 6:
            flash("Le mot de passe doit faire au moins 6 caractères.")
        elif mdp != mdp2:
            flash("Les deux mots de passe ne correspondent pas.")
        elif not question or not reponse:
            flash("Veuillez renseigner la question de sécurité et sa réponse.")
        else:
            co().execute(
                "INSERT INTO kine (identifiant, mdp_hash, role, question, reponse_hash, cree_le) "
                "VALUES (?,?,?,?,?,?)",
                (ident, generate_password_hash(mdp), "admin", question,
                 generate_password_hash(_norm_reponse(reponse)), maintenant()),
            )
            co().commit()
            ligne = co().execute(
                "SELECT id FROM kine WHERE identifiant = ?", (ident,)
            ).fetchone()
            session["kine_id"] = ligne["id"]
            session["est_admin"] = True
            return redirect(url_for("dashboard"))
    return render_template("setup.html")


@app.route("/connexion", methods=["GET", "POST"])
def connexion():
    if not compte_existe():
        return redirect(url_for("setup"))
    if request.method == "POST":
        ident = (request.form.get("identifiant") or "").strip()
        mdp = request.form.get("mdp") or ""
        ligne = co().execute(
            "SELECT * FROM kine WHERE identifiant = ?", (ident,)
        ).fetchone()
        if ligne and check_password_hash(ligne["mdp_hash"], mdp):
            session["kine_id"] = ligne["id"]
            session["est_admin"] = (ligne["role"] == "admin")
            return redirect(url_for("dashboard"))
        flash("Identifiant ou mot de passe incorrect.")
    return render_template("connexion.html")


@app.route("/deconnexion")
def deconnexion():
    session.clear()
    return redirect(url_for("connexion"))


@app.route("/mot-de-passe-oublie", methods=["GET", "POST"])
def mdp_oublie():
    if not compte_existe():
        return redirect(url_for("setup"))
    if request.method == "POST":
        ident = (request.form.get("identifiant") or "").strip()
        compte = co().execute(
            "SELECT * FROM kine WHERE identifiant = ?", (ident,)
        ).fetchone()
        if not compte or not compte["question"] or not compte["reponse_hash"]:
            flash("Aucune question de sécurité n'est configurée pour cet identifiant.")
            return render_template("mdp_oublie.html", etape=1)
        # Étape 2 : la réponse et le nouveau mot de passe sont fournis
        if "reponse" in request.form:
            if not check_password_hash(compte["reponse_hash"],
                                       _norm_reponse(request.form.get("reponse"))):
                flash("Réponse incorrecte.")
            else:
                mdp = request.form.get("mdp") or ""
                mdp2 = request.form.get("mdp2") or ""
                if len(mdp) < 6:
                    flash("Le mot de passe doit faire au moins 6 caractères.")
                elif mdp != mdp2:
                    flash("Les deux mots de passe ne correspondent pas.")
                else:
                    co().execute("UPDATE kine SET mdp_hash = ? WHERE id = ?",
                                 (generate_password_hash(mdp), compte["id"]))
                    co().commit()
                    flash("Mot de passe réinitialisé. Vous pouvez vous connecter.")
                    return redirect(url_for("connexion"))
            return render_template("mdp_oublie.html", etape=2, identifiant=ident,
                                   question=compte["question"])
        # Étape 1 -> 2 : afficher la question de ce compte
        return render_template("mdp_oublie.html", etape=2, identifiant=ident,
                               question=compte["question"])
    return render_template("mdp_oublie.html", etape=1)


@app.route("/securite", methods=["GET", "POST"])
@connexion_requise
def securite():
    compte = co().execute(
        "SELECT * FROM kine WHERE id = ?", (session["kine_id"],)
    ).fetchone()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "mdp":
            ancien = request.form.get("ancien") or ""
            mdp = request.form.get("mdp") or ""
            mdp2 = request.form.get("mdp2") or ""
            if not check_password_hash(compte["mdp_hash"], ancien):
                flash("Mot de passe actuel incorrect.")
            elif len(mdp) < 6:
                flash("Le nouveau mot de passe doit faire au moins 6 caractères.")
            elif mdp != mdp2:
                flash("Les deux mots de passe ne correspondent pas.")
            else:
                co().execute("UPDATE kine SET mdp_hash = ? WHERE id = ?",
                             (generate_password_hash(mdp), compte["id"]))
                co().commit()
                flash("Mot de passe modifié.")
        elif action == "question":
            question = (request.form.get("question") or "").strip()
            reponse = (request.form.get("reponse") or "").strip()
            if not question or not reponse:
                flash("Question et réponse sont requises.")
            else:
                co().execute("UPDATE kine SET question = ?, reponse_hash = ? WHERE id = ?",
                             (question, generate_password_hash(_norm_reponse(reponse)),
                              compte["id"]))
                co().commit()
                flash("Question de sécurité enregistrée.")
        return redirect(url_for("securite"))
    return render_template("securite.html", compte=compte)


# --------------------------------------------------------------------------
#  Tableau de bord
# --------------------------------------------------------------------------
@app.route("/dashboard")
@connexion_requise
def dashboard():
    patients = co().execute(
        """
        SELECT p.*,
               (SELECT COUNT(*) FROM seances s WHERE s.patient_id = p.id) AS nb_seances,
               (SELECT MAX(date_seance) FROM seances s WHERE s.patient_id = p.id) AS derniere,
               (SELECT douleur FROM seances s WHERE s.patient_id = p.id
                  AND douleur IS NOT NULL ORDER BY date_seance DESC LIMIT 1) AS douleur_recente
        FROM patients p
        WHERE p.archive = 0
        ORDER BY p.nom COLLATE NOCASE, p.prenom COLLATE NOCASE
        """
    ).fetchall()
    nb_archives = co().execute(
        "SELECT COUNT(*) AS n FROM patients WHERE archive = 1"
    ).fetchone()["n"]
    return render_template("dashboard.html", patients=patients, nb_archives=nb_archives)


@app.route("/archives")
@connexion_requise
def archives():
    patients = co().execute(
        "SELECT * FROM patients WHERE archive = 1 ORDER BY nom COLLATE NOCASE"
    ).fetchall()
    return render_template("archives.html", patients=patients)


@app.route("/calendrier")
@connexion_requise
def calendrier():
    return render_template("calendrier.html")


@app.route("/agenda.json")
@connexion_requise
def agenda_json():
    lignes = co().execute(
        """SELECT s.date_seance, s.heure, s.douleur, s.fait, s.praticien,
                  p.id AS patient_id, p.prenom, p.nom, p.archive
           FROM seances s JOIN patients p ON p.id = s.patient_id
           ORDER BY s.date_seance, s.heure IS NULL, s.heure,
                    p.nom COLLATE NOCASE, p.prenom COLLATE NOCASE"""
    ).fetchall()
    return jsonify([dict(x) for x in lignes])


@app.route("/patients.json")
@connexion_requise
def patients_json():
    rows = co().execute(
        "SELECT id, prenom, nom FROM patients WHERE archive = 0 "
        "ORDER BY nom COLLATE NOCASE, prenom COLLATE NOCASE"
    ).fetchall()
    return jsonify([dict(r) for r in rows])


# --------------------------------------------------------------------------
#  Dossiers patients
# --------------------------------------------------------------------------
def get_patient(pid):
    p = co().execute("SELECT * FROM patients WHERE id = ?", (pid,)).fetchone()
    if p is None:
        abort(404)
    return p


@app.route("/patient/nouveau", methods=["GET", "POST"])
@connexion_requise
def patient_nouveau():
    if request.method == "POST":
        prenom = (request.form.get("prenom") or "").strip()
        nom = (request.form.get("nom") or "").strip()
        if not prenom or not nom:
            flash("Le prénom et le nom sont obligatoires.")
            return render_template("patient_form.html", patient=request.form, mode="nouveau")
        cur = co().execute(
            """INSERT INTO patients
               (prenom, nom, naissance, pathologie, objectif_court, objectif_long,
                note_libre, cree_le)
               VALUES (?,?,?,?,?,?,?,?)""",
            (
                prenom, nom,
                request.form.get("naissance") or None,
                request.form.get("pathologie") or None,
                request.form.get("objectif_court") or None,
                request.form.get("objectif_long") or None,
                request.form.get("note_libre") or None,
                maintenant(),
            ),
        )
        co().commit()
        return redirect(url_for("patient", pid=cur.lastrowid))
    return render_template("patient_form.html", patient={}, mode="nouveau")


@app.route("/patient/<int:pid>")
@connexion_requise
def patient(pid):
    p = get_patient(pid)
    seances = co().execute(
        "SELECT * FROM seances WHERE patient_id = ? ORDER BY date_seance DESC", (pid,)
    ).fetchall()
    return render_template("patient.html", p=p, seances=seances)


@app.route("/patient/<int:pid>/modifier", methods=["GET", "POST"])
@connexion_requise
def patient_modifier(pid):
    p = get_patient(pid)
    if request.method == "POST":
        prenom = (request.form.get("prenom") or "").strip()
        nom = (request.form.get("nom") or "").strip()
        if not prenom or not nom:
            flash("Le prénom et le nom sont obligatoires.")
            return render_template("patient_form.html", patient=request.form, mode="modifier")
        co().execute(
            """UPDATE patients SET prenom=?, nom=?, naissance=?, pathologie=?,
               objectif_court=?, objectif_long=?, note_libre=? WHERE id=?""",
            (
                prenom, nom,
                request.form.get("naissance") or None,
                request.form.get("pathologie") or None,
                request.form.get("objectif_court") or None,
                request.form.get("objectif_long") or None,
                request.form.get("note_libre") or None,
                pid,
            ),
        )
        co().commit()
        return redirect(url_for("patient", pid=pid))
    return render_template("patient_form.html", patient=p, mode="modifier")


@app.route("/patient/<int:pid>/note", methods=["POST"])
@connexion_requise
def patient_note(pid):
    get_patient(pid)
    co().execute(
        "UPDATE patients SET note_libre = ? WHERE id = ?",
        (request.form.get("note_libre") or None, pid),
    )
    co().commit()
    return redirect(url_for("patient", pid=pid))


@app.route("/patient/<int:pid>/archiver", methods=["POST"])
@connexion_requise
def patient_archiver(pid):
    get_patient(pid)
    co().execute("UPDATE patients SET archive = 1 WHERE id = ?", (pid,))
    co().commit()
    flash("Patient archivé.")
    return redirect(url_for("dashboard"))


@app.route("/patient/<int:pid>/restaurer", methods=["POST"])
@connexion_requise
def patient_restaurer(pid):
    get_patient(pid)
    co().execute("UPDATE patients SET archive = 0 WHERE id = ?", (pid,))
    co().commit()
    return redirect(url_for("patient", pid=pid))


# --------------------------------------------------------------------------
#  Séances (annotation depuis le calendrier + douleur)
# --------------------------------------------------------------------------
@app.route("/patient/<int:pid>/seance", methods=["POST"])
@connexion_requise
def seance_enregistrer(pid):
    get_patient(pid)
    date_seance = (request.form.get("date_seance") or "").strip()
    if not date_seance:
        abort(400)
    fait = request.form.get("fait") or None
    douleur_brut = request.form.get("douleur")
    douleur = None
    if douleur_brut not in (None, "", "0"):
        try:
            d = int(douleur_brut)
            if 1 <= d <= 10:
                douleur = d
        except ValueError:
            douleur = None
    # heure et praticien : modifiés uniquement s'ils sont explicitement envoyés
    # (permet de les changer/vider depuis la modale sans casser le bilan oral)
    maj_heure = "heure" in request.form
    maj_prat = "praticien" in request.form
    heure = normaliser_heure(request.form.get("heure")) if maj_heure else None
    prat = praticien_valide(request.form.get("praticien")) if maj_prat else None
    db = co()
    db.execute(
        """INSERT INTO seances (patient_id, date_seance, heure, praticien, fait, douleur, cree_le)
           VALUES (?,?,?,?,?,?,?)
           ON CONFLICT(patient_id, date_seance)
           DO UPDATE SET fait=excluded.fait, douleur=excluded.douleur""",
        (pid, date_seance, heure, prat, fait, douleur, maintenant()),
    )
    if maj_heure:
        db.execute("UPDATE seances SET heure=? WHERE patient_id=? AND date_seance=?",
                   (heure, pid, date_seance))
    if maj_prat:
        db.execute("UPDATE seances SET praticien=? WHERE patient_id=? AND date_seance=?",
                   (prat, pid, date_seance))
    db.commit()
    if request.form.get("ajax"):
        return jsonify({"ok": True})
    return redirect(url_for("patient", pid=pid) + "#seances")


@app.route("/patient/<int:pid>/creneau", methods=["POST"])
@connexion_requise
def creneau_enregistrer(pid):
    """Assigne un patient à un créneau (date + heure) sans toucher au compte-rendu."""
    get_patient(pid)
    date_seance = (request.form.get("date") or "").strip()
    heure = normaliser_heure(request.form.get("heure"))
    prat = praticien_valide(request.form.get("praticien"))
    if not date_seance or not heure:
        abort(400)
    co().execute(
        """INSERT INTO seances (patient_id, date_seance, heure, praticien, cree_le)
           VALUES (?,?,?,?,?)
           ON CONFLICT(patient_id, date_seance)
           DO UPDATE SET heure=excluded.heure, praticien=excluded.praticien""",
        (pid, date_seance, heure, prat, maintenant()),
    )
    co().commit()
    return jsonify({"ok": True})


@app.route("/patient/<int:pid>/seance/<int:sid>/supprimer", methods=["POST"])
@connexion_requise
def seance_supprimer(pid, sid):
    get_patient(pid)
    co().execute("DELETE FROM seances WHERE id = ? AND patient_id = ?", (sid, pid))
    co().commit()
    return redirect(url_for("patient", pid=pid) + "#seances")


@app.route("/patient/<int:pid>/seances.json")
@connexion_requise
def seances_json(pid):
    get_patient(pid)
    lignes = co().execute(
        "SELECT id, date_seance, heure, praticien, fait, douleur FROM seances WHERE patient_id = ? ORDER BY date_seance",
        (pid,),
    ).fetchall()
    return jsonify([dict(x) for x in lignes])


@app.route("/patient/<int:pid>/pdf")
@connexion_requise
def patient_pdf(pid):
    p = get_patient(pid)
    seances = co().execute(
        "SELECT * FROM seances WHERE patient_id = ? ORDER BY date_seance", (pid,)
    ).fetchall()
    try:
        import pdf_export
    except Exception:
        abort(500, "Export PDF indisponible (reportlab non installé).")
    data = pdf_export.generer_fiche(dict(p), [dict(s) for s in seances])
    base = "bilan_%s_%s" % (p["nom"], p["prenom"])
    nom = "".join(c if (c.isalnum() or c in "-_") else "_" for c in base) + ".pdf"
    return send_file(io.BytesIO(data), mimetype="application/pdf",
                     as_attachment=True, download_name=nom)


@app.route("/reformuler", methods=["POST"])
@connexion_requise
def reformuler():
    """Réécrit un texte de séance via le modèle local (clarté/orthographe)."""
    if not AUDIO_DISPO:
        return jsonify({"erreur": "Module IA non installé."}), 400
    res = resume.reformuler(request.form.get("texte", ""))
    return jsonify(res)


@app.route("/patient/<int:pid>/bilan", methods=["POST"])
@connexion_requise
def bilan_oral(pid):
    """Reçoit la dictée, transcrit en local puis résume. Rien n'est envoyé en ligne."""
    if not AUDIO_DISPO:
        return jsonify({"erreur": "Module audio non installé."}), 400
    get_patient(pid)
    if "audio" not in request.files:
        return jsonify({"erreur": "Aucun audio reçu."}), 400
    fichier = request.files["audio"]
    suffixe = os.path.splitext(fichier.filename or "")[1] or ".webm"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffixe) as tmp:
        fichier.save(tmp.name)
        chemin = tmp.name
    try:
        tr = transcription.transcrire(chemin)
        texte = tr.get("texte", "")
        res = resume.resumer(texte)
        return jsonify({
            "transcription": texte,
            "resume": res.get("resume", ""),
            "moteur": res.get("moteur", ""),
            "douleur": resume.detecter_douleur(texte),
            "duree": tr.get("duree"),
        })
    except Exception as e:  # noqa: BLE001
        return jsonify({"erreur": str(e)}), 500
    finally:
        try:
            os.remove(chemin)
        except OSError:
            pass


# --------------------------------------------------------------------------
#  Données de test (patients fictifs, marqués demo=1, supprimables)
# --------------------------------------------------------------------------
_PRENOMS = ["Marie", "Jean", "Sophie", "Luc", "Alice", "Paul", "Emma", "Thomas",
            "Julie", "Pierre", "Camille", "Nicolas", "Léa", "Hugo", "Chloé",
            "Antoine", "Manon", "Louis", "Sarah", "Maxime", "Inès", "Théo",
            "Clara", "Lucas", "Eva", "Nathan", "Jade", "Gabriel", "Lola", "Adam"]
_NOMS = ["Durand", "Petit", "Martin", "Bernard", "Dubois", "Moreau", "Laurent",
         "Simon", "Michel", "Lefebvre", "Garcia", "Roux", "Fontaine", "Girard",
         "Bonnet", "Dupont", "Lambert", "Rousseau", "Vincent", "Muller", "Faure",
         "André", "Mercier", "Blanc", "Guérin", "Boyer", "Garnier", "Chevalier"]
_PATHOS = ["Lombalgie chronique", "Tendinopathie de l'épaule", "Entorse de la cheville",
           "Rééducation post-prothèse de genou", "Cervicalgie", "Syndrome rotulien",
           "Capsulite rétractile", "Lombosciatique", "Rupture du LCA (post-op)",
           "Périarthrite scapulo-humérale"]
_ACTES = ["Mobilisations passives et actives.", "Renforcement musculaire progressif.",
          "Étirements et travail proprioceptif.", "Massage décontracturant et physiothérapie.",
          "Travail de l'équilibre et de la marche.", "Exercices de gainage.",
          "Rééducation fonctionnelle.", "Travail excentrique progressif."]
_OBJ_C = ["Réduire la douleur sous 3 semaines.", "Récupérer l'amplitude articulaire.",
          "Diminuer l'inflammation.", "Reprendre la marche sans canne."]
_OBJ_L = ["Reprise du sport sans appréhension.", "Retour au travail.",
          "Autonomie complète au quotidien.", "Prévention des récidives."]


def _creer_patient_demo(db):
    cur = db.execute(
        """INSERT INTO patients
           (prenom, nom, naissance, pathologie, objectif_court, objectif_long,
            note_libre, demo, cree_le)
           VALUES (?,?,?,?,?,?,?,1,?)""",
        (random.choice(_PRENOMS), random.choice(_NOMS), None,
         random.choice(_PATHOS), random.choice(_OBJ_C), random.choice(_OBJ_L),
         "[Données de démonstration]", maintenant()),
    )
    return cur.lastrowid


def _heure_creneau_demo():
    """Heure de créneau aléatoire alignée sur :00/:30, entre 07:00 et 19:30."""
    m = random.randrange(7 * 60, 20 * 60, 30)
    return "%02d:%02d" % (m // 60, m % 60)


def _ajouter_seance_demo(db, pid, jour_iso, prats):
    db.execute(
        "INSERT INTO seances (patient_id, date_seance, heure, praticien, fait, douleur, cree_le) "
        "VALUES (?,?,?,?,?,?,?)",
        (pid, jour_iso, _heure_creneau_demo(), (random.choice(prats) if prats else None),
         random.choice(_ACTES), random.randint(1, 10), maintenant()),
    )


# --------------------------------------------------------------------------
#  Administration (réservée au compte admin) : comptes, praticiens, démo
# --------------------------------------------------------------------------
@app.route("/admin")
@admin_requise
def admin_panel():
    comptes = co().execute(
        "SELECT id, identifiant, role FROM kine ORDER BY role DESC, identifiant COLLATE NOCASE"
    ).fetchall()
    nb_demo = co().execute(
        "SELECT COUNT(*) AS n FROM patients WHERE demo = 1"
    ).fetchone()["n"]
    return render_template("admin_panel.html", comptes=comptes,
                           couleurs=praticiens_couleurs(),
                           nb_demo=nb_demo, aujourdhui=date.today().isoformat(),
                           moi=session.get("kine_id"))


@app.route("/admin/comptes/ajouter", methods=["POST"])
@admin_requise
def admin_compte_ajouter():
    ident = (request.form.get("identifiant") or "").strip()
    mdp = request.form.get("mdp") or ""
    if len(ident) < 3 or len(ident) > 40:
        flash("Le nom/identifiant doit faire entre 3 et 40 caractères.")
    elif len(mdp) < 6:
        flash("Le mot de passe doit faire au moins 6 caractères.")
    else:
        try:
            co().execute(
                "INSERT INTO kine (identifiant, mdp_hash, role, cree_le) VALUES (?,?,?,?)",
                (ident, generate_password_hash(mdp), "praticien", maintenant()),
            )
            co().commit()
            flash("Praticien « %s » ajouté (il peut se connecter avec ce nom)." % ident)
        except sqlite3.IntegrityError:
            flash("Ce nom/identifiant existe déjà.")
    return redirect(url_for("admin_panel") + "#praticiens")


@app.route("/admin/comptes/<int:compte_id>/supprimer", methods=["POST"])
@admin_requise
def admin_compte_supprimer(compte_id):
    if compte_id == session.get("kine_id"):
        flash("Vous ne pouvez pas supprimer votre propre compte.")
        return redirect(url_for("admin_panel") + "#praticiens")
    row = co().execute("SELECT role FROM kine WHERE id = ?", (compte_id,)).fetchone()
    if row and row["role"] == "admin":
        flash("Le compte administrateur ne peut pas être supprimé.")
        return redirect(url_for("admin_panel") + "#praticiens")
    co().execute("DELETE FROM kine WHERE id = ?", (compte_id,))
    co().commit()
    flash("Praticien retiré. Il ne sera plus proposé ; les séances passées "
          "conservent son nom.")
    return redirect(url_for("admin_panel") + "#praticiens")


# -- Synchronisation multi-postes (reservee a l'admin) --
@app.route("/admin/synchro")
@connexion_requise
def admin_synchro():
    db = co()
    conflits = db.execute(
        "SELECT id, tbl, contenu, maj_le, maj_par FROM sync_conflit "
        "WHERE vu = 0 ORDER BY id DESC LIMIT 100").fetchall()
    pairs = sync.pairs_recents(db)
    return render_template(
        "synchro.html",
        dossier=sync._cfg(db, "dossier_sync") or "",
        derniere=sync._cfg(db, "derniere_synchro"),
        poste=sync.poste_id(db),
        code=sync.code_cabinet(db),
        nom_poste=sync._cfg(db, "nom_poste") or "",
        pairs=pairs,
        conflits=conflits)


@app.route("/admin/synchro/dossier", methods=["POST"])
@admin_requise
def admin_synchro_dossier():
    d = (request.form.get("dossier") or "").strip()
    db = co()
    if d and not os.path.isdir(d):
        flash("Dossier introuvable sur ce poste : %s" % d)
    else:
        sync._set_cfg(db, "dossier_sync", d)
        db.commit()
        flash("Dossier de synchronisation enregistré." if d
              else "Synchronisation désactivée sur ce poste.")
    return redirect(url_for("admin_synchro"))


@app.route("/admin/synchro/lancer", methods=["POST"])
@connexion_requise
def admin_synchro_lancer():
    db = co()
    dossier = sync._cfg(db, "dossier_sync")
    if not dossier:
        flash("Indiquez d'abord le dossier de synchronisation.")
    else:
        try:
            s = sync.synchroniser_dossier(db, dossier)
            flash("Synchronisation terminée : %d ajout(s), %d mise(s) à jour, "
                  "%d conflit(s), %d suppression(s)."
                  % (s["ajouts"], s["maj"], s["conflits"], s["suppressions"]))
        except Exception as e:
            flash("Synchronisation impossible : %s" % e)
    return redirect(url_for("admin_synchro"))


@app.route("/admin/synchro/conflits/traiter", methods=["POST"])
@connexion_requise
def admin_synchro_conflits():
    db = co()
    db.execute("UPDATE sync_conflit SET vu = 1")
    db.commit()
    flash("Journal des conflits marqué comme traité.")
    return redirect(url_for("admin_synchro"))


@app.route("/admin/synchro/code", methods=["POST"])
@admin_requise
def admin_synchro_code():
    db = co()
    code = (request.form.get("code") or "").strip()
    sync._set_cfg(db, "code_cabinet", code)
    db.commit()
    flash("Code d'équipe enregistré. Mettez le MÊME code sur chaque poste."
          if code else "Synchronisation réseau désactivée (code vide).")
    return redirect(url_for("admin_synchro"))


@app.route("/admin/synchro/nom", methods=["POST"])
@connexion_requise
def admin_synchro_nom():
    db = co()
    nom = (request.form.get("nom") or "").strip()[:40]
    sync._set_cfg(db, "nom_poste", nom)
    db.commit()
    flash("Nom de ce poste enregistré : « %s »." % nom if nom
          else "Nom de ce poste effacé.")
    return redirect(url_for("admin_synchro"))


@app.route("/admin/synchro/reseau", methods=["POST"])
@connexion_requise
def admin_synchro_reseau():
    db = co()
    if not sync.code_cabinet(db):
        flash("Définissez d'abord un code cabinet.")
        return redirect(url_for("admin_synchro"))
    res = sync.synchroniser_reseau(db)
    if res is None:
        flash("Aucun code cabinet défini.")
    else:
        stats, nb, erreurs = res
        msg = ("Synchronisation réseau : %d poste(s) contacté(s) — %d ajout(s), "
               "%d mise(s) à jour, %d conflit(s)." %
               (nb, stats["ajouts"], stats["maj"], stats["conflits"]))
        if erreurs:
            msg += " Injoignables : " + ", ".join(erreurs)
        flash(msg)
    return redirect(url_for("admin_synchro"))


@app.route("/sync/echange", methods=["POST"])
def sync_echange():
    """Echange machine-a-machine entre postes, protege par le code cabinet."""
    db = co()
    code_local = sync.code_cabinet(db)
    data = request.get_json(silent=True) or {}
    if not code_local or data.get("code") != code_local:
        return jsonify({"erreur": "code cabinet invalide"}), 403
    paquet = data.get("paquet")
    if paquet:
        try:
            sync.fusionner(db, paquet)
        except Exception as e:
            return jsonify({"erreur": str(e)}), 500
    return jsonify({"paquet": sync.exporter(db)})


# -- Données de test (réservées à l'admin) --
@app.route("/test/jour", methods=["POST"])
@admin_requise
def test_jour():
    jour = (request.form.get("date") or date.today().isoformat()).strip()
    try:
        nombre = max(1, min(150, int(request.form.get("nombre") or 25)))
    except ValueError:
        nombre = 25
    db = co()
    prats = liste_praticiens()
    for _ in range(nombre):
        _ajouter_seance_demo(db, _creer_patient_demo(db), jour, prats)
    db.commit()
    flash("%d patient(s) de démo ajouté(s) le %s." % (nombre, jour))
    return redirect(url_for("admin_panel") + "#donnees")


@app.route("/test/mois", methods=["POST"])
@admin_requise
def test_mois():
    val = (request.form.get("aaaamm") or "").strip()
    try:
        annee, mois = int(val[:4]), int(val[5:7])
    except (ValueError, IndexError):
        t = date.today()
        annee, mois = t.year, t.month
    try:
        nombre = max(1, min(400, int(request.form.get("nombre") or 60)))
    except ValueError:
        nombre = 60
    njours = calendar.monthrange(annee, mois)[1]
    db = co()
    prats = liste_praticiens()
    for _ in range(nombre):
        jour = "%04d-%02d-%02d" % (annee, mois, random.randint(1, njours))
        _ajouter_seance_demo(db, _creer_patient_demo(db), jour, prats)
    db.commit()
    flash("%d séance(s) de démo réparties sur %02d/%04d." % (nombre, mois, annee))
    return redirect(url_for("admin_panel") + "#donnees")


@app.route("/test/purge", methods=["POST"])
@admin_requise
def test_purge():
    db = co()
    db.execute("DELETE FROM seances WHERE patient_id IN (SELECT id FROM patients WHERE demo = 1)")
    db.execute("DELETE FROM patients WHERE demo = 1")
    db.commit()
    flash("Données de démonstration supprimées.")
    return redirect(url_for("admin_panel") + "#donnees")


@app.context_processor
def injecter():
    return {
        "AUDIO_DISPO": AUDIO_DISPO,
        "LLM_DISPO": AUDIO_DISPO,
        "praticiens": liste_praticiens(),
        "praticiens_couleurs": praticiens_couleurs(),
        "est_admin": est_admin(),
        "annee": datetime.now().year,
        "aujourdhui": date.today().isoformat(),
    }


def ip_locale():
    """Adresse IP du PC sur le réseau local (sans rien émettre), sinon None."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except OSError:
        ip = None
    finally:
        s.close()
    return ip


def generer_certificat(cert_path, key_path, ip):
    """Crée un certificat auto-signé (localhost + IP locale) pour servir en HTTPS.

    Le micro des navigateurs n'est autorisé qu'en contexte sécurisé (HTTPS ou
    localhost) : le HTTPS débloque donc le bilan oral depuis les autres postes.
    """
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    import ipaddress as _ipaddr

    cle = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    nom = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Cabinet kine")])
    noms_alt = [x509.DNSName("localhost"),
                x509.IPAddress(_ipaddr.ip_address("127.0.0.1"))]
    if ip:
        try:
            noms_alt.append(x509.IPAddress(_ipaddr.ip_address(ip)))
        except ValueError:
            pass
    t0 = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(nom).issuer_name(nom)
        .public_key(cle.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(t0 - timedelta(days=1))
        .not_valid_after(t0 + timedelta(days=3650))
        .add_extension(x509.SubjectAlternativeName(noms_alt), critical=False)
        .sign(cle, hashes.SHA256())
    )
    with open(key_path, "wb") as f:
        f.write(cle.private_bytes(serialization.Encoding.PEM,
                                  serialization.PrivateFormat.TraditionalOpenSSL,
                                  serialization.NoEncryption()))
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))


if __name__ == "__main__":
    init_db()
    # Sauvegarde quotidienne + synchro automatique (le matin, au demarrage)
    try:
        _d = sqlite3.connect(DB)
        sync.sauvegarde_quotidienne(_d, DB, os.path.join(ICI, "sauvegardes"))
        _dossier = sync._cfg(_d, "dossier_sync")
        if _dossier and os.path.isdir(_dossier):
            try:
                r = sync.synchroniser_dossier(_d, _dossier)
                print("  Synchronisation : %d ajout(s), %d maj, %d conflit(s)."
                      % (r["ajouts"], r["maj"], r["conflits"]))
            except Exception as _se:
                print("  (synchro au demarrage ignoree : %s)" % _se)
        _d.close()
    except Exception as _be:
        print("  (sauvegarde/synchro differee : %s)" % _be)
    port = int(os.environ.get("PORT", "5001"))
    # Decouverte des autres postes sur le reseau local (threads de fond)
    try:
        reseau.Reseau(DB, port, sync).demarrer()
    except Exception as _re:
        print("  (reseau local indisponible : %s)" % _re)
    ip = ip_locale()
    ici = os.path.dirname(os.path.abspath(__file__))
    cert_path = os.path.join(ici, "cert.pem")
    key_path = os.path.join(ici, "key.pem")
    contexte_ssl = None
    try:
        if not (os.path.exists(cert_path) and os.path.exists(key_path)):
            generer_certificat(cert_path, key_path, ip)
        contexte_ssl = (cert_path, key_path)
    except Exception as err:
        print("\n  (HTTPS indisponible : %s — démarrage en HTTP)" % err)
    schema = "https" if contexte_ssl else "http"
    print("\n  Cabinet kiné — prêt.\n")
    print("  Sur CET ordinateur :")
    print("      %s://localhost:%d" % (schema, port))
    print("      %s://127.0.0.1:%d   (si « localhost » ne répond pas)" % (schema, port))
    if ip:
        print("\n  Depuis un autre PC / smartphone sur le MÊME réseau :")
        print("      %s://%s:%d" % (schema, ip, port))
        if contexte_ssl:
            print("\n  (1re visite sur chaque appareil : le navigateur affiche un")
            print("   avertissement de sécurité — normal avec un certificat local.")
            print("   Cliquez sur « Avancé » puis « Continuer ». Le HTTPS est requis")
            print("   pour autoriser le micro — donc le bilan oral — à distance.)")
        else:
            print("\n  (connexion non chiffrée : le micro ne sera pas disponible")
            print("   depuis les autres postes)")
    print("\n  Pour arrêter : Ctrl+C\n")
    app.run(host="0.0.0.0", port=port, threaded=True, ssl_context=contexte_ssl)
