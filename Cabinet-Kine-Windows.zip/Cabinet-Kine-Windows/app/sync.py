# -*- coding: utf-8 -*-
"""
Synchronisation multi-postes pour Cabinet Kine (reseau local, copie par poste).

Detection des conflits par HORLOGES VECTORIELLES : chaque enregistrement porte
une horloge {poste: compteur}. On distingue ainsi une simple mise a jour (une
horloge "domine" l'autre) d'une vraie modification concurrente (aucune ne
domine -> conflit). Regle de conflit : on applique une version (choix
deterministe, identique sur tous les postes) et on CONSERVE l'autre dans le
journal sync_conflit. Aucune donnee n'est jamais perdue.

Transport : un DOSSIER d'echange partage sur le reseau (pas de cloud).
Perimetre : patients + seances. Les comptes restent propres a chaque poste.
"""
import json
import os
import sqlite3
import hashlib
import datetime

CHAMPS = {
    "patients": ["prenom", "nom", "naissance", "pathologie", "objectif_court",
                 "objectif_long", "note_libre", "archive", "demo", "cree_le"],
    "seances":  ["date_seance", "heure", "fait", "douleur", "cree_le"],
}


def maintenant():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _cfg(db, cle, defaut=None):
    r = db.execute("SELECT valeur FROM sync_config WHERE cle=?", (cle,)).fetchone()
    return r[0] if r else defaut


def _set_cfg(db, cle, valeur):
    db.execute("INSERT INTO sync_config(cle,valeur) VALUES(?,?) "
               "ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur", (cle, valeur))


def poste_id(db):
    return _cfg(db, "poste_id")


def assurer_schema(db):
    db.execute("CREATE TABLE IF NOT EXISTS sync_config(cle TEXT PRIMARY KEY, valeur TEXT)")
    db.execute("CREATE TABLE IF NOT EXISTS sync_horloge("
               "ident TEXT, poste TEXT, cpt INTEGER, PRIMARY KEY(ident,poste))")
    db.execute("CREATE TABLE IF NOT EXISTS sync_etat("
               "ident TEXT PRIMARY KEY, maj_le_exporte TEXT)")
    db.execute("CREATE TABLE IF NOT EXISTS sync_tombstone("
               "ident TEXT PRIMARY KEY, maj_le TEXT, maj_par TEXT)")
    db.execute("CREATE TABLE IF NOT EXISTS sync_conflit("
               "id INTEGER PRIMARY KEY AUTOINCREMENT, tbl TEXT, ident TEXT, contenu TEXT,"
               " maj_le TEXT, maj_par TEXT, vu INTEGER NOT NULL DEFAULT 0, cree_le TEXT)")
    db.execute("CREATE TABLE IF NOT EXISTS sync_pairs("
               "poste TEXT PRIMARY KEY, ip TEXT, port INTEGER, nom TEXT, vu_le TEXT)")
    if not _cfg(db, "poste_id"):
        _set_cfg(db, "poste_id", hashlib.sha1(os.urandom(16)).hexdigest()[:12])
    for tbl in ("patients", "seances"):
        cols = [r[1] for r in db.execute("PRAGMA table_info(%s)" % tbl).fetchall()]
        if "uid" not in cols:
            db.execute("ALTER TABLE %s ADD COLUMN uid TEXT" % tbl)
        if "maj_le" not in cols:
            db.execute("ALTER TABLE %s ADD COLUMN maj_le TEXT" % tbl)
        if "maj_par" not in cols:
            db.execute("ALTER TABLE %s ADD COLUMN maj_par TEXT" % tbl)
    for tbl in ("patients", "seances"):
        for (rid,) in db.execute(
                "SELECT id FROM %s WHERE uid IS NULL OR uid=''" % tbl).fetchall():
            db.execute("UPDATE %s SET uid=?, maj_le=COALESCE(maj_le,?), maj_par=COALESCE(maj_par,?)"
                       " WHERE id=?" % tbl,
                       (hashlib.sha1(os.urandom(16)).hexdigest(), maintenant(), poste_id(db), rid))
    _triggers(db)
    db.commit()


def _triggers(db):
    pid = "(SELECT valeur FROM sync_config WHERE cle='poste_id')"
    now = "strftime('%Y-%m-%dT%H:%M:%fZ','now')"
    for tbl in ("patients", "seances"):
        db.execute("DROP TRIGGER IF EXISTS %s_uid_ins" % tbl)
        db.execute("CREATE TRIGGER %s_uid_ins AFTER INSERT ON %s "
                   "WHEN NEW.uid IS NULL OR NEW.maj_le IS NULL BEGIN "
                   "UPDATE %s SET uid=COALESCE(NEW.uid, lower(hex(randomblob(16)))),"
                   " maj_le=COALESCE(NEW.maj_le,%s), maj_par=COALESCE(NEW.maj_par,%s,'?')"
                   " WHERE rowid=NEW.rowid; END;" % (tbl, tbl, tbl, now, pid))
        db.execute("DROP TRIGGER IF EXISTS %s_maj_upd" % tbl)
        db.execute("CREATE TRIGGER %s_maj_upd AFTER UPDATE ON %s WHEN NEW.maj_le IS OLD.maj_le "
                   "BEGIN UPDATE %s SET maj_le=%s, maj_par=COALESCE(%s,'?') "
                   "WHERE rowid=NEW.rowid; END;" % (tbl, tbl, tbl, now, pid))
    db.execute("DROP TRIGGER IF EXISTS patients_del")
    db.execute("CREATE TRIGGER patients_del AFTER DELETE ON patients BEGIN "
               "INSERT INTO sync_tombstone(ident,maj_le,maj_par) "
               "VALUES('p:'||OLD.uid,%s,COALESCE(%s,'?')) "
               "ON CONFLICT(ident) DO UPDATE SET maj_le=excluded.maj_le,maj_par=excluded.maj_par;"
               " END;" % (now, pid))
    db.execute("DROP TRIGGER IF EXISTS seances_del")
    db.execute("CREATE TRIGGER seances_del AFTER DELETE ON seances BEGIN "
               "INSERT INTO sync_tombstone(ident,maj_le,maj_par) "
               "VALUES('s:'||COALESCE((SELECT uid FROM patients WHERE id=OLD.patient_id),'?')"
               "||'|'||OLD.date_seance,%s,COALESCE(%s,'?')) "
               "ON CONFLICT(ident) DO UPDATE SET maj_le=excluded.maj_le,maj_par=excluded.maj_par;"
               " END;" % (now, pid))


def _ident_p(uid):
    return "p:" + uid


def _ident_s(puid, date):
    return "s:" + (puid or "?") + "|" + (date or "")


def _h_get(db, ident):
    return {p: c for p, c in db.execute(
        "SELECT poste,cpt FROM sync_horloge WHERE ident=?", (ident,)).fetchall()}


def _h_set(db, ident, h):
    db.execute("DELETE FROM sync_horloge WHERE ident=?", (ident,))
    for p, c in h.items():
        db.execute("INSERT INTO sync_horloge(ident,poste,cpt) VALUES(?,?,?)", (ident, p, c))


def _h_incr(db, ident, poste):
    db.execute("INSERT INTO sync_horloge(ident,poste,cpt) VALUES(?,?,1) "
               "ON CONFLICT(ident,poste) DO UPDATE SET cpt=cpt+1", (ident, poste))


def _domine(a, b):
    for p in set(a) | set(b):
        if a.get(p, 0) < b.get(p, 0):
            return False
    return True


def _fusion_h(a, b):
    return {p: max(a.get(p, 0), b.get(p, 0)) for p in set(a) | set(b)}


def _etat_get(db, ident):
    r = db.execute("SELECT maj_le_exporte FROM sync_etat WHERE ident=?", (ident,)).fetchone()
    return r[0] if r else None


def _etat_set(db, ident, maj_le):
    db.execute("INSERT INTO sync_etat(ident,maj_le_exporte) VALUES(?,?) "
               "ON CONFLICT(ident) DO UPDATE SET maj_le_exporte=excluded.maj_le_exporte",
               (ident, maj_le))


def _contenu(row, champs):
    return {c: row[c] for c in champs}


def exporter(db):
    db.row_factory = sqlite3.Row
    moi = poste_id(db)
    paquet = {"poste": moi, "genere_le": maintenant(),
              "patients": [], "seances": [], "tombstones": []}
    for row in db.execute("SELECT * FROM patients"):
        ident = _ident_p(row["uid"])
        if _etat_get(db, ident) != row["maj_le"]:
            _h_incr(db, ident, moi)
            _etat_set(db, ident, row["maj_le"])
        d = _contenu(row, CHAMPS["patients"])
        d.update(uid=row["uid"], maj_le=row["maj_le"], maj_par=row["maj_par"],
                 horloge=_h_get(db, ident))
        paquet["patients"].append(d)
    for row in db.execute("SELECT s.*, p.uid AS puid FROM seances s "
                          "JOIN patients p ON p.id=s.patient_id"):
        ident = _ident_s(row["puid"], row["date_seance"])
        if _etat_get(db, ident) != row["maj_le"]:
            _h_incr(db, ident, moi)
            _etat_set(db, ident, row["maj_le"])
        d = _contenu(row, CHAMPS["seances"])
        d.update(uid=row["uid"], maj_le=row["maj_le"], maj_par=row["maj_par"],
                 patient_uid=row["puid"], horloge=_h_get(db, ident))
        paquet["seances"].append(d)
    for row in db.execute("SELECT ident,maj_le,maj_par FROM sync_tombstone"):
        paquet["tombstones"].append(dict(ident=row["ident"], maj_le=row["maj_le"],
                                         maj_par=row["maj_par"]))
    db.commit()
    return paquet


def _journal(db, tbl, ident, contenu, maj_le, maj_par):
    db.execute("INSERT INTO sync_conflit(tbl,ident,contenu,maj_le,maj_par,cree_le) "
               "VALUES(?,?,?,?,?,?)",
               (tbl, ident, json.dumps(contenu, ensure_ascii=False), maj_le, maj_par, maintenant()))


def _plus_recent(maj_a, par_a, maj_b, par_b):
    return (maj_a or "", par_a or "") >= (maj_b or "", par_b or "")


def _appliquer(db, tbl, rid, d):
    champs = CHAMPS[tbl]
    sets = ",".join("%s=?" % c for c in champs) + ", uid=?, maj_le=?, maj_par=?"
    vals = [d.get(c) for c in champs] + [d["uid"], d["maj_le"], d.get("maj_par"), rid]
    db.execute("UPDATE %s SET %s WHERE id=?" % (tbl, sets), vals)


def fusionner(db, paquet):
    db.row_factory = sqlite3.Row
    stats = {"ajouts": 0, "maj": 0, "conflits": 0, "suppressions": 0}
    if paquet.get("poste") == poste_id(db):
        return stats

    def traiter(tbl, d, ident, loc, extra):
        hd = d.get("horloge", {})
        if loc is None:
            tomb = db.execute("SELECT maj_le FROM sync_tombstone WHERE ident=?", (ident,)).fetchone()
            if tomb and tomb[0] >= d["maj_le"]:
                return
            db.execute("DELETE FROM sync_tombstone WHERE ident=?", (ident,))
            champs = CHAMPS[tbl]
            cols = extra[0] + ["uid", "maj_le", "maj_par"] + champs
            vals = extra[1] + [d["uid"], d["maj_le"], d.get("maj_par")] + [d.get(c) for c in champs]
            db.execute("INSERT INTO %s(%s) VALUES(%s)" %
                       (tbl, ",".join(cols), ",".join("?" * len(cols))), vals)
            _h_set(db, ident, hd)
            _etat_set(db, ident, d["maj_le"])
            stats["ajouts"] += 1
            return
        hl = _h_get(db, ident)
        if hd == hl:
            return
        if _domine(hd, hl) and not _domine(hl, hd):
            _appliquer(db, tbl, loc["id"], d)
            _h_set(db, ident, _fusion_h(hl, hd))
            _etat_set(db, ident, d["maj_le"])
            stats["maj"] += 1
            return
        if _domine(hl, hd):
            return
        # concurrents -> conflit : on garde les deux
        merge = _fusion_h(hl, hd)
        if _plus_recent(d["maj_le"], d.get("maj_par"), loc["maj_le"], loc["maj_par"]):
            _journal(db, tbl, ident, _contenu(loc, CHAMPS[tbl]), loc["maj_le"], loc["maj_par"])
            _appliquer(db, tbl, loc["id"], d)
        else:
            _journal(db, tbl, ident, {c: d.get(c) for c in CHAMPS[tbl]},
                     d["maj_le"], d.get("maj_par"))
        _h_set(db, ident, merge)
        cur = db.execute("SELECT maj_le FROM %s WHERE id=?" % tbl, (loc["id"],)).fetchone()
        if cur:
            _etat_set(db, ident, cur["maj_le"])
        stats["conflits"] += 1

    for d in paquet.get("patients", []):
        ident = _ident_p(d["uid"])
        loc = db.execute("SELECT * FROM patients WHERE uid=?", (d["uid"],)).fetchone()
        traiter("patients", d, ident, loc, ([], []))

    for d in paquet.get("seances", []):
        pat = db.execute("SELECT id FROM patients WHERE uid=?", (d["patient_uid"],)).fetchone()
        if pat is None:
            continue
        ident = _ident_s(d["patient_uid"], d["date_seance"])
        loc = db.execute("SELECT * FROM seances WHERE patient_id=? AND date_seance=?",
                         (pat["id"], d["date_seance"])).fetchone()
        traiter("seances", d, ident, loc, (["patient_id"], [pat["id"]]))

    for t in paquet.get("tombstones", []):
        ident, tmaj = t["ident"], t["maj_le"]
        if ident.startswith("p:"):
            loc = db.execute("SELECT * FROM patients WHERE uid=?", (ident[2:],)).fetchone()
            table = "patients"
        elif ident.startswith("s:"):
            puid, _, dt = ident[2:].partition("|")
            pat = db.execute("SELECT id FROM patients WHERE uid=?", (puid,)).fetchone()
            loc = (db.execute("SELECT * FROM seances WHERE patient_id=? AND date_seance=?",
                              (pat["id"], dt)).fetchone() if pat else None)
            table = "seances"
        else:
            continue
        db.execute("INSERT INTO sync_tombstone(ident,maj_le,maj_par) VALUES(?,?,?) "
                   "ON CONFLICT(ident) DO UPDATE SET maj_le=excluded.maj_le "
                   "WHERE excluded.maj_le > sync_tombstone.maj_le",
                   (ident, tmaj, t.get("maj_par")))
        if loc is None:
            continue
        if loc["maj_le"] > tmaj:
            continue
        db.execute("DELETE FROM %s WHERE id=?" % table, (loc["id"],))
        stats["suppressions"] += 1

    db.commit()
    return stats


def synchroniser_dossier(db, dossier):
    if not dossier or not os.path.isdir(dossier):
        raise FileNotFoundError("Dossier de synchro introuvable : %s" % dossier)
    db.row_factory = sqlite3.Row
    moi = poste_id(db)
    paquet = exporter(db)
    cible = os.path.join(dossier, "%s.cksync.json" % moi)
    tmp = cible + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(paquet, f, ensure_ascii=False)
    os.replace(tmp, cible)
    total = {"ajouts": 0, "maj": 0, "conflits": 0, "suppressions": 0}
    fichiers = [os.path.join(dossier, n) for n in os.listdir(dossier)
                if n.endswith(".cksync.json") and not n.startswith(moi + ".")]
    for _passe in range(2):
        for chemin in fichiers:
            try:
                with open(chemin, encoding="utf-8") as f:
                    autre = json.load(f)
            except (OSError, ValueError):
                continue
            s = fusionner(db, autre)
            for k in total:
                total[k] += s[k]
    _set_cfg(db, "derniere_synchro", maintenant())
    db.commit()
    return total


def sauvegarde_quotidienne(db, chemin_db, dossier_backups):
    import shutil
    os.makedirs(dossier_backups, exist_ok=True)
    jour = datetime.date.today().isoformat()
    if _cfg(db, "derniere_sauvegarde") == jour:
        return None
    cible = os.path.join(dossier_backups, "cabinet-%s.db" % jour)
    try:
        db.execute("PRAGMA wal_checkpoint(FULL)")
    except sqlite3.Error:
        pass
    shutil.copy2(chemin_db, cible)
    _set_cfg(db, "derniere_sauvegarde", jour)
    db.commit()
    fichiers = sorted(n for n in os.listdir(dossier_backups)
                      if n.startswith("cabinet-") and n.endswith(".db"))
    for n in fichiers[:-30]:
        try:
            os.remove(os.path.join(dossier_backups, n))
        except OSError:
            pass
    return cible


# --------------------------------------------------------------------------- #
#  Reseau local : code cabinet + echange pair-a-pair
# --------------------------------------------------------------------------- #
def code_cabinet(db):
    return _cfg(db, "code_cabinet") or ""


def code_empreinte(code):
    """Empreinte courte du code cabinet (annoncee sur le reseau, jamais le code)."""
    return hashlib.sha256(("cabinetkine:" + (code or "")).encode()).hexdigest()[:16]


def echanger_avec_pair(db, base_url, code):
    """Echange bidirectionnel avec un poste : on envoie notre paquet, on fusionne le sien."""
    import urllib.request
    import ssl
    paquet = exporter(db)
    corps = json.dumps({"code": code, "paquet": paquet}).encode("utf-8")
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(base_url.rstrip("/") + "/sync/echange", data=corps,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=8, context=ctx) as r:
        rep = json.loads(r.read().decode("utf-8"))
    if rep.get("paquet"):
        return fusionner(db, rep["paquet"])
    return {"ajouts": 0, "maj": 0, "conflits": 0, "suppressions": 0}


def pairs_recents(db, minutes=30):
    limite = (datetime.datetime.now(datetime.timezone.utc)
              - datetime.timedelta(minutes=minutes)).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    return db.execute("SELECT poste, ip, port, nom, vu_le FROM sync_pairs "
                      "WHERE vu_le >= ? ORDER BY nom, ip", (limite,)).fetchall()


def synchroniser_reseau(db):
    """Synchronise avec tous les pairs recemment vus. Renvoie (stats, nb_pairs, erreurs)."""
    db.row_factory = sqlite3.Row
    code = code_cabinet(db)
    if not code:
        return None
    total = {"ajouts": 0, "maj": 0, "conflits": 0, "suppressions": 0}
    erreurs = []
    pairs = pairs_recents(db)
    for p in pairs:
        url = "https://%s:%d" % (p["ip"], p["port"])
        try:
            s = echanger_avec_pair(db, url, code)
            for k in total:
                total[k] += s[k]
        except Exception as e:
            erreurs.append("%s (%s)" % (p["nom"] or p["ip"], e.__class__.__name__))
    _set_cfg(db, "derniere_synchro", maintenant())
    db.commit()
    return total, len(pairs), erreurs
