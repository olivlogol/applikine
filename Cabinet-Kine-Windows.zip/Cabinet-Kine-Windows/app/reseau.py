# -*- coding: utf-8 -*-
"""
Decouverte des autres postes Cabinet Kine sur le reseau local.

Chaque poste ANNONCE periodiquement sa presence par un petit message UDP diffuse
(broadcast) sur le reseau local, et ECOUTE les annonces des autres. Seuls les
postes partageant la meme EMPREINTE de code cabinet sont retenus. Une boucle
synchronise ensuite avec les postes connus (toutes les 10 min + sur demande).

100% bibliotheque standard (socket, threading) -> fonctionne sur Mac/Windows/Linux
sans dependance a installer.
"""
import socket
import struct
import threading
import time
import json
import sqlite3
import datetime

PORT_DECOUVERTE = 50505
MAGIC = b"CABKINE1"
INTERVALLE_ANNONCE = 20          # secondes entre deux annonces
INTERVALLE_SYNC = 600            # 10 minutes


def _maintenant():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def construire_annonce(poste, http_port, empreinte, nom):
    """Message d'annonce (binaire simple : MAGIC + JSON)."""
    corps = json.dumps({"poste": poste, "port": http_port,
                        "emp": empreinte, "nom": nom}).encode("utf-8")
    return MAGIC + corps


def lire_annonce(data):
    if not data.startswith(MAGIC):
        return None
    try:
        return json.loads(data[len(MAGIC):].decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return None


class Reseau:
    def __init__(self, db_path, http_port, sync_module):
        self.db_path = db_path
        self.http_port = http_port
        self.sync = sync_module
        self._stop = threading.Event()

    # -- helpers base (chaque thread a sa connexion) --
    def _db(self):
        d = sqlite3.connect(self.db_path, timeout=10)
        d.row_factory = sqlite3.Row
        d.execute("PRAGMA busy_timeout=8000")
        return d

    def _infos(self, db):
        poste = self.sync.poste_id(db)
        code = self.sync.code_cabinet(db)
        nom = self.sync._cfg(db, "nom_poste") or socket.gethostname()
        return poste, code, nom

    # -- thread : annonce --
    def _boucle_annonce(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        while not self._stop.is_set():
            try:
                db = self._db()
                poste, code, nom = self._infos(db)
                db.close()
                if code:
                    emp = self.sync.code_empreinte(code)
                    msg = construire_annonce(poste, self.http_port, emp, nom)
                    for cible in ("255.255.255.255", "<broadcast>"):
                        try:
                            s.sendto(msg, (cible, PORT_DECOUVERTE))
                            break
                        except OSError:
                            continue
            except Exception:
                pass
            self._stop.wait(INTERVALLE_ANNONCE)
        s.close()

    # -- thread : ecoute --
    def _boucle_ecoute(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        except (AttributeError, OSError):
            pass
        try:
            s.bind(("", PORT_DECOUVERTE))
        except OSError:
            return
        s.settimeout(1.0)
        while not self._stop.is_set():
            try:
                data, addr = s.recvfrom(2048)
            except socket.timeout:
                continue
            except OSError:
                break
            info = lire_annonce(data)
            if not info:
                continue
            try:
                db = self._db()
                poste, code, _ = self._infos(db)
                if code and info.get("poste") != poste and \
                        info.get("emp") == self.sync.code_empreinte(code):
                    db.execute(
                        "INSERT INTO sync_pairs(poste,ip,port,nom,vu_le) VALUES(?,?,?,?,?) "
                        "ON CONFLICT(poste) DO UPDATE SET ip=excluded.ip, port=excluded.port,"
                        " nom=excluded.nom, vu_le=excluded.vu_le",
                        (info["poste"], addr[0], int(info.get("port", 5001)),
                         info.get("nom", addr[0]), _maintenant()))
                    db.commit()
                db.close()
            except Exception:
                pass
        s.close()

    # -- thread : synchro periodique --
    def _boucle_sync(self):
        # premiere synchro apres un court delai (laisser le temps de decouvrir)
        if self._stop.wait(15):
            return
        while not self._stop.is_set():
            try:
                db = self._db()
                if self.sync.code_cabinet(db):
                    self.sync.synchroniser_reseau(db)
                db.close()
            except Exception:
                pass
            self._stop.wait(INTERVALLE_SYNC)

    def demarrer(self):
        for cible in (self._boucle_ecoute, self._boucle_annonce, self._boucle_sync):
            t = threading.Thread(target=cible, daemon=True)
            t.start()

    def arreter(self):
        self._stop.set()
