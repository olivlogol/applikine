#!/usr/bin/env python3
"""Génère un compte-rendu PDF du dossier patient (reportlab).

Contenu : identité, pathologie, objectifs, note, courbe d'évolution de la
douleur (EVA) et historique des séances. Renvoie les octets du PDF.
"""
import io
from datetime import date, datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor, white
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether,
)
from reportlab.graphics.shapes import Drawing, Line, Circle, PolyLine, String

# Charte (cohérente avec l'application)
ACCENT = HexColor("#5A4FE3")
INK = HexColor("#161A23")
MUTED = HexColor("#5A6473")
LIGNE = HexColor("#DCE0E8")
SOFT = HexColor("#F0EFFC")
PATHO_BG = HexColor("#FBF1EE")
VERT = HexColor("#1F9D6B")
ORANGE = HexColor("#E0A100")
ROUGE = HexColor("#D2493B")


def _coul(n):
    if not n:
        return MUTED
    if n <= 3:
        return VERT
    if n <= 6:
        return ORANGE
    return ROUGE


def _jolie_date(iso):
    try:
        d = datetime.strptime(iso[:10], "%Y-%m-%d")
        return d.strftime("%d/%m/%Y")
    except Exception:
        return iso or ""


def _styles():
    s = getSampleStyleSheet()
    base = ParagraphStyle("base", parent=s["Normal"], fontName="Helvetica",
                          fontSize=10, leading=14, textColor=INK)
    return {
        "titre": ParagraphStyle("titre", parent=base, fontName="Helvetica-Bold",
                                fontSize=20, leading=24, textColor=INK),
        "sous": ParagraphStyle("sous", parent=base, fontSize=10, textColor=MUTED),
        "eyebrow": ParagraphStyle("eyebrow", parent=base, fontName="Helvetica-Bold",
                                  fontSize=8, textColor=MUTED, spaceAfter=2),
        "h2": ParagraphStyle("h2", parent=base, fontName="Helvetica-Bold",
                             fontSize=11, leading=14, textColor=INK, spaceBefore=4, spaceAfter=6),
        "val": ParagraphStyle("val", parent=base, fontSize=11, leading=15),
        "valbold": ParagraphStyle("valbold", parent=base, fontName="Helvetica-Bold",
                                  fontSize=12, leading=16),
        "base": base,
        "cell": ParagraphStyle("cell", parent=base, fontSize=9.5, leading=13),
        "cellmuted": ParagraphStyle("cellmuted", parent=base, fontSize=9.5,
                                    leading=13, textColor=MUTED),
        "pied": ParagraphStyle("pied", parent=base, fontSize=8, textColor=MUTED),
    }


def _graphe_douleur(points, largeur, hauteur=165):
    d = Drawing(largeur, hauteur)
    padL, padR, padT, padB = 26, 10, 12, 32
    plotW = largeur - padL - padR
    plotH = hauteur - padT - padB
    n = len(points)

    for lvl in range(0, 11, 2):
        y = padB + (lvl / 10.0) * plotH
        d.add(Line(padL, y, largeur - padR, y, strokeColor=LIGNE, strokeWidth=0.5))
        d.add(String(padL - 5, y - 3, str(lvl), fontSize=7,
                     fillColor=MUTED, textAnchor="end"))

    def X(i):
        return padL + (plotW / 2.0 if n == 1 else (i / (n - 1.0)) * plotW)

    def Y(v):
        return padB + (v / 10.0) * plotH

    if n >= 2:
        flat = []
        for i, p in enumerate(points):
            flat += [X(i), Y(p["d"])]
        d.add(PolyLine(flat, strokeColor=ACCENT, strokeWidth=1.5))

    step = 1 if n <= 12 else (n // 12 + 1)
    for i, p in enumerate(points):
        d.add(Circle(X(i), Y(p["d"]), 3, fillColor=_coul(p["d"]),
                     strokeColor=white, strokeWidth=1))
        if i % step == 0:
            d.add(String(X(i), padB - 12, p["date"][5:], fontSize=6.5,
                         fillColor=MUTED, textAnchor="middle"))
    d.add(Line(padL, padB, largeur - padR, padB, strokeColor=MUTED, strokeWidth=0.8))
    return d


def _bloc_clef(titre, valeur, st, accent=False):
    eyebrow = ParagraphStyle("eb", parent=st["eyebrow"],
                             textColor=(ROUGE if accent else MUTED))
    contenu = [
        Paragraph(titre.upper(), eyebrow),
        Paragraph(valeur or "Non renseigné",
                  st["valbold"] if accent else st["val"]),
    ]
    t = Table([[contenu]], colWidths=["100%"])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), PATHO_BG if accent else white),
        ("BOX", (0, 0), (-1, -1), 0.7, (HexColor("#F1D9D1") if accent else LIGNE)),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("ROUNDEDCORNERS", [6, 6, 6, 6]),
    ]))
    return t


def generer_fiche(patient, seances):
    st = _styles()
    buf = io.BytesIO()
    marge = 18 * mm
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=marge, rightMargin=marge, topMargin=16 * mm, bottomMargin=16 * mm,
        title="Bilan kinésithérapie", author="Cabinet kiné",
    )
    util = A4[0] - 2 * marge
    story = []

    nom = f"{patient.get('nom','')} {patient.get('prenom','')}".strip()

    # En-tête
    gauche = [
        Paragraph("BILAN KINÉSITHÉRAPIE", st["eyebrow"]),
        Paragraph(nom or "Patient", st["titre"]),
    ]
    sous = []
    if patient.get("naissance"):
        sous.append("Né(e) le " + _jolie_date(patient["naissance"]))
    sous.append("Édité le " + date.today().strftime("%d/%m/%Y"))
    gauche.append(Paragraph(" · ".join(sous), st["sous"]))
    story.append(Table([[gauche]], colWidths=[util], style=TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LINEBELOW", (0, 0), (-1, -1), 1, LIGNE),
    ])))
    story.append(Spacer(1, 14))

    # Pathologie + objectifs
    col = (util - 12) / 2.0
    story.append(_bloc_clef("Pathologie", patient.get("pathologie"), st, accent=True))
    story.append(Spacer(1, 8))
    obj = Table(
        [[_bloc_clef("Objectif court terme", patient.get("objectif_court"), st),
          _bloc_clef("Objectif long terme", patient.get("objectif_long"), st)]],
        colWidths=[col, col],
    )
    obj.setStyle(TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (0, 0), 12),
        ("RIGHTPADDING", (1, 0), (1, 0), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(obj)
    story.append(Spacer(1, 14))

    # Note libre
    if patient.get("note_libre"):
        story.append(Paragraph("Note", st["h2"]))
        note = Table([[Paragraph(patient["note_libre"].replace("\n", "<br/>"), st["base"])]],
                     colWidths=[util])
        note.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), HexColor("#FFFDF6")),
            ("BOX", (0, 0), (-1, -1), 0.7, HexColor("#F0E4BE")),
            ("LEFTPADDING", (0, 0), (-1, -1), 10), ("RIGHTPADDING", (0, 0), (-1, -1), 10),
            ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(note)
        story.append(Spacer(1, 14))

    seances = sorted(seances, key=lambda s: s.get("date_seance", ""))
    points = [{"date": s["date_seance"], "d": s["douleur"]}
              for s in seances if s.get("douleur")]

    # Graphe douleur
    if points:
        bloc = [Paragraph("Évolution de la douleur (EVA)", st["h2"]),
                _graphe_douleur(points, util)]
        story.append(KeepTogether(bloc))
        story.append(Spacer(1, 14))

    # Historique des séances
    story.append(Paragraph("Historique des séances", st["h2"]))
    if seances:
        entete = [Paragraph("<b>Date</b>", st["cell"]),
                  Paragraph("<b>EVA</b>", st["cell"]),
                  Paragraph("<b>Séance</b>", st["cell"])]
        lignes = [entete]
        for s in reversed(seances):  # plus récentes d'abord
            eva = str(s["douleur"]) if s.get("douleur") else "—"
            fait = (s.get("fait") or "").replace("\n", "<br/>") or "<i>—</i>"
            lignes.append([
                Paragraph(_jolie_date(s["date_seance"]), st["cellmuted"]),
                Paragraph(eva, st["cell"]),
                Paragraph(fait, st["cell"]),
            ])
        tbl = Table(lignes, colWidths=[24 * mm, 14 * mm, util - 38 * mm], repeatRows=1)
        style = [
            ("LINEBELOW", (0, 0), (-1, 0), 0.8, ACCENT),
            ("LINEBELOW", (0, 1), (-1, -1), 0.4, LIGNE),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ]
        for i, s in enumerate(reversed(seances), start=1):
            if s.get("douleur"):
                style.append(("TEXTCOLOR", (1, i), (1, i), _coul(s["douleur"])))
                style.append(("FONTNAME", (1, i), (1, i), "Helvetica-Bold"))
        tbl.setStyle(TableStyle(style))
        story.append(tbl)
    else:
        story.append(Paragraph("Aucune séance enregistrée.", st["cellmuted"]))

    def pied(canvas, doc_):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(MUTED)
        canvas.drawString(marge, 10 * mm, "Document confidentiel — secret médical")
        canvas.drawRightString(A4[0] - marge, 10 * mm, "Page %d" % doc_.page)
        canvas.restoreState()

    doc.build(story, onFirstPage=pied, onLaterPages=pied)
    return buf.getvalue()
