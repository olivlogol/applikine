#!/bin/bash
# ============================================================================
#  Cabinet kine — installateur macOS (double-cliquable)
#  Cree ~/cabinet-kine et un lanceur « demarrer.command » double-cliquable.
#  Sans Homebrew : utilise Python 3 des outils Apple.
# ============================================================================
cd "$HOME" || exit 1
info(){ echo "  $1"; }

echo ""
echo "  Installation du Cabinet kine (macOS)..."
echo ""

# 1) Python 3 (outils de developpement Apple)
if ! command -v python3 >/dev/null 2>&1; then
  echo "  Python 3 n'est pas encore installe."
  echo "  Une fenetre Apple va proposer d'installer les outils de developpement."
  echo "  -> Cliquez sur « Installer », attendez la fin, puis RELANCEZ ce fichier."
  xcode-select --install 2>/dev/null
  echo ""
  echo "  (Appuyez sur Entree pour fermer cette fenetre.)"
  read -r _
  exit 0
fi

APP="$HOME/cabinet-kine"
mkdir -p "$APP/templates" "$APP/static"

# 2) Environnement Python isole + dependances
info "Preparation de l'environnement Python..."
python3 -m venv "$APP/venv" || { echo "  Echec de creation de l'environnement."; read -r _; exit 1; }
source "$APP/venv/bin/activate"
pip install --upgrade pip >/dev/null 2>&1
info "Installation des dependances (cela peut prendre quelques minutes)..."
pip install flask reportlab cryptography faster-whisper || { echo "  Echec d'installation des dependances."; read -r _; exit 1; }

# 3) Fichiers de l'application
info "Ecriture des fichiers de l'application..."
info "  · app.py"
cat > "$APP/app.py" << '__FIN_APP_PY__'
#!/usr/bin/env python3
"""Cabinet kiné — socle de gestion (espace kiné uniquement).

Application web LOCALE pour un cabinet de kinésithérapie :
  - dossiers patients (pathologie, objectifs court/long terme, note libre),
  - calendrier par patient avec annotation des séances,
  - niveau de douleur (EVA 1-10) par séance + graphique d'évolution.

Tout reste sur la machine : base SQLite locale, aucun envoi en ligne.
Sert une interface sur http://127.0.0.1:5001
"""
import os
import io
import sqlite3
import secrets
import tempfile
import random
import calendar
import re
import socket
from datetime import datetime, date, timedelta, timezone
from functools import wraps

from flask import (
    Flask, request, session, redirect, url_for,
    render_template, jsonify, abort, flash, g, send_file,
)
from werkzeug.security import generate_password_hash as _gen_hash, check_password_hash


def generate_password_hash(secret):
    """Hachage portable. pbkdf2 plutôt que scrypt : certains Python de macOS
    n'ont pas hashlib.scrypt (compilés sans le scrypt d'OpenSSL)."""
    return _gen_hash(secret, method="pbkdf2:sha256")

ICI = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ICI, "cabinet.db")
SECRET_FILE = os.path.join(ICI, ".secret")

# Le module de transcription vocale est optionnel (installé séparément).
try:
    import transcription
    import resume
    AUDIO_DISPO = True
except Exception:
    AUDIO_DISPO = False


def cle_secrete():
    """Clé de session persistante (pour rester connecté entre redémarrages)."""
    if os.path.exists(SECRET_FILE):
        with open(SECRET_FILE) as f:
            return f.read().strip()
    cle = secrets.token_hex(32)
    with open(SECRET_FILE, "w") as f:
        f.write(cle)
    os.chmod(SECRET_FILE, 0o600)
    return cle


app = Flask(__name__)
app.secret_key = cle_secrete()


# --------------------------------------------------------------------------
#  Base de données
# --------------------------------------------------------------------------
def co():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def fermer_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


ADMIN_DEFAUT_ID = "admin"
ADMIN_DEFAUT_MDP = "admin"
QUESTION_DEFAUT = "Quelle est la marque de ma première voiture ?"
REPONSE_DEFAUT = "citroen"


def init_db():
    db = sqlite3.connect(DB)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS kine (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            identifiant TEXT UNIQUE NOT NULL,
            mdp_hash    TEXT NOT NULL,
            cree_le     TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS patients (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            prenom          TEXT NOT NULL,
            nom             TEXT NOT NULL,
            naissance       TEXT,
            pathologie      TEXT,
            objectif_court  TEXT,
            objectif_long   TEXT,
            note_libre      TEXT,
            archive         INTEGER NOT NULL DEFAULT 0,
            cree_le         TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS seances (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id  INTEGER NOT NULL,
            date_seance TEXT NOT NULL,
            heure       TEXT,
            fait        TEXT,
            douleur     INTEGER,
            cree_le     TEXT NOT NULL,
            UNIQUE(patient_id, date_seance),
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS praticiens (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            nom     TEXT UNIQUE NOT NULL,
            cree_le TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS config (
            cle    TEXT PRIMARY KEY,
            valeur TEXT
        );
        """
    )
    db.commit()
    # Migration : marqueur des patients de démonstration
    cols = [r[1] for r in db.execute("PRAGMA table_info(patients)").fetchall()]
    if "demo" not in cols:
        db.execute("ALTER TABLE patients ADD COLUMN demo INTEGER NOT NULL DEFAULT 0")
        db.commit()
    # Migration : heure des séances (créneaux)
    cols_s = [r[1] for r in db.execute("PRAGMA table_info(seances)").fetchall()]
    if "heure" not in cols_s:
        db.execute("ALTER TABLE seances ADD COLUMN heure TEXT")
        db.commit()
    if "praticien" not in cols_s:
        db.execute("ALTER TABLE seances ADD COLUMN praticien TEXT")
        db.commit()
    # Migration : rôle des comptes
    cols_k = [r[1] for r in db.execute("PRAGMA table_info(kine)").fetchall()]
    if "role" not in cols_k:
        db.execute("ALTER TABLE kine ADD COLUMN role TEXT NOT NULL DEFAULT 'praticien'")
        db.commit()
    if "question" not in cols_k:
        db.execute("ALTER TABLE kine ADD COLUMN question TEXT")
        db.commit()
    if "reponse_hash" not in cols_k:
        db.execute("ALTER TABLE kine ADD COLUMN reponse_hash TEXT")
        db.commit()
    # Compte administrateur par défaut : garanti tant que son mot de passe
    # est encore celui par défaut (sinon on respecte le mot de passe choisi).
    rep_def = generate_password_hash(REPONSE_DEFAUT.strip().upper())
    admin = db.execute(
        "SELECT mdp_hash FROM kine WHERE identifiant = ?", (ADMIN_DEFAUT_ID,)
    ).fetchone()
    if admin is None:
        db.execute(
            "INSERT INTO kine (identifiant, mdp_hash, role, question, reponse_hash, cree_le) "
            "VALUES (?,?,?,?,?,?)",
            (ADMIN_DEFAUT_ID, generate_password_hash(ADMIN_DEFAUT_MDP), "admin",
             QUESTION_DEFAUT, rep_def, datetime.now().isoformat(timespec="seconds")),
        )
        db.commit()
    elif check_password_hash(admin[0], ADMIN_DEFAUT_MDP):
        db.execute(
            "UPDATE kine SET role = 'admin', question = ?, reponse_hash = ? "
            "WHERE identifiant = ?",
            (QUESTION_DEFAUT, rep_def, ADMIN_DEFAUT_ID),
        )
        db.commit()
    # Un seul administrateur : tout autre compte est un praticien
    db.execute(
        "UPDATE kine SET role = 'praticien' WHERE identifiant <> ? AND role = 'admin'",
        (ADMIN_DEFAUT_ID,),
    )
    db.commit()
    db.close()


def normaliser_heure(v):
    """Renvoie 'HH:00' ou 'HH:30' (créneaux de 30 min), ou None."""
    v = (v or "").strip()
    if not v:
        return None
    try:
        parts = v.split(":")
        h, m = int(parts[0]), int(parts[1])
        if 0 <= h <= 23:
            return "%02d:%02d" % (h, 0 if m < 30 else 30)
    except (ValueError, IndexError):
        pass
    return None


PALETTE_PRAT = ["#5A4FE3", "#1F9D6B", "#E0A100", "#2563EB", "#D6409F",
                "#0E8FA8", "#C2410C", "#7C3AED"]


def liste_praticiens():
    return [r["identifiant"] for r in co().execute(
        "SELECT identifiant FROM kine WHERE role = 'praticien' ORDER BY id"
    ).fetchall()]


def praticiens_couleurs():
    rows = co().execute(
        "SELECT id, identifiant FROM kine WHERE role = 'praticien' ORDER BY id"
    ).fetchall()
    return {r["identifiant"]: PALETTE_PRAT[(r["id"] - 1) % len(PALETTE_PRAT)] for r in rows}


def praticien_valide(v):
    v = (v or "").strip()
    return v if v in liste_praticiens() else None


# -- Administration (réservée au compte de rôle « admin ») --
def est_admin():
    return bool(session.get("est_admin"))


def _norm_reponse(v):
    return (v or "").strip().upper()


def admin_requise(vue):
    @wraps(vue)
    def wrap(*a, **kw):
        if not session.get("kine_id"):
            return redirect(url_for("connexion"))
        if not est_admin():
            flash("Cette section est réservée à l'administrateur.")
            return redirect(url_for("dashboard"))
        return vue(*a, **kw)
    return wrap


def maintenant():
    return datetime.now().isoformat(timespec="seconds")


# --------------------------------------------------------------------------
#  Authentification
# --------------------------------------------------------------------------
def compte_existe():
    return co().execute("SELECT 1 FROM kine LIMIT 1").fetchone() is not None


def connexion_requise(vue):
    @wraps(vue)
    def wrap(*a, **kw):
        if not session.get("kine_id"):
            return redirect(url_for("connexion"))
        return vue(*a, **kw)
    return wrap


@app.route("/")
def accueil():
    if not compte_existe():
        return redirect(url_for("setup"))
    if not session.get("kine_id"):
        return redirect(url_for("connexion"))
    return redirect(url_for("dashboard"))


@app.route("/bienvenue", methods=["GET", "POST"])
def setup():
    """Création du premier (et unique) compte kiné. Pas de mot de passe par défaut."""
    if compte_existe():
        return redirect(url_for("connexion"))
    if request.method == "POST":
        ident = (request.form.get("identifiant") or "").strip()
        mdp = request.form.get("mdp") or ""
        mdp2 = request.form.get("mdp2") or ""
        question = (request.form.get("question") or "").strip()
        reponse = (request.form.get("reponse") or "").strip()
        if len(ident) < 3:
            flash("L'identifiant doit faire au moins 3 caractères.")
        elif len(mdp) < 6:
            flash("Le mot de passe doit faire au moins 6 caractères.")
        elif mdp != mdp2:
            flash("Les deux mots de passe ne correspondent pas.")
        elif not question or not reponse:
            flash("Veuillez renseigner la question de sécurité et sa réponse.")
        else:
            co().execute(
                "INSERT INTO kine (identifiant, mdp_hash, role, question, reponse_hash, cree_le) "
                "VALUES (?,?,?,?,?,?)",
                (ident, generate_password_hash(mdp), "admin", question,
                 generate_password_hash(_norm_reponse(reponse)), maintenant()),
            )
            co().commit()
            ligne = co().execute(
                "SELECT id FROM kine WHERE identifiant = ?", (ident,)
            ).fetchone()
            session["kine_id"] = ligne["id"]
            session["est_admin"] = True
            return redirect(url_for("dashboard"))
    return render_template("setup.html")


@app.route("/connexion", methods=["GET", "POST"])
def connexion():
    if not compte_existe():
        return redirect(url_for("setup"))
    if request.method == "POST":
        ident = (request.form.get("identifiant") or "").strip()
        mdp = request.form.get("mdp") or ""
        ligne = co().execute(
            "SELECT * FROM kine WHERE identifiant = ?", (ident,)
        ).fetchone()
        if ligne and check_password_hash(ligne["mdp_hash"], mdp):
            session["kine_id"] = ligne["id"]
            session["est_admin"] = (ligne["role"] == "admin")
            return redirect(url_for("dashboard"))
        flash("Identifiant ou mot de passe incorrect.")
    return render_template("connexion.html")


@app.route("/deconnexion")
def deconnexion():
    session.clear()
    return redirect(url_for("connexion"))


@app.route("/mot-de-passe-oublie", methods=["GET", "POST"])
def mdp_oublie():
    if not compte_existe():
        return redirect(url_for("setup"))
    if request.method == "POST":
        ident = (request.form.get("identifiant") or "").strip()
        compte = co().execute(
            "SELECT * FROM kine WHERE identifiant = ?", (ident,)
        ).fetchone()
        if not compte or not compte["question"] or not compte["reponse_hash"]:
            flash("Aucune question de sécurité n'est configurée pour cet identifiant.")
            return render_template("mdp_oublie.html", etape=1)
        # Étape 2 : la réponse et le nouveau mot de passe sont fournis
        if "reponse" in request.form:
            if not check_password_hash(compte["reponse_hash"],
                                       _norm_reponse(request.form.get("reponse"))):
                flash("Réponse incorrecte.")
            else:
                mdp = request.form.get("mdp") or ""
                mdp2 = request.form.get("mdp2") or ""
                if len(mdp) < 6:
                    flash("Le mot de passe doit faire au moins 6 caractères.")
                elif mdp != mdp2:
                    flash("Les deux mots de passe ne correspondent pas.")
                else:
                    co().execute("UPDATE kine SET mdp_hash = ? WHERE id = ?",
                                 (generate_password_hash(mdp), compte["id"]))
                    co().commit()
                    flash("Mot de passe réinitialisé. Vous pouvez vous connecter.")
                    return redirect(url_for("connexion"))
            return render_template("mdp_oublie.html", etape=2, identifiant=ident,
                                   question=compte["question"])
        # Étape 1 -> 2 : afficher la question de ce compte
        return render_template("mdp_oublie.html", etape=2, identifiant=ident,
                               question=compte["question"])
    return render_template("mdp_oublie.html", etape=1)


@app.route("/securite", methods=["GET", "POST"])
@connexion_requise
def securite():
    compte = co().execute(
        "SELECT * FROM kine WHERE id = ?", (session["kine_id"],)
    ).fetchone()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "mdp":
            ancien = request.form.get("ancien") or ""
            mdp = request.form.get("mdp") or ""
            mdp2 = request.form.get("mdp2") or ""
            if not check_password_hash(compte["mdp_hash"], ancien):
                flash("Mot de passe actuel incorrect.")
            elif len(mdp) < 6:
                flash("Le nouveau mot de passe doit faire au moins 6 caractères.")
            elif mdp != mdp2:
                flash("Les deux mots de passe ne correspondent pas.")
            else:
                co().execute("UPDATE kine SET mdp_hash = ? WHERE id = ?",
                             (generate_password_hash(mdp), compte["id"]))
                co().commit()
                flash("Mot de passe modifié.")
        elif action == "question":
            question = (request.form.get("question") or "").strip()
            reponse = (request.form.get("reponse") or "").strip()
            if not question or not reponse:
                flash("Question et réponse sont requises.")
            else:
                co().execute("UPDATE kine SET question = ?, reponse_hash = ? WHERE id = ?",
                             (question, generate_password_hash(_norm_reponse(reponse)),
                              compte["id"]))
                co().commit()
                flash("Question de sécurité enregistrée.")
        return redirect(url_for("securite"))
    return render_template("securite.html", compte=compte)


# --------------------------------------------------------------------------
#  Tableau de bord
# --------------------------------------------------------------------------
@app.route("/dashboard")
@connexion_requise
def dashboard():
    patients = co().execute(
        """
        SELECT p.*,
               (SELECT COUNT(*) FROM seances s WHERE s.patient_id = p.id) AS nb_seances,
               (SELECT MAX(date_seance) FROM seances s WHERE s.patient_id = p.id) AS derniere,
               (SELECT douleur FROM seances s WHERE s.patient_id = p.id
                  AND douleur IS NOT NULL ORDER BY date_seance DESC LIMIT 1) AS douleur_recente
        FROM patients p
        WHERE p.archive = 0
        ORDER BY p.nom COLLATE NOCASE, p.prenom COLLATE NOCASE
        """
    ).fetchall()
    nb_archives = co().execute(
        "SELECT COUNT(*) AS n FROM patients WHERE archive = 1"
    ).fetchone()["n"]
    return render_template("dashboard.html", patients=patients, nb_archives=nb_archives)


@app.route("/archives")
@connexion_requise
def archives():
    patients = co().execute(
        "SELECT * FROM patients WHERE archive = 1 ORDER BY nom COLLATE NOCASE"
    ).fetchall()
    return render_template("archives.html", patients=patients)


@app.route("/calendrier")
@connexion_requise
def calendrier():
    return render_template("calendrier.html")


@app.route("/agenda.json")
@connexion_requise
def agenda_json():
    lignes = co().execute(
        """SELECT s.date_seance, s.heure, s.douleur, s.fait, s.praticien,
                  p.id AS patient_id, p.prenom, p.nom, p.archive
           FROM seances s JOIN patients p ON p.id = s.patient_id
           ORDER BY s.date_seance, s.heure IS NULL, s.heure,
                    p.nom COLLATE NOCASE, p.prenom COLLATE NOCASE"""
    ).fetchall()
    return jsonify([dict(x) for x in lignes])


@app.route("/patients.json")
@connexion_requise
def patients_json():
    rows = co().execute(
        "SELECT id, prenom, nom FROM patients WHERE archive = 0 "
        "ORDER BY nom COLLATE NOCASE, prenom COLLATE NOCASE"
    ).fetchall()
    return jsonify([dict(r) for r in rows])


# --------------------------------------------------------------------------
#  Dossiers patients
# --------------------------------------------------------------------------
def get_patient(pid):
    p = co().execute("SELECT * FROM patients WHERE id = ?", (pid,)).fetchone()
    if p is None:
        abort(404)
    return p


@app.route("/patient/nouveau", methods=["GET", "POST"])
@connexion_requise
def patient_nouveau():
    if request.method == "POST":
        prenom = (request.form.get("prenom") or "").strip()
        nom = (request.form.get("nom") or "").strip()
        if not prenom or not nom:
            flash("Le prénom et le nom sont obligatoires.")
            return render_template("patient_form.html", patient=request.form, mode="nouveau")
        cur = co().execute(
            """INSERT INTO patients
               (prenom, nom, naissance, pathologie, objectif_court, objectif_long,
                note_libre, cree_le)
               VALUES (?,?,?,?,?,?,?,?)""",
            (
                prenom, nom,
                request.form.get("naissance") or None,
                request.form.get("pathologie") or None,
                request.form.get("objectif_court") or None,
                request.form.get("objectif_long") or None,
                request.form.get("note_libre") or None,
                maintenant(),
            ),
        )
        co().commit()
        return redirect(url_for("patient", pid=cur.lastrowid))
    return render_template("patient_form.html", patient={}, mode="nouveau")


@app.route("/patient/<int:pid>")
@connexion_requise
def patient(pid):
    p = get_patient(pid)
    seances = co().execute(
        "SELECT * FROM seances WHERE patient_id = ? ORDER BY date_seance DESC", (pid,)
    ).fetchall()
    return render_template("patient.html", p=p, seances=seances)


@app.route("/patient/<int:pid>/modifier", methods=["GET", "POST"])
@connexion_requise
def patient_modifier(pid):
    p = get_patient(pid)
    if request.method == "POST":
        prenom = (request.form.get("prenom") or "").strip()
        nom = (request.form.get("nom") or "").strip()
        if not prenom or not nom:
            flash("Le prénom et le nom sont obligatoires.")
            return render_template("patient_form.html", patient=request.form, mode="modifier")
        co().execute(
            """UPDATE patients SET prenom=?, nom=?, naissance=?, pathologie=?,
               objectif_court=?, objectif_long=?, note_libre=? WHERE id=?""",
            (
                prenom, nom,
                request.form.get("naissance") or None,
                request.form.get("pathologie") or None,
                request.form.get("objectif_court") or None,
                request.form.get("objectif_long") or None,
                request.form.get("note_libre") or None,
                pid,
            ),
        )
        co().commit()
        return redirect(url_for("patient", pid=pid))
    return render_template("patient_form.html", patient=p, mode="modifier")


@app.route("/patient/<int:pid>/note", methods=["POST"])
@connexion_requise
def patient_note(pid):
    get_patient(pid)
    co().execute(
        "UPDATE patients SET note_libre = ? WHERE id = ?",
        (request.form.get("note_libre") or None, pid),
    )
    co().commit()
    return redirect(url_for("patient", pid=pid))


@app.route("/patient/<int:pid>/archiver", methods=["POST"])
@connexion_requise
def patient_archiver(pid):
    get_patient(pid)
    co().execute("UPDATE patients SET archive = 1 WHERE id = ?", (pid,))
    co().commit()
    flash("Patient archivé.")
    return redirect(url_for("dashboard"))


@app.route("/patient/<int:pid>/restaurer", methods=["POST"])
@connexion_requise
def patient_restaurer(pid):
    get_patient(pid)
    co().execute("UPDATE patients SET archive = 0 WHERE id = ?", (pid,))
    co().commit()
    return redirect(url_for("patient", pid=pid))


# --------------------------------------------------------------------------
#  Séances (annotation depuis le calendrier + douleur)
# --------------------------------------------------------------------------
@app.route("/patient/<int:pid>/seance", methods=["POST"])
@connexion_requise
def seance_enregistrer(pid):
    get_patient(pid)
    date_seance = (request.form.get("date_seance") or "").strip()
    if not date_seance:
        abort(400)
    fait = request.form.get("fait") or None
    douleur_brut = request.form.get("douleur")
    douleur = None
    if douleur_brut not in (None, "", "0"):
        try:
            d = int(douleur_brut)
            if 1 <= d <= 10:
                douleur = d
        except ValueError:
            douleur = None
    # heure et praticien : modifiés uniquement s'ils sont explicitement envoyés
    # (permet de les changer/vider depuis la modale sans casser le bilan oral)
    maj_heure = "heure" in request.form
    maj_prat = "praticien" in request.form
    heure = normaliser_heure(request.form.get("heure")) if maj_heure else None
    prat = praticien_valide(request.form.get("praticien")) if maj_prat else None
    db = co()
    db.execute(
        """INSERT INTO seances (patient_id, date_seance, heure, praticien, fait, douleur, cree_le)
           VALUES (?,?,?,?,?,?,?)
           ON CONFLICT(patient_id, date_seance)
           DO UPDATE SET fait=excluded.fait, douleur=excluded.douleur""",
        (pid, date_seance, heure, prat, fait, douleur, maintenant()),
    )
    if maj_heure:
        db.execute("UPDATE seances SET heure=? WHERE patient_id=? AND date_seance=?",
                   (heure, pid, date_seance))
    if maj_prat:
        db.execute("UPDATE seances SET praticien=? WHERE patient_id=? AND date_seance=?",
                   (prat, pid, date_seance))
    db.commit()
    if request.form.get("ajax"):
        return jsonify({"ok": True})
    return redirect(url_for("patient", pid=pid) + "#seances")


@app.route("/patient/<int:pid>/creneau", methods=["POST"])
@connexion_requise
def creneau_enregistrer(pid):
    """Assigne un patient à un créneau (date + heure) sans toucher au compte-rendu."""
    get_patient(pid)
    date_seance = (request.form.get("date") or "").strip()
    heure = normaliser_heure(request.form.get("heure"))
    prat = praticien_valide(request.form.get("praticien"))
    if not date_seance or not heure:
        abort(400)
    co().execute(
        """INSERT INTO seances (patient_id, date_seance, heure, praticien, cree_le)
           VALUES (?,?,?,?,?)
           ON CONFLICT(patient_id, date_seance)
           DO UPDATE SET heure=excluded.heure, praticien=excluded.praticien""",
        (pid, date_seance, heure, prat, maintenant()),
    )
    co().commit()
    return jsonify({"ok": True})


@app.route("/patient/<int:pid>/seance/<int:sid>/supprimer", methods=["POST"])
@connexion_requise
def seance_supprimer(pid, sid):
    get_patient(pid)
    co().execute("DELETE FROM seances WHERE id = ? AND patient_id = ?", (sid, pid))
    co().commit()
    return redirect(url_for("patient", pid=pid) + "#seances")


@app.route("/patient/<int:pid>/seances.json")
@connexion_requise
def seances_json(pid):
    get_patient(pid)
    lignes = co().execute(
        "SELECT id, date_seance, heure, praticien, fait, douleur FROM seances WHERE patient_id = ? ORDER BY date_seance",
        (pid,),
    ).fetchall()
    return jsonify([dict(x) for x in lignes])


@app.route("/patient/<int:pid>/pdf")
@connexion_requise
def patient_pdf(pid):
    p = get_patient(pid)
    seances = co().execute(
        "SELECT * FROM seances WHERE patient_id = ? ORDER BY date_seance", (pid,)
    ).fetchall()
    try:
        import pdf_export
    except Exception:
        abort(500, "Export PDF indisponible (reportlab non installé).")
    data = pdf_export.generer_fiche(dict(p), [dict(s) for s in seances])
    base = "bilan_%s_%s" % (p["nom"], p["prenom"])
    nom = "".join(c if (c.isalnum() or c in "-_") else "_" for c in base) + ".pdf"
    return send_file(io.BytesIO(data), mimetype="application/pdf",
                     as_attachment=True, download_name=nom)


@app.route("/reformuler", methods=["POST"])
@connexion_requise
def reformuler():
    """Réécrit un texte de séance via le modèle local (clarté/orthographe)."""
    if not AUDIO_DISPO:
        return jsonify({"erreur": "Module IA non installé."}), 400
    res = resume.reformuler(request.form.get("texte", ""))
    return jsonify(res)


@app.route("/patient/<int:pid>/bilan", methods=["POST"])
@connexion_requise
def bilan_oral(pid):
    """Reçoit la dictée, transcrit en local puis résume. Rien n'est envoyé en ligne."""
    if not AUDIO_DISPO:
        return jsonify({"erreur": "Module audio non installé."}), 400
    get_patient(pid)
    if "audio" not in request.files:
        return jsonify({"erreur": "Aucun audio reçu."}), 400
    fichier = request.files["audio"]
    suffixe = os.path.splitext(fichier.filename or "")[1] or ".webm"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffixe) as tmp:
        fichier.save(tmp.name)
        chemin = tmp.name
    try:
        tr = transcription.transcrire(chemin)
        texte = tr.get("texte", "")
        res = resume.resumer(texte)
        return jsonify({
            "transcription": texte,
            "resume": res.get("resume", ""),
            "moteur": res.get("moteur", ""),
            "douleur": resume.detecter_douleur(texte),
            "duree": tr.get("duree"),
        })
    except Exception as e:  # noqa: BLE001
        return jsonify({"erreur": str(e)}), 500
    finally:
        try:
            os.remove(chemin)
        except OSError:
            pass


# --------------------------------------------------------------------------
#  Données de test (patients fictifs, marqués demo=1, supprimables)
# --------------------------------------------------------------------------
_PRENOMS = ["Marie", "Jean", "Sophie", "Luc", "Alice", "Paul", "Emma", "Thomas",
            "Julie", "Pierre", "Camille", "Nicolas", "Léa", "Hugo", "Chloé",
            "Antoine", "Manon", "Louis", "Sarah", "Maxime", "Inès", "Théo",
            "Clara", "Lucas", "Eva", "Nathan", "Jade", "Gabriel", "Lola", "Adam"]
_NOMS = ["Durand", "Petit", "Martin", "Bernard", "Dubois", "Moreau", "Laurent",
         "Simon", "Michel", "Lefebvre", "Garcia", "Roux", "Fontaine", "Girard",
         "Bonnet", "Dupont", "Lambert", "Rousseau", "Vincent", "Muller", "Faure",
         "André", "Mercier", "Blanc", "Guérin", "Boyer", "Garnier", "Chevalier"]
_PATHOS = ["Lombalgie chronique", "Tendinopathie de l'épaule", "Entorse de la cheville",
           "Rééducation post-prothèse de genou", "Cervicalgie", "Syndrome rotulien",
           "Capsulite rétractile", "Lombosciatique", "Rupture du LCA (post-op)",
           "Périarthrite scapulo-humérale"]
_ACTES = ["Mobilisations passives et actives.", "Renforcement musculaire progressif.",
          "Étirements et travail proprioceptif.", "Massage décontracturant et physiothérapie.",
          "Travail de l'équilibre et de la marche.", "Exercices de gainage.",
          "Rééducation fonctionnelle.", "Travail excentrique progressif."]
_OBJ_C = ["Réduire la douleur sous 3 semaines.", "Récupérer l'amplitude articulaire.",
          "Diminuer l'inflammation.", "Reprendre la marche sans canne."]
_OBJ_L = ["Reprise du sport sans appréhension.", "Retour au travail.",
          "Autonomie complète au quotidien.", "Prévention des récidives."]


def _creer_patient_demo(db):
    cur = db.execute(
        """INSERT INTO patients
           (prenom, nom, naissance, pathologie, objectif_court, objectif_long,
            note_libre, demo, cree_le)
           VALUES (?,?,?,?,?,?,?,1,?)""",
        (random.choice(_PRENOMS), random.choice(_NOMS), None,
         random.choice(_PATHOS), random.choice(_OBJ_C), random.choice(_OBJ_L),
         "[Données de démonstration]", maintenant()),
    )
    return cur.lastrowid


def _heure_creneau_demo():
    """Heure de créneau aléatoire alignée sur :00/:30, entre 07:00 et 19:30."""
    m = random.randrange(7 * 60, 20 * 60, 30)
    return "%02d:%02d" % (m // 60, m % 60)


def _ajouter_seance_demo(db, pid, jour_iso, prats):
    db.execute(
        "INSERT INTO seances (patient_id, date_seance, heure, praticien, fait, douleur, cree_le) "
        "VALUES (?,?,?,?,?,?,?)",
        (pid, jour_iso, _heure_creneau_demo(), (random.choice(prats) if prats else None),
         random.choice(_ACTES), random.randint(1, 10), maintenant()),
    )


# --------------------------------------------------------------------------
#  Administration (réservée au compte admin) : comptes, praticiens, démo
# --------------------------------------------------------------------------
@app.route("/admin")
@admin_requise
def admin_panel():
    comptes = co().execute(
        "SELECT id, identifiant, role FROM kine ORDER BY role DESC, identifiant COLLATE NOCASE"
    ).fetchall()
    nb_demo = co().execute(
        "SELECT COUNT(*) AS n FROM patients WHERE demo = 1"
    ).fetchone()["n"]
    return render_template("admin_panel.html", comptes=comptes,
                           couleurs=praticiens_couleurs(),
                           nb_demo=nb_demo, aujourdhui=date.today().isoformat(),
                           moi=session.get("kine_id"))


@app.route("/admin/comptes/ajouter", methods=["POST"])
@admin_requise
def admin_compte_ajouter():
    ident = (request.form.get("identifiant") or "").strip()
    mdp = request.form.get("mdp") or ""
    if len(ident) < 3 or len(ident) > 40:
        flash("Le nom/identifiant doit faire entre 3 et 40 caractères.")
    elif len(mdp) < 6:
        flash("Le mot de passe doit faire au moins 6 caractères.")
    else:
        try:
            co().execute(
                "INSERT INTO kine (identifiant, mdp_hash, role, cree_le) VALUES (?,?,?,?)",
                (ident, generate_password_hash(mdp), "praticien", maintenant()),
            )
            co().commit()
            flash("Praticien « %s » ajouté (il peut se connecter avec ce nom)." % ident)
        except sqlite3.IntegrityError:
            flash("Ce nom/identifiant existe déjà.")
    return redirect(url_for("admin_panel") + "#praticiens")


@app.route("/admin/comptes/<int:compte_id>/supprimer", methods=["POST"])
@admin_requise
def admin_compte_supprimer(compte_id):
    if compte_id == session.get("kine_id"):
        flash("Vous ne pouvez pas supprimer votre propre compte.")
        return redirect(url_for("admin_panel") + "#praticiens")
    row = co().execute("SELECT role FROM kine WHERE id = ?", (compte_id,)).fetchone()
    if row and row["role"] == "admin":
        flash("Le compte administrateur ne peut pas être supprimé.")
        return redirect(url_for("admin_panel") + "#praticiens")
    co().execute("DELETE FROM kine WHERE id = ?", (compte_id,))
    co().commit()
    flash("Praticien retiré. Il ne sera plus proposé ; les séances passées "
          "conservent son nom.")
    return redirect(url_for("admin_panel") + "#praticiens")


# -- Données de test (réservées à l'admin) --
@app.route("/test/jour", methods=["POST"])
@admin_requise
def test_jour():
    jour = (request.form.get("date") or date.today().isoformat()).strip()
    try:
        nombre = max(1, min(150, int(request.form.get("nombre") or 25)))
    except ValueError:
        nombre = 25
    db = co()
    prats = liste_praticiens()
    for _ in range(nombre):
        _ajouter_seance_demo(db, _creer_patient_demo(db), jour, prats)
    db.commit()
    flash("%d patient(s) de démo ajouté(s) le %s." % (nombre, jour))
    return redirect(url_for("admin_panel") + "#donnees")


@app.route("/test/mois", methods=["POST"])
@admin_requise
def test_mois():
    val = (request.form.get("aaaamm") or "").strip()
    try:
        annee, mois = int(val[:4]), int(val[5:7])
    except (ValueError, IndexError):
        t = date.today()
        annee, mois = t.year, t.month
    try:
        nombre = max(1, min(400, int(request.form.get("nombre") or 60)))
    except ValueError:
        nombre = 60
    njours = calendar.monthrange(annee, mois)[1]
    db = co()
    prats = liste_praticiens()
    for _ in range(nombre):
        jour = "%04d-%02d-%02d" % (annee, mois, random.randint(1, njours))
        _ajouter_seance_demo(db, _creer_patient_demo(db), jour, prats)
    db.commit()
    flash("%d séance(s) de démo réparties sur %02d/%04d." % (nombre, mois, annee))
    return redirect(url_for("admin_panel") + "#donnees")


@app.route("/test/purge", methods=["POST"])
@admin_requise
def test_purge():
    db = co()
    db.execute("DELETE FROM seances WHERE patient_id IN (SELECT id FROM patients WHERE demo = 1)")
    db.execute("DELETE FROM patients WHERE demo = 1")
    db.commit()
    flash("Données de démonstration supprimées.")
    return redirect(url_for("admin_panel") + "#donnees")


@app.context_processor
def injecter():
    return {
        "AUDIO_DISPO": AUDIO_DISPO,
        "LLM_DISPO": AUDIO_DISPO,
        "praticiens": liste_praticiens(),
        "praticiens_couleurs": praticiens_couleurs(),
        "est_admin": est_admin(),
        "annee": datetime.now().year,
        "aujourdhui": date.today().isoformat(),
    }


def ip_locale():
    """Adresse IP du PC sur le réseau local (sans rien émettre), sinon None."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except OSError:
        ip = None
    finally:
        s.close()
    return ip


def generer_certificat(cert_path, key_path, ip):
    """Crée un certificat auto-signé (localhost + IP locale) pour servir en HTTPS.

    Le micro des navigateurs n'est autorisé qu'en contexte sécurisé (HTTPS ou
    localhost) : le HTTPS débloque donc le bilan oral depuis les autres postes.
    """
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    import ipaddress as _ipaddr

    cle = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    nom = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Cabinet kine")])
    noms_alt = [x509.DNSName("localhost"),
                x509.IPAddress(_ipaddr.ip_address("127.0.0.1"))]
    if ip:
        try:
            noms_alt.append(x509.IPAddress(_ipaddr.ip_address(ip)))
        except ValueError:
            pass
    t0 = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(nom).issuer_name(nom)
        .public_key(cle.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(t0 - timedelta(days=1))
        .not_valid_after(t0 + timedelta(days=3650))
        .add_extension(x509.SubjectAlternativeName(noms_alt), critical=False)
        .sign(cle, hashes.SHA256())
    )
    with open(key_path, "wb") as f:
        f.write(cle.private_bytes(serialization.Encoding.PEM,
                                  serialization.PrivateFormat.TraditionalOpenSSL,
                                  serialization.NoEncryption()))
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))


if __name__ == "__main__":
    init_db()
    port = 5001
    ip = ip_locale()
    ici = os.path.dirname(os.path.abspath(__file__))
    cert_path = os.path.join(ici, "cert.pem")
    key_path = os.path.join(ici, "key.pem")
    contexte_ssl = None
    try:
        if not (os.path.exists(cert_path) and os.path.exists(key_path)):
            generer_certificat(cert_path, key_path, ip)
        contexte_ssl = (cert_path, key_path)
    except Exception as err:
        print("\n  (HTTPS indisponible : %s — démarrage en HTTP)" % err)
    schema = "https" if contexte_ssl else "http"
    print("\n  Cabinet kiné — prêt.\n")
    print("  Sur CET ordinateur :")
    print("      %s://localhost:%d" % (schema, port))
    print("      %s://127.0.0.1:%d   (si « localhost » ne répond pas)" % (schema, port))
    if ip:
        print("\n  Depuis un autre PC / smartphone sur le MÊME réseau :")
        print("      %s://%s:%d" % (schema, ip, port))
        if contexte_ssl:
            print("\n  (1re visite sur chaque appareil : le navigateur affiche un")
            print("   avertissement de sécurité — normal avec un certificat local.")
            print("   Cliquez sur « Avancé » puis « Continuer ». Le HTTPS est requis")
            print("   pour autoriser le micro — donc le bilan oral — à distance.)")
        else:
            print("\n  (connexion non chiffrée : le micro ne sera pas disponible")
            print("   depuis les autres postes)")
    print("\n  Pour arrêter : Ctrl+C\n")
    app.run(host="0.0.0.0", port=port, threaded=True, ssl_context=contexte_ssl)
__FIN_APP_PY__

info "  · resume.py"
cat > "$APP/resume.py" << '__FIN_RESUME_PY__'
#!/usr/bin/env python3
"""Résumé LOCAL du bilan oral via Ollama (avec repli par règles si Ollama est absent).

Aucune donnée ne quitte la machine : Ollama tourne en local sur le port 11434.
Utilise uniquement la bibliothèque standard (pas de dépendance pip).
"""
import json
import re
import urllib.request

OLLAMA_URL = "http://127.0.0.1:11434/api/generate"
MODELE = "llama3.2:3b"

SYSTEME = (
    "Tu es l'assistant d'un kinésithérapeute. À partir de la dictée brute d'un "
    "bilan de séance, rédige en français un résumé clair et concis des éléments "
    "cliniquement pertinents, en quelques phrases courtes : ce qui a été fait, "
    "l'évolution, la douleur, les objectifs. N'invente rien ; garde uniquement ce "
    "qui est dit. Pas de préambule, donne directement le résumé."
)

SYSTEME_REFORM = (
    "Tu es l'assistant d'un kinésithérapeute. Reformule le texte suivant, qui décrit "
    "ce qui a été fait lors d'une séance, pour qu'il soit clair, concis et "
    "professionnel, en français. Corrige l'orthographe et la grammaire. N'ajoute "
    "aucune information et ne retire aucun fait : garde strictement le même sens. "
    "Réponds uniquement par le texte reformulé, sans préambule ni commentaire."
)


def resumer(texte):
    """Retourne {'resume': ..., 'moteur': 'ollama'|'règles'|'vide'}."""
    texte = (texte or "").strip()
    if not texte:
        return {"resume": "", "moteur": "vide"}
    try:
        return {"resume": _ollama(SYSTEME, texte), "moteur": "ollama"}
    except Exception:
        return {"resume": _regles(texte), "moteur": "règles"}


def reformuler(texte):
    """Réécrit un texte de séance (clarté/orthographe) sans changer le sens.

    Retourne {'texte': ..., 'moteur': 'ollama'|'indisponible'|'vide'}.
    En cas d'absence d'Ollama, renvoie le texte d'origine inchangé.
    """
    texte = (texte or "").strip()
    if not texte:
        return {"texte": "", "moteur": "vide"}
    try:
        return {"texte": _ollama(SYSTEME_REFORM, texte), "moteur": "ollama"}
    except Exception:
        return {"texte": texte, "moteur": "indisponible"}


def _ollama(systeme, texte):
    corps = json.dumps({
        "model": MODELE,
        "prompt": systeme + "\n\nTexte :\n" + texte + "\n\nRésultat :",
        "stream": False,
        "options": {"temperature": 0.2},
    }).encode("utf-8")
    req = urllib.request.Request(
        OLLAMA_URL, data=corps, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=240) as r:
        data = json.loads(r.read().decode("utf-8"))
    sortie = (data.get("response") or "").strip()
    if not sortie:
        raise ValueError("réponse vide d'Ollama")
    return sortie


def _regles(texte):
    """Repli sans IA : garde les phrases porteuses de sens clinique, en puces."""
    phrases = re.split(r"(?<=[.!?])\s+", texte)
    cles = (
        "douleur", "amplitude", "exercice", "renforc", "étire", "etire", "mobilis",
        "objectif", "progrès", "progres", "séance", "seance", "marche", "gainage",
        "raide", "souple", "force", "reprise", "mieux", "moins", "plus", "degré", "degre",
    )
    gardees = [p.strip() for p in phrases if any(k in p.lower() for k in cles)]
    if not gardees:
        gardees = [p.strip() for p in phrases if p.strip()]
    return "\n".join("- " + p for p in gardees if p)


def detecter_douleur(texte):
    """Repère un niveau de douleur cité (ex. « 3 sur 10 », « EVA 4 »). 0 si rien."""
    t = (texte or "").lower()
    for motif in (
        r"(\d{1,2})\s*(?:/|sur)\s*10",
        r"eva\D{0,6}(\d{1,2})",
        r"douleur\D{0,15}(\d{1,2})",
    ):
        m = re.search(motif, t)
        if m:
            v = int(m.group(1))
            if 0 <= v <= 10:
                return v
    return 0
__FIN_RESUME_PY__

info "  · pdf_export.py"
cat > "$APP/pdf_export.py" << '__FIN_PDF_EXPORT_PY__'
#!/usr/bin/env python3
"""Génère un compte-rendu PDF du dossier patient (reportlab).

Contenu : identité, pathologie, objectifs, note, courbe d'évolution de la
douleur (EVA) et historique des séances. Renvoie les octets du PDF.
"""
import io
from datetime import date, datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor, white
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether,
)
from reportlab.graphics.shapes import Drawing, Line, Circle, PolyLine, String

# Charte (cohérente avec l'application)
ACCENT = HexColor("#5A4FE3")
INK = HexColor("#161A23")
MUTED = HexColor("#5A6473")
LIGNE = HexColor("#DCE0E8")
SOFT = HexColor("#F0EFFC")
PATHO_BG = HexColor("#FBF1EE")
VERT = HexColor("#1F9D6B")
ORANGE = HexColor("#E0A100")
ROUGE = HexColor("#D2493B")


def _coul(n):
    if not n:
        return MUTED
    if n <= 3:
        return VERT
    if n <= 6:
        return ORANGE
    return ROUGE


def _jolie_date(iso):
    try:
        d = datetime.strptime(iso[:10], "%Y-%m-%d")
        return d.strftime("%d/%m/%Y")
    except Exception:
        return iso or ""


def _styles():
    s = getSampleStyleSheet()
    base = ParagraphStyle("base", parent=s["Normal"], fontName="Helvetica",
                          fontSize=10, leading=14, textColor=INK)
    return {
        "titre": ParagraphStyle("titre", parent=base, fontName="Helvetica-Bold",
                                fontSize=20, leading=24, textColor=INK),
        "sous": ParagraphStyle("sous", parent=base, fontSize=10, textColor=MUTED),
        "eyebrow": ParagraphStyle("eyebrow", parent=base, fontName="Helvetica-Bold",
                                  fontSize=8, textColor=MUTED, spaceAfter=2),
        "h2": ParagraphStyle("h2", parent=base, fontName="Helvetica-Bold",
                             fontSize=11, leading=14, textColor=INK, spaceBefore=4, spaceAfter=6),
        "val": ParagraphStyle("val", parent=base, fontSize=11, leading=15),
        "valbold": ParagraphStyle("valbold", parent=base, fontName="Helvetica-Bold",
                                  fontSize=12, leading=16),
        "base": base,
        "cell": ParagraphStyle("cell", parent=base, fontSize=9.5, leading=13),
        "cellmuted": ParagraphStyle("cellmuted", parent=base, fontSize=9.5,
                                    leading=13, textColor=MUTED),
        "pied": ParagraphStyle("pied", parent=base, fontSize=8, textColor=MUTED),
    }


def _graphe_douleur(points, largeur, hauteur=165):
    d = Drawing(largeur, hauteur)
    padL, padR, padT, padB = 26, 10, 12, 32
    plotW = largeur - padL - padR
    plotH = hauteur - padT - padB
    n = len(points)

    for lvl in range(0, 11, 2):
        y = padB + (lvl / 10.0) * plotH
        d.add(Line(padL, y, largeur - padR, y, strokeColor=LIGNE, strokeWidth=0.5))
        d.add(String(padL - 5, y - 3, str(lvl), fontSize=7,
                     fillColor=MUTED, textAnchor="end"))

    def X(i):
        return padL + (plotW / 2.0 if n == 1 else (i / (n - 1.0)) * plotW)

    def Y(v):
        return padB + (v / 10.0) * plotH

    if n >= 2:
        flat = []
        for i, p in enumerate(points):
            flat += [X(i), Y(p["d"])]
        d.add(PolyLine(flat, strokeColor=ACCENT, strokeWidth=1.5))

    step = 1 if n <= 12 else (n // 12 + 1)
    for i, p in enumerate(points):
        d.add(Circle(X(i), Y(p["d"]), 3, fillColor=_coul(p["d"]),
                     strokeColor=white, strokeWidth=1))
        if i % step == 0:
            d.add(String(X(i), padB - 12, p["date"][5:], fontSize=6.5,
                         fillColor=MUTED, textAnchor="middle"))
    d.add(Line(padL, padB, largeur - padR, padB, strokeColor=MUTED, strokeWidth=0.8))
    return d


def _bloc_clef(titre, valeur, st, accent=False):
    eyebrow = ParagraphStyle("eb", parent=st["eyebrow"],
                             textColor=(ROUGE if accent else MUTED))
    contenu = [
        Paragraph(titre.upper(), eyebrow),
        Paragraph(valeur or "Non renseigné",
                  st["valbold"] if accent else st["val"]),
    ]
    t = Table([[contenu]], colWidths=["100%"])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), PATHO_BG if accent else white),
        ("BOX", (0, 0), (-1, -1), 0.7, (HexColor("#F1D9D1") if accent else LIGNE)),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("ROUNDEDCORNERS", [6, 6, 6, 6]),
    ]))
    return t


def generer_fiche(patient, seances):
    st = _styles()
    buf = io.BytesIO()
    marge = 18 * mm
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=marge, rightMargin=marge, topMargin=16 * mm, bottomMargin=16 * mm,
        title="Bilan kinésithérapie", author="Cabinet kiné",
    )
    util = A4[0] - 2 * marge
    story = []

    nom = f"{patient.get('nom','')} {patient.get('prenom','')}".strip()

    # En-tête
    gauche = [
        Paragraph("BILAN KINÉSITHÉRAPIE", st["eyebrow"]),
        Paragraph(nom or "Patient", st["titre"]),
    ]
    sous = []
    if patient.get("naissance"):
        sous.append("Né(e) le " + _jolie_date(patient["naissance"]))
    sous.append("Édité le " + date.today().strftime("%d/%m/%Y"))
    gauche.append(Paragraph(" · ".join(sous), st["sous"]))
    story.append(Table([[gauche]], colWidths=[util], style=TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LINEBELOW", (0, 0), (-1, -1), 1, LIGNE),
    ])))
    story.append(Spacer(1, 14))

    # Pathologie + objectifs
    col = (util - 12) / 2.0
    story.append(_bloc_clef("Pathologie", patient.get("pathologie"), st, accent=True))
    story.append(Spacer(1, 8))
    obj = Table(
        [[_bloc_clef("Objectif court terme", patient.get("objectif_court"), st),
          _bloc_clef("Objectif long terme", patient.get("objectif_long"), st)]],
        colWidths=[col, col],
    )
    obj.setStyle(TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (0, 0), 12),
        ("RIGHTPADDING", (1, 0), (1, 0), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(obj)
    story.append(Spacer(1, 14))

    # Note libre
    if patient.get("note_libre"):
        story.append(Paragraph("Note", st["h2"]))
        note = Table([[Paragraph(patient["note_libre"].replace("\n", "<br/>"), st["base"])]],
                     colWidths=[util])
        note.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), HexColor("#FFFDF6")),
            ("BOX", (0, 0), (-1, -1), 0.7, HexColor("#F0E4BE")),
            ("LEFTPADDING", (0, 0), (-1, -1), 10), ("RIGHTPADDING", (0, 0), (-1, -1), 10),
            ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(note)
        story.append(Spacer(1, 14))

    seances = sorted(seances, key=lambda s: s.get("date_seance", ""))
    points = [{"date": s["date_seance"], "d": s["douleur"]}
              for s in seances if s.get("douleur")]

    # Graphe douleur
    if points:
        bloc = [Paragraph("Évolution de la douleur (EVA)", st["h2"]),
                _graphe_douleur(points, util)]
        story.append(KeepTogether(bloc))
        story.append(Spacer(1, 14))

    # Historique des séances
    story.append(Paragraph("Historique des séances", st["h2"]))
    if seances:
        entete = [Paragraph("<b>Date</b>", st["cell"]),
                  Paragraph("<b>EVA</b>", st["cell"]),
                  Paragraph("<b>Séance</b>", st["cell"])]
        lignes = [entete]
        for s in reversed(seances):  # plus récentes d'abord
            eva = str(s["douleur"]) if s.get("douleur") else "—"
            fait = (s.get("fait") or "").replace("\n", "<br/>") or "<i>—</i>"
            lignes.append([
                Paragraph(_jolie_date(s["date_seance"]), st["cellmuted"]),
                Paragraph(eva, st["cell"]),
                Paragraph(fait, st["cell"]),
            ])
        tbl = Table(lignes, colWidths=[24 * mm, 14 * mm, util - 38 * mm], repeatRows=1)
        style = [
            ("LINEBELOW", (0, 0), (-1, 0), 0.8, ACCENT),
            ("LINEBELOW", (0, 1), (-1, -1), 0.4, LIGNE),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ]
        for i, s in enumerate(reversed(seances), start=1):
            if s.get("douleur"):
                style.append(("TEXTCOLOR", (1, i), (1, i), _coul(s["douleur"])))
                style.append(("FONTNAME", (1, i), (1, i), "Helvetica-Bold"))
        tbl.setStyle(TableStyle(style))
        story.append(tbl)
    else:
        story.append(Paragraph("Aucune séance enregistrée.", st["cellmuted"]))

    def pied(canvas, doc_):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(MUTED)
        canvas.drawString(marge, 10 * mm, "Document confidentiel — secret médical")
        canvas.drawRightString(A4[0] - marge, 10 * mm, "Page %d" % doc_.page)
        canvas.restoreState()

    doc.build(story, onFirstPage=pied, onLaterPages=pied)
    return buf.getvalue()
__FIN_PDF_EXPORT_PY__

info "  · templates/base.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/base.html" << '__FIN_TEMPLATES_BASE_HTML__'
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{% block titre %}Cabinet kiné{% endblock %}</title>
<link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
</head>
<body class="{% block body_classe %}app{% endblock %}">
{% block chrome %}
  <aside class="rail">
    <div class="rail-mark">
      <span class="rail-dot"></span>
      Cabinet kiné
    </div>
    <nav class="rail-nav">
      <a href="{{ url_for('dashboard') }}" class="{% block nav_dash %}{% endblock %}">Patients</a>
      <a href="{{ url_for('calendrier') }}" class="{% block nav_cal %}{% endblock %}">Calendrier</a>
      <a href="{{ url_for('patient_nouveau') }}" class="{% block nav_new %}{% endblock %}">Nouveau patient</a>
      <a href="{{ url_for('archives') }}" class="{% block nav_arch %}{% endblock %}">Archives</a>
    </nav>
    <div class="rail-foot">
      {% if est_admin %}<a href="{{ url_for('admin_panel') }}" class="rail-test">Administration</a>{% endif %}
      <a href="{{ url_for('securite') }}" class="rail-test">Sécurité</a>
      <span class="local-tag">Tout en local</span>
      <a href="{{ url_for('deconnexion') }}" class="rail-out">Déconnexion</a>
    </div>
  </aside>
  <main class="stage {% block stage_classe %}{% endblock %}">
    {% with messages = get_flashed_messages() %}
      {% if messages %}
        <div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>
      {% endif %}
    {% endwith %}
    {% block contenu %}{% endblock %}
  </main>
{% endblock %}
{% block scripts %}{% endblock %}
</body>
</html>
__FIN_TEMPLATES_BASE_HTML__

info "  · templates/setup.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/setup.html" << '__FIN_TEMPLATES_SETUP_HTML__'
{% extends "base.html" %}
{% block titre %}Bienvenue — Cabinet kiné{% endblock %}
{% block body_classe %}center{% endblock %}
{% block chrome %}
<div class="auth-card">
  <div class="eyebrow">Première utilisation · tout reste en local</div>
  <h1>Créer votre compte</h1>
  <p class="lede">Ce compte protège l'accès aux dossiers. Choisissez vos identifiants ; ils restent sur cette machine.</p>
  {% with messages = get_flashed_messages() %}
    {% if messages %}<div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>{% endif %}
  {% endwith %}
  <form method="post">
    <label class="champ"><span>Identifiant</span>
      <input type="text" name="identifiant" autocomplete="username" required autofocus></label>
    <label class="champ"><span>Mot de passe (6 caractères minimum)</span>
      <input type="password" name="mdp" autocomplete="new-password" required></label>
    <label class="champ"><span>Confirmer le mot de passe</span>
      <input type="password" name="mdp2" autocomplete="new-password" required></label>
    <label class="champ"><span>Question de sécurité (pour récupérer le mot de passe)</span>
      <input type="text" name="question" maxlength="120" required
             value="Quelle est la marque de ma première voiture ?"></label>
    <label class="champ"><span>Réponse</span>
      <input type="text" name="reponse" maxlength="80" autocomplete="off" required></label>
    <button class="btn" type="submit" style="width:100%; justify-content:center;">Créer le compte</button>
  </form>
</div>
{% endblock %}
__FIN_TEMPLATES_SETUP_HTML__

info "  · templates/connexion.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/connexion.html" << '__FIN_TEMPLATES_CONNEXION_HTML__'
{% extends "base.html" %}
{% block titre %}Connexion — Cabinet kiné{% endblock %}
{% block body_classe %}center{% endblock %}
{% block chrome %}
<div class="auth-card">
  <div class="eyebrow">Cabinet kiné · accès privé</div>
  <h1>Connexion</h1>
  <p class="lede">Accédez à vos dossiers patients.</p>
  {% with messages = get_flashed_messages() %}
    {% if messages %}<div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>{% endif %}
  {% endwith %}
  <form method="post">
    <label class="champ"><span>Identifiant</span>
      <input type="text" name="identifiant" autocomplete="username" required autofocus></label>
    <label class="champ"><span>Mot de passe</span>
      <input type="password" name="mdp" autocomplete="current-password" required></label>
    <button class="btn" type="submit" style="width:100%; justify-content:center;">Se connecter</button>
  </form>
  <a class="lien-discret" href="{{ url_for('mdp_oublie') }}">Mot de passe oublié ?</a>
</div>
{% endblock %}
__FIN_TEMPLATES_CONNEXION_HTML__

info "  · templates/dashboard.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/dashboard.html" << '__FIN_TEMPLATES_DASHBOARD_HTML__'
{% extends "base.html" %}
{% block titre %}Patients — Cabinet kiné{% endblock %}
{% block nav_dash %}actif{% endblock %}
{% block contenu %}
<div class="row-between">
  <div>
    <h1 class="page">Patients</h1>
    <p class="page-lede">{{ patients|length }} dossier{{ 's' if patients|length != 1 else '' }} actif{{ 's' if patients|length != 1 else '' }}.</p>
  </div>
  <a class="btn" href="{{ url_for('patient_nouveau') }}">+ Nouveau patient</a>
</div>

{% if patients %}
<div class="patients">
  {% for p in patients %}
  <a class="pcard" href="{{ url_for('patient', pid=p.id) }}">
    <div class="nom">{{ p.nom }} {{ p.prenom }}{% if p.demo %} <span class="demo-tag">démo</span>{% endif %}</div>
    <div class="patho">{{ p.pathologie or "Pathologie non renseignée" }}</div>
    <div class="meta">
      <span>{{ p.nb_seances }} séance{{ 's' if p.nb_seances != 1 else '' }}</span>
      {% if p.douleur_recente %}
        <span class="pastille douleur-{{ p.douleur_recente }}">
          <span class="pip pip-{{ p.douleur_recente }}"></span>EVA {{ p.douleur_recente }}
        </span>
      {% endif %}
    </div>
  </a>
  {% endfor %}
</div>
{% else %}
<div class="vide">Aucun patient pour l'instant.<br>Cliquez sur « Nouveau patient » pour créer le premier dossier.</div>
{% endif %}

{% if nb_archives %}
<p class="page-lede" style="margin-top:28px;"><a href="{{ url_for('archives') }}">Voir les {{ nb_archives }} dossier{{ 's' if nb_archives != 1 else '' }} archivé{{ 's' if nb_archives != 1 else '' }}</a></p>
{% endif %}
{% endblock %}
__FIN_TEMPLATES_DASHBOARD_HTML__

info "  · templates/archives.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/archives.html" << '__FIN_TEMPLATES_ARCHIVES_HTML__'
{% extends "base.html" %}
{% block titre %}Archives — Cabinet kiné{% endblock %}
{% block nav_arch %}actif{% endblock %}
{% block contenu %}
<h1 class="page">Archives</h1>
<p class="page-lede">Dossiers archivés. L'historique est conservé ; vous pouvez les réactiver à tout moment.</p>

{% if patients %}
<div class="patients">
  {% for p in patients %}
  <div class="pcard" style="cursor:default;">
    <div class="nom">{{ p.nom }} {{ p.prenom }}</div>
    <div class="patho">{{ p.pathologie or "—" }}</div>
    <div class="meta" style="justify-content:space-between;">
      <a href="{{ url_for('patient', pid=p.id) }}">Ouvrir</a>
      <form method="post" action="{{ url_for('patient_restaurer', pid=p.id) }}">
        <button class="btn ghost sm" type="submit">Réactiver</button>
      </form>
    </div>
  </div>
  {% endfor %}
</div>
{% else %}
<div class="vide">Aucun dossier archivé.</div>
{% endif %}
{% endblock %}
__FIN_TEMPLATES_ARCHIVES_HTML__

info "  · templates/calendrier.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/calendrier.html" << '__FIN_TEMPLATES_CALENDRIER_HTML__'
{% extends "base.html" %}
{% block titre %}Calendrier — Cabinet kiné{% endblock %}
{% block nav_cal %}actif{% endblock %}
{% block stage_classe %}stage-large{% endblock %}
{% block contenu %}
<h1 class="page">Calendrier</h1>
<p class="page-lede">Toutes les séances du cabinet. Cliquez sur un jour pour voir les patients concernés.</p>

<div class="card">
  <div class="cal-tete">
    <div class="vue-toggle">
      <button id="vueJour" type="button">Jour</button>
      <button id="vueSemaine" type="button">Semaine</button>
      <button id="vueMois" type="button" class="actif">Mois</button>
    </div>
    <div class="mois" id="calMois"></div>
    <div class="cal-nav">
      <button id="calPrev" type="button" aria-label="Précédent">‹</button>
      <button id="calNext" type="button" aria-label="Suivant">›</button>
    </div>
  </div>
  <div class="cal-grille agenda-grille" id="calGrille"></div>
  <div class="cal-legende" id="calLegende"></div>
</div>

<!-- Fenêtre du jour -->
<div class="overlay" id="jourOverlay">
  <div class="modale" role="dialog" aria-modal="true" aria-labelledby="jourTitre">
    <h3 id="jourTitre">Séances du jour</h3>
    <div class="when" id="jourSous"></div>
    <div id="jourListe" class="jour-liste"></div>
    <div class="modale-actions" style="justify-content:flex-end;">
      <button class="btn ghost" id="jourFermer" type="button">Fermer</button>
    </div>
  </div>
</div>

<!-- Fenêtre d'ajout de créneau -->
<div class="overlay" id="creneauOverlay">
  <div class="modale" role="dialog" aria-modal="true" aria-labelledby="creneauTitre">
    <h3 id="creneauTitre">Nouveau créneau</h3>
    <div class="when" id="creneauQuand"></div>
    <label class="champ"><span>Patient</span>
      <select id="creneauPatient"></select></label>
    <label class="champ"><span>Praticien</span>
      <select id="creneauPraticien"></select></label>
    <div class="modale-actions" style="justify-content:flex-end;">
      <button class="btn ghost" id="creneauAnnuler" type="button">Annuler</button>
      <button class="btn" id="creneauOk" type="button">Ajouter au créneau</button>
    </div>
  </div>
</div>

<script>
  window.AGENDA_URL = "{{ url_for('agenda_json') }}";
  window.PATIENTS_URL = "{{ url_for('patients_json') }}";
  window.PATIENT_BASE = "{{ url_for('patient', pid=0) }}";
  window.CRENEAU_BASE = "{{ url_for('creneau_enregistrer', pid=0) }}";
  window.PRATICIENS = {{ praticiens|tojson }};
  window.PRAT_COULEURS = {{ praticiens_couleurs|tojson }};
</script>
{% endblock %}
{% block scripts %}
<script src="{{ url_for('static', filename='agenda.js') }}"></script>
{% endblock %}
__FIN_TEMPLATES_CALENDRIER_HTML__

info "  · templates/patient_form.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/patient_form.html" << '__FIN_TEMPLATES_PATIENT_FORM_HTML__'
{% extends "base.html" %}
{% block titre %}{{ "Nouveau patient" if mode == "nouveau" else "Modifier" }} — Cabinet kiné{% endblock %}
{% block nav_new %}{{ 'actif' if mode == 'nouveau' else '' }}{% endblock %}
{% block contenu %}
<h1 class="page">{{ "Nouveau patient" if mode == "nouveau" else "Modifier le dossier" }}</h1>
<p class="page-lede">La pathologie et les objectifs apparaîtront en évidence sur la fiche.</p>

<form method="post" class="card" style="max-width:720px;">
  <div class="grille2">
    <label class="champ"><span>Nom *</span>
      <input type="text" name="nom" value="{{ patient.nom or '' }}" required autofocus></label>
    <label class="champ"><span>Prénom *</span>
      <input type="text" name="prenom" value="{{ patient.prenom or '' }}" required></label>
  </div>
  <label class="champ"><span>Date de naissance</span>
    <input type="date" name="naissance" value="{{ patient.naissance or '' }}"></label>
  <label class="champ"><span>Pathologie</span>
    <input type="text" name="pathologie" value="{{ patient.pathologie or '' }}" placeholder="ex. Tendinopathie de la coiffe des rotateurs"></label>
  <div class="grille2">
    <label class="champ"><span>Objectif court terme</span>
      <textarea name="objectif_court" placeholder="ex. Retrouver l'amplitude sans douleur sous 3 semaines">{{ patient.objectif_court or '' }}</textarea></label>
    <label class="champ"><span>Objectif long terme</span>
      <textarea name="objectif_long" placeholder="ex. Reprise du sport sans appréhension">{{ patient.objectif_long or '' }}</textarea></label>
  </div>
  <label class="champ"><span>Note libre (particularités du patient)</span>
    <textarea name="note_libre" placeholder="ex. dépendant·e, déteste les courbatures, à rassurer…">{{ patient.note_libre or '' }}</textarea></label>

  <div style="display:flex; gap:10px; margin-top:8px;">
    <button class="btn" type="submit">{{ "Créer le dossier" if mode == "nouveau" else "Enregistrer" }}</button>
    <a class="btn ghost" href="{{ url_for('patient', pid=patient.id) if patient.id else url_for('dashboard') }}">Annuler</a>
  </div>
</form>
{% endblock %}
__FIN_TEMPLATES_PATIENT_FORM_HTML__

info "  · templates/patient.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/patient.html" << '__FIN_TEMPLATES_PATIENT_HTML__'
{% extends "base.html" %}
{% block titre %}{{ p.nom }} {{ p.prenom }} — Cabinet kiné{% endblock %}
{% block contenu %}
<div class="fiche-tete">
  <div class="row-between">
    <div>
      <a href="{{ url_for('dashboard') }}" style="font-size:13px;">← Patients</a>
      <h1>{{ p.nom }} {{ p.prenom }}</h1>
      <div class="sous">
        {% if p.naissance %}Né(e) le {{ p.naissance }} · {% endif %}
        Dossier créé le {{ p.cree_le[:10] }}
        {% if p.archive %} · <strong style="color:var(--danger)">archivé</strong>{% endif %}
      </div>
    </div>
    <div style="display:flex; gap:8px;">
      <a class="btn ghost sm" href="{{ url_for('patient_pdf', pid=p.id) }}">Exporter en PDF</a>
      <a class="btn ghost sm" href="{{ url_for('patient_modifier', pid=p.id) }}">Modifier</a>
      {% if p.archive %}
        <form method="post" action="{{ url_for('patient_restaurer', pid=p.id) }}"><button class="btn ghost sm">Réactiver</button></form>
      {% else %}
        <form method="post" action="{{ url_for('patient_archiver', pid=p.id) }}" onsubmit="return confirm('Archiver ce dossier ? L\'historique est conservé.')"><button class="btn danger sm">Archiver</button></form>
      {% endif %}
    </div>
  </div>
</div>

<!-- Infos clés en évidence -->
<div class="bandeau">
  <div class="bloc-clef patho">
    <div class="k">Pathologie</div>
    <div class="v {{ '' if p.pathologie else 'vide-v' }}">{{ p.pathologie or "Non renseignée" }}</div>
  </div>
  <div class="bloc-clef">
    <div class="k">Objectif court terme</div>
    <div class="v {{ '' if p.objectif_court else 'vide-v' }}" style="font-size:14px; font-weight:500;">{{ p.objectif_court or "Non renseigné" }}</div>
  </div>
  <div class="bloc-clef">
    <div class="k">Objectif long terme</div>
    <div class="v {{ '' if p.objectif_long else 'vide-v' }}" style="font-size:14px; font-weight:500;">{{ p.objectif_long or "Non renseigné" }}</div>
  </div>
</div>

<!-- Note libre -->
<div class="card note-zone">
  <h2>Note du patient</h2>
  <form method="post" action="{{ url_for('patient_note', pid=p.id) }}">
    <textarea name="note_libre" placeholder="Particularités à garder en tête…">{{ p.note_libre or '' }}</textarea>
    <div class="note-row"><button class="btn ghost sm" type="submit">Enregistrer la note</button></div>
  </form>
</div>

<!-- Bilan oral -->
{% if AUDIO_DISPO %}
<div class="card" id="bilan">
  <h2>Bilan oral</h2>
  <p class="aide">Dictez votre bilan : transcription et résumé sont calculés en local, rien n'est envoyé en ligne. Relisez le résumé avant de l'insérer.</p>
  <div class="rec-row">
    <button id="recBtn" class="rec-btn" type="button" aria-label="Démarrer la dictée"><span class="dot"></span></button>
    <div id="meter" class="meter" aria-hidden="true">
      <span class="bar"></span><span class="bar"></span><span class="bar"></span><span class="bar"></span>
      <span class="bar"></span><span class="bar"></span><span class="bar"></span><span class="bar"></span>
      <span class="bar"></span><span class="bar"></span><span class="bar"></span><span class="bar"></span>
    </div>
    <div id="timer" class="timer">0:00</div>
  </div>
  <p class="hint" id="recHint">Cliquez pour dicter. Re-cliquez pour arrêter et lancer la transcription.</p>
  <div class="status" id="bilanStatus" role="status" aria-live="polite"></div>

  <div class="bilan-res" id="bilanRes" style="display:none;">
    <label class="champ"><span>Résumé du bilan (modifiable)</span>
      <textarea id="bilanResume" style="min-height:120px;"></textarea></label>
    <details><summary>Voir la transcription brute</summary>
      <div class="brut" id="bilanBrut"></div></details>
    <label class="champ" style="max-width:240px; margin-top:14px;"><span>Date de la séance</span>
      <input type="date" id="bilanDate"></label>
    <div class="hint" id="dateInfo" style="margin-top:0;"></div>
    <div class="bilan-actions">
      <span class="moteur-tag" id="moteurTag"></span>
      <div style="display:flex; gap:8px;">
        <button class="btn ghost" id="bilanNote" type="button">Ajouter à la note</button>
        <button class="btn" id="bilanSeance" type="button">Insérer dans la séance</button>
      </div>
    </div>
  </div>
</div>
{% else %}
<div class="card" id="bilan">
  <h2>Bilan oral</h2>
  <p class="aide">Le module audio n'est pas installé. Pour l'activer : <code>bash installer.sh --avec-audio</code>, puis relancez l'application.</p>
</div>
{% endif %}

<!-- Calendrier -->
<div class="card">
  <h2>Calendrier des séances</h2>
  <div class="cal-tete">
    <div class="cal-nav"><button id="calPrev" type="button" aria-label="Mois précédent">‹</button></div>
    <div class="mois" id="calMois"></div>
    <div class="cal-nav"><button id="calNext" type="button" aria-label="Mois suivant">›</button></div>
  </div>
  <div class="cal-grille" id="calGrille"></div>
  <div class="cal-legende">
    <span><span class="lg" style="background:var(--accent)"></span> séance notée</span>
    <span><span class="lg" style="background:var(--ok)"></span> douleur faible (1-3)</span>
    <span><span class="lg" style="background:var(--warn)"></span> modérée (4-6)</span>
    <span><span class="lg" style="background:var(--danger)"></span> forte (7-10)</span>
  </div>
</div>

<!-- Graphique douleur -->
<div class="card">
  <h2>Évolution de la douleur (EVA)</h2>
  <div class="graph-wrap" id="graphWrap">
    <div class="graph-vide" id="graphVide">Pas encore de douleur enregistrée. Notez une séance pour voir la courbe.</div>
  </div>
</div>

<!-- Séances -->
<div class="card" id="seances">
  <h2>Séances <span class="compteur">· {{ seances|length }}</span></h2>
  {% if seances %}
    {% for s in seances %}
    <div class="seance-item">
      <div class="tete">
        <span class="date">{{ s.date_seance }}</span>
        <div style="display:flex; align-items:center; gap:10px;">
          {% if s.douleur %}<span class="pastille douleur-{{ s.douleur }}"><span class="pip pip-{{ s.douleur }}"></span>EVA {{ s.douleur }}</span>{% endif %}
          <button class="btn ghost sm js-edit"
                  data-date="{{ s.date_seance }}"
                  data-fait="{{ s.fait or '' }}"
                  data-douleur="{{ s.douleur or 0 }}">Modifier</button>
        </div>
      </div>
      {% if s.fait %}<div class="fait">{{ s.fait }}</div>{% endif %}
    </div>
    {% endfor %}
  {% else %}
    <div class="vide" style="padding:30px;">Aucune séance enregistrée.<br>Cliquez sur un jour du calendrier pour en ajouter une.</div>
  {% endif %}
</div>

<!-- Modale séance -->
<div class="overlay" id="overlay">
  <div class="modale" role="dialog" aria-modal="true" aria-labelledby="modTitre">
    <h3 id="modTitre">Séance</h3>
    <div class="when" id="modDate"></div>
    <form method="post" action="{{ url_for('seance_enregistrer', pid=p.id) }}" id="seanceForm">
      <input type="hidden" name="date_seance" id="fDate">
      <div class="grille2">
        <label class="champ"><span>Heure du créneau</span>
          <select name="heure" id="fHeure">
            <option value="">— sans horaire —</option>
            {% for h in range(7, 20) %}
            <option value="{{ '%02d:00'|format(h) }}">{{ '%02d:00'|format(h) }}</option>
            <option value="{{ '%02d:30'|format(h) }}">{{ '%02d:30'|format(h) }}</option>
            {% endfor %}
          </select></label>
        <label class="champ"><span>Praticien</span>
          <select name="praticien" id="fPraticien">
            <option value="">—</option>
            {% for pr in praticiens %}<option value="{{ pr }}">{{ pr }}</option>{% endfor %}
          </select></label>
      </div>
      <label class="champ"><span>Ce qui a été fait</span>
        <textarea name="fait" id="fFait" placeholder="Exercices, manipulations, ressenti…"></textarea></label>
      <div class="reform-row">
        <button type="button" class="btn ghost sm" id="reformBtn">Reformuler</button>
        <button type="button" class="btn ghost sm" id="reformUndo" style="display:none;">Rétablir</button>
        <span class="reform-status" id="reformStatus"></span>
      </div>
      <div class="eva">
        <div class="eva-haut">
          <span style="font-size:13px;color:var(--muted);">Niveau de douleur</span>
          <span class="eva-val" id="evaVal">—</span>
        </div>
        <input type="range" name="douleur" id="fDouleur" min="0" max="10" value="0" step="1">
        <div class="eva-echelle"><span>aucune</span><span>5</span><span>10 max</span></div>
      </div>
      <div class="modale-actions">
        <button type="button" class="btn ghost sm" id="modSupprimer" style="visibility:hidden;">Supprimer</button>
        <div style="display:flex; gap:8px;">
          <button type="button" class="btn ghost" id="modFermer">Annuler</button>
          <button type="submit" class="btn">Enregistrer</button>
        </div>
      </div>
    </form>
    <form method="post" id="supprimerForm" style="display:none;"></form>
  </div>
</div>

<script>
  window.PATIENT_ID = {{ p.id }};
  window.SEANCES_URL = "{{ url_for('seances_json', pid=p.id) }}";
  window.SUPPR_BASE = "{{ url_for('seance_supprimer', pid=p.id, sid=0) }}";
  window.SEANCE_URL = "{{ url_for('seance_enregistrer', pid=p.id) }}";
  window.NOTE_URL = "{{ url_for('patient_note', pid=p.id) }}";
  window.BILAN_URL = "{{ url_for('bilan_oral', pid=p.id) }}" ;
  window.REFORM_URL = "{{ url_for('reformuler') }}";
  window.AUDIO_DISPO = {{ 'true' if AUDIO_DISPO else 'false' }};
  window.AUJOURDHUI = "{{ aujourdhui }}";
</script>
{% endblock %}
{% block scripts %}
<script src="{{ url_for('static', filename='app.js') }}"></script>
{% endblock %}
__FIN_TEMPLATES_PATIENT_HTML__

info "  · templates/admin_panel.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/admin_panel.html" << '__FIN_TEMPLATES_ADMIN_PANEL_HTML__'
{% extends "base.html" %}
{% block titre %}Administration — Cabinet kiné{% endblock %}
{% block contenu %}
<h1 class="page">Administration</h1>
<p class="page-lede">Réservé au compte administrateur : gestion des praticiens et données de test.</p>

{% with messages = get_flashed_messages() %}
  {% if messages %}<div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>{% endif %}
{% endwith %}

<div class="card" id="praticiens">
  <h2>Praticiens</h2>
  <p class="aide">Chaque praticien a son propre compte : il se connecte avec son nom et son mot de passe, et il est proposé lors de la planification des séances. Seul l'administrateur peut gérer cette liste et générer des données de test.</p>
  <ul class="prat-liste">
    {% for c in comptes %}
    <li>
      {% if c.role == 'admin' %}
        <span class="role-tag role-admin">admin</span>
        <span class="prat-nom">{{ c.identifiant }}{% if c.id == moi %} <span class="aide">(vous)</span>{% endif %}</span>
      {% else %}
        <span class="prat-pastille" style="background:{{ couleurs[c.identifiant] }}"></span>
        <span class="prat-nom">{{ c.identifiant }}</span>
        <form method="post" action="{{ url_for('admin_compte_supprimer', compte_id=c.id) }}"
              onsubmit="return confirm('Retirer le praticien {{ c.identifiant }} ? Son compte sera supprimé (les séances passées gardent son nom).')">
          <button class="btn ghost sm" type="submit">Retirer</button>
        </form>
      {% endif %}
    </li>
    {% endfor %}
  </ul>
  <h3 style="margin:16px 0 6px; font-size:14px;">Ajouter un praticien</h3>
  <form method="post" action="{{ url_for('admin_compte_ajouter') }}" class="grille2">
    <label class="champ"><span>Nom (sert d'identifiant de connexion)</span>
      <input type="text" name="identifiant" minlength="3" maxlength="40" required></label>
    <label class="champ"><span>Mot de passe (6 caractères min)</span>
      <input type="password" name="mdp" minlength="6" autocomplete="new-password" required></label>
    <div style="grid-column:1/-1;"><button class="btn" type="submit">Créer le compte praticien</button></div>
  </form>
  <p class="aide">Le praticien pourra ensuite définir sa propre question de sécurité et changer son mot de passe via « Sécurité ».</p>
</div>

<div class="card" id="donnees">
  <h2>Données de test</h2>
  <p class="aide">Génère des patients fictifs (marqués « démo ») pour tester l'affichage. Réservé à l'administrateur ; tout est supprimable ci-dessous.</p>

  <h3 style="margin:14px 0 6px; font-size:14px;">Beaucoup de patients un même jour</h3>
  <form method="post" action="{{ url_for('test_jour') }}">
    <div class="grille2">
      <label class="champ"><span>Date</span>
        <input type="date" name="date" value="{{ aujourdhui }}"></label>
      <label class="champ"><span>Nombre de patients (max 150)</span>
        <input type="number" name="nombre" value="25" min="1" max="150"></label>
    </div>
    <button class="btn" type="submit">Générer ce jour-là</button>
  </form>

  <h3 style="margin:18px 0 6px; font-size:14px;">Remplir un mois</h3>
  <form method="post" action="{{ url_for('test_mois') }}">
    <div class="grille2">
      <label class="champ"><span>Mois</span>
        <input type="month" name="aaaamm" value="{{ aujourdhui[:7] }}"></label>
      <label class="champ"><span>Nombre de séances (max 400)</span>
        <input type="number" name="nombre" value="60" min="1" max="400"></label>
    </div>
    <button class="btn" type="submit">Remplir le mois</button>
  </form>

  <h3 style="margin:18px 0 6px; font-size:14px;">Nettoyage</h3>
  <p class="aide">Patients de démo actuellement en base : <strong>{{ nb_demo }}</strong>.</p>
  <form method="post" action="{{ url_for('test_purge') }}"
        onsubmit="return confirm('Supprimer tous les patients de démo et leurs séances ?')">
    <button class="btn danger" type="submit">Supprimer toutes les données de démo</button>
  </form>
</div>
{% endblock %}
__FIN_TEMPLATES_ADMIN_PANEL_HTML__

info "  · templates/mdp_oublie.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/mdp_oublie.html" << '__FIN_TEMPLATES_MDP_OUBLIE_HTML__'
{% extends "base.html" %}
{% block titre %}Mot de passe oublié — Cabinet kiné{% endblock %}
{% block body_classe %}center{% endblock %}
{% block chrome %}
<div class="auth-card">
  <div class="eyebrow">Cabinet kiné · récupération</div>
  <h1>Mot de passe oublié</h1>
  {% with messages = get_flashed_messages() %}
    {% if messages %}<div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>{% endif %}
  {% endwith %}
  {% if etape == 2 %}
    <p class="lede">Répondez à votre question de sécurité pour définir un nouveau mot de passe.</p>
    <form method="post">
      <input type="hidden" name="identifiant" value="{{ identifiant }}">
      <label class="champ"><span>{{ question }}</span>
        <input type="text" name="reponse" autocomplete="off" required autofocus></label>
      <label class="champ"><span>Nouveau mot de passe</span>
        <input type="password" name="mdp" autocomplete="new-password" required></label>
      <label class="champ"><span>Confirmer le mot de passe</span>
        <input type="password" name="mdp2" autocomplete="new-password" required></label>
      <button class="btn" type="submit" style="width:100%; justify-content:center;">Réinitialiser</button>
    </form>
  {% else %}
    <p class="lede">Saisissez votre identifiant pour afficher votre question de sécurité.</p>
    <form method="post">
      <label class="champ"><span>Identifiant</span>
        <input type="text" name="identifiant" autocomplete="username" required autofocus></label>
      <button class="btn" type="submit" style="width:100%; justify-content:center;">Continuer</button>
    </form>
  {% endif %}
  <a class="lien-discret" href="{{ url_for('connexion') }}">Retour à la connexion</a>
</div>
{% endblock %}
__FIN_TEMPLATES_MDP_OUBLIE_HTML__

info "  · templates/securite.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/securite.html" << '__FIN_TEMPLATES_SECURITE_HTML__'
{% extends "base.html" %}
{% block titre %}Sécurité — Cabinet kiné{% endblock %}
{% block contenu %}
<h1 class="page">Sécurité du compte</h1>
<p class="page-lede">Compte : <strong>{{ compte.identifiant }}</strong></p>

{% with messages = get_flashed_messages() %}
  {% if messages %}<div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>{% endif %}
{% endwith %}

<div class="card">
  <h2>Changer le mot de passe</h2>
  <form method="post">
    <input type="hidden" name="action" value="mdp">
    <label class="champ"><span>Mot de passe actuel</span>
      <input type="password" name="ancien" autocomplete="current-password" required></label>
    <div class="grille2">
      <label class="champ"><span>Nouveau mot de passe</span>
        <input type="password" name="mdp" autocomplete="new-password" required></label>
      <label class="champ"><span>Confirmer</span>
        <input type="password" name="mdp2" autocomplete="new-password" required></label>
    </div>
    <button class="btn" type="submit">Modifier le mot de passe</button>
  </form>
</div>

<div class="card">
  <h2>Question de sécurité</h2>
  <p class="aide">Elle permet de réinitialiser votre mot de passe en cas d'oubli.
    {% if compte.question %}Question actuelle : « {{ compte.question }} ».{% else %}<strong>Aucune question n'est encore définie.</strong>{% endif %}</p>
  <form method="post">
    <input type="hidden" name="action" value="question">
    <label class="champ"><span>Question</span>
      <input type="text" name="question" maxlength="120" required
             value="{{ compte.question or 'Quelle est la marque de ma première voiture ?' }}"></label>
    <label class="champ"><span>Réponse</span>
      <input type="text" name="reponse" maxlength="80" autocomplete="off" required></label>
    <button class="btn" type="submit">Enregistrer la question</button>
  </form>
</div>
{% endblock %}
__FIN_TEMPLATES_SECURITE_HTML__

info "  · static/style.css"
mkdir -p "$APP/static"
cat > "$APP/static/style.css" << '__FIN_STATIC_STYLE_CSS__'
:root {
  --bg: #EAEDF2;
  --surface: #FFFFFF;
  --ink: #161A23;
  --muted: #5A6473;
  --line: #DCE0E8;
  --accent: #5A4FE3;
  --accent-deep: #463CC4;
  --accent-soft: #F0EFFC;
  --live: #E2683A;
  --ok: #1F9D6B;
  --warn: #E0A100;
  --danger: #D2493B;
  --cal-h: clamp(340px, calc(100vh - 300px), 1000px);
  --mono: ui-monospace, "SF Mono", "JetBrains Mono", Menlo, Consolas, monospace;
  --sans: system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}

* { box-sizing: border-box; }

body {
  margin: 0;
  min-height: 100vh;
  background: radial-gradient(120% 80% at 50% -10%, #F4F5F9 0%, var(--bg) 55%);
  color: var(--ink);
  font-family: var(--sans);
  line-height: 1.5;
}

a { color: var(--accent); text-decoration: none; }
a:hover { color: var(--accent-deep); }

/* ---------- Pages plein écran (connexion / setup) ---------- */
body.center {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
}
.auth-card {
  width: 100%;
  max-width: 400px;
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 16px;
  padding: 32px;
  box-shadow: 0 1px 0 rgba(22,26,35,0.02), 0 12px 30px -18px rgba(22,26,35,0.22);
}
.eyebrow {
  font-family: var(--mono);
  font-size: 12px;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--muted);
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 14px;
}
.eyebrow::before {
  content: "";
  width: 7px; height: 7px; border-radius: 50%;
  background: var(--ok);
  box-shadow: 0 0 0 3px rgba(31,157,107,0.18);
}
.auth-card h1 { font-size: 24px; font-weight: 660; letter-spacing: -0.02em; margin: 0 0 6px; }
.auth-card .lede { color: var(--muted); margin: 0 0 24px; font-size: 14px; }

/* ---------- Application (rail + scène) ---------- */
body.app { display: flex; }

.rail {
  width: clamp(190px, 16vw, 232px);
  flex: none;
  min-height: 100vh;
  background: var(--surface);
  border-right: 1px solid var(--line);
  padding: 26px 18px;
  display: flex;
  flex-direction: column;
  position: sticky;
  top: 0;
  height: 100vh;
}
.rail-mark {
  font-weight: 680;
  letter-spacing: -0.01em;
  display: flex; align-items: center; gap: 9px;
  margin-bottom: 28px;
}
.rail-dot {
  width: 10px; height: 10px; border-radius: 3px;
  background: var(--accent);
}
.rail-nav { display: flex; flex-direction: column; gap: 2px; }
.rail-nav a {
  color: var(--ink);
  padding: 9px 12px;
  border-radius: 9px;
  font-size: 14px;
  transition: background .12s ease, color .12s ease;
}
.rail-nav a:hover { background: var(--accent-soft); color: var(--accent-deep); }
.rail-nav a.actif { background: var(--accent); color: #fff; }
.rail-foot { margin-top: auto; display: flex; flex-direction: column; gap: 12px; }
.local-tag {
  font-family: var(--mono);
  font-size: 11px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--muted);
  display: flex; align-items: center; gap: 7px;
}
.local-tag::before {
  content: ""; width: 6px; height: 6px; border-radius: 50%;
  background: var(--ok); box-shadow: 0 0 0 3px rgba(31,157,107,0.16);
}
.rail-out { font-size: 13px; color: var(--muted); }
.rail-out:hover { color: var(--danger); }
.rail-test { font-size: 13px; color: var(--muted); }
.rail-test:hover { color: var(--accent); }
.demo-tag {
  font-family: var(--mono); font-size: 10px; color: var(--muted);
  border: 1px solid var(--line); border-radius: 6px; padding: 1px 5px;
  vertical-align: 1px; font-weight: 400;
}

.stage { flex: 1; min-width: 0; padding: clamp(24px, 3vw, 40px) clamp(18px, 3.4vw, 44px) 64px; max-width: 1120px; margin: 0 auto; }
.stage-large { max-width: 1560px; }

/* ---------- Éléments communs ---------- */
.flash {
  background: #FFF7E8;
  border: 1px solid #F0DDA8;
  color: #8A6400;
  border-radius: 10px;
  padding: 12px 14px;
  font-size: 14px;
  margin-bottom: 22px;
}
.flash div + div { margin-top: 4px; }

h1.page { font-size: 28px; font-weight: 660; letter-spacing: -0.02em; margin: 0 0 4px; }
.page-lede { color: var(--muted); margin: 0 0 28px; font-size: 15px; }

.row-between { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; flex-wrap: wrap; }

.btn {
  font: inherit; font-size: 14px; font-weight: 560;
  padding: 10px 16px; border-radius: 10px;
  border: none; background: var(--accent); color: #fff;
  cursor: pointer; transition: background .14s ease, transform .06s ease;
  display: inline-flex; align-items: center; gap: 8px;
}
.btn:hover { background: var(--accent-deep); }
.btn:active { transform: translateY(1px); }
.btn.ghost { background: #fff; color: var(--ink); border: 1px solid var(--line); }
.btn.ghost:hover { border-color: var(--accent); color: var(--accent); }
.btn.danger { background: #fff; color: var(--danger); border: 1px solid #E6C7C2; }
.btn.danger:hover { background: var(--danger); color: #fff; border-color: var(--danger); }
.btn.sm { padding: 7px 12px; font-size: 13px; }
.btn:focus-visible, a:focus-visible { outline: 3px solid var(--accent); outline-offset: 2px; border-radius: 8px; }

.card {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 1px 0 rgba(22,26,35,0.02), 0 12px 30px -20px rgba(22,26,35,0.18);
}
.card + .card { margin-top: 20px; }
.card h2 { font-size: 15px; font-weight: 620; margin: 0 0 16px; letter-spacing: -0.01em; }
.card h2 .compteur { color: var(--muted); font-weight: 400; }

/* Champs de formulaire */
label.champ { display: block; margin-bottom: 16px; }
label.champ > span {
  display: block; font-size: 13px; color: var(--muted);
  margin-bottom: 6px; font-weight: 540;
}
input[type=text], input[type=password], input[type=date], textarea, select {
  width: 100%; font: inherit; font-size: 15px;
  padding: 10px 12px; border-radius: 10px;
  border: 1px solid var(--line); background: #FBFBFD; color: var(--ink);
}
textarea { resize: vertical; min-height: 80px; line-height: 1.55; }
input:focus-visible, textarea:focus-visible, select:focus-visible {
  outline: 3px solid var(--accent); outline-offset: 1px;
}
.grille2 { display: grid; grid-template-columns: 1fr 1fr; gap: 0 18px; }

/* ---------- Liste patients (dashboard) ---------- */
.patients { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 16px; }
.pcard {
  background: var(--surface); border: 1px solid var(--line); border-radius: 14px;
  padding: 18px; transition: border-color .14s ease, transform .08s ease, box-shadow .14s ease;
  display: block;
}
.pcard:hover { border-color: var(--accent); transform: translateY(-2px); box-shadow: 0 14px 26px -18px rgba(90,79,227,0.4); }
.pcard .nom { font-weight: 620; color: var(--ink); font-size: 16px; letter-spacing: -0.01em; }
.pcard .patho { color: var(--muted); font-size: 13px; margin-top: 4px; min-height: 18px; }
.pcard .meta { display: flex; align-items: center; gap: 10px; margin-top: 14px; font-size: 12.5px; color: var(--muted); }

.pastille {
  display: inline-flex; align-items: center; gap: 6px; white-space: nowrap; flex: none;
  font-family: var(--mono); font-size: 12px; padding: 3px 9px; border-radius: 999px;
  border: 1px solid var(--line);
}
.pastille .pip { width: 8px; height: 8px; border-radius: 50%; }
.douleur-1, .douleur-2, .douleur-3 { color: var(--ok); }
.douleur-4, .douleur-5, .douleur-6 { color: var(--warn); }
.douleur-7, .douleur-8, .douleur-9, .douleur-10 { color: var(--danger); }
.pip-1,.pip-2,.pip-3 { background: var(--ok); }
.pip-4,.pip-5,.pip-6 { background: var(--warn); }
.pip-7,.pip-8,.pip-9,.pip-10 { background: var(--danger); }

.vide {
  text-align: center; color: var(--muted); padding: 50px 20px;
  border: 1.5px dashed var(--line); border-radius: 14px; font-size: 15px;
}

/* ---------- Fiche patient ---------- */
.fiche-tete { margin-bottom: 24px; }
.fiche-tete h1 { font-size: 30px; font-weight: 680; letter-spacing: -0.025em; margin: 6px 0 0; }
.fiche-tete .sous { color: var(--muted); font-size: 14px; margin-top: 4px; }

.bandeau { display: grid; grid-template-columns: 1.1fr 1fr 1fr; gap: 16px; margin-bottom: 20px; }
.bloc-clef {
  border-radius: 14px; padding: 18px; border: 1px solid var(--line); background: var(--surface);
}
.bloc-clef.patho { background: linear-gradient(180deg, #FBF1EE 0%, #fff 70%); border-color: #F1D9D1; }
.bloc-clef .k {
  font-family: var(--mono); font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase;
  color: var(--muted); margin-bottom: 8px;
}
.bloc-clef.patho .k { color: var(--live); }
.bloc-clef .v { font-size: 16px; font-weight: 560; letter-spacing: -0.01em; }
.bloc-clef .v.vide-v { color: var(--muted); font-weight: 400; font-style: italic; }

.note-zone textarea { background: #FFFDF6; border-color: #F0E4BE; }
.note-row { display: flex; justify-content: flex-end; margin-top: 10px; }

/* Calendrier */
.cal-tete { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
.cal-tete .mois { font-weight: 620; font-size: 15px; min-width: 150px; text-align: center; text-transform: capitalize; }
.cal-nav { display: flex; gap: 6px; }
.cal-nav button {
  width: 34px; height: 34px; border-radius: 9px; border: 1px solid var(--line);
  background: #fff; cursor: pointer; font-size: 16px; color: var(--ink);
}
.cal-nav button:hover { border-color: var(--accent); color: var(--accent); }
.cal-grille { display: grid; grid-template-columns: repeat(7, 1fr); gap: 6px; }
.cal-jour-nom { font-size: 11px; color: var(--muted); text-align: center; font-family: var(--mono); text-transform: uppercase; letter-spacing: 0.06em; padding-bottom: 4px; }
.cal-case {
  aspect-ratio: 1 / 1; border: 1px solid var(--line); border-radius: 10px;
  background: #fff; cursor: pointer; padding: 6px; position: relative;
  font-size: 13px; color: var(--ink); text-align: left;
  transition: border-color .12s ease, background .12s ease;
}
.cal-case:hover { border-color: var(--accent); background: var(--accent-soft); }
.cal-case.vide-case { background: transparent; border-color: transparent; cursor: default; }
.cal-case.ajd { box-shadow: inset 0 0 0 2px var(--accent); }
.cal-case .pt {
  position: absolute; bottom: 6px; right: 6px;
  width: 18px; height: 18px; border-radius: 50%;
  font-size: 10px; color: #fff; display: grid; place-items: center; font-weight: 600;
}
.cal-case .fait-dot { position: absolute; bottom: 8px; left: 6px; width: 7px; height: 7px; border-radius: 50%; background: var(--accent); }
.cal-legende { display: flex; gap: 16px; margin-top: 14px; font-size: 12px; color: var(--muted); flex-wrap: wrap; }
.cal-legende span { display: inline-flex; align-items: center; gap: 6px; }
.lg { width: 12px; height: 12px; border-radius: 50%; }

/* Graphique douleur */
.graph-wrap { width: 100%; overflow-x: auto; }
.graph-vide { color: var(--muted); font-style: italic; font-size: 14px; padding: 30px 0; text-align: center; }
svg.graph text { font-family: var(--mono); font-size: 11px; fill: var(--muted); }

/* Calendrier général (agenda) */
.vue-toggle { display: inline-flex; border: 1px solid var(--line); border-radius: 9px; overflow: hidden; }
.vue-toggle button {
  border: none; background: #fff; padding: 7px 14px; font: inherit; font-size: 13px;
  cursor: pointer; color: var(--muted); transition: background .12s ease, color .12s ease;
}
.vue-toggle button + button { border-left: 1px solid var(--line); }
.vue-toggle button:hover { color: var(--accent); }
.vue-toggle button.actif { background: var(--accent); color: #fff; }

.cal-case.sel { box-shadow: inset 0 0 0 2px var(--accent); background: var(--accent-soft); }
.agenda-grille { height: var(--cal-h); grid-template-rows: auto; grid-auto-rows: 1fr; }
.agenda-grille .cal-case {
  aspect-ratio: auto; min-height: 0; padding: 5px 6px;
  display: flex; flex-direction: column; align-items: stretch; gap: 2px; overflow: hidden;
}
.agenda-grille .cal-case .cal-jour-num { font-size: 12px; font-weight: 600; color: var(--muted); }
.agenda-grille .cal-case.ajd .cal-jour-num { color: var(--accent); }
.cal-noms { display: flex; flex-direction: column; gap: 1px; overflow: hidden; min-width: 0; }
.nom-mini {
  font-size: 10.5px; line-height: 1.35; color: var(--ink);
  display: flex; align-items: center; gap: 4px; min-width: 0; overflow: hidden;
}
.nom-mini .nm-dot { width: 6px; height: 6px; border-radius: 50%; flex: none; }
.nm-dot { width: 6px; height: 6px; border-radius: 50%; flex: none; }
.nom-txt { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0; }
.nom-plus { font-size: 10px; color: var(--muted); font-family: var(--mono); }
@media (max-width: 760px) {
  .agenda-grille { height: auto; grid-auto-rows: minmax(58px, auto); }
  .agenda-grille .cal-case { min-height: 58px; }
  .nom-mini { font-size: 9.5px; }
}

.agenda-jour h2 { font-size: 15px; }
.jour-liste { max-height: 56vh; overflow-y: auto; overflow-x: hidden; scrollbar-gutter: stable; margin: 4px 0 4px; }
.jour-liste .agenda-item:first-child { margin-top: 0; }

/* Vue semaine */
.semaine-grille { gap: 8px; align-items: stretch; height: var(--cal-h); grid-auto-rows: 1fr; }
.sem-col {
  border: 1px solid var(--line); border-radius: 12px; background: #fff;
  overflow: hidden; display: flex; flex-direction: column; min-width: 0;
  height: 100%;
}
.sem-col.ajd { border-color: var(--accent); box-shadow: inset 0 0 0 1px var(--accent); }
.sem-tete {
  flex: none;
  border: none; background: var(--accent-soft); color: var(--ink);
  padding: 8px 6px; cursor: pointer; border-bottom: 1px solid var(--line);
  display: flex; flex-direction: column; align-items: center; gap: 1px;
  transition: background .12s ease;
}
.sem-tete:hover { background: #E6E3FB; }
.sem-col.ajd .sem-tete { background: var(--accent); color: #fff; }
.sem-jour { font-family: var(--mono); font-size: 10px; letter-spacing: 0.06em; text-transform: uppercase; opacity: .85; }
.sem-num { font-size: 16px; font-weight: 600; line-height: 1.1; }
.sem-liste {
  flex: 1; min-height: 0; display: flex; flex-direction: column; gap: 2px; padding: 6px;
  min-width: 0; overflow-y: auto; overflow-x: hidden; scrollbar-gutter: stable;
}
.sem-item {
  display: flex; align-items: center; gap: 5px; padding: 4px 5px; border-radius: 7px;
  text-decoration: none; color: var(--ink); font-size: 12px; min-width: 0; flex: none;
}
.sem-item:hover { background: var(--accent-soft); }
.sem-item .nom-txt { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0; }
.sem-vide { color: var(--muted); text-align: center; padding: 10px 0; font-size: 13px; }
@media (max-width: 760px) {
  .semaine-grille { grid-template-columns: 1fr; height: auto; grid-auto-rows: auto; }
  .sem-col { height: auto; }
  .sem-liste { max-height: 280px; }
  .sem-tete { flex-direction: row; gap: 8px; justify-content: flex-start; padding-left: 12px; }
}
.sem-h { font-family: var(--mono); font-size: 10px; color: var(--muted); flex: none; }

/* Vue jour (créneaux) */
.jour-vue {
  height: var(--cal-h); overflow-y: auto; overflow-x: hidden; scrollbar-gutter: stable;
  border: 1px solid var(--line); border-radius: 12px; background: #fff; padding: 2px 4px;
}
.jour-sans { border-bottom: 2px solid var(--line); margin-bottom: 2px; }
.jour-sans-tete {
  font-family: var(--mono); font-size: 11px; text-transform: uppercase; letter-spacing: .06em;
  color: var(--muted); padding: 8px 6px 2px;
}
.creneau { display: flex; gap: 10px; align-items: flex-start; padding: 3px 6px; border-bottom: 1px solid var(--line); }
.creneau:last-child { border-bottom: none; }
.creneau-h { font-family: var(--mono); font-size: 12px; color: var(--muted); width: 46px; flex: none; padding-top: 8px; }
.creneau-corps { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; flex: 1; min-width: 0; padding: 4px 0; }
.creneau-pat {
  display: inline-flex; align-items: center; gap: 5px; padding: 4px 9px;
  border: 1px solid var(--line); border-radius: 999px; text-decoration: none;
  color: var(--ink); font-size: 12.5px; background: #fff; max-width: 100%;
}
.creneau-pat:hover { border-color: var(--accent); background: var(--accent-soft); }
.creneau-pat .nom-txt { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.chip-eva {
  color: #fff; font-size: 10px; font-weight: 600; min-width: 16px; height: 16px;
  border-radius: 8px; display: inline-grid; place-items: center; padding: 0 3px;
}
.chip-prat {
  color: #fff; font-size: 10px; font-weight: 600; height: 16px; flex: none;
  border-radius: 8px; display: inline-grid; place-items: center; padding: 0 7px;
  white-space: nowrap; letter-spacing: 0.02em;
}
.creneau-add {
  width: 24px; height: 24px; border-radius: 7px; border: 1px dashed var(--line);
  background: #fff; color: var(--muted); cursor: pointer; font-size: 15px; line-height: 1;
  display: grid; place-items: center; flex: none;
}
.creneau-add:hover { border-color: var(--accent); color: var(--accent); border-style: solid; }
.agenda-item {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  padding: 12px 14px; border: 1px solid var(--line); border-radius: 12px;
  text-decoration: none; color: var(--ink);
  transition: border-color .12s ease, background .12s ease;
}
.agenda-item + .agenda-item { margin-top: 8px; }
.agenda-item:hover { border-color: var(--accent); background: var(--accent-soft); }
.agenda-item .who { font-weight: 600; }
.agenda-item .extrait { color: var(--muted); font-size: 13px; margin-top: 3px; }

/* Bilan oral (enregistreur) */
.aide { color: var(--muted); font-size: 13.5px; margin: 0 0 16px; }
.aide code { font-family: var(--mono); font-size: 12.5px; background: var(--accent-soft); padding: 2px 6px; border-radius: 5px; color: var(--accent-deep); }
.rec-row { display: flex; align-items: center; gap: 18px; }
.rec-btn {
  flex: none; width: 56px; height: 56px; border-radius: 50%;
  border: none; background: var(--accent); color: #fff; cursor: pointer;
  display: grid; place-items: center; position: relative;
  transition: background .15s ease, transform .08s ease;
}
.rec-btn:hover { background: var(--accent-deep); }
.rec-btn:active { transform: scale(0.96); }
.rec-btn:focus-visible { outline: 3px solid var(--accent); outline-offset: 3px; }
.rec-btn .dot { width: 18px; height: 18px; border-radius: 5px; background: #fff; transition: all .18s ease; }
.rec-btn.live { background: var(--live); }
.rec-btn.live .dot { width: 16px; height: 16px; border-radius: 3px; }
.rec-btn.live::after {
  content: ""; position: absolute; inset: -6px; border-radius: 50%;
  border: 2px solid var(--live); animation: pulse 1.4s ease-out infinite;
}
@keyframes pulse { 0% { transform: scale(0.9); opacity: .8; } 100% { transform: scale(1.35); opacity: 0; } }
.meter { display: flex; align-items: flex-end; gap: 4px; height: 40px; flex: 1; }
.meter .bar { flex: 1; background: var(--line); border-radius: 3px; height: 6px; transition: height .06s linear, background .12s ease; }
.meter.live .bar { background: var(--accent); }
.timer { font-family: var(--mono); font-size: 15px; color: var(--muted); min-width: 52px; text-align: right; font-variant-numeric: tabular-nums; }
.timer.live { color: var(--live); }
.hint { margin: 14px 2px 0; font-size: 13px; color: var(--muted); }
.status { margin-top: 16px; font-size: 14px; min-height: 22px; display: flex; align-items: center; gap: 10px; }
.status .spin { width: 15px; height: 15px; border-radius: 50%; border: 2px solid var(--line); border-top-color: var(--accent); animation: spin .8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.status.err { color: var(--live); }
.bilan-res { margin-top: 18px; }
.bilan-res details { margin-top: 10px; }
.bilan-res summary { cursor: pointer; font-size: 13px; color: var(--muted); }
.bilan-res .brut { margin-top: 8px; padding: 12px; background: #FBFBFD; border: 1px solid var(--line); border-radius: 10px; font-size: 13.5px; color: var(--muted); white-space: pre-wrap; }
.bilan-actions { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-top: 14px; flex-wrap: wrap; }
.moteur-tag { font-family: var(--mono); font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.08em; }

/* Liste des séances */
.seance-item { border: 1px solid var(--line); border-radius: 12px; padding: 14px 16px; }
.seance-item + .seance-item { margin-top: 10px; }
.seance-item .tete { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
.seance-item .date { font-weight: 600; font-size: 14px; }
.seance-item .fait { color: var(--muted); font-size: 14px; margin-top: 6px; white-space: pre-wrap; }

/* Barre Reformuler (IA) */
.reform-row { display: flex; align-items: center; gap: 10px; margin: -6px 0 8px; }
.reform-status { font-size: 12px; color: var(--muted); }
.reform-status.err { color: var(--live); }
.reform-status .spin { display: inline-block; width: 12px; height: 12px; vertical-align: -2px; border-radius: 50%; border: 2px solid var(--line); border-top-color: var(--accent); animation: spin .8s linear infinite; }

/* Modale séance */
.overlay {
  position: fixed; inset: 0; background: rgba(22,26,35,0.42);
  display: none; align-items: center; justify-content: center; padding: 20px; z-index: 50;
}
.overlay.ouvert { display: flex; }
.modale {
  width: 100%; max-width: 460px; background: var(--surface);
  border-radius: 16px; padding: 24px; box-shadow: 0 30px 60px -20px rgba(22,26,35,0.5);
}
.modale h3 { margin: 0 0 4px; font-size: 18px; letter-spacing: -0.01em; }
.modale .when { color: var(--muted); font-size: 13px; margin-bottom: 18px; }

/* Curseur EVA */
.eva { margin-bottom: 8px; }
.eva-haut { display: flex; align-items: baseline; justify-content: space-between; margin-bottom: 8px; }
.eva-val { font-family: var(--mono); font-size: 22px; font-weight: 600; }
.eva input[type=range] { width: 100%; accent-color: var(--accent); }
.eva-echelle { display: flex; justify-content: space-between; font-size: 11px; color: var(--muted); font-family: var(--mono); margin-top: 4px; }
.modale-actions { display: flex; justify-content: space-between; align-items: center; margin-top: 22px; }

@media (max-width: 760px) {
  .rail { position: static; width: 100%; height: auto; min-height: 0; flex-direction: row; align-items: center; flex-wrap: wrap; }
  .rail-foot { margin-top: 0; flex-direction: row; margin-left: auto; }
  body.app { flex-direction: column; }
  .stage { padding: 24px 18px 48px; }
  .bandeau { grid-template-columns: 1fr; }
  .grille2 { grid-template-columns: 1fr; }
}
@media (prefers-reduced-motion: reduce) {
  * { transition: none !important; }
}

/* Administration des praticiens */
.kbd {
  font-family: var(--mono); font-size: 13px; background: var(--accent-soft);
  border: 1px solid var(--line); border-radius: 7px; padding: 4px 9px; color: var(--ink);
}
.lien-discret { display: inline-block; margin-top: 12px; font-size: 13px; color: var(--muted); }
.lien-discret:hover { color: var(--accent); }
.prat-liste { list-style: none; margin: 10px 0 0; padding: 0; }
.prat-liste li {
  display: flex; align-items: center; gap: 10px; padding: 9px 4px;
  border-bottom: 1px solid var(--line);
}
.prat-liste li:last-child { border-bottom: none; }
.prat-pastille { width: 12px; height: 12px; border-radius: 50%; flex: none; }
.prat-nom { font-weight: 600; flex: 1; min-width: 0; }
.prat-liste form { margin: 0; }
.prat-ajout { display: flex; gap: 8px; margin-top: 6px; }
.prat-ajout input {
  flex: 1; min-width: 0; padding: 9px 11px; border: 1px solid var(--line);
  border-radius: 9px; font: inherit; background: #fff;
}

/* Badges de rôle de compte */
.role-tag {
  font-family: var(--mono); font-size: 10px; color: var(--muted);
  border: 1px solid var(--line); border-radius: 6px; padding: 2px 7px; flex: none;
  text-transform: uppercase; letter-spacing: 0.04em;
}
.role-admin { color: #fff; background: var(--accent); border-color: var(--accent); }
__FIN_STATIC_STYLE_CSS__

info "  · static/app.js"
mkdir -p "$APP/static"
cat > "$APP/static/app.js" << '__FIN_STATIC_APP_JS__'
/* Fiche patient : calendrier mensuel, graphique douleur (SVG), modale séance.
   Aucune dépendance externe : tout est fait main pour rester hors-ligne. */
(function () {
  "use strict";

  var MOIS = ["janvier","février","mars","avril","mai","juin","juillet","août",
              "septembre","octobre","novembre","décembre"];
  var JOURS = ["Lun","Mar","Mer","Jeu","Ven","Sam","Dim"];

  var seances = {};        // "AAAA-MM-JJ" -> {fait, douleur}
  var seancesIds = {};     // "AAAA-MM-JJ" -> id (pour la suppression)
  var vue = new Date();    // mois affiché
  vue.setDate(1);

  var grille = document.getElementById("calGrille");
  var moisLabel = document.getElementById("calMois");
  var overlay = document.getElementById("overlay");

  function iso(d) {
    return d.getFullYear() + "-" +
           String(d.getMonth() + 1).padStart(2, "0") + "-" +
           String(d.getDate()).padStart(2, "0");
  }
  function couleurDouleur(n) {
    if (!n) return null;
    if (n <= 3) return getCss("--ok");
    if (n <= 6) return getCss("--warn");
    return getCss("--danger");
  }
  function getCss(v) {
    return getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  }

  /* ---------------- Calendrier ---------------- */
  function dessinerCalendrier() {
    moisLabel.textContent = MOIS[vue.getMonth()] + " " + vue.getFullYear();
    grille.innerHTML = "";
    JOURS.forEach(function (j) {
      var c = document.createElement("div");
      c.className = "cal-jour-nom";
      c.textContent = j;
      grille.appendChild(c);
    });
    var premier = new Date(vue.getFullYear(), vue.getMonth(), 1);
    var decalage = (premier.getDay() + 6) % 7; // lundi = 0
    var nbJours = new Date(vue.getFullYear(), vue.getMonth() + 1, 0).getDate();
    var ajdIso = iso(new Date());

    for (var i = 0; i < decalage; i++) {
      var v = document.createElement("div");
      v.className = "cal-case vide-case";
      grille.appendChild(v);
    }
    for (var jour = 1; jour <= nbJours; jour++) {
      var d = new Date(vue.getFullYear(), vue.getMonth(), jour);
      var key = iso(d);
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cal-case" + (key === ajdIso ? " ajd" : "");
      btn.textContent = jour;
      var s = seances[key];
      if (s) {
        if (s.fait) {
          var fd = document.createElement("span");
          fd.className = "fait-dot";
          btn.appendChild(fd);
        }
        if (s.douleur) {
          var pt = document.createElement("span");
          pt.className = "pt";
          pt.style.background = couleurDouleur(s.douleur);
          pt.textContent = s.douleur;
          btn.appendChild(pt);
        }
      }
      (function (k) {
        btn.addEventListener("click", function () { ouvrirModale(k); });
      })(key);
      grille.appendChild(btn);
    }
  }

  /* ---------------- Graphique douleur (SVG) ---------------- */
  function dessinerGraphique() {
    var wrap = document.getElementById("graphWrap");
    var vide = document.getElementById("graphVide");
    var points = Object.keys(seances)
      .filter(function (k) { return seances[k].douleur; })
      .sort()
      .map(function (k) { return { date: k, d: seances[k].douleur }; });

    var ancien = wrap.querySelector("svg.graph");
    if (ancien) ancien.remove();

    if (points.length === 0) { vide.style.display = "block"; return; }
    vide.style.display = "none";

    var W = Math.max(560, points.length * 60 + 80);
    var H = 240, padL = 38, padR = 20, padT = 18, padB = 46;
    var plotW = W - padL - padR, plotH = H - padT - padB;
    var svgns = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(svgns, "svg");
    svg.setAttribute("class", "graph");
    svg.setAttribute("viewBox", "0 0 " + W + " " + H);
    svg.setAttribute("width", W);
    svg.setAttribute("height", H);

    function x(i) {
      return padL + (points.length === 1 ? plotW / 2 : (i / (points.length - 1)) * plotW);
    }
    function y(v) { return padT + plotH - (v / 10) * plotH; }

    // Grille horizontale 0,2,4,6,8,10
    [0, 2, 4, 6, 8, 10].forEach(function (lvl) {
      var yy = y(lvl);
      var ligne = document.createElementNS(svgns, "line");
      ligne.setAttribute("x1", padL); ligne.setAttribute("x2", W - padR);
      ligne.setAttribute("y1", yy); ligne.setAttribute("y2", yy);
      ligne.setAttribute("stroke", getCss("--line"));
      ligne.setAttribute("stroke-width", lvl === 0 ? 1.5 : 1);
      svg.appendChild(ligne);
      var t = document.createElementNS(svgns, "text");
      t.setAttribute("x", padL - 8); t.setAttribute("y", yy + 4);
      t.setAttribute("text-anchor", "end");
      t.textContent = lvl;
      svg.appendChild(t);
    });

    // Aire + ligne
    var dPath = "", dArea = "";
    points.forEach(function (p, i) {
      dPath += (i === 0 ? "M" : "L") + x(i) + " " + y(p.d) + " ";
    });
    dArea = dPath + "L" + x(points.length - 1) + " " + y(0) + " L" + x(0) + " " + y(0) + " Z";

    var aire = document.createElementNS(svgns, "path");
    aire.setAttribute("d", dArea);
    aire.setAttribute("fill", getCss("--accent"));
    aire.setAttribute("opacity", "0.08");
    svg.appendChild(aire);

    var ligne2 = document.createElementNS(svgns, "path");
    ligne2.setAttribute("d", dPath);
    ligne2.setAttribute("fill", "none");
    ligne2.setAttribute("stroke", getCss("--accent"));
    ligne2.setAttribute("stroke-width", "2.5");
    ligne2.setAttribute("stroke-linejoin", "round");
    ligne2.setAttribute("stroke-linecap", "round");
    svg.appendChild(ligne2);

    // Points + dates
    points.forEach(function (p, i) {
      var c = document.createElementNS(svgns, "circle");
      c.setAttribute("cx", x(i)); c.setAttribute("cy", y(p.d));
      c.setAttribute("r", "5");
      c.setAttribute("fill", couleurDouleur(p.d));
      c.setAttribute("stroke", "#fff");
      c.setAttribute("stroke-width", "2");
      var titre = document.createElementNS(svgns, "title");
      titre.textContent = p.date + " — EVA " + p.d;
      c.appendChild(titre);
      svg.appendChild(c);

      if (points.length <= 14 || i % 2 === 0) {
        var t = document.createElementNS(svgns, "text");
        t.setAttribute("x", x(i)); t.setAttribute("y", H - 24);
        t.setAttribute("text-anchor", "middle");
        t.setAttribute("font-size", "10");
        t.textContent = p.date.slice(5); // MM-JJ
        svg.appendChild(t);
      }
    });

    wrap.appendChild(svg);
  }

  /* ---------------- Modale ---------------- */
  function ouvrirModale(key) {
    var s = seances[key] || { fait: "", douleur: 0, heure: "", praticien: "" };
    document.getElementById("fDate").value = key;
    document.getElementById("fHeure").value = s.heure || "";
    document.getElementById("fPraticien").value = s.praticien || "";
    document.getElementById("fFait").value = s.fait || "";
    var d = s.douleur || 0;
    document.getElementById("fDouleur").value = d;
    majEva(d);
    document.getElementById("modDate").textContent = formaterDate(key);
    var supBtn = document.getElementById("modSupprimer");
    supBtn.style.visibility = seances[key] ? "visible" : "hidden";
    supBtn.dataset.key = key;
    overlay.classList.add("ouvert");
    if (window.__resetReform) window.__resetReform();
    document.getElementById("fFait").focus();
  }
  function fermerModale() { overlay.classList.remove("ouvert"); }

  function majEva(v) {
    document.getElementById("evaVal").textContent = (v > 0) ? v : "—";
  }
  function formaterDate(key) {
    var p = key.split("-");
    return p[2] + " " + MOIS[parseInt(p[1], 10) - 1] + " " + p[0];
  }

  /* ---------------- Données ---------------- */
  function charger() {
    fetch(window.SEANCES_URL)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        seances = {};
        seancesIds = {};
        data.forEach(function (s) {
          seances[s.date_seance] = { fait: s.fait || "", douleur: s.douleur || 0, heure: s.heure || "", praticien: s.praticien || "" };
          seancesIds[s.date_seance] = s.id;
        });
        dessinerCalendrier();
        dessinerGraphique();
      });
  }

  /* ---------------- Événements ---------------- */
  document.getElementById("calPrev").addEventListener("click", function () {
    vue.setMonth(vue.getMonth() - 1); dessinerCalendrier();
  });
  document.getElementById("calNext").addEventListener("click", function () {
    vue.setMonth(vue.getMonth() + 1); dessinerCalendrier();
  });
  document.getElementById("fDouleur").addEventListener("input", function (e) {
    majEva(parseInt(e.target.value, 10));
  });
  document.getElementById("modFermer").addEventListener("click", fermerModale);
  overlay.addEventListener("click", function (e) { if (e.target === overlay) fermerModale(); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && overlay.classList.contains("ouvert")) fermerModale();
  });

  document.getElementById("modSupprimer").addEventListener("click", function () {
    if (!confirm("Supprimer cette séance ?")) return;
    var key = this.dataset.key;
    var sid = seancesIds[key];
    if (!sid) { fermerModale(); return; }
    var f = document.createElement("form");
    f.method = "post";
    f.action = window.SUPPR_BASE.replace(/\/0\/supprimer$/, "/" + sid + "/supprimer");
    document.body.appendChild(f);
    f.submit();
  });

  // Bouton « Modifier » dans la liste des séances
  Array.prototype.forEach.call(document.querySelectorAll(".js-edit"), function (b) {
    b.addEventListener("click", function () {
      ouvrirModale(b.dataset.date);
    });
  });

  // Reformulation IA du champ « ce qui a été fait »
  var reformBtn = document.getElementById("reformBtn");
  if (reformBtn) {
    var reformUndo = document.getElementById("reformUndo");
    var reformStatus = document.getElementById("reformStatus");
    var avantReform = "";
    window.__resetReform = function () {
      reformUndo.style.display = "none";
      reformStatus.textContent = "";
      reformStatus.className = "reform-status";
      avantReform = "";
    };
    reformBtn.addEventListener("click", function () {
      var f = document.getElementById("fFait");
      var t = f.value.trim();
      if (!window.AUDIO_DISPO) {
        reformStatus.className = "reform-status err";
        reformStatus.textContent = "Module IA non installé. Relancez : bash installer.sh --avec-audio";
        return;
      }
      if (!t) { reformStatus.className = "reform-status"; reformStatus.textContent = "Rien à reformuler."; return; }
      reformBtn.disabled = true;
      reformStatus.className = "reform-status";
      reformStatus.innerHTML = '<span class="spin"></span> Reformulation en local…';
      var fd = new FormData();
      fd.append("texte", t);
      fetch(window.REFORM_URL, { method: "POST", body: fd })
        .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
        .then(function (res) {
          reformBtn.disabled = false;
          if (!res.ok) throw new Error(res.d.erreur || "Erreur.");
          if (res.d.moteur === "indisponible") {
            reformStatus.className = "reform-status err";
            reformStatus.textContent = "Modèle injoignable (Ollama éteint) : texte inchangé.";
            return;
          }
          avantReform = t;
          f.value = res.d.texte || t;
          reformUndo.style.display = "";
          reformStatus.className = "reform-status";
          reformStatus.textContent = "Reformulé. Relisez avant d'enregistrer.";
        })
        .catch(function (e) {
          reformBtn.disabled = false;
          reformStatus.className = "reform-status err";
          reformStatus.textContent = "Échec : " + e.message;
        });
    });
    reformUndo.addEventListener("click", function () {
      if (!avantReform) return;
      document.getElementById("fFait").value = avantReform;
      reformUndo.style.display = "none";
      reformStatus.className = "reform-status";
      reformStatus.textContent = "Texte d'origine rétabli.";
    });
  }

  charger();
})();

/* ===================== Bilan oral ===================== */
(function () {
  "use strict";
  var recBtn = document.getElementById("recBtn");
  if (!recBtn) return; // module audio non installé

  var meter = document.getElementById("meter");
  var bars = Array.prototype.slice.call(meter.querySelectorAll(".bar"));
  var timerEl = document.getElementById("timer");
  var recHint = document.getElementById("recHint");
  var statusEl = document.getElementById("bilanStatus");
  var resEl = document.getElementById("bilanRes");
  var resumeEl = document.getElementById("bilanResume");
  var brutEl = document.getElementById("bilanBrut");
  var moteurTag = document.getElementById("moteurTag");
  var btnSeance = document.getElementById("bilanSeance");
  var btnNote = document.getElementById("bilanNote");
  var dateEl = document.getElementById("bilanDate");
  var dateInfo = document.getElementById("dateInfo");

  var mediaRecorder = null, chunks = [], stream = null;
  var audioCtx = null, analyser = null, rafId = null;
  var startTime = 0, timerInt = null, douleurDetectee = 0;

  function fmt(sec) {
    var m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m + ":" + String(s).padStart(2, "0");
  }
  function setStatus(html, err) {
    statusEl.className = "status" + (err ? " err" : "");
    statusEl.innerHTML = html;
  }
  function startMeter() {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    var src = audioCtx.createMediaStreamSource(stream);
    analyser = audioCtx.createAnalyser();
    analyser.fftSize = 64;
    src.connect(analyser);
    var data = new Uint8Array(analyser.frequencyBinCount);
    meter.classList.add("live");
    (function loop() {
      analyser.getByteFrequencyData(data);
      bars.forEach(function (bar, i) {
        var v = data[i * 2] || 0;
        bar.style.height = (6 + (v / 255) * 34).toFixed(0) + "px";
      });
      rafId = requestAnimationFrame(loop);
    })();
  }
  function stopMeter() {
    if (rafId) cancelAnimationFrame(rafId);
    if (audioCtx) audioCtx.close();
    meter.classList.remove("live");
    bars.forEach(function (b) { b.style.height = "6px"; });
  }

  function start() {
    navigator.mediaDevices.getUserMedia({ audio: true }).then(function (s) {
      stream = s;
      chunks = [];
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.ondataavailable = function (e) { if (e.data.size) chunks.push(e.data); };
      mediaRecorder.onstop = function () {
        var blob = new Blob(chunks, { type: mediaRecorder.mimeType || "audio/webm" });
        envoyer(blob);
      };
      mediaRecorder.start();
      recBtn.classList.add("live");
      timerEl.classList.add("live");
      recHint.textContent = "Dictée en cours… Re-cliquez pour arrêter.";
      startTime = Date.now();
      timerEl.textContent = "0:00";
      timerInt = setInterval(function () {
        timerEl.textContent = fmt((Date.now() - startTime) / 1000);
      }, 250);
      startMeter();
    }).catch(function () {
      setStatus("Accès au micro refusé. Autorisez le micro pour cette page.", true);
    });
  }
  function stop() {
    if (mediaRecorder && mediaRecorder.state !== "inactive") mediaRecorder.stop();
    if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
    clearInterval(timerInt);
    stopMeter();
    recBtn.classList.remove("live");
    timerEl.classList.remove("live");
    recHint.textContent = "Cliquez pour dicter. Re-cliquez pour arrêter et lancer la transcription.";
  }
  recBtn.addEventListener("click", function () {
    if (recBtn.classList.contains("live")) stop(); else start();
  });

  function envoyer(blob) {
    resEl.style.display = "none";
    setStatus('<span class="spin"></span> Transcription puis résumé en local… (calcul CPU, patientez)');
    var fd = new FormData();
    fd.append("audio", blob, "bilan.webm");
    fetch(window.BILAN_URL, { method: "POST", body: fd })
      .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error(res.d.erreur || "Erreur inconnue.");
        resumeEl.value = res.d.resume || "(résumé vide)";
        brutEl.textContent = res.d.transcription || "(rien transcrit)";
        douleurDetectee = res.d.douleur || 0;
        var moteur = res.d.moteur === "ollama" ? "résumé : IA locale (Ollama)" :
                     res.d.moteur === "règles" ? "résumé : mise en forme locale (Ollama injoignable)" : "";
        var dl = douleurDetectee ? " · douleur détectée : EVA " + douleurDetectee : "";
        moteurTag.textContent = moteur + dl;
        dateEl.value = window.AUJOURDHUI;
        dateEl.max = window.AUJOURDHUI;
        verifDate();
        resEl.style.display = "block";
        setStatus("Terminé. Choisissez la date puis insérez.");
      })
      .catch(function (e) { setStatus("Échec : " + e.message, true); });
  }

  function soumettre(action, champs) {
    var f = document.createElement("form");
    f.method = "post";
    f.action = action;
    Object.keys(champs).forEach(function (k) {
      var i = document.createElement("input");
      i.type = "hidden"; i.name = k; i.value = champs[k];
      f.appendChild(i);
    });
    document.body.appendChild(f);
    f.submit();
  }

  function verifDate() {
    dateInfo.textContent = "";
    var d = dateEl.value;
    if (!d) return;
    fetch(window.SEANCES_URL)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var existe = data.filter(function (s) { return s.date_seance === d; })[0];
        if (existe) {
          dateInfo.textContent = "Une séance existe déjà ce jour-là : son contenu sera remplacé.";
        } else if (d !== window.AUJOURDHUI) {
          dateInfo.textContent = "Séance antérieure : le résumé sera enregistré à cette date.";
        }
      })
      .catch(function () {});
  }
  dateEl.addEventListener("change", verifDate);

  btnSeance.addEventListener("click", function () {
    if (!resumeEl.value.trim()) return;
    soumettre(window.SEANCE_URL, {
      date_seance: dateEl.value || window.AUJOURDHUI,
      fait: resumeEl.value.trim(),
      douleur: douleurDetectee || 0,
    });
  });

  btnNote.addEventListener("click", function () {
    if (!resumeEl.value.trim()) return;
    var noteEl = document.querySelector('textarea[name="note_libre"]');
    var ancienne = noteEl ? noteEl.value.trim() : "";
    var ajout = "[" + (dateEl.value || window.AUJOURDHUI) + "] " + resumeEl.value.trim();
    soumettre(window.NOTE_URL, {
      note_libre: ancienne ? (ancienne + "\n" + ajout) : ajout,
    });
  });
})();
__FIN_STATIC_APP_JS__

info "  · static/agenda.js"
mkdir -p "$APP/static"
cat > "$APP/static/agenda.js" << '__FIN_STATIC_AGENDA_JS__'
/* Calendrier général : vues Jour, Semaine et Mois.
   - Jour : grille de créneaux de 30 min ; on assigne un patient à un créneau.
   - Semaine : 7 colonnes listant tous les patients de chaque jour.
   - Mois : grille classique (jusqu'à 3 noms + N…).
   Clic sur un patient -> sa fiche. */
(function () {
  "use strict";

  var MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
              "août", "septembre", "octobre", "novembre", "décembre"];
  var JOURS = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
  var JOURS_LONG = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"];
  var H_DEBUT = 7, H_FIN = 20;   // créneaux de 7:00 à 19:30

  var agenda = {};            // "AAAA-MM-JJ" -> [ {patient_id, prenom, nom, douleur, heure, archive} ]
  var patients = [];          // [{id, prenom, nom}]
  var mode = "mois";          // "jour" | "semaine" | "mois"
  var ancre = new Date();
  var selection = null;

  var grille = document.getElementById("calGrille");
  var moisLabel = document.getElementById("calMois");
  var overlay = document.getElementById("jourOverlay");
  var jourTitre = document.getElementById("jourTitre");
  var jourSous = document.getElementById("jourSous");
  var jourListe = document.getElementById("jourListe");
  var btnJour = document.getElementById("vueJour");
  var btnSemaine = document.getElementById("vueSemaine");
  var btnMois = document.getElementById("vueMois");

  // Fenêtre d'ajout de créneau
  var crOverlay = document.getElementById("creneauOverlay");
  var crQuand = document.getElementById("creneauQuand");
  var crSelect = document.getElementById("creneauPatient");
  var crPrat = document.getElementById("creneauPraticien");
  var crDateHeure = { date: null, heure: null };

  function iso(d) {
    return d.getFullYear() + "-" +
           String(d.getMonth() + 1).padStart(2, "0") + "-" +
           String(d.getDate()).padStart(2, "0");
  }
  function getCss(v) {
    return getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  }
  function couleur(n) {
    if (!n) return getCss("--muted");
    if (n <= 3) return getCss("--ok");
    if (n <= 6) return getCss("--warn");
    return getCss("--danger");
  }
  function couleurPrat(nom) {
    return (window.PRAT_COULEURS || {})[nom] || "#8A93A6";
  }
  function jolie(key) {
    var p = key.split("-");
    return p[2] + " " + MOIS[parseInt(p[1], 10) - 1] + " " + p[0];
  }
  function urlPatient(id) { return window.PATIENT_BASE.replace(/\/0$/, "/" + id); }
  function lundi(d) {
    var x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    x.setDate(x.getDate() - ((x.getDay() + 6) % 7));
    return x;
  }
  function ligneNom(it) {
    var dot = document.createElement("span");
    dot.className = "nm-dot";
    dot.style.background = couleurPrat(it.praticien);
    var txt = document.createElement("span");
    txt.className = "nom-txt";
    txt.textContent = it.nom + " " + it.prenom;
    return [dot, txt];
  }

  /* ---------------- Vue jour ---------------- */
  function dessinerJour() {
    grille.className = "jour-vue";
    grille.innerHTML = "";
    var key = iso(ancre);
    var items = agenda[key] || [];
    var parHeure = {};
    var sansHeure = [];
    items.forEach(function (it) {
      if (it.heure) (parHeure[it.heure] = parHeure[it.heure] || []).push(it);
      else sansHeure.push(it);
    });

    if (sansHeure.length) {
      var bloc = document.createElement("div");
      bloc.className = "jour-sans";
      var t = document.createElement("div");
      t.className = "jour-sans-tete";
      t.textContent = "Sans horaire";
      bloc.appendChild(t);
      var corps = document.createElement("div");
      corps.className = "creneau-corps";
      sansHeure.forEach(function (it) { corps.appendChild(chipPatient(it)); });
      bloc.appendChild(corps);
      grille.appendChild(bloc);
    }

    for (var min = H_DEBUT * 60; min < H_FIN * 60; min += 30) {
      var hh = String(Math.floor(min / 60)).padStart(2, "0");
      var mm = String(min % 60).padStart(2, "0");
      var slot = hh + ":" + mm;
      var rang = document.createElement("div");
      rang.className = "creneau";
      var lab = document.createElement("div");
      lab.className = "creneau-h";
      lab.textContent = slot;
      rang.appendChild(lab);
      var corps2 = document.createElement("div");
      corps2.className = "creneau-corps";
      (parHeure[slot] || []).forEach(function (it) { corps2.appendChild(chipPatient(it)); });
      var add = document.createElement("button");
      add.type = "button";
      add.className = "creneau-add";
      add.textContent = "+";
      add.title = "Ajouter un patient à " + slot;
      (function (s) {
        add.addEventListener("click", function () { ouvrirCreneau(key, s); });
      })(slot);
      corps2.appendChild(add);
      rang.appendChild(corps2);
      grille.appendChild(rang);
    }
  }

  function chipPatient(it) {
    var a = document.createElement("a");
    a.className = "creneau-pat";
    a.href = urlPatient(it.patient_id);
    ligneNom(it).forEach(function (e) { a.appendChild(e); });
    if (it.praticien) {
      var b = document.createElement("span");
      b.className = "chip-prat";
      b.textContent = it.praticien;
      b.style.background = couleurPrat(it.praticien);
      a.appendChild(b);
    }
    return a;
  }

  /* ---------------- Vue mois ---------------- */
  function dessinerMois() {
    grille.className = "cal-grille agenda-grille";
    grille.innerHTML = "";
    JOURS.forEach(function (j) {
      var c = document.createElement("div");
      c.className = "cal-jour-nom";
      c.textContent = j;
      grille.appendChild(c);
    });
    var an = ancre.getFullYear(), mo = ancre.getMonth();
    var premier = new Date(an, mo, 1);
    var decalage = (premier.getDay() + 6) % 7;
    var nbJours = new Date(an, mo + 1, 0).getDate();
    var ajd = iso(new Date());
    for (var i = 0; i < decalage; i++) {
      var v = document.createElement("div");
      v.className = "cal-case vide-case";
      grille.appendChild(v);
    }
    for (var jour = 1; jour <= nbJours; jour++) {
      var key = iso(new Date(an, mo, jour));
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cal-case" + (key === ajd ? " ajd" : "") +
                      (key === selection ? " sel" : "");
      var numero = document.createElement("span");
      numero.className = "cal-jour-num";
      numero.textContent = jour;
      btn.appendChild(numero);
      var items = agenda[key];
      if (items && items.length) {
        var noms = document.createElement("div");
        noms.className = "cal-noms";
        var MAX = 3;
        items.slice(0, MAX).forEach(function (it) {
          var l = document.createElement("span");
          l.className = "nom-mini";
          ligneNom(it).forEach(function (e) { l.appendChild(e); });
          noms.appendChild(l);
        });
        if (items.length > MAX) {
          var plus = document.createElement("span");
          plus.className = "nom-plus";
          plus.textContent = "+" + (items.length - MAX) + "…";
          noms.appendChild(plus);
        }
        btn.appendChild(noms);
      }
      (function (k) {
        btn.addEventListener("click", function () { ouvrirJour(k); });
      })(key);
      grille.appendChild(btn);
    }
  }

  /* ---------------- Vue semaine ---------------- */
  function dessinerSemaine() {
    grille.className = "cal-grille semaine-grille";
    grille.innerHTML = "";
    var debut = lundi(ancre);
    var ajd = iso(new Date());
    for (var i = 0; i < 7; i++) {
      var d = new Date(debut);
      d.setDate(debut.getDate() + i);
      var key = iso(d);
      var col = document.createElement("div");
      col.className = "sem-col" + (key === ajd ? " ajd" : "");
      var tete = document.createElement("button");
      tete.type = "button";
      tete.className = "sem-tete";
      var jn = document.createElement("span"); jn.className = "sem-jour"; jn.textContent = JOURS[i];
      var nm = document.createElement("span"); nm.className = "sem-num"; nm.textContent = d.getDate();
      tete.appendChild(jn); tete.appendChild(nm);
      (function (k) { tete.addEventListener("click", function () { ouvrirJour(k); }); })(key);
      col.appendChild(tete);
      var liste = document.createElement("div");
      liste.className = "sem-liste";
      var items = agenda[key] || [];
      if (!items.length) {
        var vide = document.createElement("div");
        vide.className = "sem-vide"; vide.textContent = "—";
        liste.appendChild(vide);
      } else {
        items.forEach(function (it) {
          var a = document.createElement("a");
          a.className = "sem-item";
          a.href = urlPatient(it.patient_id);
          if (it.heure) {
            var h = document.createElement("span");
            h.className = "sem-h"; h.textContent = it.heure;
            a.appendChild(h);
          }
          ligneNom(it).forEach(function (e) { a.appendChild(e); });
          liste.appendChild(a);
        });
      }
      col.appendChild(liste);
      grille.appendChild(col);
    }
  }

  function majLabel() {
    if (mode === "mois") {
      moisLabel.textContent = MOIS[ancre.getMonth()] + " " + ancre.getFullYear();
    } else if (mode === "semaine") {
      var d = lundi(ancre), f = new Date(d); f.setDate(d.getDate() + 6);
      if (d.getMonth() === f.getMonth()) {
        moisLabel.textContent = d.getDate() + " – " + f.getDate() + " " + MOIS[d.getMonth()] + " " + d.getFullYear();
      } else {
        moisLabel.textContent = d.getDate() + " " + MOIS[d.getMonth()] + " – " + f.getDate() + " " + MOIS[f.getMonth()] + " " + f.getFullYear();
      }
    } else {
      var jl = JOURS_LONG[(ancre.getDay() + 6) % 7];
      moisLabel.textContent = jl.charAt(0).toUpperCase() + jl.slice(1) + " " +
                              ancre.getDate() + " " + MOIS[ancre.getMonth()] + " " + ancre.getFullYear();
    }
  }

  function dessiner() {
    if (mode === "mois") dessinerMois();
    else if (mode === "semaine") dessinerSemaine();
    else dessinerJour();
    majLabel();
    btnJour.classList.toggle("actif", mode === "jour");
    btnSemaine.classList.toggle("actif", mode === "semaine");
    btnMois.classList.toggle("actif", mode === "mois");
  }

  /* ---------------- Fenêtre du jour (liste) ---------------- */
  function ouvrirJour(key) {
    selection = key;
    if (mode === "mois") dessiner();
    var items = agenda[key] || [];
    jourTitre.textContent = "Séances du " + jolie(key);
    jourSous.textContent = items.length ? (items.length + " patient" + (items.length > 1 ? "s" : "")) : "";
    jourListe.innerHTML = "";
    if (!items.length) {
      var vide = document.createElement("div");
      vide.className = "vide"; vide.style.padding = "26px";
      vide.textContent = "Aucune séance ce jour-là.";
      jourListe.appendChild(vide);
    } else {
      items.forEach(function (it) {
        var a = document.createElement("a");
        a.className = "agenda-item";
        a.href = urlPatient(it.patient_id);
        var gauche = document.createElement("div"); gauche.style.minWidth = "0";
        var who = document.createElement("div"); who.className = "who";
        who.textContent = (it.heure ? it.heure + " · " : "") + it.nom + " " + it.prenom + (it.archive ? "  · archivé" : "");
        gauche.appendChild(who);
        if (it.fait) {
          var ex = document.createElement("div"); ex.className = "extrait";
          var t = it.fait.replace(/\s+/g, " ").trim();
          ex.textContent = t.length > 90 ? t.slice(0, 90) + "…" : t;
          gauche.appendChild(ex);
        }
        a.appendChild(gauche);
        if (it.praticien) {
          var past = document.createElement("span"); past.className = "pastille";
          var pip = document.createElement("span"); pip.className = "pip"; pip.style.background = couleurPrat(it.praticien);
          past.appendChild(pip); past.appendChild(document.createTextNode(it.praticien));
          a.appendChild(past);
        }
        jourListe.appendChild(a);
      });
    }
    overlay.classList.add("ouvert");
  }
  function fermerJour() { overlay.classList.remove("ouvert"); }

  /* ---------------- Ajout de créneau ---------------- */
  function ouvrirCreneau(date, heure) {
    crDateHeure = { date: date, heure: heure };
    crQuand.textContent = jolie(date) + " à " + heure;
    crSelect.innerHTML = "";
    if (!patients.length) {
      var o = document.createElement("option");
      o.textContent = "Aucun patient actif"; o.disabled = true;
      crSelect.appendChild(o);
    } else {
      patients.forEach(function (p) {
        var o = document.createElement("option");
        o.value = p.id; o.textContent = p.nom + " " + p.prenom;
        crSelect.appendChild(o);
      });
    }
    crOverlay.classList.add("ouvert");
  }
  function fermerCreneau() { crOverlay.classList.remove("ouvert"); }

  function ajouterCreneau() {
    var pid = crSelect.value;
    if (!pid) { fermerCreneau(); return; }
    var fd = new FormData();
    fd.append("date", crDateHeure.date);
    fd.append("heure", crDateHeure.heure);
    fd.append("praticien", crPrat ? crPrat.value : "");
    fetch(window.CRENEAU_BASE.replace(/\/0\/creneau$/, "/" + pid + "/creneau"),
          { method: "POST", body: fd })
      .then(function () { return charger(); })
      .then(function () { fermerCreneau(); dessiner(); })
      .catch(function () { fermerCreneau(); });
  }

  /* ---------------- Données ---------------- */
  function charger() {
    return fetch(window.AGENDA_URL)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        agenda = {};
        data.forEach(function (s) {
          (agenda[s.date_seance] = agenda[s.date_seance] || []).push(s);
        });
      });
  }

  /* ---------------- Navigation & événements ---------------- */
  document.getElementById("calPrev").addEventListener("click", function () {
    if (mode === "mois") ancre.setMonth(ancre.getMonth() - 1);
    else if (mode === "semaine") ancre.setDate(ancre.getDate() - 7);
    else ancre.setDate(ancre.getDate() - 1);
    dessiner();
  });
  document.getElementById("calNext").addEventListener("click", function () {
    if (mode === "mois") ancre.setMonth(ancre.getMonth() + 1);
    else if (mode === "semaine") ancre.setDate(ancre.getDate() + 7);
    else ancre.setDate(ancre.getDate() + 1);
    dessiner();
  });
  btnJour.addEventListener("click", function () { mode = "jour"; dessiner(); });
  btnSemaine.addEventListener("click", function () { mode = "semaine"; dessiner(); });
  btnMois.addEventListener("click", function () { mode = "mois"; dessiner(); });

  document.getElementById("jourFermer").addEventListener("click", fermerJour);
  overlay.addEventListener("click", function (e) { if (e.target === overlay) fermerJour(); });
  document.getElementById("creneauAnnuler").addEventListener("click", fermerCreneau);
  document.getElementById("creneauOk").addEventListener("click", ajouterCreneau);
  crOverlay.addEventListener("click", function (e) { if (e.target === crOverlay) fermerCreneau(); });
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    if (overlay.classList.contains("ouvert")) fermerJour();
    if (crOverlay.classList.contains("ouvert")) fermerCreneau();
  });

  function construireLegende() {
    var el = document.getElementById("calLegende");
    if (!el) return;
    el.innerHTML = "";
    (window.PRATICIENS || []).forEach(function (nom) {
      var s = document.createElement("span");
      var dot = document.createElement("span");
      dot.className = "lg";
      dot.style.background = couleurPrat(nom);
      s.appendChild(dot);
      s.appendChild(document.createTextNode(" " + nom));
      el.appendChild(s);
    });
  }
  function remplirPraticiens() {
    if (!crPrat) return;
    crPrat.innerHTML = "";
    (window.PRATICIENS || []).forEach(function (nom) {
      var o = document.createElement("option");
      o.value = nom; o.textContent = nom;
      crPrat.appendChild(o);
    });
  }
  construireLegende();
  remplirPraticiens();

  Promise.all([
    charger(),
    fetch(window.PATIENTS_URL).then(function (r) { return r.json(); })
      .then(function (d) { patients = d; }).catch(function () { patients = []; })
  ]).then(function () { dessiner(); })
    .catch(function () {
      grille.innerHTML = '<div class="vide" style="padding:30px;">Impossible de charger l\'agenda.</div>';
    });
})();
__FIN_STATIC_AGENDA_JS__

info "Ecriture du module de transcription locale..."
cat > "$APP/transcription.py" << '__FIN_TRANSCRIPTION__'
#!/usr/bin/env python3
"""Module de transcription vocale LOCALE (optionnel).

Sa simple présence active la fonctionnalité audio dans l'application
(le bilan oral sera branché à l'étape suivante). Moteur : faster-whisper,
CPU, quantification INT8. Aucun audio ne quitte la machine.
"""
from faster_whisper import WhisperModel

_modeles = {}
MODELE_DEFAUT = "medium"          # "large-v3" pour la qualité maximale
MODELES_OK = {"large-v3", "medium", "small"}


def _charger(nom):
    if nom not in MODELES_OK:
        nom = MODELE_DEFAUT
    if nom not in _modeles:
        _modeles[nom] = WhisperModel(nom, device="cpu", compute_type="int8")
    return _modeles[nom]


def transcrire(chemin, modele=MODELE_DEFAUT, langue="fr"):
    """Transcrit un fichier audio en texte (français par défaut)."""
    model = _charger(modele)
    segments, info = model.transcribe(chemin, language=langue)
    texte = "".join(s.text for s in segments).strip()
    return {"texte": texte, "duree": round(info.duration, 1)}
__FIN_TRANSCRIPTION__
# Moteur de resume local (Ollama) — facultatif (repli par regles sinon)
if command -v ollama >/dev/null 2>&1; then
  info "Ollama detecte : telechargement du modele de resume (~2 Go)..."
  (ollama serve >/dev/null 2>&1 &)
  sleep 3
  ollama pull llama3.2:3b || echo "  (Le modele se chargera plus tard ; sinon resume par regles.)"
else
  echo ""
  echo "  --- RESUME automatique (facultatif) : installez Ollama ---"
  echo "   1) La page de telechargement va s'ouvrir."
  echo "   2) Telechargez la version macOS, ouvrez le fichier, glissez"
  echo "      « Ollama » dans Applications, lancez-le une fois (autorisez"
  echo "      l'installation de la commande)."
  echo "   3) Le modele se telechargera ensuite tout seul au demarrage."
  echo "   Sans Ollama : la transcription marche, le resume se fait par"
  echo "   regles (un peu moins fin)."
  open "https://ollama.com/download" 2>/dev/null
fi

# 4) Lanceur double-cliquable
cat > "$APP/demarrer.command" << '__MAC_DEMARRER__'
#!/bin/bash
cd "$HOME/cabinet-kine" || exit 1
# Si le serveur tourne deja, on ouvre juste le navigateur
if curl -sk -o /dev/null --max-time 2 https://127.0.0.1:5001/ 2>/dev/null; then
  echo "Le serveur tourne deja. Ouverture du navigateur..."
  open "https://localhost:5001"
  exit 0
fi
source venv/bin/activate
# Resume local (Ollama) : demarrer l'app si besoin, garantir le modele
if ! curl -s -o /dev/null --max-time 2 http://127.0.0.1:11434/api/tags 2>/dev/null; then
  if [ -d "/Applications/Ollama.app" ]; then
    open -a Ollama 2>/dev/null
    for i in 1 2 3 4 5 6 7 8 9 10; do
      curl -s -o /dev/null --max-time 2 http://127.0.0.1:11434/api/tags 2>/dev/null && break
      sleep 2
    done
  elif command -v ollama >/dev/null 2>&1; then
    (ollama serve >/dev/null 2>&1 &)
    sleep 3
  fi
fi
# Telecharger le modele de resume s'il manque (via l'API, sans dependre du PATH)
if curl -s --max-time 2 http://127.0.0.1:11434/api/tags 2>/dev/null | grep -q '"models"'; then
  if ! curl -s --max-time 2 http://127.0.0.1:11434/api/tags 2>/dev/null | grep -q "llama3.2"; then
    echo "Telechargement du modele de resume (une seule fois, en arriere-plan)..."
    curl -s http://127.0.0.1:11434/api/pull -d '{"name":"llama3.2:3b"}' >/dev/null 2>&1 &
  fi
fi
# Ouvrir le navigateur des que le serveur repond (en tache de fond)
( for i in $(seq 1 30); do
    curl -sk -o /dev/null --max-time 2 https://127.0.0.1:5001/ 2>/dev/null && break
    sleep 1
  done
  open "https://localhost:5001" ) &
echo "======================================================================"
echo "  Cabinet Kine — serveur en cours d'execution."
echo "  Laissez CETTE fenetre ouverte. Les journaux (logs) s'affichent ici."
echo "  Pour arreter : icone « Arreter Cabinet Kine », ou fermez la fenetre."
echo "======================================================================"
python app.py
__MAC_DEMARRER__
chmod +x "$APP/demarrer.command"

# 5) Script de secours (reinitialiser un mot de passe)
cat > "$APP/reinitialiser.command" << '__MAC_REINIT__'
#!/bin/bash
cd "$HOME/cabinet-kine" || exit 1
source venv/bin/activate
cat > .reinit_tmp.py << 'PY'
import sqlite3, getpass, sys
from werkzeug.security import generate_password_hash
db = sqlite3.connect("cabinet.db")
rows = db.execute("SELECT identifiant, role FROM kine ORDER BY id").fetchall()
if not rows:
    print("Aucun compte dans la base."); sys.exit(0)
print("Comptes existants :")
for ident, role in rows:
    print("  - %s (%s)" % (ident, role))
cible = input("\nIdentifiant a reinitialiser : ").strip()
if not db.execute("SELECT 1 FROM kine WHERE identifiant = ?", (cible,)).fetchone():
    print("Identifiant introuvable."); sys.exit(1)
mdp = getpass.getpass("Nouveau mot de passe (6 caracteres min) : ")
if len(mdp) < 6:
    print("Mot de passe trop court."); sys.exit(1)
db.execute("UPDATE kine SET mdp_hash = ? WHERE identifiant = ?",
           (generate_password_hash(mdp), cible))
db.commit()
print("Mot de passe de '%s' reinitialise." % cible)
PY
python .reinit_tmp.py
rm -f .reinit_tmp.py
echo ""
echo "(Vous pouvez fermer cette fenetre.)"
read -r _
__MAC_REINIT__
chmod +x "$APP/reinitialiser.command"

# 6) Icones double-cliquables sur le Bureau : Demarrer / Arreter
BUREAU="$HOME/Desktop"; [ -d "$BUREAU" ] || BUREAU="$APP"

START_APP="$BUREAU/Cabinet Kine.app"
rm -rf "$START_APP"; mkdir -p "$START_APP/Contents/MacOS"
cat > "$START_APP/Contents/Info.plist" << '__ICONE_PLIST_GO__'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Cabinet Kine</string>
<key>CFBundleDisplayName</key><string>Cabinet Kine</string>
<key>CFBundleIdentifier</key><string>fr.cabinetkine.demarrer</string>
<key>CFBundleExecutable</key><string>lanceur</string>
<key>CFBundleIconFile</key><string>icone</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleVersion</key><string>1.0</string>
<key>LSMinimumSystemVersion</key><string>10.13</string>
</dict></plist>
__ICONE_PLIST_GO__
cat > "$START_APP/Contents/MacOS/lanceur" << '__ICONE_GO__'
#!/bin/bash
APP="$HOME/cabinet-kine"
if [ ! -d "$APP" ]; then
  osascript -e 'display alert "Cabinet Kine" message "Dossier introuvable. Relancez l installeur."' 2>/dev/null
  exit 1
fi
# Lancer le serveur dans une fenetre Terminal : il reste en vie et affiche les logs.
# (demarrer.command demarre Ollama, ouvre le navigateur, puis montre les journaux.)
open -a Terminal "$APP/demarrer.command"
__ICONE_GO__
chmod +x "$START_APP/Contents/MacOS/lanceur"
mkdir -p "$START_APP/Contents/Resources"
python3 -c 'import base64,sys;open(sys.argv[1],"wb").write(base64.b64decode(sys.stdin.read()))' "$START_APP/Contents/Resources/icone.icns" << '__ICNS_GO_DATA__'
aWNucwAB/uNpYzExAAAHfIlQTkcNChoKAAAADUlIRFIAAAAgAAAAIAgGAAAAc3p69AAABztJREFUeJytl2uMXVUVx39rn/uaR+fRQikURqktpQxFE5QmRKWAragYmthpUl8fCBZDNH5QP+AHZ26MBkFNRIkEjUTSEmCiwcQ0AWM7GB4WqdKW1pZOpY8Zii3znrmPc/Zeyw/nzp3bdmipcSUrOTln7bX+e73OWsL5yJBeTA7QL7OvTg3sl/MdWby222afr6PHiogh2PnOzEs99kx00Yf+B13n3sZMEEkRG9Jz7JlVPmapachAAC6EK5URF3kn8vbvt77xL4pFPUf3vAAaBO46uO0+iaJ7zev1USHr5sN6fjJCJVGJ3H4sPPbsyi89AtjZIOa0mgnAHYe3LsgFeTrb1nKHL1UIlQTM9KLjaAgiLipkyTQXSKZKz+ez2U39y3omU8spiDqAXjN3oL9fSivL2/OL2tZXRiZigQyIu+jLz4EATA18YVF7rjoysWN69K1Pr12LFqVogDmAW3b2ZooiOrOidE+uo3V95fR4LEYOw5kpqOEUUEvVvV82A8OJkaucGotznQtua+744L1FKeotO3ujOQ+YyS0DfVFTe9e+TCF/jS9XERE3KxDMKGtCS5QjEiHYxVeVmWnUlCeUq0dOm+/efeMWjwiu18whYk3tXdc4kZVJqeIMS29uRjnEfP3KNfQsXk0cPONJGSwtbTNFTbH3w5jzpbK4yK1YnM1ei4j1mombbTInpsaumnYqYigKQQ0zI/aernw73+i6mUdWbeD2zuWUfcJkXAEFUVC183JQS2VNdNoFTkyNXQUwMNDnMv21zlY2705WJmmOsYXZZvIuqidSRT1qxsqWS+lbvo69UyfZOvwPXhk/BkBLlANAG0JjtfCJCA6I1TOWlJgxMB/Xm0nmjECpMRlXmEkqLMgUaM8WwAyH4ETwpjiEGxZczoPXfo5d48fZOryb3RNDZMTRHOUwDDNwkuZgJSRM+SpTvoq3QDbbVDf3whkAvEezEWIQTBmtzjCZlElCIA6e2YR0IqgZIrCmo4s1HV3sfHeQbcO72Tt5kkgckTgqIaEUEiqaoGa4midUFfWhbrYOIACRKqpaN4bCdFIl1rkD1EDMulxEuPWS5Xxi0TKePbmP3xzbxaHpU6gp1DwnaRVgGE4tNTarq/4UQoruLBazWkTPpRSIEWsgI46NV3yYh1bdSWdUIKjijLP0GaqKZx4PeJ96wGoeADBJFcxn3wA1JRJHzkWcmBnjl2++QP/be4glfR9MzwGvqlALaQpgoA4B1SjtdDUSScuoUUWj4UgcpytTPHb4RR4/9irvJNN05luIcHgNCBCJq51JtYgaOme/IQfC/B4wTRsSpMk5a3gyLvPbwZd57N8vc7QyTnu+iUtzrYxWZwBozxYIZowmM2RdRGsmn1ZRmNN/BgAINQ/MCYiABcPX3uVchmpIeOLILh45/FcOzZymNVdgUb4FNeXdyhSfv2I1X736Jla1LSFWz+7R4zw6+BKvjR2nI9uU5kKYJwfwYFk7IwQmhteQ9gNg25Fd/OLQAK9Pvk1zzXBQJYTARFKm7/rP8t1VnzrjhitaL2XD0hv42qtP8oehPXTmO9DZJBxoTEI87iwPmBg5cWwfeoMf7tnOc/85SHOuwMJ8C1pr05E4xuISd125um58eHqEtVu/w4qFV7J90w8oRFke/dhmXh8dYjgp0dQwVTWUIVhIc2CWQwjkJOJnB3ew8/QglxRaKUhE7D0hBKxWXqbKPctuxoC3xt/hRy89yeDICf5y9J88/NofGatM05LJsfkDH2UyLpNvANCQhF6dRlgIgjTi0nqvT7yn/gevPSV42jMFVrZdRtDA+qe+x+DIcTpbOsHgW3/6CS8O7efpDffT3bYEpxCb1ZPA0Ufqc9UhLcemhjR6wdQIIdRubGd4aPb2SfDEGhCEFQuXkq/lDECuqY1lHUsAqIbEhUqVnEVDAPShDikqhoxd3n5IQ3jTss5Ug87XFefjyITx8gyvvXuUyDme/UIvD952D2Pj7zAVl3h+8wM8sPZuBNFXJk6YVqtHfmzdB9OZsZiOZPT1Rtxa9Bb0YbIZp8H8bNu8EAdVMuL46b4/4zWQizJ85fp19HzkDr69ZiOf7FoNwPHpEb/txG7XlC38fNOmTTF9vRFpq6lRb6+j+4C0li57Ttqab7eJUozUhtILUCSOibhEz9U38ujHv8zCfEvjZx2cOOU3/v13ub3HDg98/0NfXFccGFCK6VB61lgudPZvaauW8/3SnF9HJcaSUKuR85BB5BxT1RLL2y9j8/KbuGHhUirBR38bO8ZTw68zMjq6Y/WSqzfuu/P+cczOHcvrINIP0vT4fd/EuS0E6yYXzYm+14heA1H2McHHqWDsQfRAJlP4dXL3rx4WEX3vxWROkdSXkJ6eKPuZxdc5saXmLXvh1SyQJyKXz6NqvjmXHR7a/NB+EQnn6L4gPdPzf1tOa7rm9d2Fdh7BeoX+A8L+Uxe3H3UvNnquM2ob0HuJ/RfcTaU0rheamgAAAABJRU5ErkJggmljMTIAABAxiVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAP8ElEQVR4nO2be3AdV33HP7+ze9/StSxHtpO4iWNwnDh2HBKaQhuI3ZBHCWTKQ2ZaSIFgMNCBaQc6pTMMskqZaRnawJCSd8sQM4A1xTSBAm0T2yEOJiSObWzHdoMTxw8SP/SwrnTv3d1zfv1j915L8pV05ReZNr+ZM7Kl3XN+v+/5Pb6/s7vwmrwm/69FTutuRbpQWb9+lWHpUlh/RnSaXJYC62Hp0qWuG1EEPUcrx9KlXeb6dV3+OV10Arl+XZffpV3mVO6dmgeoSic9pkeWW4CPPX1v6tiM9kUusovV6lxV1yYOccApaTOB1OZUg4rIgIrsE8/7VarCr3oWLQ8AOnWN10OnQ6Rpj2gagC7tMt3S7QBu3fHt+am09xF17l2CXOrns2CEc+aIAjglKldA+R9E/j1y9sEfXvb+XbGuarpFXLNTTSqdusbrkeX295/4h9aZ583pQswnvHw2bytVbCUE1MZxeHoppXlRBEEV38uk8HIZouFKBfTeocHBrv9+48qBms6TzTSpxrWJ3v7sv16VKmRX+4XsFUF/CZyLFDEiZ9zbpyQKTlQdYvx0WwvRcGW3LZVv/+HVd/zy+nVd/oZl3dFE908IQOeaNV7P8uX2ls0PXp8p5B8W3xSj4UoI+CDn0OcnEwFUgcjLZVI4HQpKpXf9+OqP/tdknjAuALWY/6Ot/7LYz2Y3imprVA2sEeO9WsweKyLgnLNeOu2JkWFbDd76oys/9MxEOaFxKVMVgOu3d7QY9XvEmNZoqGzFGE9frdYT+4CI8Ww1sH4+m0ek521P3/sGWDWIqjSqDg3jt5Me0y3iCtX8qnSxsCAqDUci4uE0XuXVPJwiIl40VI7SxZZL0ib1pW7pdp09PQ1tPSkEaq7/zi3fusQZfU6VFM5Jo2tf5aIYcWKMRi5Y9NMlK3aPLOU1OQmV9euXGgDroo/7hVxGbeRUVVSVyYaJl530unM0RK1VP5/1jTOfjG072d6xuyoA1zx9r98h3i4vk55nq6FrrtQJwzYgbTwyxseq8tuuEgrOS6VMFAQHKu3e/A2XfLhSoxC1a0YZ1qVdAmi7l75CfG+erQYKmIlCThAGoyrLps/jLy66jhYvTV84jFWHicnKb22gmKgaqJdOzUkfc0sAOnvWjLJ51H9qLpKy9iovl0FV7WSuhoJzjpz4/PHMK3hg4Xv50PlvJCsefWEZpy7m8L+lUAC1XjaNr/oGgMMdHTIuAHGfCUfCoblRfQebWQisc1hV2lN5Vsy5lvsWvof3zboSg9AfliHJEecaAIMQOsuxcHhuozAZA8B6AI4F5eKB8gClKMAkaWKEWzUegCdCpBaryqxMK5+++DruWfhu3tmxkMgpA2EVQeI5J5rrNMZIPQ1CKQo5UB7gaDhcHGljTRoSIU9EQmc5VBmi6GdpT+XxxcOpwzE6cyonQgHinOCJoChO4eLcdD43bxnvmrWIbx98lsd79xKpo8VPA+D0zCVKTXQzYojUcjQoMxBV8FI5PG1cxhsC4CKHURAHA2GZoShgeipH0c/gicGpotRmHOMGjASiBhAsKHTwt5fexNbjh1h9cDOb+veBCC1eOgHr1IFQTgDv1NEfDtMflgnVIiqIgnWN5x/nVMehGu+gQbBqOVwdZCAsM83P0uJn8MXgqMWaSxLOySJIzNGJvWRJ8QKWFC9gU/8+Vh/czOaBA/jikfdSI4CYjHOdWEtE8BAidRwPqwxEFaouwiAYkYS8jg/uOL1AcpNq3eWNCFUb8YodpC8o0+KnafUz5LwUBplUZYOAxC4vAm9qu5g3tV3MumPP8+2Dm9k++DIZ45MzPi4JHxllau1fMaAmKeaBjShFAYNRlUCjOMckjaqrVakRIdoUAA6QJIvWlUgUEhFCF3EsiOhPgAicJdKmDmBi5agBISyb8Xre2j6PnxzexXcOPsueoSPkvBRZk8Li4nWFOsSKElpH2YYM2YCyDbG4+o4zZsfjhKjE2atJAHAOdeO4dT3jxwsNRQFHgyH6gnJTADQCwhPDrbMWckPHpTzy8na+d3AL+8p9tPgZ0saj6iyBi6jYiIoLqbooYZqxJ3hSI1wn61v/vZsCADFoOmHs1P5UOxKa6NqJpAaEVSVrfDovuIpbZl7OmoNbeGDfJnYOv0zeSyMiWHWxFyIYqemhTLR0DYCag24Yu36jm5xrnmg4F4/T5f1x6QSrjlY/w0cu/j2+f+2H+fNL/gADDIYVfOKMzoh1J2eqiZ7j6Dd+k1NjFE2P07IfiHOMJ6YOxPnZIl9YcDPPLPss7z5/MUNRkBx+nUpz0HjNUSEw0j1qbGoyu8aygDNBa5w6PIn3pq86zHdfeobt/Yfi0juJyzdScKLrxyVCtSow+fyKnoEQgHjXPTF4YqjYkNW//gV3//oJdpePUsjkyHp+Em5TkCQHTK0KxBQHPYn4Npo/BqDJKthQrDqMSMIyHd974Rnu2rOBbaWXKWSzdOSL2CTup34ulWxkNCUAAKfQzILSmAo3IzX6W3P3R17ayld3r+Op/v1kMxlmFIo4dYTWxmoIjLOR44tOrFvjEFCHJD4w6fw1OjwFnVxyvZeUwMcO7eLO5x5lw7G9+OkU7YUiqo7IJs80ak8gTinKEg+dWghMzgNGTH8iK08itSaqtuObDu/lzp2P8tPDu8D3aCu0oDDKcADRuIWWhEqPpOdC7XfjrK8xAOOljsYe4GLPbibbJmV5ws2p1eHYcGFb7wHu3PkoDx/6FYGBtlwBBCJnGRVzCUu0qhwPy0TqyBiftOfjVKnYEKuOvJcm76ewtU2TkXNMrNs4HjCifjYDgWrD2Kx1d54YPITnB17hazsfY83+ZykR0ZYtkE8Y3ol8q/W+3hNDf3WYgp/h7ecv5A9nLWBhcTbTUzlCtRwY7uep3n385DfPsWPgNxT8DGnPwzqHSJ0qxiOaSjvsTiEExvRtrl7ShANDfdy1cx0PvfgUvbZCW7bAdJPBqhvtmqOWE45VS9x24WL+ZuFNLGm78KS1r2qbwzsuWMTnLr+J7+57mi/t/E+OVku0prJEzsWOUGeCU+kFnIsTR9MA1MomROrwk1p+tFLinuc28OCvN3IoKNGWKzAj3UKkLnH3xmIQjodluhfdyl9dfgNwIs5VlZTxcCjWWYwY8l6KO+a9maUz53P7pm+xrf8QxVQW61ys4QQ1etJ2uBkAatxcgKzxGQwqPLj7Ce7e8zgvlPuYlstzXr6IVUc4geEAvhiOVYf4uyXv5LOX3ZA0QJI0XfGZwvHqMK2ZHCnj1ytV6CzzWs7jB2/5GDetu4sXSsfIeamEOSpuKt0gzk0pB1jnyPvxYvfvepxv7NrAztJhWrM5OgpFInWELpqQUmhifF91mNsuXMxnL7uBSF1SKuPT6aoN+cxj9/PInieZnivy5WUruHneNTh1pIxHpI6OTAsPXPunvO2xr9cPQiYq0+M0Q66O3GQjco6cl2bTkRe56adf5RNPfZd9wQAdhSIp4xG6KHbBSbs2krlSdF95a/2cD4QgCnEoX/3lWr7x5Hfoqw6z7ZW93P7IlzlU6sWpEjmLL4ZIHde0X8QH5v4ufdWh+tH+eAg0bodrqDXRZDl1ZI3PpqMvsKnvJWa1tJHxUoQuqjcuzQwDHA/K3DBrAZcXZ6OqeEmdz/gpPDE8/Zs9mEwLKc9jeq7I0eHj7D9+BN94+MYjPsGKKdwd895MzqSwztayckMATpsIQZwHsl4KhDExPhXqFj/AuPH8y+rtsIghsBH/9NT3eerQLrYefoGMnyZyDlXIpTL89boHmdM6g5VXv4O3zLkCSUBYPP1CLm2dyXMDL1PQ3BSbIVWdCgAAtpneeaL71ZERj4XF2fVcIQifefQ+/nnjd5BcKxkvFSe+eg8hPHFgOzYKWLt7I09+8GssmXkJobOkjMf81g629O6nJZ6toXbjnAi5wakfOJzecAnLa0vnAUgZj8GgzNo9T9JS7GBapjAq60OMdyGVo6NlBuVgmLW7n6iDCdCeKcTZXxWsG2xka+MyaPVFaZIHnCkRhMidKJNOlYyX4rxckUPHjzI9VxynOVNCZ9Eo5HeKM5O5YqlGURzKTlGnLzZad7QHHNmZ+JZu1XKAKt65eogpQDmqcmC4LyZUzpL2fL68bAUzC20MVEvxUfoY0CpRyEClxLsX38ifLFyaEKV4X/cP9eJhPFsNALtllI2JjPaA5T0OYMBM216sDrxoMv5cDSMHck7eBbTW8vPDe3nHnMUYY1CUm+ddw9YV97Dr2H5W/Ww1G/fvIJ/OAEIlCvj7pXfw1osWcc3s+UDsOUaE3uoQO/oOumw2Y2w5ONSfMVtG2liTsYYp67p8lncHwL+R9uM6dw5ygHWOrJfm4Ze2ESSPtkBwqswuTGfpRVdy8bSZRFGVjJfCiBDYkFvmvZFrZs+vx32tLf6PA9s5UOp1mVwOi65l+Z1lurp8xqTqk3d2fVIvVO5xQ5VABaPuRFU4W8NpTIK29+5n9fO/wIgQOVv/aZ1jxZJbKGTyHCn10n/8CO+57DpeN312/TolDpHIWe7c8aimvbTYoYrVwH0jse6kWtiYna7p9FjeY1u++amvmWn5T+vAUIQxZ/31+DgRWoqpLD+/7XPMbZkRM7wayRFh2+EXWLv7CeYUO/jAohvIJA9VSe5NGY8vbH6YLz7zcNQ+c6Yf9g/eN/ihu1bWbGoOAFVh1Sppf31vS6CyWVL+67QSWIx4ZxsETwylsMKV7XP48c2fZlaumOxw7KxGRqusqtjksEWA+3f/jI//7CHb0tLquci+5JngqoE9MwdYtUqbflESEWUV9N7+9eMussvVuWF8z1Or9sQR0NkZkbO0+Bm2HH2JZT/6ChtfeR7feHE3KDFbrNiQqg3rD1j9hDF+/ukfsPLxh2w+m/Oc06qNqu8beP/dfaxKbGpk6oTbkbhN4f6VN5LPrgUpUAmi2BNGvix9Zt+hVBRfPIaiKikxfGD+m/jIguu4+ryLSI+JxJeHB/jx/u18fcdjPHt4b9RabPMVKq5cfe/wirt/NJ7r12Ryzbu6fLq7o9zdK6+VQnq1ZNPztVQB1QjBnL0SqZjkSdBwMIzvp1kwbRaXTpvNjGyBwFr2l3rZ2X/IvVLqc+L5fuv0NqJKda8rVf+s8ol7N9Z0n2iV5rYuQXHanR9sC9uLX1TVj0k2ldZqCKFVYNIPE05VRKgfjFaiEOci4qcwAmK8dDYrmXwOVw1Dde5Bb3Dg84OfeujYZDtfn79pTbTLkLxnm/rmJ6/w1HxUcLch5hIyPmPf5zgbEh+NxwNVXBCh1u1z6CNe5O4f+ujd2wCaNR6m/NEUQk+nqU/+j3+Zy7VHS5xzV4LOFZiGc2eXNYqowgBGXhRPtlUq4VZW3jcMxIZ39jjO+md0XV2GNZ1nvSQ2LWs6PbrOxWdzY6XmETsWSu1jxnMitbWu2KnnZsdfk9fk/6z8L5U5xjPNqLzCAAAAAElFTkSuQmCCaWMwNwAAIPOJUE5HDQoaCgAAAA1JSERSAAAAgAAAAIAIBgAAAMM+YcsAACCySURBVHic7Z15lF3Fde5/u845d+jbk7olgQQWiEkYMVlKeLbBCGxsA3Zsx3bLTjzywMYriePhLWfwW0l3r/it55cYAw/sxGAS5xkToyZxgmfAIGzAyAgkhhaDQICEZqnn7jucc2q/P845V63W0Pe2+na3RH9rFUPfe27Vqb1r166vdu2CWcxiFrOYxSxmMYtZzGIWs5jFLGbxeoFMdwMOgKoAtNMx89p2BOikQwEQ0Wluyn6Y3k5WlbauLrNr3jyZf8lu7ZKVFphRHVQLtOkqZ9fqeTJ/927tamuz06kUU68AirSxygB0ycpw7Mfv3Xp3XbZUaPT9MGdDx4XilDdxcpFGXULXc4Zz6eGB2xd8cnjsN9p0lQPQxUqLTO0AmDoFUJUVqzucBy/tDJI/fXz7L3NDI/1vIgjfgrIM9HRVjgdtUtWsIAbV6bZTE4cCIihqRaQgQr8iOxB5UYR1Kjxa1OCJX5zxiYHkkRUPtLsPXtIRTpVVmJKubdNVTjLaVzzQ7s5ZcOY7MbIStW83rrvISadQtVg/RIMQtRa1yrEzGwhiBDEGcR2M6yDGEBZLWN/fhpgHxOiqvO7+5S/O+EIRyn1W8ymxpgrQru2mkw5FRC9/9PuNqTnOp0XkM47nnS2uQ5gvYou+YghBUFUjIrEjKEfvyD8YNJKjIiqCBUVVjJNyjZNJoVaxpdLzKLeN+EO33XP2Z3oA2latcrpWHjhVThZq1sUrHmh3Y3Mv73/+B58VMX/pZjOLw2KJIF+0ImIBE5fXL1RVwQLiZFLGzaQJhgtbFf3Gaw+u/tbj197ij+rLScfkK0Ds2XetXBm+76l//T3JpK93s6mLwnyRsOgHIEbkdS70Q0AVC2qN57luLkOYL64NSsUv/eTsTz002ppOZp2TqwDt7YbOTgvw3g23f8lxna8bz00FQ/lAwYjIrOArgKqqQOjUZVwNrVU/aL976ce/BvG0KlEfTwYmTQGShl3+wo3pVDj3u15D9uOl/iFVq1ZEnMmq5/UEVQ1FxKTmNEgwOPIj3ZP/1N0XXTPYrmo6oyn0iDEpCpAI/7K132mqyzX8l9uQXVHqGQgAB5FjyZWbDigQpJrrPX84v7ZQCN9z7/mf3DVZSnDkJrl9n/Czdbn7nLrUimJPv4/gIkjU/tlyBEVAvWLvgO9mUr+XSTsPvHP9t+d3ith2bT9i+R3Z6IwdvsHzt7tuqeUeryF7cal/yBcR75hZws8UCKjVwGvMueFI8QnpLVxy971bhuk4MsfwiDRoxerVTtfKlaFTaPpnryl3cbFvyAfxVGfAuDnWigIibmlg2HcbssvCRvcOOjvtitUdDkcwkCf8YMLuvWfdv3wx1dp0fal30Ae8if7eLCqEgCp+ek6DV9wz0PGzZZ/uHM20TuDnqkfCTr3n6f93nvHcx6wfGEJrZh2+qYKqGBOalOv6peJFPz/nqocnyhi6E6g92q/XdvPYk+EtJpPywnwYihFJ6M5Z1Bxiw1AMHiaUWy5/4cZlZ53e7aMq1foDVfsAKx5od7pWrgx/99Ti/55qarggGMoHIuLMOn1TC0GccKQQpJrrzzLDjX/eKZ22ja6q5VmdydZoWbei+1u5XJB7znjuQlsKlNc7nz99sOK5EIR9hZSc8as3frIHqCrqqCrBrVj9gIOI1vn1n/Ya608IC6VkQ2cW0wOjJd+6TbmWVMH+CSK6YvXqqljXaiyAoMryx29x54v3tJNNnREWSiqzCjCtULBOypOwWNrmaHDGT5ZfmweoNLKoYuG16SqDiM7DudTNZZYE+aICZtrXx6/zApigWLJuY+6EwEm9B0FXrG6v2ApUP3rFfExcEwc11AYCOLMryoohIoqqCvZjAPN3L63YB6islxVB0Peu/U5dYNyNxnMXWj+oyfxvEHwNKdiAeieNEQhnl5eHh6oa1xEbhH02rafec/ZneipdElYkwLauKIo3dMybnHRqYVgKLIqphU0L1fKVk1Zw5dwzyYc+g0EJg2Bm95UOXUQk9EPr5rLNJu+8GaDSJWFFRNCuefMEwFoudNMuUihYmPzgDgF8G7Kkbi7vbD2dK1uXcMf2dawZ2Iwi5JwUUdjMrEXYDwoiasU1BqMXAj/btXpeRda9IgWYf8nuqMdVlqlVtJbRmgojNsCinNuwgHMbFvC7/s38YPs61g1uwxFDnUlhUXRWEcpQRWxgUavLAC655BL7YAXPVaQAXbRZAEFPt6UAVRWpkRKoahwpKgTW4hjhgqZFXNC0iNU9L/Fv29fTPbSTlHHJOi5WZ9UAAEWsHwB6atuqVU6nSEhkVA/bPeMrgCKI6ImPXJf1rV2QDi0oolIjO5DsJQNGBEGwqogIl7ScytvmLObevS/ww+3r2Tiyl4zxyBiXMJ4YXo9rBwVQFQJLqHb+KyftbAb2RodqDt8j4ytAR7tApxo/37w1CBvnSyN1uFKrkacH8fhN/BJWFUcMl889k0tbTuMnu56la8dTbC70UeekSBkHq69PD8GIYcQvsqs4WF8K/DnAXqIDtoftjvEduY7oX/WeyYXYzPZ8P3tLw/HDU7sBmChCqErauHzo+HP47tkf5k8WvYVGJ0WfnyeMleT1gOjUXDQZ9/gjsi3fp4Gok/bcegC6NoxrECveDg6K6ooRo1FljFifuV49Wced1HV6JT/lSMRzWlXq3TQfX7iMK+aeyV07nuLHu55lb2mEBjeNI4ZQa8ZXTTscEQo2YE9pmHzoR8tlMQQjpYoDcyoeKuK5sdFXjBiKoc+2Qh97SsPR34DJXdyO0x72KUKoSmuqjmsXvZlbz/kQHzn+XASl349ocafsCx0bJenrntIIWwt95MNSbB2jtZG4TsUjsrqAEN33H8kqoKc0wnBQosWro95NEZ1zOgIHsUpjsk8RFKuwIN3IFxe/jQ8ct5Q7tq3jV3tfZDhmFUUiq3E0QommXBEYDkv0lEYo2ABHEpJMKx07+6GqyfJg+mhEKNmA7cUBthcGKMWNisbc1HW2IGVFCFU5ua6Fr572Dr619A95e8upFK3PUFDEiJR9iaMBCeviiFDSgB3FQbYXBijaABNbwLHFr+L3K7cAReK9vwMhcRkKioyEJRrdNM1eFs84aNWrhSNTmkgRoo5ThTPr5/N3Sy5n/cBWbt/6BGv6NiMCOSdV9iNmKsqCtyH9foEBv0Couk+Bx7ZdtTInahQqVoAiMN4eY6KRvX6BgSBShCYvQyqOGKtkgTYBK3ZQSGwukzrPbzyB8xtP4Le9r3D71idYN7ANzxiyTgqdYfSyEJ2e9TWkv1RgICgSqC1br8lsaZU+wOGrTj41gKqltzTCgF+gwU3T6KZJO1F1CYdwUEM8ySPSsI9DEIG3zDmZt8w5mV/t2cgdW5+ge2gnaeOSdby4XVOvCElfJCO7ZAMG/AKDYRHfxoIHGM+ali1A5ZPARKKCK4aJ5+Q+P89AUCDnpGh0M2QdN+IQ0OhgfC0bMaotQJlVfMfc01nReio/3/UsP9y2npdG9pJ1PNLGnTIyKXLsYj4FyIc+A36R4bBIGLfTneQRPxZVKcDBWLrxITFhpJFWB0XSxqXBTZNzUngmmliiuVijOmr4xqMVwRXDHxy3lMvmnsHdO7vp2vYkWwp95XbVziJITHNDYEOGwxKDQZGCDaK9EJEyyVaVKtbSB5g49nVhsm4vhj6F0KdXDFnHo95NkTUejpiyya41RrOKWcfjIwvP54r5Z/Lv25/iP7Y/za7SIPVOGtc4k0ImRY5yUqdlOAxip9knUBt9PmqOn6qpaII8wMSQPJ7Ql6EqA36RQb8YOWTGw8NM6Tw8mlVsdDNc9YYL+IPjlnLn1vX8eGc3vaU89W4aV+SwjOfYTxKBSxzHElhL0ZYYDn3yoY9vw/Iyuqz0R2r8JrAOrEIBimUOajJh4nf31eIHBUqBT8nWLCfSQTGaVbRqmZvK8aeLL+QDC87mjtee4Be7nqUvKNHgpjGxIuiY58sjPCYdQxTfBhRsJPBCGBDElkQkUozo1SdT3atfQ1WwGzjm92sEgX2hX9OESBFMmVU8IdPEV067lA8uOIfbX3uc+3dvpKghjW4GgxDGcbGqEflU0oCSDSiEAUUbCTzhGSQe6cKkL3T2YQJr6OqcwBqbZjsFdVSCsWTSqbm5tC95Nx9eeB7f3/IY9+3eSNEGZB2Pko0CWH0bxpZBy78hss/CJZ/U/u2qo+Gn1AeoqIrpl38Z+5FJCksbjufrZ/0Bv9m7iRteepDVe17CiNDoZcoJTZMlHXDkc3q1qLUFeL3CxHN7Ys7f1noKb2s9hV/ueo6bNv2G3/a8Sso41LvpeMVwSJqrxqhe3aaAB6gSM8kEjMH+ZBK8e/6ZvGv+Ev5j21PcvOkh1vdvJeukSBt3eqYyBVSpJqPk6yN0ZpKRxCqGahGEDy08j1++9XN88+wP8IZsMyUbHDWxiZUrQCmyAFNRZrIVGI0k9My3Ia4YrjrpAh66+PNcOvc0RoJSvCcyNX22X//NlL2AYx0JVZzQ2Q/t2cQ/bnqINX2byTjeUXGkbVJ3AycFR0GnJdvHkQUQnuzZwo3Pr+anOzfgi1KfykxPuqTYB6gJE1hi/HiAycBMFn9EEEWCdxBe6N/JTc89wF1b1jNCQHM2R50xhMzs9xiNGccDzMSe20/wImwZ7uFbzz3IHa88Rl9YoDmTo8XNEsbhaOUNgKlvaK15gFq/1bjnGKYUyd5AIvjdhSG+8/yv+d5Lv2WnP0RTJkdrppFQlBAdtfSfzneo4XbwVLkAM0EFwrLgDQOlPP+88RFu2fgQr+Z7acrmaK1vIiRZc+/bzZtW1NYClJga2mB6e3G04Auhz+0vreHbz6/m+aHdNGTqmNfQhBVGjfjplvpYHAMWYDr6NIyDLh0xWFXufPkxbnp2NU/2byWXzjKvvplQ2J9lm4my1+pI6BnmA0xVHfuQ8PsJqfPjzU9yw4ZfsabnVTKpNHPjER9U27PThlqGhB1D8k8En/D79297juu77+PB3S/iui6t9U2owH6hKTNtxI9F7eMBao9a15Gwd8mIf3TXJq7vvo9fbn8WdYSmXAMYiUY8cpSM+v1RzWbQpJwMmlTUyAkYy9493fMa13ffx39teYqSKM11dWDMmCjcGbIkqRRlJnB2L6CMsezdiwO7uLH7V6x69XGGrE9ztp46Z5Tg49jAiQ785NkomGT/RDpjfzeSl5ajhabD2My4eIDJqmMsibN1uJebNzzA9zetYW+Qpzmbo8WJ2bvyMN834ifSin0HVIljA/1yIKiJFWL0MTRHDBnHJW2igzJHfA4hsQBV4JizAPsL3rCnMMR3nnuQ2zY+zLbiIM3ZHPMyjQQwhr2bOJJg0pIN6fOLuGI4sa6ZsxqP56zG4zkp10Jrqo6UcfFtyN7SMFtG+tgwsJ0N/TvYnO/FtyH1boZ0fA5hqmaemckDTBCjSZwhv8Btzz/EPz7/a14e3ktTNse8mL3zE75+vwonoglazkLSUxpifrqBD5x0Lh888TwuaD2JZi877i8M+AXW9m7hP197kp9u62ZboZ8mL4tbzm5SRbuO/r2AidUxWvAlG3D7xke5acP9bBjcSUOmjvkNCYlzOL5+AvF0Yuj38+TcNF8641I+e+qFnJxrKX9uR5n7sXM/RNNCo5fh7fNP5+3zT+cv33gZt236Lbe+9Ai9fp45XrY8hVSO1xEPMJq9U1VWbVrLDd33sa73NerSGeY1NGOZfPYuOca1uzDEO45fwtfPex/nNC0stwkoH+Ue75xD4qQCnJBt5m+XXsFHFy3nq0/+mJ9se4aWdC76ViXtPtrPBSR1jFfLWPbup5uf4rqn7+GRPS+TTqVobYhInFqwdxKHffeVRvjKGy+j8+wrMSIEanGQqjOUJY4jRO8eqnJGw3zuuuhqvv7svXyt+xfUu+m43kq1oHLMTAtwiHrGkjirtz3PdU/fw/07nse4Ts3Zu0SXBoMCNy77MJ859a3YeAS74whegSRx46F0UoiOgycK/ldvfCcn1bXwucd+SNbxyquIw1ZSKwsQZQiZGgswFvsLXnhs98t846l7+Nlrz2AdaMrVj2LvqNmC2oihtzTCTcvbuObUt0ajXsxhk3GqarQqMU7Z8QzjpA+HChtL6GnfhvzRScsRgWvW/IAGL8P4dri6sPCZaQGS/9RojZ4I/pmerVz/9L38+6vrKBLSVJfDGDNqHV+7drrGsLswxF8vfRfXnPpWfA3xxrkUXTVK8uBIlMG0vzhMQ6oOd1ROhMMlrPKMg29DPrpoOVtH+vjr9XczL1NPYA/hGCYB1bU5HTx1iOZCi2Mis7ppYDc3PH0v/7bpMQZsMWbvnJjEYdx8uEfaGkcM/aU87zh+Ce1nX0moFrdC4fcUBvn7367i55vW0lcYojGd47KTz+cv3/IRjs/NGVcJXOMQqOV/nPkO1ux5hZ9sfYbmVLb6JeKhfr/yrxZRrX1AiFXFEwdHDNuG+7i5+36+t/ERdpeGac7maHUbCdB95r7GfL0AgVqyjscNyz6EEcGO41smJ4c2D+ziyjv/hu4dG/HSdThi2D7cyzM7NnL3xkf52Ue+xpKWEw+rBKPPG1637IM8vHsTxTgV3wH+QJkJrNwEzKiTQck831Ma5obu+3jzj/83f999DyWjzGtowrhONL9NYci1I4a+0gifPe0iljQeV87WdXhESvm5X9xE984XaW2YS9ZN4RmXrJuitb6VTT1bufpn1+NXkAshyklgeUPdHL6w5BL6S3mcSRJdVSeDyjloalRUo0MWn3r4X/mLx3/EoPrMq2/GuC6+Js5PbduwX0Ep2YD5mXr+9IyLUXTcdX3ETRjW7tjIPZsep6luDsXQLzuyVpVi6NNc18TDm5/h15ufjgR8qHk9RpIE85rTLuSkujkUwniUH7TdleOIM4VOZgEIVOkPirTUNeC5HgGKxik4al3/2GIwDPgF3nvCOSzMNo07X4dq8cOAwIY8vmMjYegf1liJRt8LbIhvg8PmIkruTWhJ1fHBRecz4BdwOHim0GpQnR2ZglEnaJkHL6dUmKoRfxCL5CC0LVp22I5NtnQdMWTcFK5xSDsejHOznqJ4jotrHDJuqsxvHC57qQIfXrSMrPGwao/YAsy4iKConqmq6dAQhKL1WZSbwwWtJ8eJHA8cL4m3D7Bm23Os3/kSgbU8snUDnps+pDCtKp6b5jdbnom2g0U4e/5iLjpxaexoHmhtEgU5b86JnNowl01De8jECS4nipnHA8wQGIF84LO0aSENXvqgAkn+tnlgF9f+/EbufWUdYRDNzcbxyKUy0Sg9CKxaMl6Guzc+yo+e/XX8jMvFbzib71zxRc5oOeGgdYZqSRuH8+ecSHffdrImtW/UT2AOmIG7gTMDghDYkLObo00eO8YBVI1y8ezND0ZLvZ0v0ZRrQlJ10fdVDyn80b+R89KYVLRtrMDqV9Zz+Z1f5aFPfJMFuZYDlCCRwDnNC7FqR3kBo74R2oqXSZVfGOHH78S0TcnTUk6qazlof4RqERGuW3MX3TteoLWhhdBaAhsS2HBc4SewquVnQhvSmpvDy3u38LWH/y3i/g8x6BblWqINotHtBdQq4rgVs8GVWwDrDalTKIqYunGZkGMCiiNCayYHHPi6rnEIbMhPXvodXjqHH1bDwB8aJRuQTtdzz8uPM+IXqfPSRHcGyH7taE3noo2jfRYg+lIYWDGpQQC6zxrXZFdwaVSnAngjXj/KAGJQUZ3qkTjVJdHxlDlwjCQM3GApT29hCFfM5E2OCq4I/cURevODcX0Hfi1l3NgCRLECahUVg1WG8n66L5JdxyQoQBwku/3azhGUHeUEelO+Kp/6YlUpHWRkJ15/fSpDU7qunOt3UiBRCt2GVJambH1c34FfK4XBKO9fQVTFCAK7hl6g75APjkFlPsCqNgMgho04Jhoe0y+fmhbRaNu2J74ib+xQCmyIZ1zevXg5fnEE7yCWYiJIGZdCcZhLTzqPei9TTkSVIGlHT2mYwIbRUQ0FrCiOAWUTnZ0B7e3mIM0+AJUpwLyzBMBaXadR2LPOABnVvAC8OtRz0C5JwtC+8uY2Tpm7iL3DvbjGKZeDcQYHgxHZ77m9+X4WNB3H31z4x4ye+8di83BP+eKNqKiqY1DV9QBcUplsK1Pb3Rui/lAeoeQDOomT3syESrT8eqZ3K8ABewASkzXH5+bws498jat/+k0efq0bbJQo0jgpcqkMh4vgERGG/SJhUCQ6hmZYvuB0vvueL3Ny03EH5QGS/3u6Z1ucTqOsrkIYgrUPA7B7aUUSqkwB2rosgOcVHy8V2CmeexxBUJMr5GcKrCpZ4/F07zaGgyI5N42y/2ogYeyWtJzIbz7xTe57+QnW7XyJwIas3fECP924hox3cDbQiFDwi7x78TIuPHEpjhjOnb+Ydy1ejmPMIfcdHDH4NmRdzxbSJmYBLYpjHDtcHAxL9rcAdHdPogIIyqo2Z/fKbw813f7F+0m5H1Xft8jM2k6eTKhVUsbllcE9PLbnVVYcf0b5wMlojKZt37l4Ge9cvAyA7z19Dz969kHqUlmsHrjla8RQCgpctngZX/r9P9zvs0MJP9lpfKp3Ky/07yTjuFhrQbGSdg0j4W+Grr5pN9pukM6KiIgqBNgGgGDvwFpBD3Fp3bFS4s7xbcCqlx8/rJef3PIRqqUQlAhsSD4YP6OKIBRDn8CGFIJS+UTQoXYcEwt01ytPkPeL8Y2o8SdRiOEdAHRULtfKFWDlSosifXv13nCksImUY1TVTrecalkCteS8DD96dR078wORoA8xpyfHw5LdvfPmn4px3MO6SiqG8+efgmscPONGAaaH+i7RzmR/Kc+dL68l66UJoh1Tq65j7FBhp5P37gago7PiGzeqMeHK6naHL9xURM0/knIFVTvtjE0Ni6qSFocdw718+7kHI6JtHO83STHz3xYu4eJF59I/0k86DulODpSkHI++/CDLF57JpSedh6pizOFFkdwidtvGh3m5fydZ40bKaNVKxhMV+e7ea/5hkPZ2lyouGqtuDr+kI0QRN5O+VYcKu3AdB47h67mJrEBDqo6bNtzPpsE9uLGAD48oNuCWy/+cxXMWsndoL6UwIFTFDwN6hnpYUN/CbVd+kbTjES33Do3oeLuwIz/AN566h5wXB4WqKq4xdrg4EPqlm+OfqUoeVR5jEaWj3eld+X/6NQj/FxlP1KqdjoTIU1kcMfQVR/j8oz8sC+RwKmBiJTm95QQe+uQ3+dzvvZ83NLSS89IsrG/hqjddwcOfuoHz5p8SO3yHF4ONyaAvrVnF9pE+UsmVdqoh2bTRMLxu5Kpv76BrlaGzMuevLNJqvlx+RtuFW7Y7DZn0WsmkztW8H2KmJJPstMEVQ29hiK/9/gf5n+ddgW/DcpLoQ2G0Nz/iF+krDNKYrqc+lTng80MhqefmDQ/w+UfuYE6mPjowqmpJeaJ+uGkonz+XbQsKdHRqNeYfJhYVrHRtEK69xUfMZ9WGFgdFVad7pNaqoNGWbWO6jr9d+5/c/uKa8qGNw3Zu7DSGaqnz0ixsmEt9KqJ3qxH+f726ni8/uoqGVF10KESj2R8johp+jmtvGWHpBqlW+DDRsPCVXSGr2pzBT964Rgv+35LLuFrdiaSjCuWVgUKdl+aqX/9LWQkSYR4KkpxeJlao2D84nPBtrDSecfjRq+v56AO3korvXY5+h0Aasq4dKX5j+FM338eqNoeVXRO6a+9INrGE9naHzs4g970/+09Tn32/DowEmEnaFZmhiA5oWkaCEn+3/P189fwrgehiSMckV2JODIoSWsWNVwQ3dv+Kr6y5i5RxcOJ5H7WB1GddHSk8MLSp9TKWbhBWdiUXFVX/PhNuLYCq0NEh8+btrhtpdFdL2luuw4UAI8e2EsRiHiwO8b6Tl3Pdm9s4rXE+MDo/QGU3IEaWJUokkZww3jzUw1/87i7ufHEN9em6KCQcBdVAsmlXS8Fzpj+8aPDPvtVDR7tU6/jt/y5HivZ2Q2enrb/t8/OsJ6tN2j1LR0o+4B3xb89wuMbQXxymNdPAny99B9e+8WKOyzaWPw9jmmRsukGN/yHCftTy3sIQtz3/ENc/cx87hvtoSuf25QtKhO8Hr4T5worCtbdsTvr+SN5hcuIY4obkbr36ONLZn5JJL2eoECnBMR46liSHKpTyLGxo5cMnL6ftlOUsn3syWXf8MVAMA9bt3cxdmx6n6+W1bB7YTdrLkHbceK0PgE8u7WnRf9aWwisK13z71SOZ90dj8sSTNOjGjzXWNbd8X7Lp9+lQPhoCcuzuGkKc5cMIhSCg5BdwXI/TGudzfusizms9gZMb5tKariflRCuHvYVhXh3ay1M9r7FuzxY2Duwk8Et4Xpqs6xHayFlEo1AjaagzNl+8z8kX/2jo2lv2TJbwo7ZPJkaZpLrv/Vk7jukQEbRYCkCcI/KQjgJInCImVEsh9AlDn3gARDvnIjHNbMt/dxyPjOOVn4sEj4KGpDwXI4hv/2H45Za/orPTVrPTV1mbJxuxY0hnp03feu0lJp26XtLe+eRLaBAG0RbysW4R9l0WHUdtxEvJiKsdfcu4LS8PibxBCHGMK3VptOA/J4H/5ZGr/+nno/t1sttaG5SnhMvTmcbTvoDhyybtHadFH/wwMV9meq7XmkGIhB55ep7jSMZDi36PIDeO7Oq9jq/cPjyZJn8satv5oxqeu/Xq49TNflbRq0i5iwEoBhCGFrBR9iSN4gz2D4E/VhANc1FFRffNAeKQ9qIcxUX/NRH5V0qFf8p/9ruvAdRS+DA1nSysajPll7j5T+ozDeY9WPsRLBeTdlvFMWioEIYQahRXF3m/EyI3ZiQEwRhwBBwHcSR651LQi+jDiLkzWyz9uPfaW/qBRPATJngqb9ZUIZrDHDo7y5Rx/Q++PLdULFwg8FaxugzlFNDjUBpwjIOJnaajGYnjF9oQGEJkF7BJRdYblUdMnbNm+I//787y99vbXTo6QkSm5MWn3swqQld0zuAA09bebhpO2TOnpKbZatjghsExwSgKJgxTZtBzMn1D3pbeg703SzcIbV3Jac8pbNt0QlXoWmnoPisKZJhkD3fGIjq0YVi6QWlbZadqtB8MM83Rio67dnRE7Vq6Yaa1b2JIDml2dGh8XOson9dmMYtZzGIWs5jFLGYxi1nMYhazmMXRiP8PJCVCNJJRgwQAAAAASUVORK5CYIJpYzA4AABBNIlQTkcNChoKAAAADUlIRFIAAAEAAAABAAgGAAAAXHKoZgAAQPNJREFUeJztvXmAHFW59/85p6qX6Z4lO2FVCGsCKIu4sQQRkU30SiIuCIpXL8j7U+/qct87Ge9931fvFUW2K4hsbpgRvYAisoZFQNYQkkACgewhmSyz91JV5/n9UV09PZN1Jt0z3T3nEyszxJnuqup6nvOc5/me54DFYrFYLBaLxWKxWCwWi8VisVgsFovFYrFYLBaLxWKxWCwWi8VisVgsFovFYrFYLBaLxWKxWCwWi8VisVgsFovFYhlD1FifQE0gogBamadgHktpt/etGmmHmXOWCPOgbd48QSkZ61OqduyDXIqImtPerjdNnaoApnV0SPvcucFYn5Zl5LSK6AULFmiAabM7pH3eEqGtzYz1eVUL49sBiKg5tOtNC6aqx2bPDnY2Ynxuwx3p7k63JZFwm3IZP+Uk3ImBlxcJ9Pi+f1WCcow4sbgKPL87kXB7/JjTF/Q6Xfcc9fGenf3OaY+2ugCzF2DaxrFDGHcPcKu06gULZuvZsxeYNjX4g79oxd37eOQPDwL/aITDEQ4XYw4ApqBUCyIp5WjlJOKI2OiymlBKYfIexg8ERRahG6U6lFLrBPW6EnlDYizWxl/2+8MvXjvol0XUaQsWODt6Juqd8eEACiP9TJZI6Qf8iZV37YsfvE+C4FSE9wtypBOPtehEDAWYwCB+gAQGCQLECCCIMK4eklpBgUIppbRCORrlOCjXQTsagMDzCbL5PiW8juKvotXjxHjq7oM/vbL4IiLqtAXznMdmz9tpRFhP1LUDaG1t1Qtmox87vc2P/u381+cf6mLONsacrQwfdFKJZu04GM8jyHmYwBiFGAABhSilEBXeqYG/LFWLFP+nlBQyuAIggtaOo3Uiho67IILXm8mg1LNaqz8Zx7nv7hlzX4leaI7Md4YOGvVGXT7MrdKqlzJLtaswgffRZ37e3DApdj7wWROY0+NNqaTxA4JMDhMEgVKIgFKCRqm6vCeWAiIiKFFKjAhKa+04DQl03CXf0x9opZ/E4deu0b9rP3xuB4SJRIA2perOEdTXw97aqufMGzD8jy//9QyBy8TI52Kp5IEiQtCXRYzxBZTCGvy4RxBRYpQgKOW6qSTKdfD7sh0o5uM6N0ZRQegI5lFPEUF9PPyCmsN8HRn+uUvvONp1Yn+v4FNuuiHl92cJ8l4AoJTS1Mt1W8qNCGIQ0DHXcdNJ/L6sr7S+OxD5wb2HX/QMhFODduaYesgR1LwhzJH5TnHEf+W2GRKLfwfFZ91UQ9zr6QdjfAQHXQj0LZbdoRSFMk8AuLGmFEE2D3CX8fP/555Zl7wEg5+9WqV2HUAhs9+u5ganPXpd44R9J/+L0nzNSSaavO4+REygUDbEt+wtIiJGgY41p5WfzXvATTrjfff37/78plZp1W3zoFbFRTVpHING/dd+cYFo9z9jDYnDvZ4+JDA+SjnU6LVZqhcRCZRSTrylET+TW09g/vf/HPWZW6B2o4GaM5LTHm11Hzu9zT/v+RunOI1NV+t47LMSGIJszgccO+JbKowgEuh4zHWScfxs7k9BV+bKP5502ZthbmCuQVEzc83aMRYR1co81abazPmL7/iojsd+4jQk35Hv7DGh/gM91qdoGT9ImCMw8ea0E+S9LeIHX7vnqM/+EsIydK1UCmrCAcyZP9+JFuV87LVftGrHnScimFzeRyl3rM/PMn4RYwIdizlOQwKTy10ff3n537fPbcvXypSg6h1AFPKf+8QNE52pzbfHmtLn57f1GBGJSnoWy5gSRQOJic2O15t52u/r//R9J3xp1WnyqPuYOt3f7QuMIVXtAIrz/UW3Huk0JO5ykomZXmevHfUtVYkY8WPNKdd4/nrTm51773Ff+Eu1O4GqdQDRjTvnhdtOdZsS7dp1pvm9GV9pa/yW6sUYE7jJhINS/X5/9pI/vuvS31azE6hKB1A0/pduO91NJf4ApIJsLlBaO2N9bhbL7hAjRsccrWMuXn/2M/e969JfV6sTqDoHEN2osxfe8qlYuuEO8YK48XyjtJ3vW2oHEYzSGrchrr3e/m/88V1fuPqE52+MvXDiV7yxPrdSqsqoTnu01X1Mne6f+9JPZ8caEr8QL4gb3xq/pfZQCi0mUH4mZ2LN6R+d/eItn3nhxK94Jzx/Y2ysz62UqokAorLJec//7GSnqeHPJjANxvPFGr+lpjEiuNo48Zjj92bn/vG4L7RHye2xPjWoEgcQ1fnPXnj74bFk7ElgapDN25HfUheIYLTroFztmUzmw39492VPVotOYOwdQGurBrjg4+9sDuKxZ5xE7Aivt98m/Cx1hRgxTjKuEenIdvW998H3ffmtalAMju0IK6jTZqNpazO+1r9w08kjvL6Mrxxr/Jb6Qmmlg2wu0PHY1Hhj8renvXVrcimzVLTnxFgxpg7gtAWtzmOnt/nnLLytNT6p6dx8V5+nlHJrZymFxbLnKK0dr6ffjzc3Hp/u4oZ2NTc4bcG8MR3sxsz7RPP+c1+8/cNOOvFgkM/7GLHLeC3jAT/WnHZzW7u++KcTLrt1LPMBY2Nsra26dR48/8rhLahgsXbdfYOcJ3ZFn2VcICLKdUVplfEC7133H33pm620qrHIB4yJwc2ZN0u1qTZjgvz1sabUfiaXC0LjD/vu28MedX0opYzviY7H0trIbShkafssxRgMyKPuAObMD8Odc1669dx4U+rTXle0uEdG+1QsljFCUEo5fm+fH29pOvmcF2+5on3u3GCOzB91exxdj1No6vHC+hOSsnnrEh2PvSPI2tDfMk4RERVzBTG9nqOP/PNRn3u7dd48NZp7FY6q4c2hXbepNhNs7PhWvKXxnSabD6zxW8YtSinjeeKmU8066/0nSsnSWbNGdVAetTdrlVbdxjw5b8kdB4qo1xQkxDcKZbP+lvGNKAInHnNM1nvvH4+79NnSDliVZtTW1i9tn6WYq0zw0s++G29pbvC6emxjD4sFECMo18FI9vvA6TPnLBm1hNiojL7h6N8mZ798+2HaUYslME5BAWVHf4sFEBHjppLaZHKn//G4LywYrShgVObfS9tnKRRC4H/bTSVjiBis8VssAyhEaY0xphVgtKKAijuA1tZW3T53bnDe4tsP0q5zkdfTL4DV+lssJSiU4/VmjNOQnH3Owp+9t021mTnz51fcTiruABbMDt/DeObv3KZ0AmMC7OhvsWyHUhgn7iJGfX3U3rOiry4oFHLmwjvSTuC94cRj043nG8Z6FaLFUo0IorQCRdbPyxEPnPTFNbS26kruO1hRQzxtQasDKNf4F8Sa09MLW3Rb47dYdoRCiZjAbUo3OC6fAzhtdmXtpaIvPns2BhCESxARG/hbLLtGRGmTy4Mxn2ttbdWPzW6raCWgYg6gtTXsdnLmwjsOVlqd5vdlUdgWXxbLrlAK7WfzRjckZj573gHvRyGVTAZWzCAXzJ6tAZwgf57bnE4gNvlnsewJCjFOMoE4+m8ANk1dUjG7qZgSb/bsBeYxQCnOFd9HkJrft1srhRG7atFSWUTQJpcDkbPmzJ//z+2z50aDZ9kfvsrYpIhCKTlz4R3TnCD/pnKctASBoGrTByjAAP1BnpQTx1WaQGpi92dLrSKIcrUSX73r/hMuXVSpBqIVmQLMoT0M/33vg25TKm2CIKhV49dK0Rd4fHG/E7lkvxMwYujysyjAqc1LstQCisBtbAAJPgSwYMHsithqRaYAmxaEcxal5FSlNQoltdrvQwGBGKbFGpm7z7F8aOIMfrvxFR7Y8jo549PoJFAKOzWwlBVBFL4gSk4Frp7W0VGRB6yiU4Cznr/52Vgq+R4vkw1Ujcp/HaXp8jL87xkf5sOTDkMXRv1X+zYx/+2XeXzbW/hiaHTjgMLYqYGlPBgdj+kg561Vzfsdev/h5+QiYV0536T8YUXB+D+6/GdTETkqyOdRIrVb/pOwj5sinA54EmBEOCo9jdYZZ3LVEefxvpYDyfh5+vwcWim0LXZY9h5l8p5oR+9Pz7ojAFppLfuDVfYpwJz2dt0OQdDjHRVLpRr9TN4oVbv1f0EwUvADgEaF1QAEBN7dtB/vbtqPZ7tWc8f6F1nUswFHa1JOHCNCzc59LGONAnw3nXTz3f3HAIsWLEAT5qPLRtkdQFSzVOLM0jEXlckbpMblv7L9XEmjoDD3VwpOajmIk1oO4rGtb3LH+hdY1tdBQrsknZh1BJYRIqAUCjkm/O/ZQFtZ36EChjk7/KI4AlWR0uXoIRL2LdnFJWgVdjULjRxOm3QIN876JP864wz2TzSzLd+PJwGOshMDy3BREAjAEQDTZt9QdmMqewQwrSM8SWU4XIKgxgVAQhhxmYE5wE6IkoNGBFdpPjrlCE6beAj3dbzGbzcuYlV2G2knTly7NiKw7BEiaON7CDIDoF21l10QVO4IQLXPbQ8AtFL7ix9Q0/YfIXt+xyNHEIjQ4MT45PRjuGnWhfzdAe+jxUnS6fUTiMGp3bSIZZRQiDJBgEZPm7P4ukZgtwPRcClvBCDhnIWnvtHQ6WWnToy5IKJqdhlgwfCNDMMDFHCUKv5uk5vg8/ufyPnTZnLnhoXc17GMrfl+Gt0EjlUVWnaBDqDHy01cnemdBPTCvKqOAAA4jAMmdeR6J2zs7y68SZmLl6PNCE8+UgsKYUQwMZbi8oM+wE+PvpBP7HM0iNDtZayq0DIIAVThz+Zsr2wymXgOd2ol3qvMDmCeAnAcSWutG7q8DOty3WSNjzuOH/ChjmB6ool/PPg0bjz6k5w99UjyJqA70hCM4/tkCXEKepMNuR611esXHXNxlWoGoL28G4dUJALwM15aOQoHJGd81ue62OZlihnzmo4G9oIBRyAYEd7ZMInvzDiD62d+nA9NmkG/n6fXOoJxSyQ26/FzrMt20R/kcZQSNAR+vrES71neHEDBOylhsoq5GC8vWimNwOZ8H5nAY0osTUw7taGdlyFfy4RCoVQoMhKBoxr34buHncULXWu5c8NCntm2Gq0VaSc+kIOw1DVaKQIxbMn30e1nUSgcFEYQ5WiAqQCnTV2iHivj+1ZkMZDSg/NmijAP0OvnyQY+U+JpGt0EItVfDCvd2LncRI7AFF79hJYDOKHlAJ7Y+hZ3bljIy90bcLWmwYkjIsWfs9QP0ajfF+TZnO8jb4JiPijsp1fIrUt5FYARo7I1V/TYaqUIEN7O9dAU5JkcS+NqPe5HuEgiFKkKT5l0MKdMOpgHNy/nV+sXWlVhHSKE08FAhM35Prr9DBDayNBPt5Kf9qjvzacApRQ9fpaM8ZgUS9HsJosj3HjeK7RUTKSV4swph3P65EO5v+M1frn+JVZmttHgxEloFyM2HqhFBCmuJ+nzc2zx+skbHz1GupDKOQCRXYoWNIrAGDbleujzc0yOpYkXcgNhGaQKiM5/N9dSboaqCs+bNpMPTT6M+za9yp3rX2JtrptGN0FMOdYR1BhuIcO/Nd9Pt58LE8MoZFfPVwWfvTHdnTfKDfT5eTKBx4RYAxPcBhzbew8Y7AhSTowL9z2WD085jLs3LuGuDYvYlO+jKZbAVY4VE1U5oRZG6PSybPP68cUUP9+xfNLHXI8qDMx7tuT7WZvtotfPj/uSYSm6REMwIdbAJQecyE+PncPF+x9PXDl0ev0AVl5cZUSCHq0UGeOxLtfNpnwvAVI1Zd7K6AAYnD3fkwPCpEhefDbku9mQ6yEvPo5SlWmHWmMMFhMZ9kk08dV3fpAbj/lkUVXYVVAVVsvDNV6JnlVXKXwJ2JjvZV2ui4zxBo36w7WPSlCZKYAPxIc/bx6QQEKvn6Xfz9ESSzLBbcAt5gdGc2VBhYQAe0HoCHSxUckByQn884zTuXDfY7lj7fM8vvVN8hLQ6CawLcrGhmh9x5Z8hk4vQ4BBF5/sYT5LUR2wQoxpDmDHhBcblca25TP0+DkmxBpodpPF/EDVJArHCIXCKRETHZKazLzDz2Jp70Z+vvZ5/rJtJQKk3ThgxUSjQbRvRLeXYZuXKWb3neJUtvo+gyp0AIMp1kpzfXR7WSbGGgqr6GyiELZXFc5s3If/d+S5vNC1lp+vfZ7nutbgaE3aSVgxUYXQKszi9/o5tnkZsoGPUlGkVo1mP0DVO4BopFeF8snGXC+dfpYWN0mTmyh6XRsRqGJ7cqUGVIWPb32TO9e/xEvd64hr1/YqLAPRsxYZfo+fo8vLkgk8UFRFdn9PqZgDMMNPAewBCq0gF/hsDHrp9LJMiCVpdCrkCKTiU7CyU1o6VEpx6qRDOGXSwdy/aRnzN7zMq70bSToxkjqGQXZdf7YMYpDhI/R4OTq9UNAGhWnr8FtH7Po9C3YUVGiP4ApGAJUJfkQi/QDkjcfGrEenzjAhliRdaLAxoCrc63cb8rV2GKoqPHvakZw59XDueXsx8ze8zMrMNlJOzLYo2wMiw3eUxogZPOJTWnWp1D0UoDIeoOqnADtjoMYKefHZmOsl7mVoLkwNXK1D7znOH+zSFmWu0vzNvsfy0WlHcvfbi5m/YSEbcj2knQQxbcVEOyIa8QMxdHkZuvwsucCvm3JrzTqAiFJH4EnA5nwfnX6GJjdBk5sgocNLHO95AqfEEaScOJ/e/3jOnnYUd21YxF1vL2Kr10+jmxz3G5+WhvkAeRPQ6+Xo9nN4JkCp+jD8iAquBWBUI2chTBQqBYERtuUzdOWzpNw4zW6CBidWKMeE9fPiR7ir0mztzgB2SmmvwgmxBi476L2cu89M7trwMne/vYROr58mNxnWsjEDFlFH96BIyXWFitSB9nX9vkePn6MvyBOIKSr6ij88WlTYjirmAMak/FHyhtEH2ePl6PVyJByXRidBoxsnpsNtCvek2We1l3FGQqmq0BRalH31nSdz7rSZ/Gb9Qh7oWEaPnytWWYJ6TRQWLksXKii+MfQFOXr8HNnAK8rUo2dpLG5DbSoB8QsvPXYPTvTOuuC0c8YjE3hs8zRpJ0ZjISoISzmFOjpDpwilIUD9GcF2LcpSk/iXQz/Ex6cfzS/WvsATg1SF9SEmKpaVS8qm/cajtzDa+8YUS3lRMW/sr3pcKQErg0LhFgQz3X6O7iBHQrmk3ThpJ05CO7txBvVLqCpURTHREY3T+Pcjz2ZxzwZuXf0sf+1cXdOqwgGjH1hY5ZmAvkIPxpzxCx3tVTEyGi/UTQ5gTxAANRD+5o1PLu/TSYaE45J24qScOHHtoKOfj/QMVXYtlWBQizKBo5v25apZF/Bc52puXf0sC7vX4SiHlBMvRg2FX6yO+zNkTh8KyAamg54JyBgvXH5uvFArQWj4WlWp5qNWcwBVS8m0X6GKhp71PTK+h1b9JHXoDBqcGEnl4qrx1ado6Man75lwEO+ZcBCPbVnBz9c8zyvdG0g4MRqiFmXVYjVFf1QwaAHfBPQHHn1B2I8yqnBopQY0+mUW79QS9ZUEHAFFZ1Cy7Dh6YBwUDU6MnOfhVaYnY1UzVFV42uQZnDzpYP68aRl3rnuJV3s3knLiJJzYGHQmGni3MHIJPz8jQs74ZIxH/yCjD53C0OW4tUDlZEA1qASsFKVnWgwbRcgYjy25XvoLqq/xSKkjcJTmnH2O4oyph3H324u5a/3LvNm/lbQbbXxaOUdQmpdRJVGZbwy5wCcTeGSMR94E4fSk8DmW1u2rIaU3fGwScNQpVhEKCbLxNAXYGaWqwoR2mbvfuzlvn5m0r1/I7za8woZsN2m3TKpCibQdA1n7iEAMOeOTLRh93vj4BccTzenrKplXczkAH4hTSwHAjokSSrUVzFScAQ2BIeXEueTAk7hg+jH8au0L3PP2ErbmS8REe+AIBnIy0dcwGQmFhTBiyItPLvDJGp+88fHEFHMPqtA+blDitryXPHZEz17tLQay1DMDnYlCRzAh1sAVB5/M3+x7LL9e9xJ/eHsJXQVJtt6JIyiO7CVraQIET3zyQUDO+OSCAE8KI3yU5CtEZEN76NeN0Y8iFXEAPuBQDyvMpPjHsmMGOwJherKZb8w4jY/vewx3rn2RP216lZzxaYk1FFWFkd7AF4MvBk8C8iY0eM8EBGKK6sNwCqCKoX2IlPzNdt/XG+HzFzrQcm4LBjYCsJSJUlWhCBycmsS3Dv8wF+x7NL9a+yJ/2vgq/cYj5cTxJCAXhKN65BBKX0ftYHPU7U3eUg7GlRBo2MiQr5bdsl2Lsqbp/MdR53DWtCO57s0neKTjDVDQHEsWezts1y7T3u8BrBDIUouUau0BTpl8CKdMPoQHNy3nmjcf55ltq3CVptFNYEpVhZZRxe4kYakouhDOGwmN/Mxph3Pv+77ELcddxMymfdia7yMbeLhKY4uto48VAu0SoT6uY+wp1RBopTh/+iw+us+R/G79Iq5Z8ThLet4urtAcmhew1KAQaJT306wMMrBApNYvpVoY6ExkiCmHT+1/HOftM4tfrX2Bn7z1FG/0baY5liShXQK78enAYrQKKdHtFMAyJkT7GAZiSLtx/vad7+fBD17Ovx3xESa6DXTk+op9DC2Vw95dy5gSaQgCMUyKp/iHw07ngQ9eztdnnEKDdtmS7yv+nKX8VPCujvvgzbKHlO53GIhherKJtqPO5qGTr+Cyd7wXRNiS67WVggpQobUAPohT+0mAaBFAXSQ0qp/SzkRGhAMbJvCDoy/gS+94H7eufpb/Wf8KWeONr2pBsUtJZRYDVCwCkDo7LKOHKvzxC+sHjmzah/Onz6LRTeBLuOZvrJ+H0T4q1Y3CCoEsVUW0S5GjNBrFE5tXcO2KJ3i4YzmJwk5GtkRYPqwDsFQF0XZuYbJP8eLWNVy/4gnufXsJAUJzPGl3eqoAFVwLUAfz5tIcgKUiRPN9R2kcFMu6N3LdsgW0r11IVgImJFJorQhM9BlUSwfSUaKYA6gMNgKwjAmDDF8p1vRt45pXH+HOVc/TY/K0JFI0OOE6gUr1w7NUyAEEgEN9+GmbBCwvQthAJDL8zdlernvtUe5486905HuZkEgzMZ7GL/yc0iUZ/zrak284VPL5sxGAZdQIioav6c5nuHH5E9z2xtOs6t9KcyLFlIYmfAU+AkqFxj9OjX60sP0AdoUM+WoZEaWG3+/n+fkbz3DT8id4rWcjzYkUU1PNBAr8wk4eKuoEihq490qNz88hsqPa6wkYVS9r3YPXgycbGwIx6ILheybgtytf4NpXH+XlbetoTCSZlm4hUBKO+LrQGkSXGH+EgvH7GVT2+bNTAEvZiSS7kX7/D2sW8YPFD/DC1jUkY3GmNbZgEHwlhaZ/irD6N9AXuPSLpQYdQL2Mm1YNuOdEhh+t/X90wzL+c/Gf+UvHm8Qcl8mpJowCr2D4qmD86Oj+WsPfEbWZBKwHqynNAdT6tVSQUvUewNOb3uSqxQ/yyNvLEAUTk41IyRw/NP7oe0CGGL691wNU+NmzUwDLiNlOvbdlNdcufZQ/rH2FvAS0JFMopQh2Zvh2xB9zbEuwPaKermXv2U6917WRG159lN+sfJ6+wGNCMk1KawIlxT26Q8NniLGLNf7dUtkygI0ALHvMUBHPmr6t3LjsCW5/4ym2eRkmJNNMSiQJlBRGfb3jEX/It5axo3J7A9bDoGl1AMBQw9dszvZy07LH+enyJ9mU66ElkWZyqpkAwVcUk3s7rueXvKhl99RqDqAe7B/q5zpGSqmIp9fL8dNlT3Dj8idY3VdQ76UKtfySeX404osd8ctCBXVAdgpg2TGlhp8PfG59/SluXPY4r3VvpCmRZGo6Uu/J4NHe1vJrijI7gPbC13B70PoZO+vlOnZPqN5TxR59v17xHDe89igvbl1DOp5garopNPwdqvdKUOPnnlWWWlUC1kPsPI50AEPVe/eufpnrlj7Kk5veIBmLMzXVjFGha2e7OT62ll8panctgKUWGKree2zDslDEs2EZMddlcro5FPGAreXXITYJuBuGXkc9XBNsr957fvMqvr/ofh5Y/2qo3ks1IVoVl+aWGr5Ywx9ValMKXDcuAOrnOrZX772ybR1XvfIAf1jzCjnxaUmmUVoRRCKdnSX4xvUKvdHE5gDGjjrSAQxV763o7uDqxQ/x25Uv0B3kmJBI0eAkQ8MH0LoQ4Q+p5UeGXwf3pCaoVR2ApTrYXr23jZ+8uoBfvPFXNuV6mNiQZnKiCR+r3huPWAdQp+xIvXfL8ie58bXHWZfpYkIyxdTGFnxkyCo9a/jjiYo4gHpSAdRiP4Ch6r3bX3+Ka5Y+wqqCem9qoROPN2iOb9V71UptKgHrYl+A6GttuIChLbjueP0prl36CK91bRpQ75V04hkc6lO4RKHWavlKRbsF7nrXwLDuESZCa4bIjkxlNgezU4A6IBCDRhVLer958zl+vORhFm4JW3AVDb+g3isd8UNqp6QX+iyFLuwPaMTgmwDfGHwx4T4CMthYHFRR3ehqh5jSaBUmOQ2CyPjdb8g6gBpmR+q9a5c8wl82vUHMiTE53VRQ79W24StAF67Rl4Cs75EzPgpIOXEmxlNMTqSZmmgk7cTZJ9lE6Q5Cm3N99Po5Nuf72JzrZWu+nz4viyDEtUNSx4hpBwgdynhyBtYB1CBD1XsLNizjmiUP8+d1S3EcJxTxROq9UsOHmlLv6cJI74mhx8sQiGFiPMVxEw/ghIkH8q4J+zOreV8OSE1gYjyFq3a92bURodPLsC7TyavdG3m5cx0vbFvNa90b6cj1oYBGN0FcO5hC2bTeqVg/gHpIAURDQbWkAAaLeOD5jpX88JUHuXfNIkTBhIZGKJHtRhl9KRXwFGv5VMU17YjI8Pv9PP2Bx6R4irOnz+Sc/WbxwSmHcGjjlB3+niA73EA0ygxopZgUTzEpnuKYlv2Ye+BxAKzu38YzW1Zy34alPLbpdd7O9pB0XNJOAhCCsXyQK2xHFYoAfBCXqn3Chs3YXsdQEc9rnRv4z5fv5/erFpKTgAnJFErrgnqvVLlHTbXgUoW5ep+fI2d8jmqezqcOOp5PHPAuDmucOuhno3m+opDMDL8rfr8jpPB3qZPQSnNQaiIHpSYy98DjWNvfyd3rXuHXq59n4ba1OFrT5CaLn8HoU6tKQMteI4XRxy2IeFb3buEHix7gN289R7eXY0IyRcpxirJdpfSAZLfGavmu0mQCj/4gz/ETD+TyQ0/h4/sfS9qNAwNrFyIn4ewm3N8RxUrBkHtT+toHpCbw1cNO4cszPsB9G5ZywxtP8JfNbxJXDmk3TlBnOQLrAKqQUhGPqxQb+ru4dsnDRfVeSyLFpHQTwe7Ue1Vu9DCQx9ic7+OQ9GT+4YgPcfE7Tyom5QIxRaOv1AWVvnY00se0wwX7H8MF+x/DXWsX8v1XH2JR5zomxlM4Sm9XaahV7FqAXTHKawGGqve2ZHu5+bUnuHnZE6zq28aEZIophd57AVDcQJMSw6+BOX6EqzV9fh5BuPLQU/mXo85kSiINDNY0jCYKhaMGSoxaKT55wLs5e9+Z/HjZAq5evoB+P0tzrAHfjMLG5bW6FqAe7B9GTwk4WL2X5Y7Xn+a6JY/yevcmWpIppqVb8JXgKSlpukm4PBeohVE/KswpwpB/c66PI5qmcfXxn2T2tMOAwfdhLFEMlFcDMaScON+a+RE+uu9Mvv7iXfx1y0qmJBqLU4KBomP5scuBx5zKXctQ9d6dK57lB4se4NWuDTTGk0xrjGS7Zgey3RJqoAVXaCih4+rI9XDhgcfx4+MvZHIijS8GZ4Rz+0oTtkcLP6vjJh7A/bOv4Jsv381NK56iJZZEK1XBBGFlWwLZHMAYEc1towf+f1a+xPdfvp8Xt6yiIZYo6vX9ofvo1ZiIp5TIULryWVqPPodvzfwIEN6L3dXwx5ooaglEaHBi/Pj4Czl2wv78w0u/I6Yd4tqtybyAzQHsigrkAExBdhoZ/p/WvMJVLz/AU5tW4LoOU6LeezszfFGDjb5G7rFWCt8YPBPw05M+w2ffcSKBCFpRlaP+zgjzA2Gi8LJD3s9BqYlc+swvyAYeSR0rvxOwPQHrg6EtuB5bv4yrX3mIB9cvBaWY0FCygWak3ouSezWW2R+KRhEYQ9743Pa+i/n4AcfiS4CrnLE+tRERJQo9E3Dm9CP57cmX8cknbw6dgFMBJ1BBbA5gjxj5dQxtwfV8x0quWfwQv1+5kABDSzINUQsuXbImHwYbew3M8XeEQmEw5MXn9vddzAUHHItngmKZr5aJaQdfAt4/5WDuOvlLfPLJm8kbj5h2MWVzAtEaxspgqwC7YaTXMVS992rnBq5d/DC/WvEsWRNuoDmg3gOlC2FwnTXdVAo68xluee/nRtX4i0t+1a6XCO8trhpwAr/8wKV8/PEbCysNVVkNt1Ixhc0B7IrSHMAeXsuO1HvXvPIwt7/+FN1+lgnJNA06uWP1HiVfd3YutUChJuZqTUeul+8ecy6feceJFTV+AUxhzbyj9UAURUE2LILWejcdA0aGqxw8CTh92mFcd8Jc/va5XzMplhror7g3n12t6gDGG0PVe5uzPVy96CFuW/4Um3I9TEimmBxvLvbeG0juDVHvlQp5ov+uNSTMmG/J9THnwOP55syP4IvBrZDxF7UDeiCZ2JnrQ0RoSYTKveieRj9bbmLKwRfDxQefxOKuDfzwtUfYJ9GEJ6MgFtoLrAMoA6Xila58hv9e8ig/W/YkK3u30JJMMSXdPKj3ntqR4Q/5tpbRStEf5DmsaRrXnTgHQdAVCsWje++bgLuXP809bzzD4o6VbO7vxiBMTjZx5OQDOHvGe/jkESfTGG+omBNwlCIQw78fey7Pb1nFs1tW0RRLVnVS0CYB94gdX0ep4Wd8j1uWPcFPli7g1c63aU42MLUxasEViXgYUssvvHadGH4pvhj++z2fYmI8VTGDi173Tyue49sLbmXhxhWA4DgDDT7e7t3KyxtX8Jslj/Ifk3/Nv538WS4++owwR1Bmp6QKE4y4dvnJSRdxykM/wpeg0L1opLZQg6sB/QCcOukHsKPbX6re803AnW88yzWLH+bFLatJx5NMjdR7yKBQX4aW9Eq/rfV7VSCa93/jiA9x8tQZYehfCeM3Bkdr/t/Tv+E7C25Da8WEhqbw8ypZsRd3XFQ8iUKxunsTn7/7e7zw9uv88IwvIxJFJuVzA1opfDEc1jSNf531Ub7xwl1MTTbiGxmZXtjmAMYWKf4V1vKNhG2kAO5ZuZD/evl+ntn05nbqPbUz9V49zPF3gkKR8T0OSU/hW7M+UqiClD+8CSQ0/que/R3ffvC/aWmcDLDDxTnh5xfe5KQbJxVL8uOn7kSh+NGHv1JwJOU9R6egGPzKoSdz58oXeLlzHWk3PnK5cAWfkdqRYI0lKmweqZUirh0eXv8aH77vh8x9+EZe2raWKY0tNCQSoXpPq7Ckp3Whrl94gUGinvrEUYo+P8+3Z53FxHiquMa+nERh/+NrFvPNR26muXHyDhuB7ggjgm8CJjZN5eq/tnPn0gU4WhOUueNutLA4ph2+e+y5GDFV+7FbB7AHCELKjfPS1jWc99B1XPDQ9TzV8SYTUmnSiSQ+gtEK5eiimGc8GT6EoW+vn+PEyQfy2YPfgxEpNvIsJwqFEcO3H7sVg6DU8Nt8BxIQjzXwr4/fQV8+i9aq7IOsozRGhA9NP4Kz9p1Jp5etSslz5VqCUR8twQIRmmNJvr/4z7zVs5mt2T4mxlMoKNZ5a7UFVznRKLKBx/93xOm4Sodz/wqN/o+tXswza5fSmEiNaPQ2IqRiCVZsWcPvlz/F547+EL4Jyl6mlMJ87++P+hAPbFiKiGHkSYDKlBMr5pKipqA1fRSuw1EOS7rexhdhcrIRA8WGHGFyr3CgEFEDv1sv92E3h5Iw9J/ZMp0LDjh20JqH8j5TofHc+8YzBIGH3isHIyilufeNZwAGCYfKRRQFfHDqDD44dQY9Xg6NHtE9rpQUsPpikipEgAY3htaq2GN/0FHarmochPtD0YW5/2ffeRINToxApCK3IGoftrhjJUrHhh36l2IkLBe+tnVtUcBVCQzhvfjCjPeTN0HVPRrWAeyOwidmhPCjLFXwDZ3jV9unO0p4YpicSDPnoOMB9nJk3jlRTmFTfxda673S2gthyXJrpofuXH/4b3vhUHZGVAU5d79ZHNI0mazxKyJHHinWAewJu/q8quezHBMcpej1spw67VDe2TipkPwb5zelBEWoDmyKJTlnv1n0etmKlEZHSmU3B42UNPVMvV/fblCFtf7n738MUCiXlsErBmIIhTq64g5l6KuLhGVFpVRxD8G9RYCP7X8sNy5/AiksTtqzX5Q9/9kRYJcDW0aMIgz/JyVSnDrtUGDvw39T2g14J+ujyo0M+j4UcZU2K9lbKXO0DuLEye/gwPQkNma7iSl3WFOY2lsObKl7VCH5d+Kkg3hH42QE9mq0LjW0R1Yu5E9vPsfijlVs6u8cZCqrujaSdGJ71YhTRHC0Q3eun9m//Gd0tJJQYFJDE0dNPpCPHHw8H53xHmLa2SsnEGoXhKZYguMmHcjvVi9kYjw2tluOFbAOwDJiNIp84HPS5HegYK90/1Em/pFVC/m3x+/g6XWvYgIftIMzpD6fdGJlKdspQqezZPOqooOJruPhN5/nuhfu5t3TZvCvJ3+GTx5xcrGuP5J3jqZG759yMO2rXqya1FFlcwBV4OEslST8jI+bdMBevUo0uv7gr7/lWwtuCcVX8RRKKUS2b4lVzhbcCkjFEkP+LVzHIQiLN6/iwru+yz++by7fP/0yBDOiBUTRT7974gHElRNew55cR/RztimopdoIChLpmRP2BUY2Nkar+r739Hy+9eANNDdORqnw30cribS9QxlIXqdiSXS8gR88+Qsyfp7rPnIFgQm2i0p2R5QbOax5GpMSKTKBh0P5JcjDxZYBLSMk7Io7KZHiwNQkINREDYdoVd8Db73IdxbcQkvj5LClWpkX5+wNRkxxAdH1z/6OWxc9gFPICQyHaMqyT7KJfRtayAfBztu/7QitK+IrKuIAxChdlMLaoy4PpcLlt1MSjUyKp4DhRwBRDuGfHr25mISrhBinHAQSkEyk+M5jt7M10xPuFjTMc42axE5PtuCZoNA4dM/uN4FUpJ9aeR3AkpkCoIzqFC+gIJCXMX9a7VH2Q4nCC4Sp8SZ0Ya4+HHwT1tnvW/Esi95+g8ZC56BqxYjQ4CbY0LWRny9+GGDY5xu1KZne0ExgJOz0vttDKQIDyDYAOpYO70bvhopEACrpdBMEgKgxf1LtUbHDYGiMxaHwL8Mhmv3+bvlTw/zNscOIQbsx7iksIBrpcufmWAIhWhm4m0MZhTEopKsMl7AdFXEAQc7JgGTDOc5wHw1LLaAIDWKfhmZgYHTbUxztICIs6ViJ48TKuJFG5TAIcSfG61vX0ZXrG1HkA7BPspk9FAGFPVUCg7hO77DfaA8orwOYN08A4l52q0AXjrb2b9mOyGi68/10ZLqJaacmHpNIPNSZ66OjLxyQK37eWivxfD8I1CagOM0u28uX88WirObGz1/VJwGbC3vXy1ivV7dHZY+RIiJVm/TbFTvSJgz/NfbgMFJIo7HN8ZNbgeIgWy7KPQUQWls1gNJqfRgB1OimdpY9YiSKtqgk1pxIMamhKUwIlve0KoJS4cKn5kSKyYWpz4iuf89/UJSjEaFj68Vt3YWTGME77pxK5AAiUfXrYWE4XElvj/o6ws0+hI5cDzD8EmDUWv3ISQeE3X2qaInszlAo8oHHwROmM6mhCREZkSR5U7ZnzwqAguBqlOItAObMcQr/Z9kovwOYHX4RkWVlf21LVaHR9HhZYPgjYRT6n3/o+wh75VW/A3CUxvh5zj7kRGD4ZcCIrsI92z0ihInG0JaumFn2m1R+KXChTimBWoIXAOjy+ixLNSCEG6BuzvYhDH8VoKMdBOETh3+AGZMPZE13B0l371b4VRKFIhd4TExP4NJjzgSGXwaM5MAbM904hd6Au7UNATHqlRGc8h6eU7kpZCnzjvOqyXoZ0VoLA9dqj/o4jITNUjuyvXTmCy21huHpFWCMkI4n+Y9TP0/ey+Coym8bPlJijkt/pptvvf9T7N80pTCFGabysVA23JDpxtUOht1p5JQj2TyizWIAZpe/LUD5HUBbmwAq85n/Wi+Y5SrmwF7lii3VSDg91WzO9bC2b1v4b8P8lKNNOS6aOZuvv3cO23o6cLVTVfkApRRxx2VrdwcXHn0G//i+OQTGDHv0j5xjR66H9f2dYelzVzdMRHC1Ej/YmG5sWRr+47yy21ElkoBCa6sDoLR6GtchnOSN9Zhlj3IfrlL0eTmWdr0NDF8MBKB12DPvqjP+lq994CI6+7vI+nlc7eDosB2YGnKUm2j5b3RopcJt3rWDF/hs7d3Kp991Fred9w8M7Cc4PKKpzevdHWzJ9hIrNjXd2YEJB09e3PCxtn5aWzWq/BW1yqwGnB1+Mb55vNhOd+yfV3tU4BAjvLRldfiBj+DxVER99xRXf/jvuOOCb3JQ8zQ6+7voyvTS7+XwAn/QUW4r8Mzg18/4ebpyvXT2dzG5oYmrz/pf/OqCb5KOJcPmzyNwQtE5v7x1LTm/sKfBLu+tCFqjkMcBmF0ZW61MP4AF4VzFcZ0npT+XQ+tEId6pntjOstcIEHMcntu8EmDEm2yGu6iFkcDFR5/BJw7/AHcte5I/rXiO17asZWu2Z5DRd+f6w6ade3n+4dsqJjc0DzLqlkSKQyfsx0cOPp45R53K1FQLJkzIjzgCiWKGpzveDKc4u/diDjmPAPUIUPZFQAPnVSlaWzVtbabll994TCXjp0omH6Co3iyPZdiELbWEBjfGS+d/m/1SE9jbDUGH9t4LxNBT6NsfMftX/8ySjlWkYokRVw2UUniBz+SGZv5y8VW0JNLhGKUUjfEkMT0wNu5tU9Bo5MsEHsff839Z1beVpHZ3MWUSo2IxLXlvRVe8ZSZz2/KMbHPx3VK5hiBRyCLyR1yNFQTV3yEIMa3pyHTz5KY3ENjrRpeOCufGgQmKhjch2TjoCH+mPEQRwIRkIxMbmpiYbCSm3WIjEJG93+YsWuj00pbVvNnTQdJxMLtaDShiSDiAeoC5bXlaWyu20WblHEBhGhBI8AfpywagHGxvgLo7ojXtd69aVNgcqRzNOhWOdoqGHq0ZKB57/Q6D8YyPiGCMKb6+LiQBy5F0jM733tWLyAf53c//QZMPEB38HoBZlQn/wzeqFG1thtZW3XvxtUvFN8+oZBykYu3NLWNEIIZ0LMlDG15jQ6YLp9ADplxESbfSoxLWMOg9yvi6ArhKkwk87l6ziKSbIDC7uoIw/DfZ/FvdPdkFgGJue8XsptI9AcOFQY66I8wQVcyRWcYIARLaYVN/J79b+RKw99OAnb5X4XUnJ5swYvYq2ojaf7ckUjRFLc0qUGKM5MIPrX+VZV0bSDnxXTtIwZBwUVrdyVdu8gol9RqMAADmzSs0M062S392G67jIGJVgXV0QNgdOO7Gue2Np/FMgFOh3HJkTEdNPhAJ/L0yWIUiCDwOnbh/qMqrUEOSSP7702VPUppz38n9FFHKkf6cb3x9W+FHKxo1V9YBKCXMn+90ffZ720wgvyYZQ5BgzBew26NsRzR3TjtxXti8kj+vW4JSCr8CBhWN+OfMeA9qLxOBSmnEBHz0kBOA8u41EBHtL/jSljU8uH4pTbFkMbG44/tpAtUQR/zgzz2X/HA5c+Y4tLXVsAMAWLJEAES4TvrzYTKQyoU0lrEizJb/YPGDQGW2CHd02In3jHcex7HTD6UvnxlRhl4pRdbPsV/LPsw98tTwtfcy07/T9wJ+sPgBcr63+8hI0BijlOJHAMyZU5FzKqXyDqCtzTB/jtN7yY9fJQj+oFIJhdRAAzjLsAhEaIo18PiG5fx+1UJ0QdhTbsK+fC5tp3wO38+PaBoQ0w7ZbC/ffv9FTGpoIih0KC4nUQnzuc0r+d3Kl2iOp3YdFQkBybgy/bkXu96Y+CitrZq5cyu0H9AAo7oxiFL6u+T9vVOKWKoWKRjnv714D/1+qF0pd9HOUZpADBcc9n7+6QMX0dmzmZh292gBkSJa2LOZTx97Fl894fzi5iSV4tsv/A+eCfbg/ASltRL4Lm1thlmzRsVGRscBzG0PmD/H6br46heDrHevSiU1RoIxz2DZo6xHYIS0m2DxljX8cPFDOErtpuQ1MqLo4vuzv8gV753Dtv5t5AM/XECk9KBSXrTWwC3s5rO1dysXHnMGN5/zdYxIRaYqfmH0//kbz/DQ2qU0xxvwzS7WwxkJSMa16cu+2Pv5a+4ZrdEfRjMCaAdASSL4tsnlfdGoSNZh/9THHxA8E9CUSPG9RX9i0dZ1uFqXfSoQGbUA15/1VW469x+YnGyis7+T7nw/XuAX19p7xqc3n6Gzv4ukE+P/nvFl2j/xr6Riib3S9u+MaPefDf1d/Mtzd5GKJQpbne36zhHuAPBNlBJmLR21CHl0Q/H58x3mzg2abr3yBtWSulx6Mj5K2Q1K6wxHaXq9LMdNPpDHz/0nYoU1/pWY+ZlCb8HN/V38YvEj3Lvir7y+dR2duT4QoTmR4uCW6XzkkBP4/NEf5h0t08IsvCqParEUIdzU1NWajz10A/euXsjEeHo3c38JVDrpmN7sfb2XXnsu8+c4zG0fldEfRtsBFDoGNx2yeSLafRVXTQ7bhlUoBWsZM1ztsC3TzRWzPsT17/8Mvglwh7mj7p4ydLFOZ7aXzZlujAiTG5qKHXx39LPlxC8Y//cW3c+3nv0tEwsdj3eBoJVBax8Jjun57DVv0NqqKl36K2X0k3FRFHDblZ9XjQ23S1/WBxsF1COO0nTmernplM/zt0ecgmcCYhVyAiJSNO6hYX04MgdopSvWbSgy/vvWLOaCB68nHUuw23ULIr5qanBNd6a19wvXfne0R38Yq/X5hQttvPXKB3Rj8kzpzQVo5bDr22WpGcKVq6pQBcj6Hvee9b84a/+ZFXUCEaWGN9IGHsPBF4OrNC9vXcvsP/6AvPGLKwp3vIpXgUhAMuaQ85b0HDTp3XQsFea0Gyqz1GGnjE3ovWSmIKL8ZHCZyXldEtdKMKYKEtn2KMsRGqAh7JvvOg4XPXIjT258g5h28ExlB7morVfUTqySRMa/rOttPvbgdfT7eWLaJRAz6F4MOkREtEICEwSiLuH0Nj888dE1fhgrB9DWZmifq7Of/u814nuXq3hMU2HNs2VsMCLEtUsm8Dn/gWtHzQmMBr4Jisb/kfuvZn1fJw1ufA+qHhKoxoRDzvtO/6XXvEBrqzvaoX/E2ApyWltd2tr89K1X3qCbU5dLd7+PVu7o+0FLpXGUJht4NDgx5p/xFc7c/6hCvbwy1YFKEyU1X9qyho8/eD3r+jsLWv9dGH+4UZavGpOu6cv9se/Sa88r2EDAGM1/x/bOC4r2+RqWOOnM1id0Mn6S9EX5AEu94ShN3vgExnDDBz/DZUecDIRRQjW1At8V0aIhrRT3rl7EJQtuodfPk9qTkV8IVMJ1JDBvKeO/p+fNKdsARjPrP5SxLb8phCVLhLlt+SDwL5S8v5GE4yC7kk3Zo1aPQMIEYNxx+NLjt/H1p39DviCT9WUkTcVHF7+wGYhWiv+z8I/8zYM3kDUeKTdGINEgvrPDGFylREzGeP6FPZdcv4VZS0e15LcjqsPtFqoCyZu/+n6nwX0YYxIEBqsPqE9CJZ+iO9vDB/Y9gptOvphZE/cDKlunHymBGHRh74DVvVu58qlfce/KF2lKNgJ7sJRYRHB0oGKuSyb7yd4v/vfvounvKJz+LqkOBwDFfEDDLZf/jU4m7sILAgITFm6rfWiwjAhXO3Tl+2mJJfnOcefytaM/TFw7mIJAfKwdwdDzuGXZX/jX53/Phv5OWhKN+BLsycxdUAQqlXClJ/O1vstuuIZHW91i5n+MqR4HAEQ3Jn3zVy8iHf81OT/AmO2VHZa6wVEa3wT05/s5cZ8ZzDv+fM496FigEDgXwu7RShRG7xlFKQBPvv0G8164h4fXLSHhJkk67p41PJGC8TcmXenO/mPfZdddxY1fjvGVm7zKXsWeU32GFTmBn3316yqd+JFk8wYR7HSgflGEzT568lkE4ewDjubvjzmTM/Y/qvgzUYKtEs5AkMJoHzbwjHhm05tcvfghfr/yJfJBQEu8gUBKlu/s8kVF0CpQ6aQrPZn/6vvi9f9cLWF/KdXnAIDIS6Zv+epnSLi/xA8odG2wTqCOCTfcFHryGbTSnDL9ML5wxAc5/6B3MSmRLv6cERnYqYfhdfIVAJFwtaCAUoO7AfX5Oe5fs4Rblj3JQ+uXkvc9GhMpNMNocBIav6hUQktf/h/7vnDdVWNd7tsZ1ekAYEAj8LMr5koydrsykpS8H5YIq+oWWspN1Pqr18uCMRzUNIVzDzqGj73z3bx36iFMTKS2+x0jJUtrhz4fiuKeBTsqN/Z6OV7cvIp7Vr3MPatf5vXOcLPTdLyh0NNgDysUCjAEylUOrgvZfDjnr8KRP6J6HQAUI4HkzVecqhKx+drR+0gmZ5cQjxPCTUMhG3h4fg6Uw0GNkzhuykF8YJ9DOX7KQRwxYTrTG5r3eH1BIIZNmR6Wd21k4ZY1PL1xBc9vXslb3ZsxgY/rxmlw48WfHRYiPomYC9InOf/SzGU3/LaaEn47orodABQjgcTPLj/Eibl3qmT8PdKb9REpz7YtlqpHoXCUwgC5wMMLPDAGHIeJiUb2TbWwX6qFfVMtNMeS7JuaMOj3N2W76c5nebu/i/X9Xazv72RLthcJfFAK142RdGJopYrTi2EhCEiY7Mv5KySfvSjzpZuer3bjh1pwAFDUCXDVnIaGKdOv1Qn3Msl64RpPZVWD4wmlQKNRKgz7fROQNwHGBCCGXc8BNFo7xAqHVgoRCvmAEc4rxRiUVqoxqSTr3a239fxt79du7ajmsL+U2nAAUNxtGCB16+WX4bg/Uq7TJJmcDzgV2zPKUn2owd/uaSJQoKQJXeEfRrLnbvg74aifiLkiePjm3/q/cN33AMZiXf9IqR0HAKGkon2OZm570HTD3x3hp9yfqGRsNhkP8YNA2TUEllFARAKltUMqgeTyC8n5l2e+/JNnaG3VzJsnKFUzQ1FtOYCI1tNc2h7zARpuu/JKFG0qEZskvVkBZVBYR2ApP4X9LFQqocUP+gnMf2VeXPH/uPb+XK2E/EOpTQcAlHrb5C2XH6i08+8odYmKOUgmZxAl1hFYyoKIASUkY44CTBDc4+TMt/u+fMOS8P9v1aixXdQzUmrXAUSURAPJW6/8oFK04ugzlVZIJi8IBkUoJ67A/m+WOkSpKFlgUKJIxDVaIX7wjMb8e/8lN9wHUK3inuFQ+w4AQETRPldHiZfELV89U2v5J5Q+M4wIPDDGR6GtpNiya8SEhq9c1RBHjCBB8IwSfpD5wvV3AcXu1mO9lLcc1IcDiJBWzTyKH0zyZ1ecrBz1dxg+QUMshRdAzhMgsM7AMoAYwpZ0mpiribuQ9TxB/Um03JC75Po/F3+0hjL8e0J9OYCI+XMclsyUyBEk7rjyYGXkIoSL0OpYFY8hng95HxAfUQolyjqEcUK4M4hBiSA4xF2l4i7iG/D95YK+yyjzS+/Swhwf6s7wI+rTAUTMnxMmAaMPTlDJW688WWm5QIycCepYlYyFz4MXhIcQoKJlIhKWmcPbVIut68YnUvJ3uORHKCaAlIOrFTEX5Sgk54Mxy1HqYdHcnWuY8ihz2/JAGOrPWqrq0fAjxscjHc7Z9KAyjaBSt13xLjFqtiCnCHKCEt6hGuKgVNiVLCgcRsKDQjbYSo6qE6HgtIt9wcHR4GiU1iCC5DzEyAYFC3HU4wpnQSY96cWi0UOY3ANTD3P83TE+HMAAivlzNEtmqu1qtre2JtNq0+GB0UeLCd6lUIeBzBDYRwkTcHQC1wnjAUfXcN63TlEgQWGgDwLwjSfQqbTaiMhbImoFrnrZUfJKv59bzpdu6Rn0+62tLrOWCnPbw508xwnjzQGUomhtVYAufPA7DvNu/qemJH2TdMyZFIg/QbygUSl3shIjIjKe71/VoJQSUVpppNNop1sT9BjX2ZzL5LfylZu6dvhLUVQ4Do2+FPsADzDgEIBdOgVLbREmhcNnfR4G2uw0roB1ALtDUMxrVcwD2gv7tkcPk6W6mLV0wKiXzBTmWUO3WCwWi8VisVgsFovFYrFYLBaLxWKxWCwWi8VisVgsFovFYrFYLBaLxWKxWCwWi8VisVgsFovFYrFYLBaLxWKxWCxVzf8P1IVpoucJqnoAAAAASUVORK5CYIJpYzA5AACDHolQTkcNChoKAAAADUlIRFIAAAIAAAACAAgGAAAA9HjU+gAAgt1JREFUeJzt3XecHNWVN/zfubeq40RpJAESOYscjY1tSdhgbIwjI2djsA2Ou34ee9fPrnd30LvBu84kkYPXWeNsY8AECYyICoBQJgnlOLlTVd3z/lFVPT09ozwz3dV9vv60kUajmdZ0dZ1z7z33XEAIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghRFWjSj8BUUOYCQDaOzsV2gc/vG3BJMLMCj0nISJqMrZz8TedQGd7u/F/QwCBd/PXhNhnkgCIfVcS4LdNWk6YOROTsZ2nYznPwRyWm5IQ46ODO9SKzlNoW/skwgJg8sztPP265TznuusYRPI+FPtEEgAxMmYqDfQzMdPMITJ7+isfX/fn1gGznb1+6/hYQ7LBzeUAAMR8BuxYC+cdJiK55oTYDSJmJiIGHOOa55RFDpMi8oyryFueOmyicf6a6e2cPdvb3dfo6OhQC2bOVAAweft27mxvN5IUiJHIzVj4mKkdnWrbgkk0c+bIwb79jXlJWGjIdxVOhlLHWXHrcC9XOJIs+yjjOmlF6gRmZrJ0q47bYMMgAsiyQEoBMkEgxD4gAAxTcOG/ZwhsDNxsvkdZljGuu0VZegu7phsx60U4hW6dTL7gufrlWM+23s5zr+0p/4od3KEWLICaPPMUf6Zgzpw9JvOiPkgCUK/CEX77JJqJBWYODb0hvHfjH1N2LnMKsTqFiY71cvnzoehkImrSMbtZ2RZIa7DxwB4DbODlHYAI7HjM4GK0J4KR2C/E/mECgcN7NEFZWgGM8L1HRCBLg40Bex6cgVyWmAeUpZezUkvZ8dYReKlt7GWdp87eVfblacb8Dj155incCZkhqFeSANSTYJQPAJ00dAqx/aV5E1zLPdMwvx3AW5hxko5Zh+tEHKQIxvVgCg7YMzCuMUFBAIMIDL82gBgKACDT/EKMPvaTagYxggS7+B5kVkprRYqg4jaUZYGDWQQ3m9tFWi8jhaVE+nGLsLjz2NlvlH7pDma1YMF1auYCGJkdqB9yo651zDRjwXV65szrhkzrv3fjH1NWJncG2FwCz3sbg8/SifgEHbdhXANTcGDyDjPYEIgZTETkj0hocFQSTlEKIcZb+N7j8Ld+gkAwFHyQGUrZWul4DMrSMJ6Bl8lmWNFLitRTHsyjynEW/n76lTtLvizNWDBfz5w5fGZQ1Ba5c9ciBrVj3rCR/gdW/HaiodyFWuODDLqIiI6w0gkYx4OXK8C4riHAMEAEIlAwohdCRBczM/ykgAFSWmkVj0HHbJiCA7fg7CSihYrxO23pR0tnB8KZgcdmXufJMkHtkQSghnRwh1qBU6g06F/+ys+nWKzeA4P3G2PeasXtiWRZ8LJ5mILDADw/4EPJ1L0QdYDBTGzIL9RRyrKUlYwBRHAHshkQPU9a/44898+/PekTq8K/1s7z9HS08952A4nokBt+9FH7vHlqevvgG/PSNX+JJ6jnUhi8H8B77HRyivE8eNlglO9/ngoeQoh6FswQAIDSSut4DCpuw+nN5EmrB6DUH9yM+5c/nf7xrcHnUzs6lRQPRp8kAFEVvglLRvsfWvWzk1hbHwX4I8q2TyKt4GZyMI7jwV+4l1G+EGL3SmYHoJRlpRNQWsEZyG0jxh+Mxr1/OP5jT4af3s7ztCQC0SXBIGrKAn/7vHnaPQcXsWe+wp73LrsxHfdyebjZgiFFBsxagr4QYr8xmMEGYGjb1jqVgJfLgxlPsWfuBFKdfzz5A31AuDywnKVoMFokMERFUM3/2Kw5LgBc+vRPmmLN+gql6Wuk9WnKtuD0Z8HG8wBFJAV8QojRMlhIqKx0kqAIXsHZAMN3KXLv/N0Jn9oASCIQNZIAVLuywP/Bl38z2XDhSzD0WZ2wp7Hrwc3kGQRDRArymgohxhCDPTCgY7bWyTi8TL6Xwb9xPecH903/9EuAJAJRIcGielE7zytO9V/+4s+nqCR9kZi+YKUSU9xMDl7B8QCS0b4QYvwxM4ON0lpbDSm42VwBjJ+5Hv3gvukfLSYCUiNQvSQBqELtPE/vLvA7/Vmw67oAZG1fCFF5QSJApLTdlIabzRbA9LPSGYEZ8zusx2bN8SAHglQVCSBVpIM71BwAoDmmfd68WOEM91oi9S9WMjbZGciBHQn8QoiqxcymmAh4+XwBHm4jy/mP3x336W2AX7S8p5MMxfiSQFINyir737f6lx9Vir6lY9apXjYPI4FfCBEdg4lAYwpurrCNDN9oe9Z3Ok+dXehgVrjuOsiZA5UnAaXCSjPiy57/31OtpPUdHYu9mz0Pbjbvyd59IUREMbMxyra1lU7AzeReIqZ//P1JH7sfKC4LuJV+kvVMAkulMNMMLNCP0Sz3nYtua043N30Dhv9Rx2Mxpy9jACCo6hdCiOhiZmY2VjKhyVIwjvtLuOj4/fSPrelgVgAg7YUrQxKACigd9b9/5c/eBUU32A2pEwpdfWBmj4h0pZ+jEEKMJmY2YCDWklZe3ulh1/zrH07++I3A0MJnMX4kARhPzDRjwQL92KxZ7vsW33kYpVP/QUpdRURwc3k3CPzymgghapYxxtOWpa10Al7BecQUCt/64ymffqaDO4LZAKkNGC8SbMZJB7MKp7nev+xn70Jc3W2lEoflu/oNwDLdL4SoH8HWQbshrY3ruvDMP/zhpI//CJDagPEkCcA4mDF/vvXYrFnu+564sxGT0/+plPoqewam4Lggsir9/IQQohLCJU+/f0D+Qae77+/uf9M1a4J7pvQNGGOSAIylku19733hJ2frtH2nlUycld/VZ8BMpKS6XwhR5xgMsGc3pS2v4Ow0BedLfzrlU/NAhA7zb0qWBMaOBKAx0sEdxQv3/St+8jmK2T8AqUZ3IOuSIsv/0TPkJRBC1K9wgE9gYzwVs7SOx+Dl8j/a+Pjj/7j42tsdKRAcOxJ9xkC4hnXpX65vih036ftWPPY5dyAL4xmp8BdCiN1gwwwFE29p1O5AbqE7kLvqvrOvXhsuo1b6+dUaSQBGWTuz7iTyLlty9/G6IfFTO508P7+rxyOQNPQRQoh9wexajSnLyxd2eQX34/edduWDHcxqjl8xLXUBo0Qqz0dR+7x5fvB//sfv0un409qyzi/s6nWJlLTxFUKIfUVkOX0DHhgT7FTigctX/ORrxWZBwXZBcfAkKI2GkmK/96/8ybUqEb/VyxVgXE+m/IUQ4gCFSwKJCc0639N3R++Wl7/02Kw5rhwqNDokAThY3KEQFPtdvuKnt9oNyWudvgGPDYhIZliEEOKghLsEmhssL5tb6G7rufy+t32pS4oDD54kAAchbO7zvifubKQp6R9ZyfjV+a4+OcBHCCFGG7NrtzRYXib/nDvQ84n7zv7iWkkCDo4EqQMUTkFd9uLcVm03P2g1ps4r7OqVxj5CCDEWCGDPeHZDShvP21Xoz176wNlXPzeD51uPkewQOBCSAByAMOu87G9zW3Vb84M6FT+v0DPgEJFd6ecmhBC1jI3xdCKuAXQVBrLveuDsq587Z9Ft9uJzr3Uq/dyiRhKA/RQG/0uevGNCojX1gE7Fz3O6+10oJSN/IYQYB8zG03E/CfAy/Zfed9bnn5WZgP0nCcB+CIP/pUtuOy/W0PQzpdXxTn/GI6Wk0l8IIcYRGzY6biuyVJ/bn/3afWdefbc0DNo/kgDsozD4v3vxnefajem/kqZWtz8rwV8IISqEmY2ytNLJOJzugWvuO+uqO2QmYN9JArAPwmr/y16c26qtpsUUt472+nMulBT8CSFEJTGzIa2hLE35/syFD57zuackCdg3sk99L4rB/29+tT/F7aPd/qwnwV8IISqPiBR7HtgYjjem/nzpkrvPe4xmuTPmz5d79F7IDMCeBE1+wq1+OhU7r9DdL9P+QghRZdiw0YmYAlFXob/3XQ+cfe1z0idgzyQB2B1m6gBo8eLbE5RML7DS8fMKPf0uKWVBjqIQQojq4vcJMDoRV0TUVejLzrj/3KuXSRKwe7IEMBJmmoEFeg6RQSw5125MBfv8JfgLIURVYoCUUl4u75GlWq1k/GeXvTi3tZNme3KA0MhkBmAExUY/L/z41viExmvzu3pdkg5/QggRCcYYL9aU1l628BxnB2b++ZxrsgAgRwkPJUGtzIz5861OmuW+Z+nd19rN6WvzXX0uiCy5aoQQIhpIKV3oHXDjE5vPy3vuXBB9ZgbPtx4DZGdACZkWKRE2kbhsyV3vtJsabnX6My6YpeBPCCEihpSy8rt6ncTElivfvfSe6x6jWe45i26Tdu0lZAkgEG73u/z5249GouE5NqbVOC6ISJIkIYSIKkWOlYjb+d7+9gfO/uyvpUfAIEkAAICZ2tGpul/IJeI2LdDx2LlOf8aQUhL8hRAiygwzxW1WSvU4ueyM+8+4elk44Kv0U6s0CXAAZmCB7qTZng3vRrspfa7Tn3El+AshRA1QRCZfYLJUq9b2zy5+/n/TK9BJYK77AXDdB7kZ8/3poHcvveuqWEvjVYVdvbLXXwghaoW/PVA7fRnXakydZsO7sZNmezOwoO7ru+o6AwqngS5dfMfpsXTDk8ZzE+x4CkR1/XMRQoga5dpNaSvf3XP1/Wd99p56bxJUv4EuWPfPr+pNGTe+UCXs09z+rKz7CyFErWJmsrUhbeVQyL/lT6d/5sV6rgeo22AXrvt7Of3fdnP6NLc/K+v+QghRy4jIOC6UpdKG6cfnLLrNrud6gLoMeO08Tz9Gs9x3L7n7Yp1OfqnQ3eev+wshhKhpREq7fVk31tJw5iE69q1Omu3NWFCf9QD1l/Vwh+oA8NzyoyYTrOeVUpNNwWHIfn8hhKgbTPCseEx5+cIl951+5cP1WA9Qd6PeGZip5tAs9z1L7/nv2ITklMKuPheKLEjZvxBC1A+PCQCB+eZzFt12KjphwEz1dF5AXY16w6n/975wzzusVOJT+e4+zw/+Qggh6gkpUm4m69lN6RMma+tbnbNne+11FhPrZwmAmToAeuaZnzZYKV6iYtaxbjZvSJECo55+EkIIIRgAmKGVUZZtuJC74M9nXL2knnYF1M3otx1Qc4i89yy+55t2c9OxhV09LlFJw5+6mfQRQgjhI2LXg0ombCenftTBHTNXoLNuhoN1Md3Rwaw6AfOuZ+88USXtbxR6+j2QqsuqTyGEEIOIlHZ6B7xYS/pti5Ye+alOmu2118kpsHWRAKzo7CQQsY7pG3TMjrFnAJn0F0IIAYCUIncgx2Rb/33Ziz9rnX7ddVwPvQFqPgFo53m6c/Zs77Kl97TbDalLnP6MR0R1kd0JIYTYJ8o4jrEaUoewm//3OXPmmHZ01nx8rO0MJyj8W7DgOpWecPQKKx47zs3mmWTPvxBCiKEYRKxsbUyuMP2+s69eW+sFgTUdCNvRqeYQmcaWo66NNaSOd7M5I8FfCCHECIiNxzoWs0D0nwBQ6wWBtfuPC9ZvPrDyfyc4HtYSqRbjOADJUX9CCCGGCneDM+BZ6aT2+rOz7jvrqgXt8/xl5Eo/v7FQs6PhdnQqEHE+637Vaki1GsfxwmN+WR7ykIc85CGPkgfCX7P//4ZNBwBMb18e/nHNqc3BcMnov+DwalJqAjsuIIN/IYQQe8EMY6XiymTzNT0LUJMzAKWj/1hTeqIpOEaCvxBCiH3DTErBmNqeBai9oMhMAOEDz/54QiEho38hhBD7rx5mAWpuBsAf/YPzMfPVWKOM/oUQQhyIYBaAuaODO1QtzgLUVmAMRv8X//W7KWty2yvKtiZzwZHRvxBCiP3GDGMlY8p13PPuP/3KRbU2C1BTMwDh6D82aeIVdkNyioz+hRBCHDjDyrYA1/syAKC9wk9nlNVUcGRmmrngOp1qPmKZlUqe5Gak8Y8QQogDxiACKeUAzsn3nf7ZV9HRoTBnTk10B6yZ4Ng+b54mIm5sOmqGlUyc6GbyEvyFEEIcDGLPM1Y6ETMeXQkA7dedUjMDZ6vST2DUBFMzHnv/N2ZpAnumhvIbIYQQFUCAcjM5gHFt+/ybvtuJ2QNgJhBFviiwNhKAjg7VSbO9SxfdeyzFaFahP8sgpSL/6gghhKgsIjIFx7Mb01MGwJeD8IsZ8xdYjwFupZ/awaqJIfKMmf6/g8j7lJVOJmGMhxqrbxBCCFEhBH9LAOPzADBz5oKaqAGohSBJYKD9qXmJ/kTfMhWPH2PyBUaNJDdCCCGqApNtedo1Z/7prM8sB7NCxI8KjnyQbOd5CgQMJAcustKpY71sXoK/EEKI0cXsWamE5Rj3KgCYgQWRjzOR/wcE2BhzBWkFUoh0RiaEEKIKESkvVwBA750xv8N6DLMi3xAo2gkAM3XSbO/SJXdNIq0uCyo1daWflhBCiJqjvFzB6GTi+FTjkW8HgdvnzYt0vIl0AjBjwQINAIrUZXZjapIpOJ50/hNCCDEWiNjomKUY/BkAke8MGOkEYObMmQbMxMa0s2sYSmK/EEKIMcLQbjYP0vTO9kW3NXfSbM8/gyaaotsHgJnmEJnL/ja31UvH3+zl80TMqib2NQghhKg+BDIFx1ipxKGZHJ0FYEF7Z6fqBCJZDxDZGYB2dPrPPZ14s5WMtxjHk4N/hBBCjCkiNsrW8Dzv3QCwrX1SZONOZBOAkGfMR8i2CMRGOv9VFu/m10IIUSsYUF7BARN94NK/XB+P8m6AaC4BMFMnkffeP96WchS908vl/ep/ksBTaQaABoEAGHk1hBA1h5SbLbCO28d5UxtPAWFJ+7x5unP27MglApGcAWjv9Kf/nan6DBW3p3gFmf6vFpoIGVNA1jjQpIJUQAghageBPZ2IKRjzDgDYNimaywCRTADCNRdmvNtKxDWxkeY/FaaIkPEcnJKego5jLsbRyQnodrNw2QsSASGEqA1MIPY8wMNlACiqZwNEMgGYiQUGACmiC9l1wTLMrBqaCDNbj8GtJ38QX5x2AZqsBLqdLFw20BTJy00IIYYghvLyDkjTqZc8eUfrHJpjorgdMHo1AMH2v0uevGMCQGd6WQdkIEPMasAAM2CYoUnhE4echcvaTsIft63En7avxOZ8LxqsOCxS8DiSCbMQQgAgMgXPWKn4BIPcGQDmR3E7YOSGZOH6P5J0hk7EWo0r6//VRgUvh8eMFiuJTx92Nu445UP43NTzQQz0OFkAkBkBIURkEdiomE1kaAYQze2AkbsDhz9kMpipYhYRZChZPYZW/WsiMAYTgc9MPQe3Tv8g3j95OsCMHidT/DwhhIgSJhC7LojxdnR0qGBpOlIitwQwEwvMYwAU8wVsXDCxhI9qwPDn/3loEkAYTAQMM45MtuIbR83AFVNOx6+3voCHd65Fr+ug0YoDRDAsWweFENWPmJWXL4CJT7v03RMa5tDf94KZQBSZm1i0ZgCYaQ7NMTPm39TAwMkm74Ig8b867PmaH0wEGIYZRyVb8Y2jZuJHJ70fFzQfgaznoN/JQwFS0CGEqH5EZByPdcxuManU8QDQgWjdvCKVAIQ/3GRr4niKx6Z6BZcRsX9DTdqPUTuBoEoSgZPSk/GdE9+L7574XlzQcgQynoOMVwiaCUXqvSSEqDME9nQybpGLCwFgARZEKh5FaglgwYIFCoAxHs6yU7by8gUPoEifxxx5QfDn4LGv/ZgpmLsxYBCAc5qm4ZymaVjcuwH3bFyEJb0bkFA2ktr2v650FRRCVBsC2BjA4BwAmIztkbpRRSoBwMzgv2xOJKWk8281Gb78v0/C6X7DDJCfCJzZOBUP7VyDX299Eav6tyGmLaR0DB5LGiCEqB6MoCEQ6Dh0dKjpWB6pW1SkEoCwAJBYnc6uC0aUyi1qEJf9khkHmpOFWwf9HgKES9tOxDsnHo+Hd67FLzc/j9UD29FgxRFTGgYAS7GgEKLC/IZAHgAcF8VCwOisV5QUAIJwihQAVoMRrvGDvOxLewhYpHBp24m4efoH8YXDL0CzTqC7kIXrebJ1UAhReURkHJdV3J7gUvoEIFqFgNFJAAKxmEoxUTN7BlFsvVgzSkf/IwX9g0wEdEkikNYxXDn1XNxx6hW45vAL0Gwl0OPkgGC2QAghKohJa4uIJgHAis7OyNyUIpMAhB0AVSJ2rI7bDcZj6QBYUSON/kd/1qu0mVCrncSVU8/BnadegY8eeiaY2e8qGLQeFkKI8UbERtkWiLzTgWidDBipGgAAIOBkZWnlIedFaKalBpUH+2D9fwwaM5Y3E2qxk/jKEW/BeyedhM4tL+KRnWvR4wyg0UqASMFIc0ghxDhhMLHxQETTAWDy9ujsBIjMsCnMqtjwEWRpBPFAVFhx0D8Or0Z5InBUcgL+4eiZuPWUD+P9k09F3nPR72T9ZkIyOSSEGC/GgGGOAIDp7dHZCRCZBKCYVREfwZ4HluF/FeHB/4xTIqCGdBX0E4Hvn3Q5Lmg5UroKCiHGDxOxawDQ5PYnv5+8DtdxVOrTIrMEMJhV0TEwMsUrBpsJMRjMwFlNU3FW01Qs7t2AX21+Hs/1rAcApHRMmgkJIcYEgclzPQA0rZBXcSLKSgIwFuZ3WAXPS9pmTOrNxP4IB/2lg3/mirwuxa6CzCAa7Cr4bM8buO2Np7FqYBtipJG0YtJDQAgxuhjQDHYI9LLyGgF0V/op7atoLAEEPQCmxdG0qdB34q5MPzRUNJ57Hal0XFXknx9gmMFgnN98BG479Qr867EX45jURPQUsnA8F5qUnDMghBgVSinKFPK8BbnGjDInAgCCXWvVLlIzALGBpGdixtteGEAOFtpiaf+GH/STFwIY2lXQIoVLJ52Id7Ydj4d3rMXdG57F+lw30jqOmNYw7C8hCCHE/iD4s4/dThY7CxmQiiGhvEKln9f+iESWgqDgz7LNCSpuNynXcI+bo435XhTYlWYwYkTDugpOOhG3n3YFvnDEm9FsB10FjXQVFELsO/8IWn/guaXQjx2FDACwjlnwXDobAGZMWh6Jm0o0EoCgsxJraiZLWwywRQoF42Jjrhe9br54s5exXKVV3ytQ2lWwxUriyqnn4s5T23HtEReg2Y6juxA2E4rEe1YIUUEWEbJB7Ol38/59g4hBBENqYqWf3/6IRgIQUKS80uNn/XVcxrZ8P7bm+8Hg4j5xIcoN7yp4Lm4/9Qp88JBTAQA9kggIIUYQxhsCYaeTwaZ8Lxz2hsUbYvYq9RwPRMQSAOMNbjYf3HSuCOhzc9iY60HGK8CSigCxG6XNhDw2mGin8Q9Hz8Rtp34YHwgSgV4nJ82EhBBFmggOe9ic78VOJwMK6s64LB4RSBKA0Raup3gunU22xkibzYa/QH7GJrMBYiR+IqCGNRO67dQrcGnbieh38xgImwlJIiBE3VJE6HPz2JjvQcaMPMAkcNAMiM8CgMe2r4hE6IlEAhAypCb6JwAPP2uZuWyKJtcLx3jQoPIJAyGKCFTsKugx46hkK/7luHfihye/H29qOQIZ18GAk4cGDe0qKNeTELWJ/XiiQGBGsMTcBzYMvadBpWEYgl8D0D49EneHSG0DVAZu8ae/hyNoLRBynoONuR5MsJNotpJ+t7jd/T2x/0Z6HSIcFAkEHXYVBHBu8zSc2zwNi3s24BebluLJrnWIK41keVfBiP57hRC7Z4Ew4BWwozCAgvEGi8z38n4nA3ccnt6oiVQCwLRv7RUZAJG/TWNbYQBZ46LNTsMiBU96Bog9oKC0tNhVsHkazmmehge2r0bn5hewqn8bbOV3FWTpISBEzQi39zEYO50MdrkZAPu5BLiPMapaRCoBAPZ/kKmI0OflkTUOJtppNFpxMDMM5DSh0VA6ERDhCYBhSpsJEVGxmdBDO9aic/MLWD2wHQllIaYtaSYkRA1Q5M8c73AyyHnOfm8tj+IdIHIJwIHQIHjM2JrvQ8YrYGIwGyCHw4i9KW8m9O5JJ+LituPxp60r8L8bF2FLvh8pHQu6CkoaIESUMPz4YMDY5WTQ7WRh6mg7eV0kAP4eTn9ZYPhsAKSVsNgrXZYIfPCQUzFr4rH4/dbl+OO2Fdic60XaisFWFjyW0yqFiAKLCNmyUb+qo91jkdoFMBpKZwO25vuKzRyE2Be6ZGmgxU7iM9POxV2n+V0Fk8pGVyEjzYSEqGKla/07Cn5Tn5xx6vI9G7EZAIODXWkenA3wmwdlvAImxFJo0ongz+sl9ztY5eX/5R+rbSqYIjRBV8HPTDsX72w7Hj/btASP7liLnkIGDVYcSmkYmREQouLCwK9AyJgCdjj9yHv+AFDhYO/90ayCit4MwGj8fIOvock/OnZ7vh+b870oGHdwr3f0Xksxzsq7Ck5LNOObx8zCbaddUewq2O9koYI9xUVybQkxfoL3mz/7a7C90I/NuR44ngeLSu73dShaMwAHPwEwiAdnAxQIGbeAnOegxUqixU4WT3uq1wtjr2qsD8DBKO0qyAwclZyAfzxmFmYfcgZufeNpLNz1GhhAgxUDwusKqMuflRDjKRz1E4A+N4+dzgBcY0be13+w70e/QUikRCsBGCOMwWrvXU4GA6aACXYKaTXY9KX+VofE/iIQKGwmxMBRqQn475Peg0U9G/CrTc/jme43AADp8mZCQohRFQ7uLCLkjOvf173CkFk7IQnAMIoIBeNic64XjVYcrXYKMeVv8RJiX5QmAsBgV8FFPRtwz/pnsbhnAxLKRlLbYIJcW0KMMk3+dP+OQhY9bhaGWY6MH4EkACMIb+B9bh4Zz0GLnUCzlYQKagaE2BeEwR0DID8ROKvpMPx1xxp0bvK7CsaUhaRlSzMhIQ5Scbo/uHd3OZliG1850GtkkUoADBBUa44PFbQT3lHIoM8rYKIsC4gDUNpVUJPCuyedhIvbTsBDQSKwsn8bUtqWroJCHAA/8Puj/pxxsTPvL+MSBnfrjNfziNo7N1IJwHgLX8xwWWBTcVkgibiypKWw2C/Duwr6icAvNy3FbzYvw5Z8XzER8GSmSYh9YhHBMQa7nCy6Zbp/v0gCsI9KlwUGvAJarCSarQRspeRmLfZLeVfBT049B5dNno4/bF2OP25djs25XjRYcVhybQmxW+GSbI+bwy4ni4IJ9vTLdP8+i14fgAoLb947nQFsyHWjx8kB2M8To4TA0EQgbCZ09+mz8fkj3gQC0ONkpaugEGUobObjFbAp34Mt+T64XLKnX+yz6M0AMAOGKzbvHo7HLBBcNv60rZvDBDuJpI4Fn1MPo7bddQKsh3/76Aq3JYXtha8+/Hxc1HYc5m16AQ/vWFPsKqhlRkDUqXCdn4iQNw66Cln0eXkQ+0sAlT+am/3YFLH3p8wAHKDSfaZZz8HGfO9gN0HyT5WP1qUgKmloV0H2mwkdOwu3n9aODxxyGhhAr5PzW5nKSEfUifA+62/rY2zPD2BDtgd9bj6o+Jf77MGI3gxAlSltIjTgFpD1HDRYcbTYCSkUFPttMBEYbCb0j8fOwuVTTsGd65/Gou718JiHdxUUooaUDrAcY9DjZNHr5opd/CQJHh2SAIyi8KLsdXLod/NosQcLBY0kAmI/lHcVPLlhMr5/8vuwqGc9frXpeTwbdBVMSVdBUUNKR/yGGT3OYIGfIpIufqNMEoAxEF6kOwsZ9Lo5NFkJSQTEAQkTgbDvxLnNh+Pc5sPxbPcbuPWNJ7Gqfxts0kjpWHBUhtweRfSUB/5eJ4duN4e854KI/HV+SIXRaJMEYAwUCwWDdaswEWi2EmiSREAcgPA0QcMMIuD8liNwdvO0YjOhVf1bEdMWUjoGj1kSAREpIwf+wcGUXM1jQxKAMVRewLKjkEFPyYyAFSQC4ecJsTelXQWtsq6Cv9i4BKsHtqFBJ4KugpIIiOpUPIm1ZKq/pyTwSyOf8RG5BCDK2aAmghsmAk4OTXb0lwbKNwBG9bWJmpG6Cr59wjGYt/mFoJlQD1I6hpiy4MmrIqpE6RHsBn7g73ZyyBsXBH+bX/h5URPB04AjlgD4i5zRvDpQUtmKYGkgn0GvU7o0oGHYRCMR4LL/lv9ajIvSZkJpHcNV087DB6acij9seQl/2PoStuT6pIeAqLhha/xuSeAnQIfbpqN8iUYwNkUrAYh6BhAo3eLiH1k5gB43W5YIVPv0rTQCqiaDzYSM31Xw8PPw/kNOxU83LMIftr6EnkIuSAQ0PI7aOEVEVXhCnz/Vb4YV9xW3vEb+vhHNe1/EEoDawkFlt1WsERgo1gg0WnHElK6CDlciKvwRlhqSCHz16Lfh8imnYN7m5/HQdr+rYKOdgAquOSHGQti5TxHBNQYDbmHIGv9gcZ9cg5UkCUAVGJwR8KdpdxUy6HayfkMhK4G49l8mKRgU+6I0EWDmoJnQRZh96JmYt/l53Ld1JVz20GDFgWBKVojREI74NQGOMeh1suhxc3CMgZKq/qojCUAVKa2MDVu/9rt5pLSNJiuBtI4BJImA2DdhUdXQroIX4Z1tJ+BnG5fg2e51MMxosBIApJmQODCl9y0AyHsuetwcBrwCXGNkH38VkwSgCoVvkjBb7ncLGPAKSOoYGnUcDVYMVjByi0TBoKio0q6ChoGzm6fh7OZpWNS9Hr/ctBRPd62DIpKugmK/lBb2MQMZt4A+L49+txD0qyAZ8Vc5SQCqWPimCTPrjFtAxi2g27XQaMXRoOOIKQUjdQJiH1AwNRs2Ezq35XCc23I4Ht2xFv+7YRFWDwRdBa2YXFNij0r38Pe6efS5eWS9ApgxpGWvXEHVTRKACPFPGQQKxsX2vINulUVax9BsJRBTlt8yVpYHxF6UNhMiAi5qOx5vn3gsHtq+GvM2v4BVfVuR0Dbi2o7AbhQxHkr374MAx3joc/Lod/PIGw8AgkN6oloPX5+ilwDU+dXlvxHJ7yVgGD1eDn1OHklto8GKo0HHilNyY3rj3l0fgDp+baJmWFfBySfj4kkn4qHtq3HXG89ifbYLaR1DTBKBulVazc8MZEwBfW4eA64Dj43ftS8cbnCdv/0j+I+PVAJg4F+MEfw5j7rS5YGwTqDfLSCutJ8IBNsIgbGdFZAOANE3rKvg5JPx5taj8Lsty/DHLcuxKdeDlI4jpi3pIVBHVFA74m/j86f5c8YpTvMrmeYfIoo/i0glAGK48jqBAnvYUcigy8kipW00WnGk9GDRIBf/liwSiKFKuwq22Elcdfj5+MAhp+H3W5bhD1tewuZcLxqthHQVrFEMDoI+gZmRNY4/2vcKcI0HEAVNfaIZ7MRwEUwA5NLbE7+fgP9m7nf9NbpwViBtxRFXGsBo7P2WToC1qryr4FWHn4/Lp5yCu954Bg9tX42eQkbaC9eIoVv4Bpv2lI72S6v5pTR0d8J7X7RmyCKYAIi92d2sQLeTRVLHkNYxpC0bmhQAKRwUw5V3FWyLpfHN4y7C7MPOxLxNz+Oh7avR6+TQaCWKvSlENITvdQpG84YZA24B/V4BmWDvPggy2q8DkgDUAQIFswIozgrYji4uEcSVFSwRSH4vhhpMBPxmQkenJhQTgZ9sWIQHtq0EgZC2YtJVMAKKjcYYKLCLAcevHSqwO8JoXwJ/rZMEoE6Uzwq4bNDj5NDr5hBXFhqsOFLKLm4n5GBWQGYGBDC8mdDRqQn4txMuwXsmn4xfbFyCZ7rXwTDQaMWlmVAVKe/S5xgPWddBv1dA1nOKW0FJRvt1SRKAOlV69nbeuMjlXSgixJUVFA7asINdBJIMiFDYTCicEQibCS3qXo+fb1yMhbteR0xp6SpYQeVB32ODfreAPtcP+uFODiWj/boXrQSgNk4DrjoE8rdXMpD1HGRdB5oUktpGWttIjpQMcJAMjFQLKGpeOCNQ3lXw/q0r8atNz2NV31bYSroKjpfdBf0Bz0HWc+CUNOvRCIJ+ve/bH23RqwGMWAIgxkxxiSDo9FW6i2BYMkDa/5ySmQFRn8q7Cr57ysm4ePKJeGjbavxq0/NYHXQVlGZCoyv8Ke5L0Kdgz3753xVCEgCxW+G+8NJkwFIKCWUhrfxkwIIGEQCWxYF6NqyZUJAI/HHLS/jxG89hS74XqWJXQVkYOBgjBf2M5yAzQtAnSMAXuxe5BEAu5vETzmYNveGwv57IYTJgI6EsNCi7uLVI1C9dlgh86NDTMavtePx+s99MaFOuBw1WHLbyuwpKXcnIyu9zqliEOVjIlzNucaTPGOzOV0pOCxV7ErEEwPjFR5IGjKvynzYFIwvDBv1eDn0Oo5sU8p6LXjdXiacoqowuWRpotZO46ojz8YFDT8PvNy9D56bnsb3QjyYrAa100ExI3tPASFP7fle+vHGRMQ5ywfR+WMhHRMUq/t1VWshPdjyEcSlaP+2IJQCiOgxe6OHIBPCPK+518pV7WqLqhP3ii10FjzgfF086AT/dsAgPb1+D7kIGjXXeVbC8MQ8AeMYgY/xp/ZznIG88eMzFxGBwea70qwixfyQBEAettAK5fApSiPKugtOSLfh/x78TH5l6Nn61cSke2r4afU4ODVa8LpoJDQb8wa24zIwCu8i7LgY8B3njFtfzw658lmzZE6NMEgAhxLgYqavg/zv+HfjI1LNwy+sL8cTOV8HgmksEygN+WJjnGA95z0XOuMh5LvLGLf6bRyriq42fhqgm0UsAorfMUpt2dxaQEHsxUlfB70y/HM91r8cvNizGM13rgKC9sD9rEK0La3cB32WDgucgFwZ94w45XlnBP22v+EUgb6lIiWBsil4CIISoCaVdBQHgvJbDcV7QVfDOdU9jcfd6JJSFpI6Bq/TAodKivaFT+v4WvYIXVOsbFwXjwmVTbKKlguN1ZaueqBRJAIQQFRVuHTVBZDy35XCc1TwVD25bhXkbn8fKKuoqWLptsbRozzDDZYO85yLr+cG+wN6QgE9hwCdpoCmqgyQAQoiqUNpVUJPCe6ZMxyWTT8Jft63GvI1LsaJvK1Lj1FWwdGTv/3dwt0s4unfYQ844KARr+S57Q3YySMAX1U4SACFEVSnvKvieKSfjkskn4ucbFuPXm17AltxgV8HSNfQDNXRU7/+/Kgn2BgyHXTieVyzWc9gEo/uwaC+cERg+pS8BX1QrSQCEEFWpvKvgpw8/D5cfcip+v/lF/H7zMmzO9aLBisPax2ZCQ0f1NGTNHvC34nkcBHvjIR9O4xs/2Bse7I0ZBnwaYdsrS39DERGRSgD8tpbSCbA6DB3jMMJeWPLaiNFVmgj4zYTehA8cehp+s+lF/HzDYnQVmwnpYe2Fi8Ge4J94Cf//PBg/2HseCsGI3jEeHPbgMhdH9sDQ0T0weOXv+VqX90F94Uje/yKVAAgh6pd/dj0H7YVT+NyRF+Adk07ArzYuwV+3rUZ3IYOWWBKaVDBiZ3hgeMYvxgtH8/5/PXhs4JWeiRuO6jF0+14oWrd2IfYuWgmAQST3Wtak3fUBkNdGjCF/62DYXpiDZkJBV8ENS/CLDUuR8QpIahsuuNhcp/z8wWLr3ZLjq8p3GcqlLPZLBO9/qtJPQAgh9pffVXBwRuDo1AT8vxPeiZvO+DDOap6KLblebMv1gZmLDXZ08FDFcb4vgvdtIUZFtGYAhBCiRHlXwbdNPAZvm3gMHt/5Km557QnM3/4yiIAGKw6D6mwmJESlSAIghIi8sKtgGODfPvEYvH3iMZi/fS3+Y81DWNqzEXFlRba9sBBjQRIAIUTNKG0mBAJmTToeb514DH67+UXc/vpTWNq9EQltIW3F4Y1xMyEhqp3UAAghak7YZ98ww1YaH5l6Fh5487W45cwrcFy6DdtyfXCNC4vUkHoAIeqJJABCiJo12FXQFBOB+958Df71pEswIZbCjnw/HONCk9wKRf2J2BKA7AOsHrIPUERHGOA9Nmi04vjGcbPwmSPOx4/feBY/Wf8c1me70WQlgq6C5ZsGhdibaN77JO0VQtQNTQoMPxFoi6Xx9eNm4eELv4wvHf1WGGbszA/4hxEFt8awc2AE7+1C7FXEZgD8Zh1SwFsFyiYAGMHrIq+NqHJ+DwFV7CHQFkvj309+Dz55+Lm47bUn8dtNL6LLGUCznYIigofgDAC5tsUe+AdHRYvMAAgh6pK/ddBPBDw2OLFhMn5w2gfw4IVfwEemnY1eJ4veQsZvIiQ1AqIGyVUthKhrYSJgeDARmHvGFfjtm67GOyafgAE3h54gEVAjnP4nRFRFbglACCHGgh/cabCZUNuxeHvbsXh8xyuY+9oTeGT7WigQGu0ETLB8IESUSQIghBAlhjQTwmAi8IfNL+GHLy/Ai72bEFN+MyGDoUcHCxElsgQghBAjUORP+YenCb7/0FPx0Fu/iLlntGN64xTsyg+g4EkzIRFdkgAIIcQehF0FPTawSeOj087Cg2/5Am45sx2HxBuwPd8Hhz1JBETkSAIghBD7oLSHgK38ROCvF34R/3biuzDRSha7ClrhjgFZGhBVLlo1AAbSCKBalL4G4a/ltRE1LuwhAPiJwMRYGl8/fhauPOI8/PiN5/DjN57DG9kuNFpx//Pk/VAngnufiVYnAJkBEEKIA1DaQ6At3oCvHz8LD1z4BXz2yAswIZaSvkGi6kUqASg9CUAe1fsQol6EPQQ8NnCMh8MSTfj+ae/H7KlnwWUDgCr+fpSH3P92J1pLAEIIUUXCrYKaFDQBj2xbgzmrHsCa/u2IaxscuZAg6okkAEIIsZ8MMxhcrAd4bMfLmPvqQszfvhYAkLZikesLL+qPJABCCLGPhgZ+whM7XsWNLz+O+TvWwgOjyU4UPw/SNlhUOUkAhBBiL8KTA8PAv7pvG2595Qn8fP1iuGzQFEuAglqAwb8kSYCobpIACCHEbpQGfk2E1b1bcesrT+A3G15Aj5tDSywFrcLAL5P+IlqilwBEsdSyFvEIv5bXRdQIBmDYFAP/jnw/frTqUdz72jPo8/JotlOYGEvDZQPPGEgDQBHF2BSxBKB0I6CoLMkARG3yioFfYUe+H/e8/BR+/NrT2JDpQmM8iYmxFFxmuOxV+qmKqhHNjYARSwCEEGJslAb+PieHW1Y/jv999Wmsy+xCQyyB1ngaHhgu876N+GVWQFQ5SQCEEHWtNPA7xsOvX1+Cm1bNx/Pd69EcS6Et0QATfB5UENWD4j4C+YF+xGAvGYCobpFIAB4r+bVMNlenaE6AiXpmgk59mhRcNuh8bRFuXf04lnatR9yKYXKyeeiIXwWRPswBAHAxxkuwr3dRvPdFIgEQQojREnbvU2ETny1r8N/LHsDjW9ciacfRmmgAg+GwAREND/5UMgtQ+vtSsv1PRIAkAEKIujCse9+WNbhp5Xw8umU1QMCkVBMMGB7Yj+3+/wWD+6HBnqhkGkCIiJIEQAhR08q79y3Z+Qb+64W/YP6WNX73vngSIMDlEQJ/MfiXTP2X/HrEDEBG/yIiopUAyC7A6rG7XYDy2ogqUd69b1XPFty66jF0vr4E/W4ezfEUiAAP4eC+ZJQfBn5gcNTPKAnuFH6ToYjkPVCvInj/i1YCIIQQezGse1/PVsxdtQC/fX0pup0MmuMptCTSQfc+Kgn8CAL88LV9Kp8RGImM/EXESAIghKgZXmn3vlw/7lzzN9y0cgF6nCya4ylMTDbAC9f5VTi1XzKlT2Wj/iHr/3v4xsU/4718ohDVI4IJAMNfC5A3WXUoXwuI2ByYiLyhbXsVduT6cc/ahbj35Sexrn/XkMDvgkFUNuoHBkf2wX+pNCEYcqspu+8M+a1sUq5f0dwIHcEEQAghfOVNfG5a+SjuWP0E3hjwu/e1pZrgwowQ+IeO9A8u8AsRTZIACCEix2MDRVTSvW8xbln1GJbsfCMI/I3wmOHCDK3qB4bv4/f7+ZUlBqXfTYK/qE2SAAghIsNjAwq69wHAL159FresegxLd61HXFuYmGqECaf6VRDYh7TvHV7MR0Mq/0tJ4Be1LVIJQLjyH61VlvoQzRUwERVh977SJj43rHgUD2xcjoQVQ2uyAQwUp/oB8tv0DmvkA5QHfh78UEACv9h/Ubz/RSoBABDNn3Itkj4AYhyUd+9bsHkNbl45H49sXgUPjLakP+L3OFjjR+kov6TCL5wE4N207x2eBQz+Vq5psS8ieJ1ELwEQQtS88u59q3q2YM7SP+GBjcthADTFkiCiweI+YOQtfeVr/CNu6Rupm99Y/cuEqB6SAAghqgYHo3mrJPDfsvIx/GbdEvQ5eTTF/cDvBUsCQ9v2Di/uQ/HD+xD4JeiLOiMJgBCi4kq791lEeKVvO65f/gh+u24pugtZNMeTaE6kgsBf2sQHsqVPiAMUsQTAYPBAAFEdRioGEGLflXbv257rwz1rn8Ttqx/HpmwPWuPpoImPgQdTFviDL1D23yHt+gkYvC7LFvUl8ItRE80CqIglAEKIWjBS97671z6Be9c+hXUDO9EUS2JSMmziY0bo3kfD/jtYB4A9j/h38yEh6o0kAEKIcVXeve/Xry/Gt1+8Hy/3bkNjLIm2ZBM8NsOb+OzLVH/x40N+MUgCvxBFkgAIIcZFaRMfx3jofG0Rbl31GJbsWo+UFcOkVPNg4FflI/o9FPhJ9z4hDki0EoBw+T96Sy21R/oAiH1U3r3v968vxfde+ite2LUBMW1hQqLB797H4VQ/4E/tDw32Q6b6geHFfbKXX1RSeE5dhEQrAYDEmGolr4soV969b8Hm1bhp5Xw8vHElSCm0JhtgAHjgYjDn8iY+I+zlZxnxiyoUwfgfvQRACFHdhnfvW42bVgx272uKJ4GSJj6DPfpHauIDFNf5JfCLKhbFAZAkAEKIUVG6lx8grOregh+89BB++dpzAFGxe59hDuJ9GPghTXyEqABJAIQQB6W0e58mP/DPXbUAv3l9CXqcHFriqWLgZ0JwOp8EfiEqTRIAIcQBKe/etyXbg2+/cD86X1+MnkIOTfEkWhNpGDb+9KgqCfoj7uXfXROf8o4/XPbJQogDEcEEQMrNqkv5dgB5berBsO59axbinrULsW5gF1riKUxMpuExw8AEgb98xI8h/x0e+IGhwT/8ffmfC1EtolcGGMEEQAhRCeXd+/qcHOauXIB71z6JdQM70WAn0JZshMfsV/YPa9tLZQmA9OsXopKilwDIILM67K4PgKhJhg1USfe+ztcW4Yblj+D5XRvQFE+iLdHk9+vncEtf2YgfpQG+ZC9/6ce55GPlv5RrS1S7CMamaCYAQohxETbxUSWB/5aVC7Bk53okLBuTg+59HszwtX3p3idEVYteAiCEGHPlTXwe2bQS1y35I5bsXI+4tjEh2QAG/MCvSgN/eRLg/7oY/4dN9Yd/sPvfCiHGhiQAQoiikZv4PIpHNq0CiILA76/xD23igxFG/IA08RGiekUqATDw7xGyClB9GJFcAhOBoYGf8PiWtfjRSw/j0bB7X6y8e1/Ytnfv3fuGt+iXwC9qU9Tuf5FKAIQQo2uk7n1zV87HT195BgVj0Bwfw+59u/mQEGJ8SAIgRB0asXvfyvn49etL0F3IoiWeQkqp4swA9D5O9Q/7uP9nw0jgF6LiIpYAyHnA1UcaAUVN2MTHIsKOXD++v+xB3LN2IXqdPJr22MQn+AIjNfEZ8jEu+8TyBj5C1KLo3f+ilQBI/K8eu+sDIK9NVSpv4rM914e7V/vd+97o34WmeBITkw1+E59he/mBIdF+SGU/Df9Gu1vjl2tD1LII3v+ilQAIIfZLeeB3jIcblj+C21c9jjcGdqHBTviBHyMF/rImPsHHBmf9ZapfiCiTBECIGuWVBf7OVxdh7sr5WLzjDTTEEmhLBt37UBL4geEj/5ECP7Dn4C+BX4iqJwmAEDUm7N6nScE1BvNefQ5zVy7Akp1vIK4ttKUa/RH/vnTvC34/ZLpfAr8QNUESACFqRHn3vgWbV+Pbz/8Fj21Zg6QVL+nex2WBf4TufTRCv34J/ELUFEkAhIi4kbr33bj8UTy8aSUAYFKqCWZfu/eNVOAngV+ImhS5BCCChZZ1Q16b8VXevW/xjnX4j6V/xqObV8NjRlPQxMctGfHvrnsflVXzsxT4CVHzIpcACFHvhnfv24ybVyzAvNcWod/Nozme8rv3gcHFUf7II/6hgV+m+oWoJ5IACBERpYE/7N5384pH8evXFqPbyaI5lkJrIg2PTbAdf/cFfsW4zygL+jz4Gw4/v7yxD4b3+hFCRE70EgBm/yEqi0t+UWwEJK/NWBi6l5+wI9eH21c9jhuWP4KeQs5v4pMI9/KHlf0j7OXH4GRAEZV/Jxr62pY/kxE+JIRAcO+L1hsiegmAEHWivInPjlwf7lr9BO5esxDr+neiOZ4abOKD8iY+QPEXKswDRmjsUyRT/ULUG0kAhKhC5U187l2zEN958QGsH+hCg72bJj4jdO+jIR+DdO+rUmG3Bf/lKem9gLC4ds8jSwINednCzza8L39b1CtJAISoIh4bKKJi4J/36iLMXTEfS3e+gZQdR1uyCQampIlPyVa9PRX4yZa+quG/VFQM2gzAZQ8eGxQ8FyY4j8EEtRyKCDHSe/yaLhu4bIpf2wq2hCaUBUUKllLFFIHB/mqdpAV1TxIAIapAafc+APj5y8/g5hXzi937WpMN/hG+u+3eNzitPyzwDwvsEvjHUxiUFQgMwDEeCp6LgvGDvVYKLXYCTVYMxzZMQlxrHJmaiCNSLXDYYEIshelNh4z4tcOSzQ3ZbrzWvxMxpdHt5LC8ZxMYwJq+bch4BezMZ+CyBwCwlUZcWbCVLj6n4rHPoq5IAiBEBQ3r3rdpNX60/GE8sOElJHQME5MNMADM7vr17ynwB39c8sGh31wC/5ghEFTwGjjGQ84roGA8WKQwIZbCcY2TcELjJJzRPBWnNR+Gw9OtmBRvQIudHNXn0efk0Ovm8Er/Tqzu24plPZuwqncrXh/Yhe35fuQ8B7bSSGgbsSAhMMFuE1H7JAEQogKGde/btBo3LH8ED29aCQNGW7KxrG1vWfAP/1v8cPmflX43CfzjgQAoUgAYOc9FxiuAQJgUb8CZLVNx7oQj8OaJR+P0lsNwWLK5+NqXC68NLvvae1O6MzOc7m+0E2i0E5iabMHbJx1b/NydhQGs7N2Kp3e+jmd2vo6XejZjU7YHBeMhqW0kLRsaBA8MlmSgZkkCIMQ4Ku/et6p7M/5t0R9w/4aXYAA0h937eLBtLxMVR/ccBPuwuC+M9xzOBKC05o+G79cvrSxD2cfEfglPT1bwX5+C8dDvZKBBOLphIt4+6Ti8pe1ovK3tWExLtQz7+15wLYQBOywAVMP2ah7Ecwy2bpogoSD4s00TY2m8te0YvLXtGABAVyGDZ3atw9+2v4LHt7+M5T1bkPUcpK0YEsoGkb9MFf6bxQgimCdFKgEwxu9JIglpFeChv2ZIG4A9YfiFXVZJ4L9p+Xx0vrYYfU5uSPc+BKP+YjteorLGPijehZkx7I7MvIc79Eivj7xmB0STgmFGr5uHxwaTE424YtqZuPywU3HhpKPRaCWGfL7HBoCfMIAIehQD/e5QkBjqsu8TNpXi4Pm0xlK49JCTcekhJ8Njg8W71uMvm1fgdxtexKsDO8DMaLDjsEkXExdRhoHgJY6MSCUAgIF0nK82vJtfC2Bo9z6LCK/0bsMPlj2E37y2GF2FLFriSbQkUoNte4GyvfwoWeMv++LFzykf5vPQ34pR4xdqEhw22FUYQFJbuLDtaHz8yHPwjikn4rBkc/FzSwM+Ee12yr8Swn9HKLxOAT+xOX/ikTh/4pH4xkkX4Yntr+Bn6xZh/ra12FHoR4MVR0JZUiswTPR+FhFLAISIhvLufduzfhOfW1cuwKZMD1oTabQlG+HBDC3wK9/OB8CPG0P398sa//gKA2bOuOgq5NEaS+Hzx74FnzzyXJw34cji5xWDftDDISpKEwJ/Ns8f5TdYcVx66HRceuh0vNy/Hb9Z/zzuee0ZrMvsQkJZSFvxIcmDiBZJAIQYRcO79/XjzlWP4+41C/F6/040x5KYlAqb+JS37QWK0ZtIAn8VCNfMc8bFrkIOR6Un4hsnXoQPTTsTxzdOAjA4elZVNso/UOG2RRS3CPpbVI9rmIRvnnwxrj7mzbh/8wrc8cqTWNz1BuLKQoMVl6WBCJIEQIhRUt69b94rz+E/n78Pa3u3oSmWxKSRmviMNOIv/RhK/7z0u0nwH2uaFFw26CoM4MjUBHzjxHfg6mMuwKR4A4DB3g2Khk6n15IwAQIGC1gnxRvw6aPOx8eOOAed65di7st/w5Ku9UjpGJLaHjyMSlQ9SQCEOEilTXzCwO838VmHlB3H5FRzWeAHhjbxQcmWPgn8lRbu3+8qZNBkJ/Bv0y/F5499C9rKAn8tjPb3hyrOCvgzHrbS+PiR56L98LPQuX4p/mvFX/Fy/3a0xlLQpIrLIaJ6SQIgxAEqDwS/fW0JvvPCA3h+13rEtYWJyUaYEbv37aWJDwgYFlsk8I+1cLTb7+bhssHHjzwX3zjpIpzYOAXA0DbN9SysFwiXB8JE4F2HnIzbXlmIG9c+hm4nixY7KfUBVU4SACH2U3n3vvmbVuGGlx7BQxtXQClV7N5XbOIDjDzdP1Lg39s6/24+JA6OJgXXGHQ7Azi79XBcd+p78M4pJwKQwL87pcsDHhtMjKfxz9MvwYcOPwMdy/6Cv2xejriykNQ2XJkNqErRSwBkF2B1GGn3X42/LuXd+8LA//BGv3tfcywJEMHjkqr+0qn+klF/sXtf6T7+Ibv49jDir/Gf83izSKGnkENS25hzynvwtRNnwVZ6WKIndk+TKo72T2qcgl+95Sr8bsML+NaLf8brAzsxIZau/fMGIhibopcACDHOSvfyh018vvfCg/jFK88CRGiKJQeb+BRH+SNU9x/IiF9G+2MmXOvfURjAW9uOwf+c+X6c3Xo4gMGCTrHvwqWBMHH64LQz8Ja2Y/AvL/4Zv3hjMVI6hpjSxVMLReVFLgGIYJJVF2rxdSnt3qeJsLJ7M25+6VHMe20Rep0cWuMpEKlgqn+k6X4Uf1864Efw68EmPqUdf4KPlW4JFKOMYZFGzjjIeS6+ftJFmHPqe4qFazpie/irTZhYeWwwJdGIO87/GGZMPg7ffOEP6HWyaI4l4Rgv+OzausajttARuQSgNkNNlJWvBUT/tSnv3rcl04P/WHof5r36HLqD7n0TEukg8BsMHe2XFfhh6I6+oSP+0uAf/H7I/TD6P8tqZJFCt5PB5EQj7j7/w3jf1NOKR+JK4B89pcsCnzzqPJzRMhVfXjwPz+x8HW3xBhg2NbYkwIhaChDBBECIseON0L3vrtV/w+v9O9EaT6Et2RBU9o/Qva90qh8oifwy1V8NwqK1nYUBzJx8POae+xEcnZ4IN3jNFcmLMNrCZQGXDU5rOQz3z/gS/unFP+LOV55Es52AKlkyEONPEgBR98q79/UWcrh5+aO4e80TeL1/JxrtBCYnG+GOGPiBkog/chMfqeqvuDC4b8n14e9OmIHvnvmB4pS/JaP+MWcFByelrRhuOPsKnNN6OL6yeB4S2kZMWdIzoEIkARB1baTufT9c9hCW7lqP5lgSk5N+2153b/36Rwr8gIz6q4AmhbxxUfBc3HxOO6497q1lhZ1iPCgabCJ05dFvwpHpCbj62Z9he64fzXYSLnt7/yJiVEkCIOpSefe+X73yHG5ePh9LdqxDwrZxSKo5CPy76d43ZLq/ZJS/L4F/Nx8So0+TQtZzkNQWbjy7HR878pzivn6Z8h9/pUsCMycfj9+99fO46pmfYm3fdjTbCekXMM6ilQDIacDVY3d9AKr8tTHsF+2FI7+HNqzAvz33eyze+QYS2sLEZAMY8G9EpYG+vHUvyrb0cdlUv+zlrzhNChm3gGY7id+/7fM4s3UaXPZgka70U6t7VnDOwhktUzH/or/Dh/92JxbueBVt8YaSHQIRE4H7X7loJQBCHKCRmvhcv+wRPLxxBYgIbUHgH7LGv7cmPoBM9VcpTQoZzw/+f3j7NTijZaoE/ypjBTUYzXYSv3nb52ojCYgYSQBETRsa+AmPb16DH7z4EB7euAIGXGziMzzw76WJz7DAL9P81WLk4G8k+FchTQqmmAR8Hh/+2x2SBIwjSQBETRrWva9rM25a/ih+svZpFIyLlniqGPh5WBOfoWv6Q0b8xc/ZwzeXwF8hDE16N8Ffiv2qlQp2CDTbiaFJQKwBDruIzhsqYvP/iFwCIEUA1ae6GgGVd+9b1bUZNy5/FJ2vLkJ3IYPWRBopigVte/3AzyXb97i8eQ8Nft3iAT7Ff+OemviI8cQIC/4KaLYTEvwjJuwH4CcB/nLAkztfxQQ7DYe9iLy1Kn//21+RSgCCnmsR+xHXB0ZlL//SvfxW0MTntpWP4fqXHkZPIYvmeAptyUa4MCM28eGy/fylU/tc1sSHZbq/6igQ8sZFXFv4w9uvleAfQYNJgF8TcNljt2Jp13q02MnI7A6IWmyKVAIgRLnyJj7bc324c+XfcNfqv2Fd/060BN37PHDJlr6S9f2SqX/p3hdNYc6Wc13ccu5HpOAvwhRRsTDwzvM/jnctuBn9bh6xktMZxeiRBEBEUnngd4yHHy17CLeueAzr+neiMZbApGRjEPjLRvxlW/qke1+0aVLYnOvFred9FLOPOBuO8WArCf5RFXZoPKlpCn73ts/jokdugEsEDVVjZwdUXvQSgOgts9SmCvYBKO/e96uXn8NNyx/F4u3r0BCLD+3eN+JBPUD4i2JlP2NoEsBDPw/lv5VrsCpYpLAjP4D/c8IsXHPshXDZ1HTwZ/DgGVJctjOlhuigT8DZrYfj5nNn49pnf4lGO46qngSo5ue2G9FLAETdKu3e5xqDX778DG4KuvfFtY1JqUY/8BdP6MPwUf8+bekb9hsZ8Vch/1S/LGZNPgHfO/uDwa6P2nmhGACzgWEGEYEQdC8sWaUq/xwVfF4tCJsFfeKo87C6dxu+veKvmJJolO2Bo0gSAFH1wrW/YhOfjavwH0v+jAWbVyNtxYMT+lAS+Mu69pUE+KEjJlnnjyoFQs64mBRvxG3nfzT4KIMQ/aI/ZvYPKVIaRAqq5BrszWdg2ICCgrnWRMOwz3GNB1UjpxuGbYM7Tns3ntu5Do9tfxmtESoKrHaSAIiqNax738ZVuH7Zw3ho4wqACFNSTTDD1vhL9/MD0r2vRhGQdRz875s/jSPTE4rLQlHGYBhjoJWGRRqGDZZseRlPb1yFJzYsx65cH9bu2gjHeEECYHBc62FojqfxpsNOwoXTpuOcQ45HYywJYHDGLMqJAAUpHRHh1vM/ihkPX48+N4cYaX8rrzgokgCIqlPevW/R9tfx/y3+Ex7ZuBIGjOage99g4EdYyVcyoh9hql9G/DXBIo3t+X780/SLcdlhp9TEdj/DBooUtNLYlunGT196FL9csQDPb30FjlsASAFEiFuxIZfo3/pfArPBn1YvBGkLx7QcivYTL8SnTrsY09uOAIDIJ0fhzoAj0xNw83mzMfuJuxCzdSTX3KtNBBMAqQKsLiNVAx7oVxps4gMQVnZtxk0vPYJfvfIc+t18Sfc+U7KNL/jLZb8eHPDz4AdoNw18MMKHRVXSpNDjZvC2Scfg3057dxDcov3ChQG6t5DB9c/+Dre/8AA2dG2GtuNI2XGkY8li8Z8pKwKMaTvIf/0lgQ192/HfT/4Cc5fch49Mfzv+8YLZOK71sGDZQEX2Eg+LAi877BT8/Ykz8d2VD2NKvBFOVR0hHL3YFMEEQNSa0ra9FhFe6d2G77/wV/z61UXoKmTQGk+hNZmGxwZh977dTfX7H9qPLX1RvSPWIYI/EowrC9efc0Vxu1iUi97C4P/0plX43H0/wPKtryART6Ml3QITFPe5IwW5IM5wWBYf/CembSRTcbjGwx1L7sNvVi3E9995DT5z2sVgZhggsksCmggeM/75lHfhr5tXYk3/NqR1TPoDHITIJQDRy7Hqw4F0Ahy6l9/v3nfnqscxd/l8bMr0YEIijbZkUNkPA6iRAz+VJQBc2smvbNvfENG8D9YtTYQd+Qz+64z34dSWwyI/9R9e+3e98CC+8uBNcNmgtWECXOPBPcBKdy5JGFpSzch5BVz1x+9gyea1+OHFX4AmBQ52DESNn+gZNFhx/PCcD+OyBbdIPDhI0UoA5CiA6rG7PgD7+FeHdO8LAv+dK/+G1/t3oiWWxORUE1w2Q7v3hUq69QW7+YMvPMIaP+9hxC/XUWQoUuhz8zin9XD8/UkzI73ljwF4xoOlNP7+oVtww7O/RUOiAXFScDx31L6PazxopdGcbMKNz/0OL+1Yh9986F/RHE+DmSM5ExAuBbxt0nH4zNEX4JaXn8CkWLo6dgUw/BgVIdFNn0VV2tstxZ+yRbGJz20rFuBNv/sP/Otzf8CuwgAmp5qgtfbf0KWV/cWHAoH8fdHlSwEKZSN+me6vHQzXM/j2We+HTRrsH+FU6Sd1QMLg/08L7sENT81DS6rZr20ZgyAWbilsTbdg/quL8eHf/juI/GU3jujUeXhmwL+cdikOT7YgZ9zIXguVJgmAOHj78N7z2BQr+x3j4adrn8bb/vDf+OrCX6CrkMWkVCNsbcOFARP50/3hIzyFLzyad9hSwD6s88v9IbIsUugqZPHJo8/DzMnHR7qqPdzf//MVC/A/T/0KzQ0T4Bkz5sHY8Vy0NrRi/mtL8H8evg2aFEw1jJoPgAKBwZgcb8S/nHYp+t18ZGeDKi1aSwCi+pW9D0u79wHAz15+Bje+9Eixe9+EZEOwl798xB98sX3u1z/CN5d7QuQRCA4bNFkJ/NMplxQL4KMoXPZavmMdvnT/DUjYcX8kPk5rUY7nojnZhOuf/jXOPfQEfPKUiyKbTIWzAJ8++k24Y+2TeKlnE9JWPLJJTaVE75UX1am00Q78vfxhZb8iwvxNq/G+v96Ezzx2N5Z3b8LEZANSdgweTHDcbjjiV8WpfgQjftqnET/t9rciujQRugtZfH36RTimoa24Xz5qwhBf8Fxcc//16CtkENf2uFewGzBSiQb83V/n4tXuLVCgSFbRUzALYJHCt896X/BviN6/o9Ki904SVWZouT0jnOYMAv/m1fjAw3Px3odvwkObVqIt2YiUHYcLhqGSgF8M/Nh74C8mGxL4axkF7X6PSk/Atce9NbKFawBggva8v179Nzy57kU0JRoPuNL/YDAz4tpCV6YH33l6Hogosifs+dtAGTMnH493HXoyepxcJGczKkl+WmJ0EMDEsIPK/hXdm3HFgttx2cM34cFNK9Bgx9EcTwWBH0OL9koCOxHB7wM0wnS/bOmrK5oIvU4O1x5/IVpjKXgRLfxj+LsYsm4B333617Dtyk5VO8ZDQ6IBP18+H6t3bYh0PUA46v/6ye8o1gaIfRexGgDZB1g1CCUvA4Phj/p3FQbwzcW/xV0vL0S/k/fb9sKfFQDzCPvzg98OG72XtPktfiMa/LMRvoaoHf7o38HR6Qm4+tg3BwWk0XzBw7X/x954Ec9vWYvmZBO8Cp9oZymN7oFu/HjZw/ivGZ+BYR5yoFBU+MkL48JJx+Bdh56E+zevQIudHJMdFXsXvbgUvRkAlkf1PQjGMNI6jiU71+P6lY+CQGiNpfxtSIbL9uP70b74vzD6c8m0fnizD76+/8DQ91jF/93yGKuHJkKfk8c1x70VE2Jp/7jbiGZ8Ya581wsPgkihGg6199ggHk9i3srH0VvIwFI6stsCw1H//z35HdDwGx1V9PqNkEjNAASHvUbtZ1y7yl4MBsPSFlq0DWM8uMwlU/mMIcN/Kn8dy6f5Uf6b3X5I1BYCoWA8tNpJtB95ln/lRHT079ctKHTl+/HUxhWIW7GqOMXOrwWI4dXuzVi69RXMOPw0GDB0BN9gYXfDC9qOxhmtU/FC10Y06Lh/Zsg4q/wru3+iNwMgqlRYBOg3HuEha/gYYYtf+Ge09yY+I9T7idqliNDj5PDRo87FUemJ/vR0RF/8MNi/sPVVbBnoQkzbVTPSVkRgz8XC9csBoGqe14Ew8HcE/N2JM1Ewntwr9pEkAOLgjDRiLwbskqBf/JSSj6mRivtkL3+9M2AklY2rj3lz8JHoBqYwqC7e8jI8p1BVuxiYGVAKz21eAyC6hwQBQTID4PJpp+GExknIek5kl4zGkyQAYpTtZuSuygL+nvbx7+ZDovZpUuh38njzpKNxeuvUYi+JqAov4W0DXUMT4SrAABRp7Mz2wTVepANmeFJkSsfw4SPOku6A+yi67yxRPYa9z/Yleu9mXl8Cf91z2MOnjj7f7/YW4dE/MFi78OK214AqK7RjMGLawitdm9Dn5PyeAFX0/PZXuIvh40edi9ZYqjoOCKpykgCI0TFi0KY9PHbzqaJuhcV/hySa8K7DpgNAzYziqnkWQ1GUx/6DFPwtgSc2TcG5E45Av1uo6p97NZCfjhg9+xvEpbhPlNBE6HfzeO/UUzEp3gAvwlv/ykV3XB0t4YzRJ44+ryKdFqMmUtsA/T5AXBX7aMUokJdRlGAwFIAPH35W8SOSHYr9Ec4YXXrodByWbEKfm4cFhXHpEMgMRGzZQWYAhBAVRyBkPQfHNrThgrajAES7Kl1UBsE/3GhSogFvnXwsBpy8XEd7IAmAEKLiNBEybgEXHXICGux48RhpIfZXuAzw3qmnRfKkw/EUrSUAyKyxELWIAYCAt04+bvD3VYyZYcDFqvndjTLDQ3aq/d9j2MCwAe+m7sLvrsvF1t3VPKoOdwOcP/EotMb93QDV+2wrK5IJQLW/mYQQ+45AKLCHyYkmzJh8PIDqrP5n+IHSb2uh/La5e3maKqhCt6q4Gp0ANMSS/nPd3b+n7OMMhjH+8czV1qZZBecBHNMwEae3TsXCba+i0U6My4mH0aoAiGACIISoLUSErOPg7AmHY3Ki0R+FVlFQYQDGGGilitvKunJ9eGHba3h202rszPbixe2vBT3pR/rbhBe3vYakFa+qKWkOmiz1OTlc3tkBi/SwzyEiuJ6LY1oPxWENE3HqpCNxziHH4/CmSdDBUNszpuoSAS9oDfymtqMwf8taKEQvOI8HSQCEEBWlABSMize1HQVFBJcNrCqZtPWPySVopeAYFw++uhj3LnsYT29cic39u2C8AgAC1PDgWSppxWGpcapG3w9EBMe4+Ouri3fzGcFOjFcNYAygLUxMNuG0SUfik6e+E5cf/yZMTrUA8E8YrJZ99+HVc2HbsdD0cNX93KuFJABCiIpiMCzSuLDtWADVs/HPC0b9Hhv89KVHcMNzv8eSLS8DBCSseDBtngKw94N0DHPVBiECoTme3vPnBKN7ZkbWLeCx9S9hwevPY1rLIbjmzHfji2dfhrZkc9UkAWGNwlmt0zA50YiMV/CPCq7S16BSJAEQQlQMMcFhg4nxNM5qneZ/rAqmkl3jwVIaL2x7FV964CY8uX4ZLCuG5mQDwH5A9wvnKv1MR4e3t/Xxkn+nJkJjLAVFhB2ZHvzb/Ltx1/MP4AfvvBYfOvHCoE6isksCBL+t8ZRkE05omoyntr+GRishCUCZyqdq+4vlIQ951MqDABQ8F0ekWjExkQYDFT/612MDS2n85KVHMPOn/4CnNq5AS6oZKTsOzxj/uGtwRZ9jJTH8YkjXeLC1hdZ0KzYPdOGK3/47vjn/LihSVXGugIG/fDO96VA4nucHu7G6lk3w34iJ2AxA+FOO4E9aCDEMESHvuTi5+RDElAWPuWI7APzKdgOtNL45/2587+lOxK0YmhMN0lZ2N5gZDrtIWDEkLBvfefKXWLFjHX7yvm+iJZ4u1lBU5LkF/z1zwtQgYRvr2BG92BS9GQAhRM0gAAYGZwTT/5UcWXtB8P/aw7fiO3/7CRrjKdhaS/DfB/5yCKM11YI/r16Iy+f9G7JuHgBXbCYgTDtOazkMSW3Di1hwHg+SAAghKiYsADy15VAAlSsA9II1/3uWPYTrn/kNWhonBuv8EjT2h2NcTGiYiCfWPY+vPXwbFKm91xeMkXDm4diGSZgQT8E10l2ynCQAQoiKIPhb/lpiSRyVnuB/rALTxYb9kf+iLWvxxfuvR0Oioe7X+Q9GwXPQmp6A25/7PW5Z8mdYSlckCSAQGIxGO4FpqVYUjFsVBabVJFI1AAZ+xiJvSyFqg8uM5lgcU5JNAMZ/BiAM8j35AVz5p+/CBM1xKjVqrRUue2hMteDrD9+GN087GWdOPhaGTbEz4nhhBuLawpREIxwz9m2ZoxabZAZACFERYQHgsQ1tSGgbZjd96MeSMX5Qmrvkz1ix5RU0xFIS/EcBM0MrhZxbwD8vuLdyzyMIydNbDoUHOROgXLQSAOagG0WFn4cQ4qARAGMYSR2DvZdOemOBmaGUwvZsD+Yu/hOSiQa4LAV/o8U1HhoTDXjo1cV4bP2yitQDhKGiyU7AjHXTBsZgjIqISC0BkCGn+IpKEiBE5BlmHBGs/4/3W9pjA4s0frl8ATZ0b0ZLulUq/keZgp8I3PjcHzHj8NPG/fuH0fjwVCus4JCgMbnQinGJnDH46mMmGjMA21f4P15LPwPHBaLyvIUQu0Xwg/CxjW0AxnkLIAOaFPKei5++9ChsOyEV/2PAZYN0PIWH1y3By12boElV5Od8TGMbLKXH8ApjhqUBwrMAgAXRiFHRmgHwPEfKAIWoFX4LtaxbGPfvbOCv/a/Y8TqWbH0ZSTs+LsfF1iNbaXQPdOPB1xbjuNbDgmLA8V3yyXkOPPYwds16/K9LhmUGYMxoL1rPVwixWwx/r/bEvRxEMxbCUehTG1fBdQtVcYBNrWJmQGksXL8CwPhu9Qy/U7OdRNKyx3z2gZWK1IUUqSdLRrsVbzAthBgVDIatLJzWOhXA+G4BDIPQ39a/BJCS28oYMmDErBgWb1mDAScHPY4/7/B1Pq5xEtriDXB5bJsByQzAWGifZwAg5/Wt4ILbDUvLO1aIGuFWpEmMn4DsyPSCZPQ/5jQp9OYzFVnuAcblOGYFxwUUPQ1gsG6tykXqytfQHjPGf7+QEGLMjHvzH2YoUujNZ/Fy10bELBtG6orGDDPD1ha2Z3uxetd6AKjNnzcRALfSz2K/RCcBYKZGO5ED0wbo4sGOQghxQBgMx7jSHGachEcI1xwGgxSx42XBvBEAsHx6JOJTNHYBEDG4Q22Y/cNs68+/vhVKTWemSPyAhRAj8/umoKKpvJLwP64q+fNmDh4Y5UuOGdCKUPDy5Bk/AbjuOsacOaP5XcZEdGYAQoRuyIEOQoiDxAA8KSUaNwyuzZ83gaEIIPRSY4LB0ckqo5MAhI0VmJf5SwC1eCUJUX/G+9Q9IgKzf0rcsa2HoeC5ckzsGCIiuMbFpGQzjms9zP/YOP+8x/QKY2KyNMD06s4PfLcP6CBQNGaoo5MABEiprmAeR96xQtQAW43/SiSDYSmNiclGGPbkZjLGPDZI2wm0JBoAjH/hp0UKasxmjtn/BxF3jdE3GDPRSQCCbRWe5ufhugAxDa7myEMe8ojag4jhsYvX+ndgvIUNYc479ATAGDknfgwpEAqug+ltRyJl+R0Xx+vnzcF/N2V70FPIQBPgHyw/qtcy+7PS5kUAkWkDDEQpAVjeyQCg2HmV824/tCKM99yhEGLUEAieMXi1z08AxnNRLwxAFx5+Ckhbcg7AGCIisOfiLdOmQxGN6886bBezcaAbPYWgCdGofxcieB6MwTIAkekBAEQpAbjOf91UrL8LzJkxnM8RQoyjpGWP+/cMq9HPmnIsjmk5FHmvILMAY8Rjg1gsgYuPPgvA+LYCDiW0NYbtnpngGaNitHmMvsGYiU4CQGBwh9q59PABMK8hywL8uRwhRBSxPwuwMzcAYPxbAbvGQ1Mshdknvx35fFbOAxgDmhQGCllccNjJOO/QE2DYVOTnvLMwAI/N6F9jDIbWyuTd/kI28zIAoL0zMnEpWlf8AijMmWPAWAql/Pmdyi9lykMe8jiAB7MfIJZ1+Vunx3tkGE4iXnnaO9GYbKzNJjUVRkQwnodrzno3CDTuHdzDb7esaxPccLfHqF7HzGRpkMHLA6+s3AVmAmF8/5EHIVoJQICI1lb6OQghDl7Yk78Sa/CKFDw2OHHCNHz8lFnoz/XDVtJpfLSoYPR/xiHHof2kt8MwQ1Xo5zt2rYfJLwAkvIY5j7nonB2pmBqNToChoLiCLSyF44IjmsAIIfwmPDFtY1XvNmTcAhrsOPwuKuN5XKw/Kv3HC2Zj3srHkfdcaCVnjY0GRQTHLeC6t30SMW3BM2bcS7fC77d053oopWAYo5wKMEMpMGMpAGDS9EgVkkQrgAZrK47Tv4odb4d/KmB0pluEEENpUuh38uguZAGM9s157xQRDBjHtByCGy75EjK5fmkPPApsZaF7oAtfPPf9+MAJb4HHBlqNf7ghAK7xsDPfD016LK4vBccxbNNTACK1AwCIWgIQFAL2f+L2HeyZVRSTQkAhospvxqOwMz9Q7AVQiZG3JgXPePjkKRfh7y+4Aj3ZXtg6WpOj1cRSGj25flx45Bn43kWfh2FTkaSKwSAiDLgFvNq/E3Flje71VVIA6Dl9fg+ACBUAAlFLAIDSJgt+IWBxUkce8pBH1B5EgGdcrO7dCgAVa/Ad1gP88J3XYtbRZ6Orv0uSgANgKY2+QhZtqWb87P3/Dyk7DqAyW//CYP/GwC505QdgFVvHjNqDyVYg5rX9aw7tjloBIBDFBCCcYrHoURgPkJOBhIgs/83LWLrrjZLfV+B5EAX1AMBvPvSvmHXMOega6IYmJf0B9pGlNLpz/ZjaMAEPfPQ/cWTTZHhsoCq0vdIEofil7k3od3LBEsRoxmc2sDWY8QTmzHGx4LrIVZBGLwEIpli04uc45wxAkYbUAQgRSYYBS1l4qWtTECwqF2wV+eWHrYkGPPSxb+Or530QPdleeMaDJbsDdksrv89+90A3Zh15Bp79zI04a8qxFdvzX+75XeuBMekBQATPABYtABC59X8gigkAgcFMu7BhCzxeSTEL0g9AHvKI5oMNI0EWXu3biZ5C1m8bC0alUNCqVoFwwyVfwj3v+0ckdAzdmR4A/ihXZgT83ROW0lCk0JMbwEAhi3+88GN46GPfxpR0S0VH/qEwmVy2axM0WeDRPALAgKFJc7YwoBU/ByBy6/9AFBMAAFhwncbsTo+Jn4R0BBQishgMW2tsz/VhebffSbXSffkVEUAEwwafOe1iPPOZ6/H5sy+DAqE7042C50CRgqU0NCkoUiCQv4xQ/gg+Xu2Kz3+kfwcIigi65N/ssYfuTC/6C1lcesy5ePjj/4P/mfVZaFIwzBUf+TPYn5UoZLCqdwsS2h7t68pQzAIMVu/Chi1RXP8HotYHIBRMtRCrh+C4X0VUExkhBBQR8m4BT257BW+bcpxfCFjhmEkAKCgMPK71MNz+7q/ha+d9CD9Z9hA6Vy/Eq92bwZ4LKAUihbje83kGWqlx7W+wvxzj7uFPCY5x4RkPMB6gFCanWjD75Bn4xCmz8M6j/B7/4ai/Go5p8ZMQwrKuTdg40I0GOz7KCQAztAZU4RHM7vQw/zoLwJ5+iFUpmglAMNXCae8JZLgblm6Fa8a3g4gQYlQwA1ppLNz2SnHkVi3CES2DMb3tCHx71mfxzxd+HIu3rMXCDSvwzKZV6MkP4OWuTf6U926CTL+Tg2PcqrxFEQgTk00jPzMieMbD1MY2tKWacErbUXjrtOk479ATMLWxDQCKP59Kj/pLhUnkk9te8WdsYonRngFQcD2wp/8CIJLr/0BUE4CgH0AP5vQ0/+xrT1Hcfg/cvAEglTpCRIxhRkLHsKxrE3oLOTTHkhjvjoB74ickfm2AYYPGWBIzjzgdM484vfg5Xbn+Eaf6TTAq/sjv/gsPvbYETfEUPK6OFUsiguO5mJhsxMJP/wDN8TSYeci/g+D/G5rj6WFr+uG/ww/81fFahcIk8sntr0IrXdwRMCoYDNtSJu9sUfGBpQAiuf4PRDUBAPx+ALPg0s8xD8B7mFl2BAoRQQxGTGtsyHThqe2v4dKp04tTuNVEERU3HRlmMPuzFUQKrYmGPf5dW1kVLW7ck3AGoMFO7PHzDBsY5iE1AdUonEXanO3F4h1vIGnFglmKUeNR3LbYdR/omn17D3ieBs2O5ElS1fkK7ouZczwA0HAe4mwhA61kO6AQEaWI4HouHtuyBsBuZ9KrAmGwIM4vAESwEclPCkofHnvFP6tmjnHBwQzHkH9D+G8CBgsfVXX3Rgin+pfsfAObMt2I6VEODcwEw1Bs/R4A0Nk5el97nEV3BiBYBtjZuWJrc+HQZZSMv4mzjiwDCBFBxhjEtI1HNq9CwXiRO5WvGBDL4iJxtHYBgEfo2lf9T3+oYP3/LxteAmBAHH5wVL42wyJt8vleWxUiu/0vFN0ZAMBfBpjd6YH1b6A1pB+APOQRzYdhRsqKYdmujXihawMIqJq1chEdDIZW/gFTD29agYSOwxvdbvGG4jGQ4y3c+fGbN4E7VBS3/4UingDMMQBglPd7zhSyULIMIERUaSLk3Dz++MYLAFDVywCiOoXT/09sexmv9O5AUo9y7QX7yQRB/QwAsGBBpGNopJ885sCAO1TfJ25YC9d9lJI2IE2BhIgkzzCSdgLzXluMficPS9XOad/VsqNhJNX83PZX+G+5d+1TYDYY1fULBiNmac7mNtuJwh8AADMfi2TxXyjaCQAweDqgol+DFMmwQYhoYjCS2sIrvdvwxLaXAVS+K+Bo2XOjncohAG5QABh1YfX/lmwvHt+6Fil7tPf+s0dxG2A8vH323H6/+j/aGWr0E4BgN4AXM/dxNrcDtq6dYYMQdYfAzPjx2qeC30V7dBreiI5tPRSospoGAsEJmvwk7fiwHgBR4wWb/X/9+hJsHuhCfLSr/wEFxwOY7gUQ6er/UPQTAAKD5+n+2TduZ8/8jhI2ARzpaRkh6pVhRoOdwF83rcRr/Tv9w3kinM+HI+sjm6cAxlRVgPVH/x6mNExAQtuRHzdpIrhs8PNXn0VMx0a5+Q8bxG1l8oXlPYc3Pw5mwuzOyMeZ6CcAQJiJEZS+EwXXgGrk3yVEnQkPB9qV68OvXnvO32M/qnfy8RUG/BMnTAW0rqqpdiICGQ8nTzwcAKrque0vj/3k6sltr2LxjnVI2zGY0Z1xMWRbIOJ7MGuOiwXXRWuf6m7URqCc3emBO6h3TdMir+AuQSKmmOFVwe4mechDHvv5cA0jZSdwy6q/YWd+ACrCxYDhEsabpp6EiclmOMarmlkAZoBJYcYRp/kfqJLndSDCo/i+99Jf4QbFf6N2TTKYtdImmx+wWf0cQHHpOepqIwEAAKwgzJljQLgZoODqloc85BG1B7NBQlt4o2877lu/zO8JENFZABUcKzwl1YLTJh2FvJuHqoK6BiJCwTiYlG7BuYeeAABV8bwOhAlG/2t6tmL+ptVosOLwjBnNa9JQwia45tc7PvWjzZjXHvniv1ANJQCdBgxKmZ2dnClshT36FSBCiPFhmBHTNm5c+SjyxoUiiuzb2TBDkcKVp18Mz3OrYgZAk0I2n8V7j7sAh6Rbi1PoUcTw6xmuX/EI+p0sLFLBR0cJMcHxAMu9afS+aHWonQSAwMA8tfXTPx1g4lspbgFcZWW3Qoh9YpiRtuNYtP11/Pb1pcFIOpoJgCZ/CePy4y7AtOYpyLmFigdbwwytNa464+KKPo+DFZ62uLZ3G37+yrNojKXgjuZ1wvAoESeTcx7t/VjbEnCHqoXiv1DtJAAAgNl+Z0DdfwtnCwM11UlEiDrDwSzA9196CAXjBuu80Xs7ExGMMZiYbMSXzrkcuXwGFlWuhkwrjb78AC455jy8bdqpMGyq9mS/vWH2R/8/XP4wegoZ2GqUR//M/jqOhe+D5hh0rojmNMluRPNV3x0CY167Hvj4XVvhmt9QMkYyCyBENPlbAuNYvON1/Ob1JZGeBVCkYJhxzVnvwRGthyHj5KAqFHSZGQTgW2/5iP/7ijyLg2fYQCt/9P+zcPQ/mrUizAYJW/FAYXWzrefD3/pXU/GkthIAAGifzgDAiv6L824+OFQ8qte4EHXNM4yUFce/LPkjduUzkZ4FYDAmJhpxwyVfRMEtVOR5WEqjN9ONf3jzR3DhtFPgRXn0HxQtfnPRb9Hn5EZ/7Z/BZGtiMt/eMPuHWWD2KH+DyovmK78nNMdgXrvu+9T1q1Fwf0WpuBrtDaFCiPHBYCQsG6/2bMXcVQv8WYCI7gjQpOAZD+8//s345ls+it5sL2w1fieyW0qjJ9ePWceci/+ccaW/fh7Ryn8/cSE8unk1/vjGC2iOJUf39Mhw9N9fWN23i3+Jjg4Fqq3RP1CLCQDgzwIwSGYBhIg+zxg0xdP47rIHsbZ3G5SiyOb0Smm4xsO3Z16F957wFnQN7EJM22P+fS2l0V/IYFpjG371wX+GIgJAFS9GPBAMBoFQMB7+4blfQ0NhVA/9Cb5JOPrH39+Yx3UrajKG1GYCQHMMOttV36euX42c+ytKxhU8NhXvcCIPechjvx/MgIZCXyGPbz7322LTlygi+DMBhhk/vvwbeOuRZ2JX/07Yyhqzcw9sZaEnN4CJySb8vv06TEo2g5mDJCB6POM/95tWzMeSbevQYMdhjBnFa44NxW3FfbU9+gdqNQEABmcBLPovzjuuzAIIEV0eGzTHkvjDuufxu3XP+9PpEZ0FIPJD/YREI+7/6H/gmnPeh66BXWAwtBq93QGKFCyl0TWwC2+ZdjKe/PSPcPaU44pb56LIMEMrhdf6duC/X3wA6VjCb/ozitiAEbOIUdujf2DU502qzLx2jdmdXuO9X7mJGpNf5r6cB1XB/TdCiAOmiJD3XExONGLR+7+FifE0QFHuYDc4Cr9p8R/xzUfvRMbNoyneACLAmAM7BkmTAhGhv5CF6zq49pz34nsXfR4NwTp5VIv+AMA1BpZSuPzhm/HndS+gNZ4OWv+OEn/tn5B3l/R18YX4uwkOaE44N1Bzonsl7Iv2TgNmUrb3ryZT2CVHBQsRXYYZSSuGN/p34B+e+3WkCwIBP6FhZhg2+Mo578OCT34Plx5zLvqdLHqy/TBgWEoXA/pISwQUrOPrYLRPROgtZNCd7cWpbUdi3of/Fbde+ndoiCUjvd8fGAz+d65ZiD+/vhStiVEO/gAAYiJFzPx1/P2N+WDff3Qvsr2IZuq8P7hdgzq9hnu++i3VnPwP7s3KLIAQEaZJoTs/gJ/O/Bw+cez5kR/VAhjyb3j49aW4Zcmf8ei6F9A90A0ojZgVgyYFW2uEt20C4BgXHjPybgHwXMRiCbz5sJNx9RmX4GOnXARb6WKv/LGqMRgP4WzJiu7NeNufv4O88YodFkcNw6NUTHOm8Ne+K294VziDPHrfoPpE94rYVwwCOgidsBpyXS+qmHUC5x0GRfyOIUSdIhA89mArjYXv/Samtxw6ZDo9qgyb4ogeANbs2oAHX1mEhRtXYsnWl9FXyGJ7pqe4A4KZ0ZZqRsqO49S2o/DmqSfjnUedhQumnlT8mrWQHDEYhhl5z8XM+7+PJTvWodEe5W1/AIPIQJMHj0/v+9T1q8EdCjQnmoUm+yja75h9FWRyTfd+9RKk4w9ypuCBILMAQkSUJoV+J4uzJh6JBe/5OuLagor4KDfksQEBQwr1sm4eA04eq3euh2v8Eb1hg+NaD0NTLIWmeKr4uQyGMQylolodMZRrPFhK48tP/QJzlz+CCckmOGaUB+Yee9SS0tyb+a++K2/8FnieBs2u6dE/UC8JADBYEPjjr3RSQ/IKKQgUItpspbEr24svnfIO3Pzmj8FlE3SDqw0mqA8I1/hH63OjJHxNf/bKs/jkgjvQEm8Yg90fbMi2iF3zmg1z1q5PTugH5nCEd5vus9q5UvZm+XQGMynL+ybn3T5Yyu/NWfMvsRC1yfE8tCQaMXfFfNyz5klYpOCO9siwghRRsQiQwWBmeGyGPAz7N7HSz60VXhD8l+x8A1996udI28nRPQsirO03xLAtYs98c9enbuxF54oot5rYL/UzAwAUZwHSd335y7o5dZPMAggRbeGUf5+TxaPv+TpmHnpCzc0E1KOwpmNHfgBn/+7fsTXbh5QVG/3Rv2GPGhKa+3OdfVfdOLtepv5D9fUumd3pgefpgc/efDMP5P9G6biGQd282ELUGgaDCEhaMXxs/h1YunM9rAg3CRIojvK7C1l88KG52JTpRnosgj+DYWvinNNltPMVMBOum10XI//Q+J1EUTWWMwAoz/uacd1noeFfcbVQPSREHTLMiCmNbblefGL+HXjyff+ElmDfe1Q73tUrDv6nSeErT/4cT2xaiQmp5tEv+vO/m0ephOX1DPzrwFW3bkNip8ac+hoQ1mfQC5cC7vny11Rj6ofcn3VBVIfJkBC1w1IavYUM3jz5GPz5kr+TJCBiwu1+mhS+8tQvcPPyR9CSaBybuo5g6t9kC78e+PQN7ZjfYWHWHHf0v1F1q893RrgUcNXNP+KB3COUTlgwXFeZnxC1xjUemmIpLNyyFu/96w3oKWShSE4Dj4JhwX/ZQ2iJN4xN8Gc2iFnK5J3t5PCXwExYUNv7/XenPhMAAMByf1cA41p23C7EtN+XUwgRWa7x0JpoxMIta3GZJAGRMGLwTzWPQZvfAJEhWxPlzZf6P3vjdnTOVpiDurxA6jcBoDkGnbNV72dufAXZwjVkWwpEMgsgRMQ5u0kCpDCw+vj9C0qC/0tB8B+r7ZzMLjUmLM7kf9T/2Rt/jfkdVq23+92T+qwBKBWs/TTc+5UfUmPya9ybdaHIAkN+OkJEFfuNgrpy/bjwkONw37v+Ds01cBpeLSlt3/yVJ4Pgn2yGO9qrseG93Pi9/k2u8MxAcsuFAPwD4+pkz/9IJMQxCJ3tCgDSmUMWqmTsTTxQ8KCkVbAQUWcrja58P85tOwp3vf0zOH3C1OKpcqJywkSsu5DFl5/8GX6+9ml/zX+sZmmYGZYGFHXrXP7cnqtveQ3ooFrv9b838i4gMNqnM9o7jeW5H2fX2wlbKakHECL6HOOhJd6ARTvW4ZL7f4Bntr8GS/kdA6UNaGW4QfDfmu3Dex+8ET9f/SRaE41jF/wBgMgjWxNyhWt6PnvLq0B7zR/0sy8kAQCCeoB21fPZW17lnPtRsjUF9QByhxAi4lzjoSWWQm8hj5l//i7uXfMkLKUBxui2lhV7xOBie9/FO97A+b//Tzy57RW0jtk+/+I3dqgxaZmB/Jz+z8711/2pftf9S8kSQKmgHiB9z1e/ppqTP+SeTNAfQAoChIg29gsBjUHOK+D/nnYJvn3eB6FJSevgcVDaj+HeNU/i/z79K/S7BaTteFDwN9r31+CebYxLLWnL9GZ+M/CZm66o1/3+uyNRrRy3a1Cnl773q7erdOzz3J+TJkFC1AgCgQjozfVj1tTpuOPtV+LYxklwjQetlDQEHQPhcb79bh7feKYTt61YgJSdgK302O7MMOxRKqbZ8RbpPueSni/O7QYI9Vz0V06u9nIMCopDOP3jrzxJqcQF3JeVQ4OEqBEEv2tgd34AhySbcPOFn8CHjjobAGSXwCjyl1f8mZcXdm3A5//2Yzy39RU0Jxphgr3/Y4bZUMxSDHRZA945Pdfc9Bq4Q9b9y8iVXo7AuA4Ad5AuZC/jXGERpWJaOgUKURsYfnFgcyyFrkIW7Y/civ/z9K/Q6+T8JQFjpEDwILlsoIigSGHuygW46L7vYdGOdWhJNsENjjEeM8wGloYhdJn+wrt6rrnpNcxr1xL8h5MZgN0Jzgtovv0rRztpvZiAVuRdaSwuRA1R/pQw+nL9mD7xCFx/wUfwzqknA/BnAxQpuUnuh9IZlJd7t+H/PPUr/Hnd80jGkmM/5Q/42/1IGUrFNLqz7f3XBEV/su4/Irm29yRIApK3ffE8SsUeJEIrCq4BSRIgRC2xlEa/k4MC4TMnvAVzznkfDk01A5BlgX0RjugVERzj4fsv/hXfW/YQdmZ70ZxogDcesyrMDKUMErbm/tw1mc/NvUOC/55JArA3pUlAQ+xBMmiFI0mAELVGkV8d1p8fwGHpCfjWWZfh8ye9DbbSMDx4TK0YVP5zeXDDcvy/536L57e9jkQsgZiyxqcFM4OhyEPctjhXuCZz1U0S/PeBJAD7IriQkrd98TyVji2AMQm4BpIECFF7LKWRcwvIuwWc2XYk/vv8D+Fd004BMDzg1avyn8OKrs34p+d+iz++8QIUFBpjcXiGx6uWggF4lI5b6M9+of/qubfhtmtsXHu7Mx7fPMokAdhXwQWVuvvLV6p0/F7OOgxjWJIAIWoPEUGB0O/kAADvmnYK/u9pFxfrA4D6rBHw2ECBQEEP/xVdm3D9S4/gF688iz4nh8ZYEsA4Nljyt/u71JS0uDtz28Bnb/6CjPz3XT1duwcvuLBSd37p85SMzYVnLLieLAcIUaPCw2r6ClkQKVwaJAKzDjsJOvgzNwiK4efWGmaGBx7SLGnZro24afmjfuAvZJCKpWCN94mLYcFfOqY5W7ht4Mobv4CODgvXzfFkr/++qc0rdizNn2Fh1mNuwx3XXmgS8T9JYaAQtU+TAoPRV8hCk8aZE6fhq6e+Ax866mw02gkAg+fal46Qoyr8t1BJYuOxwfxNq/CDZQ9hweY1yDo5pGJJ2EoFRX7j+QSDgr+4rSnvfKH/MzfdFtRrGUgL930W7au0UkpqAihlP6gIrZx3pVmQEDUuTAQGnDyM8XBM8xTMPvocfPy4C3DahKnFzzPMMOBIzQxw8JwBDKlx2DjQhXmvLcLPX34WS3esg8cGaTtRHPGPe7RlNlCKkbA1Z/PXZK6ae0dYrD3eTyXqonFlVqMhSUDsQbJUKzJ5SQKEqAOKCARC1nPgODmk42mc23YkPnX8m3HptFMxNd0y5PNdNiBgyIi60sJRPjOCpj2Dz6vPyeGxzWtwz5qF+Nvmtdie6YLSMaTsGBRofKf6hzxpNtBaIW6Dszk/+EvB3wGrjisxqjo6LMyZ46bmfuEsborfpbQ6iwfyLpScHSBEPSAQtCK4xiDj5AE2mJRqxtsPOR6XH3kGzp98NE5uOXTY3/PYgBkgCpsRje0pBAw/0Ifj9ZFmJjYOdOHZ7a/j/vUv4ZGNK/Bq7w6ADeJ2HHFt+bMalTw90bCHuKXB6DKO+4XcZ+fOk4K/gyMJwMEKOwbO/WKrk7YepFTsPO7LOQDsSj81IcT4CafNC8ZF3ikAMEjHUzhzwuG4YPIxeOshx+HstiNxRMOEEf9+uGwQZgbhzTk8wGhPmDFkyx2zXx6vyK9HGOmvd+UH8MKuDVi45WUs3PoKFm1fh+2ZbgCAZcWQ1HbwvCowzV/OsEupmGU8swsZ59Lstbc8J8H/4EkCMBqCJGDinVc3ZmINP1Kp+NXck/EAVpGvBhJC7JfSaX6XDbJuAfBcQClMSDTi5JYpOLnlMJwxcRrOnHgETmyZgonxhjFdGtiVH8BrfTvw0q6NWLZrA17YtRGrurdgw0AX4DmA0ohbMcSUBQLggYMkogowHGpK2pzNP+cOFD5R+OJtayX4jw4JTqOlo0Nhjn/YROrer3TAtq6D6wGOJ3UBQtQpQtBTgAjM/iFEOc8BjAswoCwbbfE0pjVMQFuiAWdMPByNVgxHNU7CkQ0T4LJBcyyJY5smjfj1w2WErdlebBroglYWuvMZvLBrPZgZi7avQ1c+g5d7t2FXIYOCk/Nr5JVGTFuIaav43MLmPlWDmUFkqDGpOVuYZ/c7X+j50i1dUvA3eiQBGE2DRwmbxF1fmq1s61aydCtn8y5I6gKEqHfFhCA4hMgwwzEeCsYDGw8wxo/qSgFKA2wQ0zbaEo0Iu96UYvhb9XqdLPoLWYAUwAYwQXxUGiBCTNuwSfnLFITqDPilDHuwtYalwQVnTvaqm68DAAn+o0sSgLEQdg288wtncTx+l4pbZ3FfTpYEhBDDhGv8/r4CAETgIDgTCIYNHLPnqnutFKxgiyKV9CHwvw6KXy8SmF1Kxi12vV3Gcb+Y++zceZjXrtHeaaTBz+iSYDRWgjWqif9zdWPm0IYfqJj+HOccwDMeiPRgrwp5CYQQpYaP9PflLsHDfheVe0v4XNmAiakxoTlXWOgOFK6S9f6xFZUrJJpKpqtS9375c7D0D0hRI2cLsiQghBAhZhe2ZZGlwAXnR5nXlv8D5jzmhlutK/30apUkAGONQehsV5jd6aVuu+ZspBJzKWa9ifuz/t4aaSEshKhX/lYDj9IJyxTczex6X8t9du48EIB/GyysFmNDEoDxEs4GdMywkked+i9k6Q4AQN5x/SUBeS2EEHXEsAdLa0rFwJnCPO7P/J/sV+/ehI4ZFuY85kF6+o85CTrjqXSr4N1ffhdr9X2KW6fwQB5gDmoDhBCilvmdhSidUOy62+Ca/8hedfONABAEf5nyHyeSAIw/QscM7a9vtceSR03+Zyj6FmzLQibvAtCyU0AIUYMYzB5ilkWWBhfcX8Llr2c/d/MmdHQoXHcdg0hG/eNIAk2llBQIJu/60ptg6/9EzHoHck7YPEhBXh8hRC1geCBoakiA884a9kxH7qqbfwlARv0VJAGmsgZnAwCk7v7S1Uapf6eEfRhkWUAIEXXsHxtIqbjiglsA0Xeyufz3cO3tPf7e/nlGRv2VIwlANSiZ/krP/cJkL2X9CxFdS7aOcSZvAGIQJBEQQkQEGxgwEjHtHy7g3q8c7x8HPnfrSwCko1+VkASgmpRMhaXv/MKpxrK+BVt/FACQKxiwJAJCiGoWBP64pSluw2QLz7Dhf81fffNDACAd/aqLJADVpqRvAADE//fLFytD/wCtLgYRkMtLIiCEqDJswGDEbE22Bhecl8jwDzOO+xNce7uDjg6/34ns668qkgBUq7I3TPzuL1+sFP0DlLoYioBsngGYoJGQvI5CiPHH8KfxY9bQwN+w/aeY3VkAINP9VUwCR7Wb166xfDoPTwToYrI0OJsHPPZAkIOGhBBjj8H+kYNQSMaIiMCOu7vAbyANfaqWBIyoKEsEEnd/8S1E6rMAPkkJO8Y5B3CDM0AJMisghBhlbMAw0MqiRAzseoDnPQSim7KpbQ9I4I8eCRJRU7Z1JnbPV07Sij/KBp+lmDUNDCBX8A/XICj/gHAhhDgAzAyCB4ZG3CbYGpx3+sjwr1nTHbkrb36q+LkS+CNHEoCo4g6FzhVUXFu7/qtNiQb3A9D6kzB8ESVjmgsOUHAH38CyRCCE2BuGX18EAJbSiNuA64Fd8yIBPyFb/TL7qRs3+J/LhM7ZSgJ/NElAiLqODoVTShIBAOl7/+50l8ynyPB7oNV0sjU45wCeZ+C/sWVmQAhRgv17AxNBkx/0AXDB2UBKP8RkfpFPbHu0eJ+Z1+7vQpLivkiTBKBWhNsHSztrze+w4ut3zCJWH2PjXUyWNY20AjseUHCCmQEiAAok14IQdSQY5TMDULC0opjtn86bc3phqQVwvd+kJzb8bucHvttX/FsdHRauu86T7n21QW76tcjfQqgwZ06xv/aEn3y1acD1zoPBpUR0GRSdTDEL7DHguIOzA0wkRYRC1JzBgB+O8m0LZCmwa8Cuu4GAh0irP0PRs8UpfqB0tC/T/DVGbvK1jTCv3Z/qL52qm9euk/lDz+aCeTvA72bjnUkxeyLZGuwZPyFwDQPwQPBnF4bNEsilI0R1YCB4owa/HVzD99+9Ckop2BpkabAxQM7JMKnlMPwYCA80IP3szs+VjPTDGiPp2lfT5C5eL8IlguXTqXRmAACa7vjshLy2zySDt4H57Ux0OinVRomYP2AwBnC8ICngoAER4M8WMAXLCJBlBCHGhR/iiRkcTsUzA8H7MQj2UAqkFbjgAo7Xw+A1UGqhAv+Ntb0od+UNbwz5quFIv2S7sahtcsOuT/7MwPLpBMAMe7Pfdk1zUtGJUNZbmPh0JjoGjjudLD0JtgXSajAx8BjwgskFz5jgijJDxwyy+0CI/cdDR94EBQagSIEUoAiwlB/3tT+VDz9Z72GiNTBmAxGWsGueshsbXuj/xA92lH0DQkeHxikrWEb69UluzGJwdmDSdMKCERICwE8KoE8wcauVnMJ5UOo4KDoCjncotD4ExsSRsFNg+AmCGry02AtrjeRyE2KfEEBKDb5lGH7jHSIgW/BYUS+M6SetX2bXdJOtXiCPlzF5O6xkw4oRgr3/VcOAL6N8Abkji5GULhfs7WYxr103O8c25bt7Gjipj4cpsDI4w2jdQh4zExNAp5NSLTAeB/UEQoiREDiYMXOY8RwBDhMTAQ4DzyIZcznrbkmmsKWn38vj2tszu/1K84KkfvsKHrI7SIiA3IzFvgmTAgDFm4qMIoSorLAPSPieBCDBXuwrSQDEwfJXDq/rIJyywr+elk8nzCz5jDBZEELsmzColwoD/PLpjOvm+L+WdXshhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEKJ2/f/4rOSqJoykfwAAAABJRU5ErkJggmljMTAAAQHpiVBORw0KGgoAAAANSUhEUgAABAAAAAQACAYAAAB/HSuDAAEAAElEQVR4nOz9eZxcZ33nfX+vc05VV++SbJkllp0Y2zAYSIJkQUiILMJibNbMLQ3ZIAkBTyaBZJbMPK/XPbltZ5l5ss5kIc/gBUIIAaS5jQ0DYbNlG9sB240BW3gD23iRhK2tW91d3VXnXL/nj6pTfaq6qrsldXUt/Xm/LKm76lS51OpTfX7f67p+lwQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWC9cp18AAKwKM97PAADt5Zx1+iUAwOngghlA92ko5nft3RtsPO9YMNHi8IltV5TX4FUBANa5HbYvmp54pOX188TW98eLbiQ0ANBFCAAArK2G4n7rxDVR9vNTLeZ/yb4+duKhB6w0OcD7GgBgdW2SRksDfu/Ldk+f7EOzocFWScce2+j37trlawcQEABYQ1woA2iPTKGfFvkjWy+029zOxaMjDdJi3s2F4fx85AtjenW0YfynysdPeJMFC/8PhXJKJP1UODjwU0mx5J0UtH5mAABOkkkKnGS+ZOaulbN5M+ecs1rhHgSR5ONSPOuujWNf0qbK7SsNDbbe++Ec4QCAtUAAAOD0ZAr9Hbo1nJ54xC01ir/rgT0jJ/IjgY4eURQF+WjI3qcgylsSB+bklS3mKwW+uTAYy28clSVecpm3LTPJOfm5kpK5UvUCra1/WwDAulT5eZMbHar8HKr+/KncZXLOybzX/PET007ONwsNJGf5DaMuPj75L3NT+vro5gGXP+8c+4R79VSr/+sO2xe9eOIRVxcMEAoAOA0EAABOhpNZbU3+w0uM6Kej+H5mcCAc1vudC3M+jvMu0Pvlwry8lzkLBjaMjrggkDUt5q3yv0wSmVnZueZvWSYLnLmA6h8A0FbONf2ZZ5KcmXNRGC1cXi8ODVwYqHTshCzxU2Zm4dCAS4rz/+Lk7syND+fiyRN3zE3p6wPPGwnyM+W41eyBrfd+ODey9UK7TZck1dfFD0AAK0IAAKC16uj+UiP7lRH9+SCaCvLBsK4IXBj5JP6pcKjwU0lx3ksWZYv88onZWmEvmSxOYnPOFi6XmhTzrSp/AAC6idniQjwTGlhltkDOhWF6g8JCXsFAbiEciP1U5eeen5fXh3ObxsrlyRNfNxXvci95UXiT23m88X+xaKZA5ccmoQCARbioBrCgWvBvnbgmarVe/5fs62MzDz5aWZN/dCqnQFfIBXkzXxvNTxpG8euKfLO6pn8U9wCAdacWFDiZM+/kfH04UJ09MDIkF1WCAZ/441EhH8bF+buCMPoXb0nsnT48GOfmms0UeP+9H84RCABoxIU3sJ4tU/DvemDPSDEqFwKrjuz7+KfCwYGfsrnyWP6MMVnsVZ5OR/RVK/TVOIpPkQ8AwMrUzyJITDLnXM5FoeS9wsKAwkJelniVpmamZX4unSkQH5/8l+F/dcHXm/UVIBAAIBEAAOtNbQ3/s7s2u+YFf6EQ+an3mQtH5ZP3KQgK+bHhERcujOyb95U1+ZX3kHDh2Sn0AQBoi0qzHJkzLzlf6zngnHIjg3JRqNKRKblCbsoX5+/KbRj7+vzR498Yu+jCu5oFAlvv/XBuYuv7K9cB9BAA1g0u1oH1wMxtnbgmalzD37LgHx8ekXO19fqLRvYr7xy8fwAA0EkLswUWZgoEgcJCTuFQYcWBwA7bF5219zmrzg4gDAD6GBfwQD/KNO9rHOVP1/CHYyOXxFMz75VzQ80KfjlnlfX6TnK8VwAA0ANMpsosAZNfCATyCocGKoHAQG4qKZW/Hni71eUHr4/mktlsD4GGMKDynAD6Bhf1QL8wc62m9r/zxJfOsqeee68P3CVhPnq1zcdj+U1jKk1OVwr+JImltOAXU/kBAOgPVvktGwg4hYMDCnKRSpMz0zKbjcaGr09m5271ycy/fPZf/caJ7BPUlgowMwDoC1zkAz1u1549YWPRv+uBPSNxIRyyUvG9Pgh2RPnoNUE+N2pxoqRYXcMvlZ3SjvzOVXflAwAA/ai6+64qf3gnmQsrPQTy48MqTc3KyvGz0fjw9cmx6VuHX7a4mSBhAND7CACAXmTmdujW8DbtTOQqP8zf9uB1o4EN/1Q4UrgkPlGd2j82POLjWElxXuZ9bCbn5AJJTOsHAGC9q/YQMClxcpGLQuU3DKt09ITcQDSVlOKvB4nd6s7YfP1nXvCmZ9OH0TMA6F0UAECvaNHI7x2P7X1jGEWXxCdm3uui6Kz8+JBKx2ckpc37akU/5zsAAGjNzMy52EmV3gGDebkwlC+VT8Tz8V2BdNvcXPG6L77yvc+lD6mFAbt3J5186QBWhoIA6HLNpvi/8+CXzrJjz73XK9iRG8y/KRzIVabuxYlMFrt0az7W8gMAgJNXv1QgCKKwMKBgIK/SsannotHh65LpuVu9y/QMMLkd2hfepksSZgUA3YviAOhGTab4X/rN6zcXCoO/4aUd0UB1TX+SqHyiaHJKnBRS8AMAgDYwk3lnMheFUX7DiEqTs7I4fjYaHb4+ieNbbzxv15fTg5kVAHQvigWgizQb7X/7o596U24g/7PlE7Pvy28c2+znS0rmqmv6K937wk6+ZgAAsI6kywRMOReFyo8NKZkvq1wsfck5u32+OHdtbYkAswKArkMAAHSaye3auyfINtK59JvXbx4YLLzPzP3swhT/Gdb0AwCA7lFpIpjIFEYjgy4YyKl07MRzudGha/186fYbLnjXl9JDd+zbF912CUEA0GkUEECnmLkdt14V3rbz6rrR/nAg/7PJidn35TeObvbzZZWnK1P8JYWuOsWfn5wAAKAbLOwibIlMFkRhlBsbVjJfVlwsfcmc3W4zuub/bPulw5XDzO3auzdgeQDQGQQAwFpL1/dXp/lf+sjHxwaS4KeCQv7fy/SmsJBXuX60nyn+AACgN5iZVWcF5NJZAcenj8rbXw+f8yMf+uTYzvogYNdun/Y7AtB+BADAGtm1Z0+Yneb/xgeu3TQQDn3Qmf1WEIZnhoW8SlMzJudo6AcAAHqeyRJnMpeLomhwQL4cT7kwuCspx//zprrlAVdGt11yFcsDgDVAgQG0WWPh/wtT+86cefKZ31LgPpgfH94UTxfly7GZ5J1jtB8AAPQZs8oAh3NRODQg8yY5fcnPlf7HfOj/5YsX/sqUVNk9gIaBQHsRAABt0lj4v/3RT70pzEW/a4l/TZCLxuLivKwcx2K0HwAArA9mZl5mQX5s2CVzJfkkOWzOfWg+mf3rL7/sfUclggCgnSg6gFXWWPj//GP/+00K9Lvm7VIXOCWz8zKzWGYU/gAAYF0ys8RJQZCLXDQyqNLkzFHJ/nrO5//myy/bTRAAtAnFB7BKliv8yydmTc5559jCDwAAQFJtK0GXi6LcyJBKk9MEAUAbUYQAp+kkCn/W9wMAADRDEACsCQIA4BRdaRZcLRmFPwAAwCpZaRDgdiYS2wcCJ4sAADhZZm7rxDXRxLYryhKFPwAAwKqrCwKa9wjYZXvCvW530uFXCvQUAgBgpczcDt0a3uZ2xpL01u/+wxuiwcH/KG9vqhT+RZNjKz8AAIBVszgIOOIi97c3/dcb/1B79yayK4Ndey9ye3cTBAArQQAArMCuPXvC9AfLz33jY2cMD4e/LWe/nxsdCkuTM16SUfgDAAC0SRoEhGE0cMaYyrPFL/vY/+VNF7zrS9X7K3UN/QGAJREAAEvINvh7413XbhoYL3zQSR/Ij49sKh2flplPnAso/AEAANaCmZkU54YHc2Ym59wXkyT5n2kQsPXeD+cmtl0Ri/4AQFMEAEAzDev83/7Ip94aBO6j4UDujPLMnKwcx5IL5TiHAAAA1pp585K53MiQU+AUzxQ/F0z7X7vxVe85ItEfAGiF4gVokJ3uX1vnn/g3WZzIx0lZZpGc49wBAADoMDNLnCmIRgouLpaOBGHwNzf+/mf+qNIfgGUBQCOKGKAqO93/577yN2cMv2BjZZ3/yFBYmpw255wo/AEAALqPyZIgCMO0P4BZ8hc3nvcLX5ZYFgBkUcwAqv1gWDTdvzQ5wzp/AACAXpDpD9B0WUBmliewXhEAYF2rjPrvN7mrffPp/opY5w8AANA7GpcFuMD97U3/T2XbwK333pub2Lat3OnXCHQKhQ3Wp2yTv127wrf/wTt+X2b/dzQ8GDHdHwAAoPdllwXEs3NfKZ8o/tnnXvHur8iuDHbpIkeTQKxHFDhYd7LTv962/xOvj4by/zkaKrxh7rnj3swb0/0BAAD6hJmZKc6PD+fK07NJEIZ/SJNArGcEAFhfzFzzJn8zZRe4XKdfHgAAAFZftaeTK2zeEMSzxS/7TJNAtgzEekIAgHVhl+0J92qXyTmfNvkLBnJnlCdn5M0ngQtCol8AAID+5FTdAsCsnDYJLM8UPzd74Piv3fyGDxzJNoQG+hkBAPperdnLrl3h2/7wnZ8JB3Jv9fNlJXFSdjT5AwAAWFfSJoHh0IAzuaPl2Zl3f+EVv/Z5mQW79u517BSAfkbhg76V7fB/+f6PvT43NPSfgzB8Q+n4tHdOjiZ/AAAA65nF4UA+SkrlWFHwx5/7r+wUgP5HAYS+tGPfldFtO6+Oq6P+/9WS5PdzI0NheWomlnNRp18fAAAAOs+8mQucFTZvCMqzc19J0p0Crrwy0FVXGQ0C0W8IANB3rjQLrnbOv/mbH3nDwMbR38vR4R8AAABLMG/ldKcAF4Z/OHnwBX98286dMQ0C0W8IANA3so3+3vH9T77FvLsxyEVheWqWDv8AAABYUrpTwODzNwWzh458vvT0/Lu/fOn7jtIgEP2EAAB9oWHK/2fCgdxbk9l575PEXMCoPwAAAFbAJJOVo8GBXH2DwCsDiSUB6H0EAOh56ZT/y7/zsdfnRusa/QWizx8AAABOkplPosJAmJTKsQvDP2JJAPoF1RF61uIp/7oxyEVhfGKWRn8AAAA4LWmDwMqSgKOfLz393Lu/fOl/ZEkAehoBAHpSLX3dtSt82x++/TPhQJ4p/wAAAFhddUsCdLQ8W2RJAHpa0OkXAJysXQ/sye91u5PLv3P969/xp7v/ORoafGv5RNGb9wHFPwAAAFaNk5xzubg4nzizTWEY3vjWBz9x1Y6rFMg527FvH7NO0VOYAYDeYeakq5zc1f6y73z08txQ4aYgYso/AAAA2i9dElB4/qZg7rnjn//cpx59m66+2tMXAL2EGQDoCTv27YvknO24SsHbHvqnK8MwvNFiT/EPAACANeEC52QKigcOl3LDg5e/41df9sXLv3P96/e63cmuB/bkO/36gJVgBgC6Xi1VvfLK4K3vuuCzhc0bLp87dNTLzMnR5h8AAABry7xPcmPDoY/jpDw793b6AqBXUDyhq6VdVi//zvWvz42O/ecgDN5QOn6i5FyQ57sXAAAAHWMWu1wUWZLELoz+aPLgw398286rY5kFcs53+uUBzbAEAF1r15494cS2K8qX3ffRy6PB4S85pzeUjp9IXEDxDwAAgA5zLrJybDIFA2eOXTX2/Atu3LVnTyjn/C7bQ2NqdCXKKHSfTLO/tz/yibe6ILjBl31gcexZ7w8AAICuYpJk8/lNYwPzx098vvTUc+/+8qX/8eiuPXvCvbtpDojuQgCA7mJXBrpK2nGJgrEXXHBDNJB/a1Kc9z72zgWs9wcAAEB3MvNJNFgI5XS0PDP7K59/xa9/IV3O2unXBqRYAoCuke6juuuii9zY8y+4MT86/Nby9GxiiQ8o/gEAANDNnAvCuDifWOw3RUODn73svo9ePrHtivKlj/zVQKdfG5AiAEBX2GV7wtt27ozlpLlXlG7Kjw1fXjo6VXYuCEXtDwAAgB7gnAuT+bK3snf50cEbL/vOxy//4oW/My+7MqgscwU6iwAAHbf13g/n9rrdyeXfuf7173jsoi/lhgYvLx07UZZzuU6/NgAAAOBkuMAFPo5lcRKFod34tof+6codtyqQc1bZKhDoHFIodFRtm79vfuSyaHToc0EUBqWpmSQIg9DYQRUAAAA9yDnJvJmcs8HnbwqKh49/fvD+/Nv37t9vukqSu5ptAtERBADomIXi/2OXhaP5z1o5cRYndPoHAABAf8jsEFCanPn84H5CAHQWAQA6YnHx752PYznnmBYFAACA/mJWzm8ay5UnZz5fIARAB1FsYc1R/AMAAGBdcS5XOjpVzo0PXz53UemmXRdd5HSVRE8ArDW+4bCmLn3krwYmtl1Rvuzej15O8Q8AAIB1o1kIoIWtsIG1wBIArA0zJ13l5K72l9330ctzI4M3+nISUPwDAABgXUmXA5yY+fzn/tUvv02S32V7wr1ud9Lpl4b+RwCA9rMrA7mr/Y59V0bjL7jg//Zx8l9dGEa+HHuKfwAAAKxD5dzYcM6Xk6/GU9N/8vlXvver6TLZTr8w9DcCALSXXRnoKmnXRRe54kVzNxXO2nj53KGjXmZOzvH9BwAAgHXJvE9yY8OhLyc+mS6+9fOv/PUvEAKg3SjA0D6VIt927dkTFi+auyk/PnJ56ejUvOQG+M4DAADAumcWuygKXC6weHL27V/Y9huf37VnT7h3N8sB0B6UYWgPM7d14ppoUzSYH4js0/kNo5eXjk6V5Vyu0y8NAAAA6BZm5oMokosCi+fm337xy5/45+/qIkdPALQD66/RFpc++tf5iW1XlAcU/6fB522qjPxT/AMAAAB1nHOBL8eStzCMwj0Tn3thYa/bnciMWg2rjhkAWHXp2qXL7r3u8tz48Kd9Oc5bnESs+QcAAACaM/NJNDTokvnyFwb3D7xj7/79pqskuat9p18b+gepElZVtviPxodusjgZtjLFPwAAALAU54Iwni1afnz4LXMXzd2066KLnK5Spak2sEooyrBq0uL/8m9+5LJwtPBZK3vn41hs9QcAAACskFk5v2ksV56c/nxhf+HtzATAaqIww6qg+AcAAABWgXO50tGpcm585HJmAmC18U2E00bxDwAAAKyiliGAMYMbp4VvIJyWXbYn3Ot2J5fde93l0djQTRZ758uxXOACWadfHQAAANCjnCrLATaO5UqT058/8dyWd0i36rZLrkrkHFfaOCWM0OKU7di3L9rrdidv+db1PxOND99k5aRS/DuKfwAAAOC0mCRVZgLkN4xePrLpiRtu23l1vHXimqjTLw29ixkAODXVNUi79l7k5l42ty8cKLw2np6N5RxvSAAAAMBqcipHw4O5uWOTb/vi1vd9Ll2C2+mXhd7DDACcPDOnqyrFf/GiuZuiocHXlk/MJBT/AAAAQBt4i5K5+XhgdOSGy+697vKJbVeUt9774VynXxZ6DzMAcHLM3I5brwqlSzS2+akbc+Mjl5eOTpXlHG9AAAAAQLt4by6XM5cLLJ6affsXtv3G59N+XJ1+aegdBAA4Kel0o8u+/dHPFs7Y8Nb5I5Nl51yOJf8AAABA+1R6App3UaggH1lpZvaSL/7Ee+/YsW9fdNvOnXGnXx96AwEAViwt/i+duPatAxvHPxvPFMsyMfIPAAAArBWzOBoZipL5ua8NPlDYuXfXfpOuMnYGwEoQAGBF0ulFb7r3ussHxoZv9HEsKyehnON7CAAAAFhD5n2S3zASlqeLnx+6qPD2Z2/d79geECtBE0AsK93u79JvXf8z+fHhm3w5DqwUU/wDAAAAHeCCICxPzpTzG0Yvn/nOzGfYHhArRQGHpZk5OWe79uwJi2z3BwAAAHSP6vaA89XtAWkKiOUQAKA1M7d14ppoUzSYz4f26dzo8OWl4ycSFwRhp18aAAAAsO6ZmcuFSRCFKs8W37n9M09+4btXXeQIAdAKSwDQ0vn//Nf5iW1XlHOK/9Pg8zZdXp6cnqf4BwAAALqEc87KSWCJRUEu9+n/s/WFhb1udyK7kjoPTTEDAE01NP37tC/HeYuTiHX/AAAAQHcx80k0NOiSUukL089uead0q2gKiGZIhrDIjn1XVpv+faza9C8ZtjLFPwAAANCNnAvCeLZo+fHRtwxveuKG23ZeHe/QrczcxSIEAKhn5qRLtGPfviiK3H8LgjC0OI4VUPwDAAAA3cq5ICwdmyrnRoffeund1771Nrcz3mV7CAFQhwAAdXbcemt4286d8fCmJ26IRodeWz4xk9DxHwAAAOgB3qKkOB/nN43ecOm3PvYze93uZMe+K7mWRw0BAGp22Z7wtp0740vvvvatudHht5YnZ2Ka/gEAAAA9wjlncSLngiiK3H/bsW9fJF1SneULSKRBkFRb9x9f+q2P/Ux+eOCGZHY+lrdQzPwHAAAAeoiLylMzSX7j6GuHy0/c8IWf/LW37di3L7pNijv9ytB5zABA/br/0P0354LI4kQ0/QMAAAB6jwuCsDw5E+fGqv0AdtIPABUEAFhY97+Bdf8AAABAXzALk+J8nN9IPwAsIABY5+rW/Y+x7h8AAADoC9l+ACH9AFBBALCO7bI94V63O7n0Wx/7mfzG0RuS4nwsM4p/AAAAoB84F5VPzCTR6NBrhzc8ccNtO3fGu/bupQZcx0h/1iszt3XimmhT9KP5XHDon3PDg6+NT8zGTP0HAAAA+k4cDReiucni27/0yvd8bpf2Bnvd7qTTLwprj/Rnndo6cU00se2Kchg/858Gz9zw2vLUbJniHwAAAOhDpiCZL/soH3zyLROfG3yp9puuvJJacB3iH30d2rHvymhi2xXlS7/1sZ/Jjw393vzRqbKj+AcAAAD6k1Pgy7GFA7lBHx755NXuar/jkkuoBdch/tHXm4Yt/4IoHPZxHMixHAQAAADoV865MJkr+dzY8NvYGnD9IgBYZ3bt3Rtkt/wrTU4nztH1HwAAAOh73oLGrQEJAdYXRn3Xkz17Qu3enbxp4u/fVhgfvCmemYslMfUfAAAAWC/M4mh0KCrPFL9W9u7NGx4pzO3dtcvLOev0S0P7EQCsF2buSl3l/mX/RRsiP/tUEEUFK8WSYxYIAAAAsJ6YWblw1sZc8YfHrv7nn/i1q7dOfDia2HZFudOvC+1H8bdObJ24JrraXe2D0onfzo8ND1o5Tij+AQAAgPXHSVHp2FQSRsEH3jLx2cGJzx1I2BVgfeAfeR3YZXvCWtf/0aH/XD4x62XG1H8AAABgPXLO+XKisDCwyYeHP6mrr/a7LrqI2eHrAAFAvzNzj00cC95w8EvDQaD/FoThsCWJ5BwnOAAAALBOOefCuDiX5MaG3vamib9/295duzwNAfsfRWCf23rvh3MT264oX3rvR64cfuGmq4o/PFZ2gct1+nUBAAAA6DCTd7lQ5v2cm9+4+f98bmJOknT11b7DrwxtwjTwPrbL9oR7r9qfXP7tj782HIz+0/yRqbJzLhL9PQEAAABIgS/FSTRUGCyXD39SV1/99l179oR7O/2q0DYsAehneyVdfbU3H/9hEEUjliROzPoAAAAAUOWcC5PinB8YH3nbZRN//7N7d+9Oduy7koHiPkUx2K/27Am1e3fypom/f9vAcP6meG4+cXKs6QEAAABQx8ySaGTQxcW5O8s+ePOGRwpze3ft8nKOucN9hhkA/cjMXblrv73xgT2bwkif9HFiTjT9AwAAALCYcy5MpotJ4YwNr40s+b29u3b7rRPXMAugDxEA9KGtE9dEV7urfVA68dv5seFBi5NY/FsDAAAAaC0qHZtKwjD4wFsmPjs4sfX9sa68khqiz/AP2md22Z5w4nMHksu//fHX5keGfq98YtbLjPQOAAAAQGvOOV9OFBYGNiXB4U/KOdt10UXMIu4zBAD9pqHxn7w3Oab/AwAAAFiacy6MZ4sJDQH7F4VhP6HxHwAAAIDTQEPA/sYMgH5h5rRrt3/jXdfS+A8AAADAKVnUEHD37oSGgP2DAKBPbJ24JpKTRUO5D9D4DwAAAMBpiEpHp3wQuA+88a5rN01suyKWGYOLfYACsR+YubdsPZC88YE9m5zTB+Ppomj8BwAAAOCUOOcs8Ul+fGRTVMh9QGZiFkB/IADoA3Xb/o2PbLLExzT+AwAAAHDKzKLyiVkLIvfBt0x8jm0B+wT/gD1ul+0JJ7a+P063/StNzSSM/gMAAAA4Lc45ixPPtoD9hUKx1+2VtNuZ3feRPwyigZHEp6P/NOkEAAAAcKqc5BSWZ4vJwPjw2y795vU79v7k7tt32Z5wr9uddPrV4dQQAPSw9OS79JvX74iGCzvmJ6cT51xE8Q8AAADg9NRqCvPemzO7Wk6XaE8nXxNOF0sAetneyh+Vk5F9OQEAAACsuqg8U/TR6NCOS795/Y69u3cnu2xP2OkXhVPDDIAeVT/6P7ijPF1MnFzI4D8AAACAVeMkWaUlgDO7WtIl6UAkeg8zAHpVOvrv7WrnnFH4AwAAAFh1Jjm5sDxd9NEIswB6HTMAetCi0f+ZYuKc4wQEAAAA0B7pLADPLIBexgyAXsToPwAAAIA15JwL6QXQ+5gB0GMY/QcAAADQEcwC6HnMAOg1jP4DAAAA6ABmAfQ+ZgD0EEb/AQAAAHQUswB6GjMAegmj/wAAAAA6iFkAvY0ZAD0iHf2/bOLvfzYcyTP6DwAAAKAzmAXQs1ynXwBWZteePaFeqnC6NP2V3Mjga8vTRU8AAAAAAKATTJZEg4WwXCy96Ys/+atfTgcsO/26sDSWAPQCM7d39+6kOHdszAXu1fHsnBz/dgAAAAA6xMn5sJA3Z/5SSXps4hj1SQ/gH6kHbJ24JpIkr9xv5cZGQsnFco7ZGwAAAAA6wywqT83IBe6X33jXtZsmtl1Rlhk1SpcjAOh2Zm5i2xXlN9517SZFwQfjmWIo7+ndAAAAAKBznHOW+Dg/PrI5KoQfkBYGLtG9SGi63NZ7P5w777GNfvqCmd8f2DByZen4dFlSrtOvCwAAAMA6Z2YuFzpL/FHvh1/yxVfuPiwzyTn2K+tSzADoZpXR/1gvVSjzv1WeLkpmpGoAAAAAOs85Z7Ev5zeObgrdzC/JjFkAXY4AoIvt0t5AZpqZn311NDw4ZkmSsPYfAAAAQLcws8DPl+UT/2Y5Z+c9ttF3+jWhNdKZbrZX0m5ndu91f+CCQt4Sn7ggkIwZNQAAAAA6z0lheaaY5MaG3njZxN//7N6tu29nS8DuRQDQpdKT5tL7rntjVBjcUT4xkzjnQop/AAAAAF3Fm2Rm5vwf7nrgyjdoryj+uxRLALpUuo+ms+DSsJA3J8dUGgAAAABdx0lBPDsn59yryzNnju7dvTthS8DuxD9KNzJzcs4u/eb1m50L9rvAbbY4Mdb/AwAAAOhScW58xJUmp/9w9Hsjf/Tsrs3uNrcz7vSLQj1mAHShrRPXRJUQIPil/MbRzZb4MsU/AAAAgK5lFiazxVBmv62X7g9vczuZBdCFCAC60HmPbfRyzizxb/bzJZkZ/04AAAAAupdzzsdJEg0XxqaSc18lyXZpL3VMlyGR6TLZ5n+5waEvxbPFRHJhp18XAAAAACzFzJLc6FBYni7ePvq9H7xBuijZu5vdALoJiUyXSZv/mQWXBgM5E83/AAAAAPQAJwXxTNGcc68un0szwG7EP0Y3ofkfAAAAgN5GM8AuxgyALrJ14ppIkmj+BwAAAKAn1ZoB6ref3by/UvwzC6BrEAB0kfMe2+jff++Hc87szX6O5n8AAAAAeky1GWA4lB8bGj93pyTRDLB78A/RLczc3t27k4P5YJOk18XFeTn+fQAAAAD0GpOPBgt5SZft2rMnTPucofP4h+gSWyeuiWTmykn0C7mNo05mTP8HAAAA0HvMovLUjMzbL+il+8OJbVeUWQbQHQgAusR5j230cs4s8W+2Ujlk+j8AAACAnuScsyRJopHCpqnk3FdJLAPoFqQwXWCX7Qn3ut3Jpfde98bcyNCX4tliIrmw068LAAAAAE6FmSW50aGwPF28/Rxffv2xxzb6vbt3J51+XesdKUwXeGziWLBrz57QReGlwUDOJOc7/ZoAAAAA4FQ5KYhninLSqw/mg017d+9OWAbQeQQAnWbmJrZdUX52835nsf/F8olZJ7Oo0y8LAAAAAE6Zc06mcm7jaBjH4bukzLbn6BgCgA5L18IMjZ+7MxoubLIkSWj+BwAAAKDXmVlQ7W92+fvv/XDuvMc2MtO5wwgAOuyxiWOBzJwP3JvDwYGcTJwUAAAAAHqek4J4dl4uCHY+Pp9sZBlA5zEFo5PM3IRz5R37yiNubPCXypPTkvlITAAAAAAA0OucnGTl3PhIYD75NUl/snXimmhCKnf6pa1XzADoAvmNwZAL3JDMOv1SAAAAAGD1mMk5hRZow649e9jprMMIADoobYIRWvSL+fGRYfO+zPp/AAAAAH3DLCqfmJVL9OvPbt7vJrZdUWYZQOcQAHTQeY9t9O+/98M5+eAyXy47M+PfAwAAAED/cM5ZkiTRcGHj0PjZO6WFRuhYe3zhO8XM7d29OzmYDzY553bGs/Ny/HsAAAAA6DcmHw4O5CR32a49e8LHJo5R93QITQA7JG1+EcfuXdHGUVc+dqIs53Kdfl0AAAAAsKrMotLUjLzXLzy7ef/vTWy7urIMwDmaoK0xkpdOMHPnPbbR77rrLwbNucttvhwy/R8AAABAX3LOWZz4cGhg09D4C98gSdrLMoBO4IveIXt37040NpVYYjuSOab/AwAAAOhjZnFuZDBnCrdL0ktfup8dATqAorMD0qYXU6VzfjYcGkhMSjr9moBuZTKFzolWsQAAAD3MKYxn52SmV73/3g/nvnuR4k6/pPWIAKADHps4FsjMKXCX5YYLg/Lm2f4PaC5yoSbjeZXNK3QBQQAAAEAvMgVJsSQXBG94fD7ZKHe1ZzvAtUcTwLVm5iacK+/YVx5xY4O/VDo+LZlFov4H6oTO6Xg8p199wTadmR/Sxw5M6NnSjIbDnHJBKG/0jAEAAOgZzjnJyrnx0UDe/5qkP0kbo3f6pa0nzADokMEwGVTghkQNA7TglJhpKMzpHZsv0t9ftFu/efarNR4VNJuU5OQUEJwBAAD0DpOcU2jSBkb/O4MAYI1tnbimMutidPjXc2PDw+Z9men/QHNOUmKmxLzGo4J++QU/qY+8dJd2bDxPM0lJM0lJgSMIAAAA6AlmUfnErKTgvTtu/dDwxLYrygQBa4sAoBPMnHltcFQtwLKcpNAFis0rMa/RaEBXnfcG/fmFl+visS2aTcqajksKmBEAAADQ/bzJBRocDJPBTr+U9YgeAGsps/5fo0PvLU/NSp71/0BLmSUyaRCQ3nTx2Nm6eOxs3T35lPb+8H7dO/W0vEwjYV6S6BEAAADQdZyzxJdz4yPDZe9/XfQBWHPMAOiAwTAZdIEG5SlQgJPlqr+8mUym7eNb9GcXXqY/ueDN2p7OCEgqMwLYPBAAAKD7uMA5M/oAdAIBwBqqrf8fZv0/cLoCVynwG4OAP73gzdo+draKvqyyJYpcQBAAAADQLegD0FEEAGvNzJmx/h9YLY1BwMXjW/RnF16uPzr/TRoOcjpWmlXsE4XEAAAAAN2BPgAdQwCwVszcxLYryjtu/dCwFLy3fGJWMqMHA7BK6oMA6TUbztU/vuIX9G+3vFrj0YCOlRuCAFbgAAAArD3nnHlfzo0ND2t4+NelzExptB1f6DU2OporxIEG5X31FqoQoJ6TZJJlfp2EdHJN2hDwl1/4Sr39rIt007P7ddOz+3VgflLDYV75IKqFBQtTA9IPOC8BAADao3K95QJV+wDIaaLDL2kdYQbAGklTrdhFV+TGBqvr/5mRDCxivlr0p79OTSAnk2pbB/7yC1+pj7xst35zy2s0HhUqMwIsqbwJ1oIGf1r/TwAAACzHJPNR+cSM5PQbr5/48Bh9ANYOAcCasziIQr65gWZWufbObh1YHwT8m1oQMOtLcqrOHDCd9IwDAAAAnAKT5P3AMU3MdvqlrCcEAGvBzE1sPZDsuusvBiXtjIvzkoyvPZBlpzfiv5SlgoAdG1+kmaSkmbikwLlqEHDySw8AAACwcubNR4OF/Fl+6+slSXv3Uh+tAb7Ia8Vd7fX0VGLedvq5smR87YGaNSq2mwUBV53/Rv35i9+qi8fP0WxS1jRBAAAAQHs55+R9HI0ODVgQbpekl750f9jpl7Ue0ARwLVTSrGTqvB/ZGQ4OJH6+7CXW/wOdkg0CJOni8S26eHyL7p58SnsPfUf3Tj0lb6aRKC9J8mkIwO6dAAAAq8MpjGeKMulVlz7yVwNfvOBopQ+Ac4y+tBGj0Gtg63nHql/n4JLcyOCgvCVyVBKApCVH2Ns9+O6qvyq7AZi2j2/Rn734cv3JhZdre3ZGgCpbDJ7qzgQAAABoYAr8fElyen0+Gc7LXe2XfxBOFzMA1orJ2YTFPk5Ef0ugapnif63K7NrWgWZyTto+vkXbx7fonsmntOfQt3Xv1NMKXaBCECkxX3ldzAoAAAA4Pc5JTrN+Jh6QdKLTL2c9YAZAu5m5iW1XlC/9xl+Nyrl/W54uSmYEL8AS1rL4zwpcZaQ/nRFw8fgW/dmL36I/vuDNGg7zOlYuKjav0AULa3iYDQAAAHDynHOW+HJubHhsXrn3SQtbp6N9CADWyOhI6GUqUCwAVa3OBVvy0zVRHwRIr9lwrj7xil/Uv93yUxqPCjpWnq0PAlgWAAAAcEpc6JyTz3f6dawXBABrpDiXKyhwrGsBltFNZXQlCJC8TCNhXr/ywlfqoy/7N/p3W17TOggAAADAynmTnOVlNElfC0yxaLOtE9dEE1K55KIr8mPDo+XJ6bLkcl1V5QCdkj0PXKZ+rv3ZHSPrgZxMkq9uHfjLL3yl3n7WRbrp2f268dkHdGBuSmNRQaELlHhf3eOj+jMs/VHW+b8GAABAdzGLyidmJQXvf/3Eh//0q9uumGQngPZiBsCasTgIAkcRAKjpIn/zqtxWu727Tpbs1oFJJgj46Mv+jf7dOa+RkzRZLiqQU5DdMSD9ewEAAGAxk5QkA+dpYrbTL2U9IABos4mtB5JLv/BXA/LaGc/NSzK+5sBJ6a7ZYK2CgD++8M169cZzNeurWwc6V91doDtmMQAAAHQdJ5lZEg0V8o9r+05J0t691EttxBe3ncyc3NW+OOgHXeBe5+dKkvE1Bxotro+txcfdozEIeOXYj+jPX/wW/emLL9erNpyj2aQhCOiS5QwAAADdwznF5qPhwQEn/ZwkbT3vGPVSG9EDYE3kYvN+xkXhhk6/EqDjli2CremH3SoNAryZnJO2j2/R9vEtunvyKe099B3dM/mUvJlGokpzW5/9+7vumt0AAACw5gLJvJecm+r0S1kPCADWwOhorlB2Qdjp1wH0nB4IAFJBtZhfKggwM41GA0rMV/5qaRhAEAAAANazyjXRkExOE51+Mf2N6RVttHXimkiS5hW8Lzc2PGKJL8txpY917GSmwPdQ8Z9V2TrQyZvJZNo+vkV/9uLL9Wcvvlzbxrfo2dK0ErOFrQMllgcAAID1yywqTxcls/df+o2/Gp3YdkVZZtRMbcIMgDXg5PIuDPgmBpqor3tt4Q9X/aBH6+LGGQEXj2/RtvEt+vgzE/rss/t1YH5Kw2Fe+SCqhQUyYzYAAABYfyo7RBVGR0Lf6ZfS7wgA2s3k9E3Ly/vaDcD6ttQ50Oy+3j5nskFA4Jze/SNb9c7nvUw3PbtfN/7wAR2Yn9RwOKB8EFaCgNqygNpv6vWvAQAAwNJMCuSLc7mCpOlOv5p+xhKAdjFzE9uuKL/tzutGZHp/eXpWMk/ggnVuBYVs7RAvme+2XQBPWRoEZLcO/OjL/43+3Tmv0Xg0oGPlWcWWKHROrrZ1oBfFPwAA6GtOzhJfzo8Nj85L75MWllJj9REAtNls4XDgTAXW9wKLLXla1O7rkwSgKrt1YCUI2KqPvvxd1SCgoGPlWVn1OJnoDQAAANYFFzgXOFfo9OvodwQAbbaxMJLIKen06wC6X3bqe+WPuk75fSTdOrBVEOAkTZaLCpyrzBygSSAAAFgHvLm406+h3xEAtFlxLleQ4+sMrNg6qnNbBQF/fOGb9eqN52o2KWs6LhEEAACA/ldpnFyQ9dn0zy5DYdomC1sA6n25sRG2AARORtr8f53Uuo1BwCvHztafv/it+tMXX65XbTiHIAAAAPS32laAev/b7rxuhK0A24fmCu1mruACCn9gRdKadp2eMWkQkG4duH38HG0fP0d3Tz6pvYe+o3smn5I300iUl1TZWWDhwev0iwYAAPpDdSvAUjTDRU0bEQAAWCMr6PiXLvw3W9cFbXbrwFZBgMk0Gg4oMb/QK6Fu60AAAIAe4+SLA55Z6m1EANBm+SCckXOV3cwCZu1iHWvyvd/yfDDJZDKz2uPW46nTKgi4Z/Ipfergt3T70ce0ITeovAuVyFfeZ1zlK2VpgLIev3AAAKBnpKsbJcl52S9qaOa2zr6kvka60iYTWw8k53/hrwYOFE+8Li7OyzkFngtxYGkmCtYmAufk5OTNZDJdPL5Ff/7it+q3z/1pjYUDOlqeVex9betAM0ne+FoCAICuVyn+nUJzSTHvCn82N7lTkrR3L7VqG/BFbQczJ3e1H88VC1PJ/OuemTyiOR8HoXNcjwPL4SRpKRsEOCe950e26e9fUdk6cDwq6Fh5VrFVggAnVX+i8gUFAADdy0kyJ3d4btofjsoDzvQ6Sdp63jFq1Tbgi9pGk+WihYGbKVqsA3NTmo5LCqvTcrkkx3q37HIYateW0qUB6daBv/IjW5sGAZUdA8TaIwAA0HVMqgxsyPTs/LQOl2Zk3st5zXT6tfUzAoA2Kg8qkCkIVBm1OzR/QofmTsi5ygU8l+QATkd268BmQcBMXKruLMDWgQAAoLvkXKDZpKQni5Oa9SVFrlKaWkCfunYiAGijMx85OCOTVefiKnRO00lJB+ZOaC4piyUBAE5XunVgsyDgkjNepJmkpOm4pMC56owAggAAANA56aZPh0szerY0LS+TU7Uuck7OmAHQTgQA7VBtWDH5kvN3usFcwRKfSJVv9NA5zSVlHZg7wZIAAKumWRDwBxe8SX/xkrdp+4ZzNJuUCQIAAEDHLJryX56t3lYT2FxJJr3u/C98YGBi64GkU6+1nzG9og22nncsmJASF+h1wdDAQDxbKrvAhVLlGz+d/n9o/oRG4ryeVxhZaOzV2ZcOoMdlgwBJ2r5hi7Zv2KK7jz+pPYe+o3smn5I300iUl1TZYrDyQN59AABA++RcoBPxvJ4tzcjLK5e5XpEkJwU2X5ak1/ncjxTk/j/zlebqjhGLVUQA0EbOa0be1FjVp9/B6ZKAZO6ENuUGNRjmlBACAFgF6ftIumPA9g3naPuGcxYHAWG+2icw87OVMAAAAKwSJ8mrMuV/Mp6Tlxam/C862MnJZoJykaK/TQgA2sktvcSibklAEut5AyMaifILI3IAcJrSHQOaBwHf1r2TTyt0gQpBpMR85YcxswIAAMAqcM7Jm9ez8zM6kcwrSrcqXhrL1NuIAKDDmi0J2DwwrEBBtSEGAJy+VkHAXcee0P/3sX06XJrRUJhTPojkCQIAAMApStf1B85pOi7puRZT/tEZpCtt5bWwmXnrX1Y9FQLnNONLerJ4XLNJSTnHPw+A1RU4V+s5YpJes/FH9U8//ov6zXN+SuNRQcfKs4rNK8wm9MxKAgAAK5AObjonHZqb0qH5EzL56pT/5euihV9oFyrMNrJllgA0HC1VR/y9TM+WTuhwqbIDRsB2gQBWWSUIULUh4MLWgf/unNc0DwLYNQAAACwjckF1x7MpTSclhQujCSf1POVB6tR24QvbRs40cypTZ9O9MY+UZ3RwfkrFpKyQEABAG6QBY7p1YKsgIF1CQAgAAAAa1eqX0mnWL5UnsjMfOTiz6i8SkggA2mJi64Hk/C98YMDkXmdzJekUv851CVpcUsg6XABtkN06sFUQMBOXqse5hdkAZAEAAKx7zrnKDOb5EzpcPr0ZzJb4xA3mCpMv+dGdkqS9e6lXVxlf0NVm5uSu9j73IwVJr7P5stwpfp3r1tDMT+nQ3AmZrPW2GQBwGpYKAi4540WaSUqajksKnKvOCGBZAAAA61H60z9wTjPxfKWHmT/NHmbOOUvMB0MDAy4IXidJW887Rr26yviCtklQLprTqS0ByKo7ufw8DQIBtF2zIOAPLniT/uIlb9P2DedoNilXggBVgwBmBAAAsG40b/S3SoOUTlJicl4sAWgTtgFsJ1Owmo0snRam18z7WBuiQQXOKTG2C0QPaDwPmp0XjecLjWA7KhsESNL2DVu0fcMW3X38Se05+B3dM/lUtYlgXlKloWBt7x/elQAA6EuRCzQbl3S0PLuw1n+1rtes9iejnW1CANBjsg02iklZm3JDGgrzSsx3+qUB6FNpKe/N5Jy0fcM52r7hnLogwMw0Gg0oMV+9CKj+BKd3CQAAPc9U6QPkzXSkNKPjcVHejEblPYgAoEdFLlAxKeugn9KG3KDGo8peGZyAANol3QlgcRDwlD518Fu6/ehj2hgNKheE8uYr70dmzAgAAKCHpcV/MSnraHlWs0lJoQvYqrxHEQD0qPRENEmHSzMqJbE2D4wocIGMplwA2mhxELBFF2/Yon94+l599tn9OjA3peEwr3wQVYKAdEYAswEAAOgpTpWf+9NxST+cPyHJFGWWB6L3EAC0kTX8uZqcJF/9M3KBZnxJs8Xj2pwf1kg0IDPjxERXW+7700QLgG6XDQIC5/Ses7fp55//ct34wwf0mUMP6MB8JQgYCKLq0oBqvxJGDAAA6ErpcmOpur2feT03N63pZL76c9/VapB2/CxPr/1Y3Nw+NFfoUdlwofJxpUHgofkTOjR3Ql4mx2gbgDWQBgHZrQM/9uPv0m+d+xqNRwUdLc8qNl9rKMgsJQAAulNaeKfb+/2geFzTfl6uGt63c4ATa4MAoI+kU3TS7QJn4vnahTkAtFvj1oGNQcCx8mztuNrWgQAAoGtU1vWbDs2dqNveD/2DAKAPVfbgXJgNYMwGALBGslsHNgsCnKTJclGBc5WAkiAAAICukI76P1k8rhnPQGK/ogdAH0tnAxSL5VpvAM+FNoA1kA0CfCYIuGjkefrEgft0z+TT8mYaifKStPDexMUGAABrKl3rfyiz1p9R//5FANDnsrMBRuKSNg8Ms1MAgDXTGAS8cvxsvXL8bN19/El9+uB3dM/kUwQBAAB0SKXD/7yeK83IyzPqvw4QAKwTzWYDmFmtiycAtFMaBCxsHXiOtm84Z/kgQCIMAABglTHqv34RAKwjzWYDpBfkALAWslsHtgoCzEyj0UBl60BpoUcAQQAAAKfMpGqhL0b91zECgHUonQ0wVyxrLCpoQ25QgXNK0j26AaDNWgcBT+lTB7+l244+po3RoHJBKG8mU9os0DFtCQCAUxC5QLNJScfKRRWTkhyj/usSAUBbWeZXN6mc7F5eR8ozKvqyNuUGNRTmlVj6ep2673Wjty31/dR4X3aXWb4P+9niIGCLLt6wRf/w9L266dn9OjA3qeFwQPlaEOAlS0OA9KKF7xEAAOpVruVNUuicvJmOlKZ1PJ6TN6/AZTeD66afo1z7tRvbAK5LCydW5JyKSUkH56d0pDwjyWr7fwLAWknXHvrqTKT3nL1NH3vFu/Rb5/60xqMBHSvPKrZEoQvkarMBvLhIAACgmfRaP1AxKS+61u/egUq0GwHAOpeuBZKkI6UZHZyfUjEpK3J8awBYe+n7UZLZOvBjP/4L1SCgUA0CfCUIMFWCAK5dAACow/U9WmEJQDv1WLAWqZoQJlPakBvUWFSobN9Fk0Cshlaz/Btvs2WOwbqQ3TowDQLe8byX6cZDD+gzP7xfB+amau9RifnqyiXWMQIA4JzTbFxZ6z+blBS6QIGceuKSvodqp15FDIQakxRU19QeLc3qqeJxzcTzCqrtQTgXAayldOtAU2ZGwNkLMwKcpMlyUYFzlZEOM2YEAADWrXTHrx/OndCBuSnNMeqPJpgBgKZC5+TTLQNDtgwE0DnZIMBngoCLRp+nTzxzn+45/pS8TCNRXlKloSAzAgAA68FyW/tx5Y5GBABoKt0HwLXYMpAgAMBaawwCXjl+tl45frbuPv6kPn3g282DAIkgAADQt9jaDyeLAADLqmwZaLUtAzfmBjUY5iUzebElN4C1lQYBC1sHnqPtG85pGgRUVgVkAkvCAABAH3DOKTGv4+UZHS8X5c1qo/7AUggAsGKRCzSXlHUgKWskHGBZAICOSi90WgUB904+pdAFKgSREvOVaZDMCgAA9Khm0/0T8wu9cIAVIADAilWW1FbedFgWAKBbtAoC7jr6hP7792/R4dKMhsKc8kEkTxAAAOhRjdP95ZxC51jnj5NCW0ickuyygIPzU5qtrjmSaDYCoDOC6rpHbyaT9JpNP6pP/uQv6TfPfY3Go4KOlWcVm1fogoWlSwSXAIAu51zz62526cKpYAYATstSywLSRoIAsJayMwJGogG9++yteufzX6YbDz2gzxy6XwfmpzQc5hdmBDAbAADQZUyVXbmkxdP9GfXH6SAAaCOvyhSLfj1BnSp/xzSBnPbzKlaXBWzMDSpyTgmjawA6JKheIGW3DnxHkyAgF4TVrQONEAAA0BUiF2imobt/LeCW+nb039Sff69uQgCAU2YNfzbuFrCJ3QIAdFjj1oHNgoDnqj0CgmxoSRAAAOiAwDnF1e7+x8pFJWa1mQDZwpgiGaeKHgBYdemygKfnpnRo7oS8Km9cXE4D6JRsEJBkgoCP/cQvaOcZL9JMUtJ0XFropJzOCAAAYA2kP39OxPN6snhcR0qzkqSIQBqrjBkAWHXpbgGhKssC0t0CxnMFRWwbCKCDms0I+IMXX6q3HH9Knz7wLd1z/Cl5mUaivCQtvF9xAQYAWGWm6misc9Xu/nOLuvtz1YzVRgCAtgrklMh0tDyryXhOm/PDGo0GJIkgAEDHZIMASdq+YYu2b9iiu48/qU8f+DZBAACgrZxUXXrm9ezctKaTeUkLjWy5Ska7EACg7dI3OC/TD+dPaCqe18ZcQYNBXhL9AQB0Tvre483knLR9wznavuGcpkFAZVVA5pKMMAAAcAoCOcXymiwVNRXPKZavFf5AuxEAYE3UtgR0TrO+pNm5kkbCAZ1V3TbQqtsGAkAnZLcObBYE3Dv5lEIXqBBESsxkSnsEOBJMAMCKpD9rTsQlPVeaVmK+0t2fHyRYQwQAqy5zAqdNpExiIk+q2mDLSdNJ2h9gQONRtT9A3depXzc4Wa+W+rdsvK9xjwlgbbQKAu46+oT++/dv0eHStIbCnPJBJG9WmcNk1ff92ugN37cAgIrKOv/Kte9sUtKxUlFFX5ak2jp/aoWMtH7yvtOvpG+xCwDWmNVO7ECVbtxHS7N6snhcJ5L5hQ7c6bEA0AGBc5WtTauzk16z6Uf1yZ/8Jf3mua/ReFTQsfKsYksUukC1Nk3mxfsWAEBamP0aOicvr0NzU3qmOKnZpCRXvc9qO87wswNrhxkA6Ki6/gBzJzQVzmtDvqDhsNJ4KzFjUhSAjsnOCBiJBvTus7fpnc9/uW48dL8+c+gBHZif1HCYr84I8NUeASwLAID1Ki38I+dU9l5T5aIm4znFxjp/dAcCAHRcXX+ApKTZYklDYV4b84MaDvNKzC8cAwAdEFSnaaZbB/7K2dv0jloQcL8OzE9pOMwrF4SVHQMq+6F2+mUDANZY5JwSMx0uzWoqnlPZVwp/1vmjWxAAoKukyehMUtLcXFkbc4MaiwrKBYG8sWMAgM7Jbh3YPAh4QM9VewQE1QvAygN51wKAfpcGxTNJSUdLRc0mJYUuUJSu8we6BD0A0JWi6gXz4dKsnpo7rsOlWSVmipwjAADQUdkgIMkEAR/7iXdp5xnnayYpaTouLfQ0qa3xBAD0m8A5Oec0k5R0oDilZ4pTmkvKilylzOLdH92GGQDoSumbZTqN6kh1GtVYVGixYwAArK3FMwIK+oMXX6q3HH+pPn3gW7rn+FPyMo1ElZ4mnhkBANAXKp39VVu+eqw0p9mkJGlhNitXqehWBADoatlGKomZjpZmNVme0+aBYY1GA5IyF9UA0AHZIEBa2Drw7uNPLh0ESIQBANBD0sK/sszL69m5aU3H85JEgz/0DAIA9IQ0CGi2Y8BQmJcTQQCAzkov/byZnGseBJhMo9FArbmpmBUAAF0vLfxDOvujDxAAoKe02jGAIABAt8huHdgYBHzqmft029HHtDE3WNsxwGQEAQDQhRoL/6PlIp390fMIANCz0otsggAA3ahZEHDxhi36h6fv1U0/3K8Dc5MaDvPKB1F9EEAIAAAdtVzhT2d/9DICAPQ8ggAA3SwbBATO6T1nX6yff/4rqlsH3q8D81P1QQCzAQCgI1Za+HNliV5GAIC+QRAAoJul71HZrQPf8fyXtwgCfCUIIAQAgLaj8Md6QgCAvhM4J6fFQcBw2KQDNwCssfqtAxuDgAd0YH5SY1FBoQuUmK88iCAAAFZdY+F/rNrcj8If/YwAoI0s8wtro9aFW0vPCJAWggAn/o06YbmvOecO+ll268D6IOBluvHQA/r4MxM6Xi5qPFeQJCVm1fc3JyMLAICTlr51Wubz0DnF1RH/yXhOcbXwD9OlW514oetcev3H1759CADQV6zJx676Jj6TlDRTLGkoymtDrn5pQG13AQBYQ4uDgIJ+5exteuno8/WJZ76pe48/JS/TcJQJLk3MCACAk5QWloEqg0TNpvqHjPhjHSAAaCemAHQPl5kREJc0G1dnBFSDgEANSwOYFrD6Gr+ezb6+nC9Yp7JBQGJeW8fP1tbxs/WN409qz4Fv6Z40CEhnMHlL90RdeAKJ8wcAmjBJgZNCOZXN61ipOtXfvAI1TPXnfbSzuBZsOwIArA+ZN5J0z9ZFQUCUaRbIGw+ADnCSIhfUtg581YZz9KoN51SCgGcyQUDU0NOEWQEAsMii5n5xQ3M/VQt/rvuwjhAAYN2q6xGQsGsAgO6R3TqwWRBw9/GnZDKNRQXFllRHrdg1AAAkuvoDSyEAaCvWAHQ/lwkC5qvNAnPakB/UUJiTk5M3X3c8/56naqmvW6v1AZw/WN9aBQF3H39Sn3zmPt1+5PvakBtULggr/UzMq35ZAO9ZANaPSuHvqoV/oqPlOU3F8yr7pEnhz3tjd+Lar90IALDOLbzBLLVrwEKzQKNZIIA1lw0C5KTtG87RxRu26GNP3aubfviADsxNajjMKx9E8uYX1rHyhgVgHVg84j/XYsSfwhIgAAAaLBUEhHJKqhfXXFcDWGvZICBwTr+65WL96xe8Qp85dL8+c/B+HZjPBgEms+q7FW9YAPpU4JycxFR/YIUIAIAWGoOA4SivwTCnkXBA+aDSpCsz2RYA1kz6/pSY12g0oHefvU3vfP7LWwQBvtLgiv4AAPpI+j44E5dUTMqaTuZVovAHlkUAACwj+wNmOi7peFDUWFTQeFRQjiAAQAelWwf6ZkHAoft1YG5SY1FBoQuUpP1MCAIA9KB09mVQLe5nkpKOl+ZUTEryMoUuoPAHVoAAAFihdIpZYqYjpVlNxXN1QUDlIpwfOQDWllPzIOAdz3+Zbjz0gP7x6Xs1WS5qLFeQlHmfIggA0APSwj9ygbysVvjPJiVJqt/Or5MvFOgRBADASVj4IeRqQcCJeE4j4YAGw9zivbkBYI00BgFjUUHvPnubLhp9vj7x9ITuPf6kvLT4fYogAEAXyjb2K3mvyXhWxaSsmXih8M8eC2BlCACAU9AYBBwtzyooOw022TkAANZSNghIzGvr+NnaOn62vnH8Se155j7dQxAAoMtV3sfcosZ+6RIAAKeOAAA4DWl5H1UvtrM7B2zMFzQQ5BQ6J6NPAIA1VpsyaybnpFdtOEev2nBOLQi4+/iTMlWCADNVdwxIH8y7FYC1F1SvmWLzOlGe12STjv4ATg8BALAK0h9I2Z0DinNlRS7QaDRQ1zCQH14A1lJ268DGIODTz9yneyefUuQCDQSRErPKPtnMCgCwhtLGfrNJScdKc5r3ZSVmcnT0B1YdAQDQBukFd2y+1jBwPCpoNBpQ5AI552phAJfXANZCqyDgzqOP679/72YdLs1oKMxVtw4kCADQPun6flddSpkW/tnGful7FoU/sLoIAIA2amwYeLxc1ECQ08Z8QYNhXqGcEvMEAQDWTH0Q4PTTm35Mn3rlr+iGQ/frMwfv14H5SQ2H+cVBACEAgFWQ7qpU9l6T5aJOxPOKzcvMWN8PrAECAKDN0uLeZaa3zRZLGo7yGgxzGgkHlGd5AIA1lg0CRqpbB77z+S/XZ5oGAZWL80pSyQU6gJOXvufMxCUVk7Kmk3mVquv70+skAO1HAACssewPwOm4pONBsenyAABYC+naW29eo82CgLlJDUd55YKw+t5UjTW5VgewjLSwz07zLyYleZlCF9DYD+gAAoB2sswvoEGgSuKdeNOR+VkdLy0sD+jL3QMaz4Nm50Xj+cL5A6yJ7NaBi4KAg/frM4fu13Pz0xoK8wqclJhVc4C+eHcCsErSWY913fzjeU01TPOP5JS+jQB1TJKv/kJbEAAAHdRseUCz3QMqF+U0DQTQXk2DgC3b9I4XvEx/9r19uuW5R+Wc03CUl6TMbCVmBADrWXp9ErlAXguj/XO+XOs3kp3mT+EPdA4BQBsxAQAnK52KWzavw9XdA0bCAQ2GOQ1HeQVy8ub7YlbAcudFGgBz/gBrLxsEJOY1FhX0hy95s976vIv0qQP36Z5jT8pL9UEAMwKAdSU72h9IKnmvyXhWs0lZM3F9N3+uh7FSfK+0HwEA0EUyY2m13QOOlmflym5R00BmBQBot3REL31v2r7xHG3feI6+cexJfbpVEJA+kHcmoC9lR/tNtqipXxoKZI8H0D0IAIAulf7ATC++06aBk0GxblaAYytBAG2WvrdUpvJKr9p4jl7VIggwU2XHAJoFAn0jO9rvtDDaX6yO9puk0Dma+gE9gACgrVgEgNNX+e5xtR+6ifmGWQFRdVZAKJN18ayApc6DVh0COXeAbpLdOnBREPDMfbpn8klFLtBAkKsGk16y6rtRbVYA5zXQ3RbO08r1RFrYm2bieRWTuDran8hlrk+s7lHA6UgXgkrSRCdfSF8iAAB6Qv2P1DRhn4nnNR3PN5kVUOnS3Z1BAIBe1yoIuPPo4/pvj35Vh0szGgpzygeRfHWGUu03+gQAXc1kTUb75zOj/Y1b+BklP9BDCACAHpT+oF2YFbBErwCTPD+aAbRBfRDg9NObfkyf3vpu/b8Hv6PPHLpfB4qTGo7y1SDAKmUCySTQtSqFfyAtsbbfiaZ+QC8jAAB63FK9AobDAQ2FOQ2GudqevJmVuQCwKrJBwEg0oPdsuVg//4JX6DMHv6MbFgUBXgu7B/JOBHRSdm2/malsXrPxXK2T/+LRfgp/oNcRAAB9otmsgGPlWU3GgSIXaDQa0Fg0oMgFCl1A40AAqy7d7sub12g0oHdvuVjvbBIE5IKwunUgSwKAtZYt+qXK9cJsUtKx0pzmfVlJNaFjtB/oTwQAQB9qnBUQm9fR0qyOl4saDHMaCnMaZokAgDZwkkIXLBkEPDc/raEwL+eyWwcSBADt1jjFfzYpazYpqWxeZqbAOYWM9gN9jQAA6GO1WbaSXPXieiapLBHIs0QAQBu1CgLe8YKX60+/d4tuee5ROVfpWyIRBADtsNwUf8nkXFB3nUDRD/Q3AgBgnQnk5NzySwTSzt2EAQBORzYISMxrLCroj15yme5+3g/0qQP36Z5jT8pLBAHAKqkV/XKSW9kUfwDrBwEAsA6tZInAUJhXjn4BAFaJ08J7jiRt33iutm88V9849gN9eqkgQCIMAJbRuK7fm2kmYYo/gMUIAIB1rNUSgZm4pMDNLu4XIFW38iIMAHBq0veOytaB0qs2nqtXZYKAu489KZM0FhUUW1J5nzKrPpB3HiCV/ixeal2/N6+AKf4AMggAANRJlwhktxRs7BcQVg/wIgwAcGqyI5XZIODuYz/QJ5/5pm478n1tyA3Vdgwwy/QiZ0YA1qls0Z8u11tqXX921g0ASAQA7WWZX0APqW0pqOqWgt50LJnVpAuUc4GGwnx9GKAVzAxoPA+anReN5wvnDtD3skGAXGVpwMUbz9HHnrxHNx56oLZ1YD6Iqu8zbB+I9aVl0Z9Uiv5iUq6dP5Wf207pChp+jKLnUDu1HQEAgCU19gsom681D2waBjAzAMApyAYBgXP61XO261+/8McrWwcevH9xEECzQPSx5Ub6a0W/xLp+ACeFAADAimT7BRAGAGiXNAhIMlsHvvMFr2gRBFQamxECoB+suOivjvRT9AM4FQQAAE7aKYUBooEggJVLtw70SwQBY7lCbacSSQQB6DkU/QDWGgEAgNOyojAgymsoiDQYLMwMSJgZAGAZaVHUGAS84wUv140H79fHn7pXk+WixnIFSZmtAwkC0MUo+gF0EgEAgFXTMgwozWpSrjYzYDjMaSCoXyaQPp7LdgCNGoOAsaigd2+5WBeNPl//+PSE7j32pLyk4SgviSAA3adZ0R+b1wxFP4A1RgAAoC0WhQFmdTMDIhdoOMxrMMipEEa147x5GsACaCobBCTmtXXDFm3dsEXfOPYDffqZ+3R3NQgYWRQE1H4D1kxa9Kfb68bmlZg0E882LfqDTGDFz0AA7UIA0EbsAghUZM+BMDMz4Gi5qNDNyUkaCCINBTkNB3mFzil0QYdeLYButxAYmpyTXrXxXL1q47n6xrEf6FPP3Kd7ms4IqJZj5ABok+wstrTo92aaTkqaTcqaSeblrRIEuEzRz7UisCA9H3ynX0gfIwBoKyIAYIFlfnfVC/j0wsdrNilppjyvI85pMIg0Eg4osXQPAQBYLLt1YLMg4O5jT8pkGosKis3L5CWrlmh1swJ4n8GpWZjaX5m2n5jJZJpJyrWiPzZf294y+7MvfTzff0Ajzol2IgAA0AGLL3kCSXJOZqaZpKS5JNax+RlNloudeIEAeshSQcAnn/mmbjv8PW3IDSkXhLVlRrXf6BOAk7B4lN9Vm/glmo1LmknKmk9imUyJeQUuaFL0U9wA6BwCAABdI70kCuQUOSfG/wGcjGwQoGoQsH3jOfr7J+/RjYcqWwcOR3nlg6i6LalJRgiApdU38HPVZpSVqf3zPta8jxet55cWmuGmzwEA3YAAAEBX4mIJwKnKBgGBc/q1c7br/3rhj+uGg9/RDQe/szgIYNcAZLQa5Y/Na7o8r0TSdJxO7ffVqf31nfvT5wGAbkMAAAAA+lIaBCTmNRoN6D1bLtbPv+AVLYIAXwkCCAHWpZMZ5Tcps56fUX4AvYUAAAAA9LV09xG/RBAwlisodIESq/aeJgjoa9lR/nT0fiWj/GnhT9EPoFcRAAAAgL5XGdldHAS88wUv12cO3q+PP3WPJstFjeUKktKtA6uPJAvoec2m9ac7zcwm5RWP8qfPBQC9igAAAACsG41BwFhU0Hu2XKyLRp+vf3z6Xt177El5mYajAUnVIMDEjIAek4lvlpzWP1fXsZ9RfgD9jwCgnSzzC1jvljsPmp0vnD8A2iQbBCTmtW3DFm3bsEXfOPYDfeqZ+3T3sR/ILBMEeKsOIbuFJ5B4j+oStYK/OmEjlKv92yaSpstFJSZNJ/OKff20frkmo/z8uwKdkV77+U6/kP5FAAAAANatdIq3N5Orbh34qo3n6htHM0GApOEwr8pkgGplyKyAjmo1wp+YrxT6cVrwz8mbqtP9W0zrN3IcAOsHAQAAAFj3slsHOie9atO5etWmcyszAp6+T/ccf1KRCzQQRErMKkGANcwKQNssW/CXi9XGfc0L/rD678u0fgDrHQEAAABA1aIgoDoj4M4jj+uPH/mKDpdmNBTmqlsHWmXrwLScZEbAqmnWtC9dq0/BDwCnjgAAAACgQX0Q4PTTZ/yYPn3xe3TDgYWtA4ej/EIQUJsRQAhwstLiPKh+3NilfyYpa87HkqQTFPwAcFoIAAAAAFrIBgGj0YDec87F+vkXvqJFEOCrMwJEELCEdHQ//Qql0/lj83KSpjPb8mW79LtqMEDBDwCnjgAAAABgGUFtGzm/ZBCQC8Lq1oHMBpCWHt2v9FKon86fbtWX3ZZPqjTtyz4fBT8AnBoCAAAAgBXIbh3YKgh4bn5aQ2FezlUK2coD10cQkG3UJ9Wv3W81uu9UGflPp/Onj1+0Ld9a/SUAoM8RAAAAAJyEVkHAO1/4cv3JI7fo5uceUeCk4WhAUn8GAY1d+SXVRuxbrd1vNrrvtXg6f+PHAIDVQwAAAABwCrJBQGJeY1FBf/zSy/S2YxfpU0/fp7uP/UAm6/kgoNXIvqS6qfwnykVJ0lyLtfvpc2RH950o9gFgLREAAAAAnIbGojbdOvAbx36wTBBQ+60rZAvx+jX7qmvSN5OUVfRlhXIq+lhzSVlOrjqVv7JrQtBi7X7jxwCAtUUA0FaW+QWsd0udB80uDTl3APSWtJSvbB3YGAR8U3cf+4G8pJEor0qfwPR9zq15DtA4qr/QWT+7Zt9pJinVpvFPxXOSpMRM3rxUDQcCOXmZAic5uepzW93/BwBWziT5Tr+IvkUA0EZ86wInpzEG4MIRQC/Kbh3YGAR88ulv6p7jTyp0gQpBVJ0+b5mKfHWTgMa1+umoflBtzpeYl6xyvZJO4TctXrOf3YJPqix9SI8ltgWwWngfaT8CAAAAgDZoFQTceeQx/dEjX9HhUmXHgHwQydeCgJPfPjB7sdxY6GfX6sdmCp0WNefz1SdJqt34s689Xd7Q+P/hAh0AehMBAAAAQBvVBwFOP33Gedp78a/qfx/4tm44+B0dKE5qOMoEAS2aBTYbzV+Yuq9aM0JvUuDStfqxQklFH6uYxAqdFFen8C8e1XeL/l+NHwMAehsBAAAAwBrIBgEj0YB+9Zzt+tcv/HHdcODb+n8bgoDK1PxKYGBa2GJPWui875yUmHQiLirNDNIRfafsWn3VGvPFxqg+AKxnBADtRA9AYMFy50Gz84VzB0AfCqpFvTev0WhA7zlnu34+DQIOfEcH5ia1ITcoSYq9VyCnGV/tvO8CFatd+INqw726qfvVmMCrMoGgsdBPx/iN91cA3Sr7/jTRsVfRtwgAAAAA1lhl6n6wKAh45wtfoRue+Y7++rHb9VTxuDbkBuXkVLKkMppfnQkQOKdEVnkeLZ6676qfUOcDALIIAAAAADqkMQgYiwr61XO368eGz9CHHvuabjvyfXkzjeUKyrmobrS/NprfmZcOAOhBBAAAAAAdlg0CEvPaceaLtOPMF2nf4Uf1vx6/S7cd/r4S8xrLFRTIVXoESKu+bSAAoL8RAAAAAHSJtEFfunXgzjMv0M4zL2gaBLhsECARBgAAlkUAAAAA0GXqtw5sHgR4M23IDyr2SWUZQIvtAwEASBEAAAAAdKnWQcD39HeP3aEv/PBBnZkfqm4daDIZQQAAoKWg0y8AAAAASwuq3f+9mbxMO888X3u2v0d/+K/erI35IT1XmlbZEkUu3QhQ7PUHAFiEAAAAAKBHBM5VmwCanJz+w/mX6Naf+W1d9ZJLdUazIMCMIAAAUEMAAAAA0GNC52SSYvPakBvU775oxxJBgAgBAACSCAAAAAB6UrpjgMmWDAJMlS0GmQ0AACAAAAAA6GFObskgwEk6VppV6BxBAACscwQAAAAAfaBVEPCxrb+knzvrQk3HJU2WiwoIAgBg3WIbQAAAgD5SCQIqPQIS83rtGefptWecp32HH9X/evwu3Xb4+0rMayxXkJNTYj59YPobAKBPEQC0lWV+AevdUueBNfnYJPllHgcAaCXtEeDN5Jy088wLtPPMCzJBwPeaBAFWeSQ5AICO4dqvnQgAAAAA+ljgKtX8UkGAN9OG/KBin8hktRyAJAAA+gsBAAAAwDrQOgj4nv7usTv0hR9+V2fmh5QPIiVmMktnMTIjAAD6BQFAGxkrAIAFy50H1XMl7Udloj8VALRDNgiQk3aeeb4uOfNF+svv3aZ/ePJuPTF7VKNRQYU0CKi9gZMCAGiv9PrP+06/kv7FLgAAAADrUOCcAjklZnJy+o/nX6LbXvsBXf2SN+uM/JCeK02rbIkiF8iZI5UFgD5AAAAAALCOhdUdA2pbB56/o2kQkM4cIAQAgN5FAAAAALDOpTsGmKxlEDAdzyuQU+gCZgMAQI8iAAAAAIAkycm1DALe+vyXaSqe01S5qMARBABALyIAAAAAQJ1mQcD1r3yX9m7/Nb1u84WaiUuaJAgAgJ7DLgAAAABoqhIEuNo+ADs3n6+dm8/Xvuce1f96/C7devh7SsxrLFeQk1Ni1dbdjh0DAKAbEQAAAABgSWk5783knLRz8wXaufmCpkFAZTJAZjYAYQAAdA0CAAAAAKxIuhPAUkFAzgUqhDklZjJVlwYQAgBAV6AHAAAAAE5K4JycnHy1yN+5+QJ9evt79PGtv6yRXEFHSjMqW6LIBXJy9AgAgC5BAAAAAIBTUh8ESG983ov1jR3/Xv/PSy7VGfkhPVeaJggAgC5CAAAAAIDTUgkCKksDxnMF/fvq1oFXv+TNrYMAAMCaIwAAAADAqgicq9s68HdbBAGBYzYAAHQCAQAAAABWTWXrwGDJIGA6nlcgp9AFhAAAsIYIAAAAALDqlgoC3vr8l2kqntNUuajAOYVilwAAWAsEAAAAAGibZkHA9a98l/Zu/zW9bvOFmolLmiwXFUgEAQDQZlGnX0BfS9e2MbUNWOY8MMlU/WWZ2zh3AKBfVIIAp/Sdfefm87Vz8/na99yj+l+P36lbn/ueEvMayw3KOafEfEdfL4AOMZPE+d8uBAAAAABYM+kYvzeTc9LOzRdo5+YLKkHAY3fq1sPfUyLTWK5QGUcRYTAArBYCAAAAAKy5wFWigJZBwJHvK+cCFcKcEjOCAABYBfQAAAAAQMcEzsnJyVeL/J2bL9CnX/Wr+vjWX9JINKAjpRmVLansGAAAOC28kwIAAKDj6oMA6Y3Pe4m+ccl/0O+/5E0ajwo6VpplFgAAnCaWALQRP6KAk5dpAUj7FwBYh9KlAZWGgAX9h/Mv0X84/xL98cNf0Ud+8A2VLZFjtwCgL3H9134EAAAAAOgqiVltyv+R0oz+6akJffnZh5WYp/gHgNNAAAAAAICu4M0kJ4XOyWT6y0dv1ceevFuPzxzVUJRXIcx1+iUCQE8jAAAAAEBHpTsBpNP/9z33qD702B36/KH9OjM/rLMGRqo7AQAATgcBAAAAADqisfC/pboF4L7D35OZ6UcGNyj2iWJLVwUz/R8ATgcBAAAAANZU08L/8Tt163PfqzX/c3Iq+6T+gWaSIwQAgFNFAAAAAIA1Yap094+qDf4qI/53VAp/Wa3wT8yL/ZQAYPURAAAAAKCtTKbETJELFLlAX3vu+/qr792m2w9/X4l8pvA3UfgDQPsQAAAAAKAt6gt/p+Ploj76+Nf1Px+9VZPlOW0aGJakhRH/lUzvZxkAAJwyAgAAAACsqlaF/0ce/7qemD2qDflBbcwPVQt/LfT2o7gHgLYiAAAAAMCqyK7xrxX+j31dH3n8X/TE7FGN5graPDCixLwS83IU+wCwpggA2skyv4D1brnzoNn5wvkDAD0jMa+wusb/eKmojz72L9XC/5hGo4I250eUyBT7hVF/M5PLbu3nxPs+sN6ZJL/sUThFBAAAAAA4Zd4qFXvoAplMf/HgzfrYY9/QEzNHNJof1Ob8sBJTpfB3Wpjib8pM/ddC8c+kAABoGwIAAAAAnDRvJuekoFrQ3/LDh/Whh2/X/znwgDYPDGtzYbQy4m9eVPUA0B0IANqKNQDAgqXOg8Z5/+mfnD8A0G28mZwyhf+hh/V3j9yufc8+LDPp7MFxxeYVW1Jf9zfNAJjzD6AR8//biQAAAAAAy2pa+D98m/b98BF5mcbyBQUKVPZp4d+k4nctPmWCAACsCQIAAAAAtGSSEp8oCkJJ0i0HH9LfPXKb9v3wUXnzGssNygVOiXmZ/ELx37S6X6bSZ1cAAGgrAgAAAAAsYjIlZpUt/YJQt//wUf3Vg7fo1h8+Im+VEX8np0Qmpd380/q9sY5vVtefaq1PSAAAp4wAAAAAADV1hb9zOl6a1UcevUv/88Gbdbw0q02FYUmVEf9KV//qA5cb6F80/d+1PhYA0BYEAAAAAGhR+N+pjzx6p56YOaqNA0M6ozBS7epf3a+vVsNnqnjXKglg+j8AdBoBQBvR0xY4eewBAABrz5spcK6u8L/+0Tv1xPQRjeUGtbkwolimsvlq334nF6SPrhTuJlWK+Ma1/0614j7t+e+cqx6/Fn87AL0ivfZjH4D2IQAAAABYp7x5OecUOKfJUlHXPXpHZcR/+ohGcwVtLowqkaksr1qh31jku+WK/4X/X8uif6Wj/8wSAIDTQgAAAACwzixs6VcZxv/SM/v1W1//pA4VJzUSLRT+sXy16E4LerdQg7uGaf8ti//scaz9B4BOIgAAAABYJxYK/0r1fcvBh/Shh27VrYceURQEOrMwqsSaFP5SfZG/msU/o/8AsGYIAAAAAPpcq8J/36GHK1v65QZlUrXwb3hwdQ1/bRV/Xdf/xcsB6u6ru4viHwA6jQAAAACgT1n198WF/yPy5jWWK8i5ILOlX33Rnhb1i4t/1xAUNPm87rMmBTxFPQCsOQIAAACAPmMyJd4rCkJJrkXh75RYtd920LBdn1OLwl+Lt/lbakT/dEf+T/ZYAMCSCADayUsKxD5mgLT8edBs3z/OHQA4KSZTYqbIBYqCUMdLs/rdu/foMz+4T4GcRvMFOTklMslsobhO32/rCv/0hur9QeaOyl5+Df93V/88kpw1PqbhOZtxJ3EsgP7D+d5WBAAAAAA9rq7wd07HS7P6yKN36vpH7tTB2eMajwblgnTE31puxbdQ07cY5W+6j9/iJ2s65T977FIX+LX7KP4BYLURAAAAAPSopoX/I3fq+kfv1BMnDms0V9BIblA+nWIVpI/MTstP1/k3TudfuG/xY1Q/Qp855LSn/J/K8QCAFSEAAAAA6EHeKs39WhX+mwfHlJjJu+oQerZgdwtF+vKFf8PnyxX+jXdT/ANA1yAAAAAA6CHevJxzCpzTZKmo6x65Qx9pUvjXtvRrWfhLrbr+N9y4+HkaDlmVUf9TfQwAYMUIAAAAAHqAN5OTFLjKPP4vPb1fv/X1T+pQcUojUX7pwl+qbd23qMHfcoV/+tgm3KIAYenjl0TxDwBtRwDQVl4LrWwB1Gt2XnCuAECjhcK/UiDfcqCypd+thx5W5EKdWRhRYr6h8JfqR+9dfeHfclu/Jvc34ZrdX3estbqjxRM2PgbA+lXdnhRtQQAAAADQhVoV/vsOPiwv01iuIJMUW1Ib3V9Qm+Nf39m/sXBvLP4zSwTqnqvx8FbLARZZ5hgG/QFgTREAAAAAdBGr/r5U4e+cU2K+eaf+1S78F20EsLgB4DI3LEbhDwAdQQAAAADQBUymxHtFQSjJ6ZaDD+lDD7Yo/M0yo/71a/nravtlC//qb8sV/i0f24jiHwC6GQEAAABAB5lMiZkiFygKQh0vzep3v/FpfeYH9ylwgUZXVPg3a8jnVqfwb3w8hT8A9CwCAAAAgA6oK/yd0/HSrD7y6J26/pE7dHB2UuP5oYXCX2pe+Nc+bNHR/2QK/2afNV0a0Ih1/gDQKwgAAAAA1pBJSszXF/6P3KnrH71DT5w4otFcQSO5gnzaFT9omNPvsh/Whv9rty382WSd/xLr9euXDqxC4b/CQwAAa4cAAAAAYI0k5hW6QJELmhb+mwdHlZjJO9OikfpqUe7qZgGssPBfdLNrfjiFPwD0NQKANmI3W+DkWeZPziEA/cJb5R0tdIHMTH/+wJf199+7S4+fOKKxTOFfNl9Zy18txE2SnMsU6guVvjmtqPBPa3qrHljf0b/yp4nCH0Dncf3XfgQAAAAAbeKtUlrXtvQ7+JD+5rv79Lmnv6MzB0YWCn/56hR9l7n4dZl1/idf+Kuh8M8+bfqnNbt9Edb4A0C/IAAAAABYZY2F/80HHtLfPXSrbjn4sEymLUMbVbZEsS0U/gsqhb9rKPzriv6lCv+6u5aZ6r/o+GVvPOlDAADdgwCgnUzMYwFSy50Hzc4Xv4LHAUAXaVb4f+ihW7Xv4MPyZhrLF+TkVPJJfVO+ylz/WqXu0tsaC3VVj7OFD5tW4bYwC6Bpj39reJg1OaaVlo8DgFVgqlwDoi0IAAAAAE6TSUp8oigIJbUu/BPzkrOGjvyZwn/RbVpiS7/WI/51dzedLdDsb8GIPwD0OwIAAACAU2QyJWaVLf2CULcfekT/Y//NuvXQI4sLf2UL/+w6fddQrDd83HS6fuPQfqsR/4YnpfAHgHWNAAAAAOAk1RX+zul4aVbXP3Kn/sf+r+h4qahNA8NSbcRfLQp/VTr+pxoL+9Mt/JvOEFh00DJ/05UdAgDoDQQAAAAAK9Sq8L/+kTv0xPQRbRwY0hkDI9XmfmpZ+FcK9vpZAKdU+Df7rGEXgOYo/AFgPSIAAAAAWIZJSsy3LPxHcwVtLowqMV8p/oMWa+7rCv/FoUDTzv6Lh/br7l70CYU/AKAFAgAAAIAlJOYVukCRC5Yo/E2xNTb3U11R3rrwb6y4mzQAbBzxX6pZ4CIrrOgp/AGg7xEAAAAANOGtssdd6AKZmf78gS/ro4/e1aTw9ysr/NPblxvxX3TzMp39GfEHAKwQAUBbNdvYHEBFs/PCGj7m3AGw9ryZnKSgWm3fcvAh/c13b9HnnvqOziyMaHNhJFP4q1pAm+oK8lZL9tMtAGus/mBnDQ+oHLNQ+Dc8dtmu/ku8j1L4A+hKXP+1EwEAAACAFhf+Nx94SH/30D7dcvBhmZm2DG9U2SfNR/wzRbzLDtNnR+xXa8R/8WHL3XjShwAA+hMBAAAAWNes+nu28P/QQ/u07+DD8mYayxfk5FTyyRKFv2s+St+ys/8ShX/2f7GoP0DjY5re0ByFPwCsewQAAABgXTKZEu8VBaEk17LwT8yrMt2+rjJfXPhLyzf4W3Hhv+ggRvwBAKeNAAAAAKwrJlNiVtnSLwh1vDSr3/nGp/WZJ76pwAUazRb+Llv41zfzqy/8q7+1LPwb7l+4cfHN2fsaPlzmxlM+DACwPhAAAACAdaGu8HeuuqXfHbr+kTt0cHZS4/khOZcW/lpc+Dc081+4zbUo8Bvvr7ux/nma3dCyeGfUHwBwaggAAABAX1uq8E+39BvJF2rb/imoq+7rGvm5xnn6DYdK2c+bDe23KP6bLg1o/dhTuRsAAAIAAADQt7xVmvu1Kvw3F0aVmFWK/0UN/pTZ0q/W4n/h9tqfp9jZv/ETRvwBAG1GANBOJrYyB1LLnQfNzpfGj7nABbBCiXkFzilwTpOloq57+GtNC//Yp1v6Vd9gTHUFvGs5xF+9zbJ3NxxjmdsWZQtNnm/R++RJjPhzrQGgX/B+1lYEAAAAoG94MzlJoQskSV98er9+665P6FBxSiO5gcWFf1A3HF/5r3Fdf+aPkx3xrzt8USPBVn8LRvwBAO1BANAmRyUNigALOFmW+ZMJNABWKi38g2oxfvOBh/ShBytb+uWCUGcOjirxXmXzctUR/4XB+2o1Haiuu1/t/ae6DKBV4Z+dPJCdM5At/G01tvSj6AfQ59JrP9/pF9LHCAAAAEDPalX433LwYXkzjeULMpPKPqlN9V8IFjPr+oOF26zh7sVb+tWP+FvdwVr9wn+FhwAAsBwCAAAA0HOs+vtShb9TZku/hu79tWn+mcJfjR8uU/hnP6lv7LfoIAp/AEBXIAAAAAA9w2RKvFcUhJLc0oW/sp39Gxr7OS0urk+h8F/U3G/RY5v9LSj8AQCdQQAAAAC6nsmUmClygaIg1PH5Wf3ONz6tG574ppwLGkb8mxT+UnXtvxYX8i0L/4b7F25s0tW/4fGnWvifxGEAAJwsAgAAANC16gp/53S8NKvrH75D1z1yhw7MTmo8PyTnMlP9mxb+WqLwb1LJL1X4N/us6QyBRoz6AwA6jwAAAAB0nWaF/3XVwv+J6SMayxU0li8osWrLvsbt/JQp/BvW/9dvy9fANQkEGsOExk8o/AEAPYIAAAAAdBVvleZ+rQr/swZHlXhTIi0u2F12G77F6/9rt9dpFgo0jPivNEBY+o5TOgwAgNVCAAAAALpCYl6Bcwqc02SpqGsf/lrTwj/2vnXhv+yI/0k0+Mvc3TRIaIoRfwBA9yIAaCvL/AJQr9l5YQ0fZ88fziOgX3kzOUmhq+zJ98WnH9C/u+sTOlSc0khuQGcNjmQKf1ULaEs/aLHGP3Nc3Yh/9XG1wt6yB9eOWSj8Gx67bHO/Jd6rKPwBYAVMku/0i+hbBAAAAKAj0sI/qBbZNx94UB96cJ/2HXxYURBq8+CoYu+bj/inxX9Q/bhxdD+7/r/uYacw4r/4sOVuPOlDAABYCwQAAABgTbUq/G85+JC8mcbygzKTyj6pFv7NGvw5Kai/re7DRVv6LVH4160YaFKtL9EUcEkU/gCALkMAAAAA1oRJSnyiKAglNS/8nTJb+jVZy+90ioV/3eGM+AMA1icCAAAA0FZ1W/oFoW4/9Ij+x/6vaN/Bh+sLf3nJrGn3fpeGAc3W+Teb/r/wQC26o+nNyzX4o/AHAPQ+AoB2ogcgsGC586DxfHHi/AF6XF3h75yOz8/q+ke+pr984Cs6Xipq08Cw5Koj/mpS+KcfZUfxrXprrfFfs6q74TZrUfg3O7bu/9PkGNdwf+PDec8CgNNDD8C2IgAAAACralHhX5rVdQ9/Tdc/fIcenz6ijQNDOmNgRLGlV3iu4c9sDrB4/X9d4W+LHlB/vNV9tvCYpsGBWhf+Te8/ifsAAOgCBAAAAGBVmKTE/KLC/7qH79AT00c0livorMKoEjPF8lLQrLmfFor5ZlPzW3X2b9Wob9F0/+Wm+i97J1P9AQA9iwAAAACctsS8QhcockHzwn9wVImvFv6Nnf2dq+/CfzKF/6KbmzT4a3lsI9b5AwD6GwEAAAA4Zd4q895DF8jM9Gf3f0kffeROPd5Y+PslCv9TGfFfdPMynf0p/AEAIAAAAAAnz5vJSQqq1fYtBx7UX++/RZ978ts6c3B06cJfbmGqf321vvqFf5OnWcEdJ3UIAAC9ggAAAACsWGPhf/OBB/Wh7+7TLQcfkpm0ZWSTyj5pXfhX/mja8b/pln7SkoV/3eFNH9vsb0HhDwBYnwgA2ohmwMDJs8yfnENA92gs/L9aLfz3HXxIiZnG84OSnOZ9Ilct7hca9KcFvJOCyofWbIS+sTO/c3U3W/bZGvoHGoU/APSF7PXfRMdeRf8iAAAAAC2ZpMQnioJQ0kLhf8vBh+TNNJYflJNTYr5ytHOyhY5+C6PywcLzLZ7uv/SIf9PHVD+m8AcAYOUIAAAAwCImU2JW2dIvCHXboUf0Px74ivYdfHhx4e9s0ZR+l23s1zh1v2Xh33D/wo2LDs3e1/jhMjee8mEAAPQ6AgAAAFBTV/g7p+Pzs7ruka/pLx/4io6Xito0MCzVCn81Xcvv6m6v3dqiwNeShX/t+eruosEfAACnggAAAAAsLvxLs7ru4a/puofv0OPTR7RpYEhnDIwobjHiL2mhs39dMX9qI/51z9n4yZKFO4U/AACtEAAAALCOmaTE/KLC/9qH79AT00c0lissbOlnXgoWV8+LC/9l1vi3WhrQ+JzZYxcf0vKxLVH4AwDWOQIAAADWqcS8QhcocsHShX+zLf2cywzytxrxr/1W9zgturnJdP9mQUJTjPgDALBSBABtZWIzM6CVZueFNXzMuQO0g7fKuRW6QGamP7v/S/rII3fq8enD1cJ/JFP4q1pAW/pBZsRf9cV1elzdiH/1cbXjrckDLVP4Nzx22eZ+S7xPUPgDQA/i+q+dCAAAAFgnvFU2zQuqRfbNBx7UX++/WZ976ts6szBaGfG36lT/Jk38aoW/a1L9B1p8W8tR/IXbXLNjFx3f5LGneDcAAOsZAUA7MQEAWLDcedB4rnDuAKumsfD/6oEH9aH9t+iWgw/JS9oyvElln1RG/OUWT+mX5NLb0kI9O5Cfva3hcfVc64/qHquF21o9l1P9a2jE+wcA9Cbev9uKAAAAgD5l1d8XFf4HHpKXaSw/KCenUpJocWO+TOFf+9TVX5hlZwMsWaw3K/xbHFv/4lsf0+oCkQtHAABaIgAAAKDPmEyJ94qCUJLTzQce1N82KfwT86qt2c+O5EtyLQKB1lv6NUzfb5jS71odu+jOJW9c8d0AAGAxAgAAAPqEyZSYVbb0C0Idn5/VB7/+Kd3w+IScc/WFv8sW/tlCvcUWfS0Lf6kuHFiq8G98/KkU/gAA4JQRAAAA0OPqCn/nKlv6PfQ1Xffw13RgdlLj+SE5lxb+yqzxd3W1e+vCv7EhoE698F+yvl9B8U8+AADAKSMAAACgR7Uq/K99+Gt6YvqIxnIFjeULSqrb/i0U4U0K/8aW/E0a/Tc8oOGYZab7U/gDANBxBAAAAPQgb5Xmfq0K/7MGR5V4U5Jd459yzQr/pYv6ym0U/gAA9DICAAAAekhiXoFzCpzTZKmoax+6vWnhH3tfLfyza+5d5VNT/TKAzB8tC/+GAKFp4d/s+Zqi8AcAoBMIAAAA6AHeTE5S6AJJ0heffkC/ecc/6mBxSqO5geaFf6YyrxvxD2qfUPgDALCOEAAAANDF0sI/qI7kp1v67TvwsKIw1FmDo4q9XzzinynKXV2n/4Yu/KtV+C+Jwh8AgG5AAAAAQBdqLPy/euBBfWj/LbrlwEPyMo3lB2WSyj5pWvhX/lgcBij74aIt/Ro/XzjYtbh90XMuf+NJHwIAAFYHAQAAAF3Eqr8vVfg7NdnSr27E/zQK/yazApYc8afwBwCgZxAAtJF1+gUAPczEOYT1xWRKvFcUhJKcbj7woP6mVeGf6ezv6or5ym3WWFyvsPB3Lab0W9PHNvtbUPgDAE6PSfKdfhF9jAAAAIAOMpkSM0UuUBSEOj4/qw98/VO64fEJOecaRvyzW/q5TE2enQXQcJu05NT+9HFuqcq8cYZA84OW/btS/AMA0FkEAAAAdEBd4e+cjpdmdd1DX9O1D39NB2YnNZ4fknOLC3+XLeylJQp/t7jgbij8W434LxxPZ38AAPoJAQAAAGuoWeF/7UNf03UPf02PTx/RWK6gsXxBiVUXwQSuMh+ycbp/XZHfUKg3jvg3myGw6JiGY7PP1+yY5VD0AwDQdQgAAABYI968gmaF/4kjGssXdNbgqBJfCQjqtuJbVPxnR/frp/IvbtK3eCaAa1X8M9UfAIC+RgDQLkckjZlk1V/AerfoNLDFn9adK5w/6B+JeQXOKXCBJkuzuuahr+m6h26vjfifNTiixEyxr7Y9cqpM+69t55d5svRjSz+2hcLdMne4zP0myWVW+WfPq7owwJp+WP8CWpyTKzgEAIBleZM8bQDbhQAAAIA28WZykkIXSJK++NT9+rd3/KMOFic1mquO+JspNq/GqfeubmS/YU5+3aenOOLf+FhG/AEA6HsEAAAArLK08A+qhfdXn3lQf7v/Zu078LCiMNRZg2OKzStOR+IzzfYWCv9ssd9QqLcq/LM3t+rs3zIMWPKGFTwGAAB0OwIAAABWyeLC/7v60P5bdPOBh+RlGssPyiSVLVHLbfiWKvyz96vJ50tt6dc0NGj2t6D4BwCgXxEAAABwmkxS4hNFQSipeeFf29JPUnaNvqsfsqfwBwAAbUMAAADAKarb0i8IddvBh/WX939F+5oV/pZtzpct1Zts0SctUfhn7lyq8F/0RE3+H61vPOlDAABA9yMAAADgJNUV/s7p+Pysrnv4a/qL+7+s4/Oz2lQYlpoV/nL19fyihn1u9Qp/tvQDAAANCAAAAFihRYV/aVbXplv6nTiijYUhnTE4Uunqb1Lrwj97X8PHyxX+atHVv3Z8QzPA5gctdeeKDwHWk8WnhJNkCpxbZhbOyiRmaraHJrtqAlhNBAAAACyjssbfKwqaF/5j+YLOGmrY0k+VP9yikXjXtKg/rc7+zY5tftDSf9EVHgL0I1f7vbGor9w272NZ7bOKQE7TcUlzvnya/2+nsVyh7rnTjyMXKBeEMluIArJhAQEBgJNBAAAAwBIS8wpdoCgIVlb4N9vST8pM919h4d8wY4DCH1g9abEfurQBx0KBny3qnSqreALndPbQhrrzMHBOs0lJr3vehdq6cYu8TMEpnkhln+gff3CP5n2sQK6uqJ8sF/VccVqhc9UAoj4syAYEJpM3ggEArREAAADQRHoRHbpAJtOffvuL+sjDd+rxE4dbF/61WjxblLeh8G/2fE1R+APZYt85p7JPFJuXSTpSmpOZ1Qr80AV1RX2lpJYGgki/fO7FygdhbRaAVAkIx3ODq/I6P3DBDnlZ7bl99XXde/RJ3Xn4MQ2GeZmsFhbM+VihnI5nAoKBIKfBMCeTaSCIJDmZPKEAgBoCAAAAMrxVLsCD6sj6zc88qL9+4Kv67JPf1pmDoysb8XfKrOVvU+Hf5GlWcMdJHQL0osrp5xS6oK7YP1qaU2xem/JDGssVlA8i/YcLdyoMgroC/1SK+ri2xeepG47yTW+/5KwLdMlZF9Td9oELdig2r7AaEHzt8Pc1Eg7onmNP6o7D31chyOmp2WPyZiqEjaHAwhICAgFg/SEAAABAiwv/rz7zXX1o/z7dfOBBeUlbRjapbElmjb9b3I2/2Yi/Fg4/5TX+TR/b7G9B4Y/1p7HgT8w0F5c0k5Tqiv3/+OLXKfaJfvrM87R10zlykkaigZbPu1DUV8b8F5YLZJmcnCIXnPbfo3n7PydvJm++rp9INixoDAgmy0V5M/3DE3erZInuO/a07jj8fQ0GOT05e0xepvHcoJxEIACsQwQAAIB1rXnhf4tuPvCQvExj+UE551SyRHWj+XWFf0MAkKoV9i0K/2bPVXdcw/M1+XSJG0/6EKAXpFP6o2BxwX9mflj5MNTPPe9CvXTs+XrNmedp2xLFfqXIbyzwT6aoX70Ta/EzVW4JnVPowrp7Fib0VwICMy+5ymtOZy/8zoWX1I6fLBeVmOkff3CPpuN5/dMP7lUxKetAcXJRIGCSfHXWBID+QwAAAFiXKp39E0VB5cK6VeGfmK90AauO7Lu6onxhFkDt87q7ly78XbMCv3bTKhT+FP3oE5WQrtJiL23W92zxRNOC/5Ubz246hT82X13vH9QCv+ZFfvefOC7ze+iclAkI0nH8dFQ/cmHt6/HBC3ZIkn7ngks052N9okkgkAtCDYV5Bc4pF4SKvWduANBHCAAAAOuKyZR4q2zpF4S67eDD+sv7v6J9SxX+khRkx+gbC3+prvhfVPg33t9ixL/xuRo+XOZGoO+E1aK/5BOdiIsq+0QvHBzXUJjXb57/M3rdWRfqJzb8SNOCv+yTyuOzxf46OHXS95Yo8z5UHwpUlhAMK18XCBSTsv7pyXt15+HH9C9HHlcpSXSgOKmN+SHlXOX9kjAA6H0EAG1U26KV90lg+fOg4VwxVc4hTh+slvrC3+nY/Kyue+hr+ov7v6zj87PaVBiWmo74u/QJKt+P2YZ9lRsWF/3ZNuHZ2CANApp9b7eaDdD8wNayd3MCoQe56nT8kk90IikqqTbue/PzL9JPn/lj+sVzt2kwzC1qmrdQ8FeeIxeELf4P609jKJAuIagLBKJKIPDBC3ZoslzUfcee0S3PPqLPPP1tHSxO6dm5aW2ohgGBCyrvlUAbGD+72ooAAADQ1xoL/+OlWV374Nd07UO36/ETR7SxMKQzBkcqa4HTgl6SnKsfyG/W4G+la/ylugZeDQfXF+2nM+K/DkY30Z9cdU1/7BOVfKzZpKxN+UFddlal6H/Xua/UWQOjdY+JzcvJKaDgP2m1PgpNAoG0j8AlZ52vS846X//lJa/X3Ud/oH3PPloLA+aSOY1EA8pVt0UkDAB6BwEAAKAvVdb4+5aF/1i+UN3Sz2e29Ks8tnXh3/Bx07X69QV9y3X+2f/RkoU76/zRv0Ln5OQ072M9Vzyh8dygNhdG9Bvn/ZTe86PbdebASN3x6dZ3WqXO+6hYHAiYvFX+HI7y2nnWBdp51gX6vZf8nO49+qT+6pHbNHHsSR2Zn1HoAo3lCgpdJcBh8BbobgQAbcUaAKC1ZueFNXzMuYNTk5hX6AJFQaDj87O69qHbGwr/ESVmC9t8OSmdt59pBL54nX96XF1CsLBcYOF5VJlBUHeMarcvfNzqe3yF8/gp/tGD0tH+xLymykXN+VgXjGzWb57/M7rkrAu0fdO5ten96ehyGhRQ9K+NyjKMykeVXQFMJtNoNFALA56dP6FP/eCbuvPwY/rng/s1l8TakB+s7STArACcOq7/2okAAADQN3x14WDoAplMf/qtL+r6h+/Q4ycOZ0b8rX7EvzYInx2Nd1Kg7J3192U1jPi3bPDXbOlAUyuo6in80YPStf3zPtbh4rQKYaQ3v+AivebMH9Ov/Oh2bcoP1Y5NzCug6O8KTqrNukjDgMA5nTUwqg9euEMfvHCHbv7hw7r9ue/rfz91nx6dfk6FINJoriAnRxAAdBkCAABAz/NmqmwTVqmMb37mQf3VA1/V537wLZ0xOJop/BdG5yt/Zgv/hmn+2Q9Pq/BfSbXOGn/0r7ST/5wv60hpXuePnKnfPP+1+tnNL9LPPe/FteMqa/or2/2FFP1daSEMqPZXMVPoAv3c816sn3vei/U7F16ijz9xt+46/Lj++eB+mZRZHsAOAkA3IAAAAPSsxsL/q898V3+7/xbd/MyD8pLOHtmksiULI/7S4m34mjX3y364VIO/2kOXGfFvfM7lbzzpQ4Buk87EmSoXNe9j/djwmfovL3mD3nvea7QxX9m2LzvFn5H+3uIyPQMS8zJJm/JD+p0LL9HvXHiJbv7hw/rbR2/XLc8+omJcri0PSKrLCQB0BgEAAKDnpB2rmxf+prH8oJxzKlmi1oV/QwCQWmlnfwp/oKm08J8sF+WkptP809H+0AUU/n0gnbGxMCvA1WYFZJcHfG/6sMZyAyoEOYIAoEMIAAAAPaOypZ9XFISSnL76zIP62/03Lyr8E/PVjYRdk2K9fu3/4nX+p1j4N31s04OW/4tS+KMHZQv/wDm9/nkv1m9f8LOLpvkz2t+/srMCvJlcJgj43Qt36vrH7tK1j92lJ2aOEgQAHUIAAADoepXC36pb+oU6Nj+rD9z1T7rh8Qk555Yo/LOlemPhn7lNalG8t5g90ExjULD4gJX8VSn+0XOaFf6/dcHP6vXVwj87Kkzhv34EDcsDNuYH9Z9e8nP6jRe9Rtd9nyAA6BQCAABA16ov/J2Ol2Z17YOVLf0OzE5qfGAoU/hL2bX8dfV8y8LfLS64T7Xwp7M/1hlXPc+WKvzNKoVg1BiwYd1oXB6wIdc6CEh7BABoHwIAAEDXWarwr2zpN6ixgULlQjEt/KXKiH9j4V9X5GdH/Bv+p42Ff+3wZab7U/hjnUm35ptNSorNL5rqny38qfuRSpcHtAoCrnvsLh0oTmk0GlgIdgGsOgIAAEBX8eYVuGaF/xGN5Qs6a2hMiVl1lMg1FOsLHy/q7O8a7stqLOYp/IGmQuc072MdLc3rBYPj+v9t3a1LX/BSSRT+WJmWQcB5r9EHv/m/dcMz35KT01iuoErGy4wAYDURAAAAukJiXoFzClygydKsrllU+I8qMVvY0i9TYThXLfZNldtPpvBvmDGwbGd/Cn+sQ6ELZGaaKs/rhYNj+i8veYPe96LXaDw3KFOl4VtI4Y+TsCgIyA/qH179K3rPD7frbx+9XfuefVSRCzQU5hVbQgwArBICAABAR3mz2nZgkvTPT92vf/u1j+tgcVKjuRaFf60WzxblTgpqn5xc4a9qiNDMss39lrzjpA4Buo2TUy4IdKw0Ky/Tz//IT+ivX/l/aUN+UFLl/A2cU0jlj1O0EARUpLsGfPHgd/WbE3t0sDipjfkhRS6o/hwAcDoIAAAAHZEW/mmn6K8+8139zf5btO/AQ4qCUGcNjik2v3zh7+oq/Ypao/FVGPFv8jQruGNFdwPdLHROpf9/e3ceJ1dZ5Y//c557b229pZMQCCDKIqsgAiI7KBBWAdEEV3CB4O53ZhwdlZkmis64/RxZBIKogI6YsAgIgYQACZusspgEEAhCFkJCOunuWu+9z/n9cauqq7fs3bV93r5Kku6q7pvuqlv3nOec89gQb2bW48M77Y9vvPs4fGj7PQH0b+dnGPjTNlJ6JoXFpNLJk/fF3076Nn79yiP4+Yv34e1CGp2xFBSAclAg0RZjAmA0acWNqNlt7HUw3GuFr5+GNCTwX7YYly+6D/NXLIFVRXssCRXAt2ExuJf+afzaP+yvf7K/9D9PKj9WaZggpRz4Vz629Acd+iUGPhcHf/3hvs5IjyWqbaa4GhuV+3fgm3sfj3/f+3gI+ldpuZ0fjZZSNYmtmA/w/vHvxC9eug8PrPoHXONE2wbC9p+reY5tLAqAxR6jhgkAIiIaE1r8/yGB//IlsIgC/yFb+hVJOcgfIfAv3X1IoL+BwL//oEa879D7jXCfkS4+eVFKdcYRg3zoIxsGOPsdBxTL/VMAojkdDgN/GiOlRFSoFsdO2gPHTtojagt4YhbW+hm0ODEIokQBEW06JgCIiGhURVv6WbjGASC4d/kSXP73+SME/hWT/UUGpAD6A/8K5er/wQP6BpXvb8pU/2EeupEPbvZdiGqVEYEq0BvkMT6Wwg2Hn4OTJ+8DoFTubxj805gTRNUmVhVSbAt45pRv46tPzcaty55D0riIOx63DCTaDEwAEBHRqIgCf4VrDFzjoDufwdce/j/csvQpiMiIgb+Ut+8Dhg/8ZQOBf8VfpPTpDUTmHPBH1L/qbwN8ZOcDcPnBU8vT/QGW+1P1lSrHQrXo8JK44bBzcffKJfjSk3/C2kJUDQBwy0CiTcEEABERbVMDA3/BunwG17ywENcsWYgVmfXoiKeGlvoXA/UBi/EDAv9B0/6HzP3bjBX/YR8/zH02BQN/qmMCwDUOevwcOmMp3HBI/6o/y/2pFjliyiH+yZP3wTMn91cDtDoxeMbhTgFEG8EEwChiDpJoy3H+X/0ZLvCfWQz8l/auQXssibZ4AqFqecW/vEBfjPz7W/+HqQIofw6DAu+BVQClVf9hnz/DVgwMudPG/7EM/KnORSX/ijfSa/HJd70fvzpk2oBVfwb/VKv6dwsYWA3wyUd/h95C1MLiMwlQ1zgDcHQxATBq1gJoBcMYopEM97rQQX/m66deWLUwMnLgPynVhlA1Cv6BYkyvFSX4lb3/FV9Yip8bELgPGtEvpa9ZueY/aDqgDLrvEJXfdAPPOQb+1AAcMUgHeSTdGH584Fn4t70/BEcMV/2prpSqAVQVJ0/eB7cdPR0/WXIv5r35AibEW2BV2RJQt5gCGE1MABAR0RYL1cKIwIjBukIGM5cMH/hHJZlS3tUvMlxZ/6AV+iHVAEPvM2Kf/3Bfb1hc8afmUFnyP85L4toPfAonbL8XLKJAicE/1ZuogCxqKTt6u91x1Ha74dOPXo/blj+HFicOzxi2BBANwgQAERFtNqsKQX+Z8Jw3nscXF96AFZn1aIslhgn8BwX7QBS5D5sMwCYF/iP2+W+rqf6bcTeiWlea8r8svRaffNeh5ZL/QC2H/FHdK1WwiAj+cPh55ZaAvkIenbEkkwBEFZgAICKiTVYK/EsTme9dthiXLZqP+5a/ANdxMCnVhkDtRgL/4v8NXrmXwZ+r/AQ2IfAf9PWG+esGPrjZdyGqF6WS/5Qbw48P/MiAkn8G/9QoSglpq5YtAUQbwAQAERFt1PCB/32Yv3wJLBTtsQQUgK8hovBcBgb0wKA+/mG23xMG/kTbmiMGfUGeJf/UNEwxuTVcS4BjBFaZBKDmxgQAERGNSAGENoRrHADDB/7lLf2A4QP/YT+GgYH/gE8x8CfaWgIgZlysyK7HtF0OwpWHnIN2L8GSf2oKQ1sCFuNTj14Haw3i3CqQmhwTAERENMTALf0cLFjxIn7+3Fzct+KFoYF/aUu/aBpTxVcZZqo/sIHAv+IvgpED/yFfaJjvMfIHN/suRPWm1O//evptfOJd78f1h32GJf/UdEoVLqFanDx5X8w68gv42EO/RiYocC4ANTW+CxARUZlCEVgLgcA1Bt35DH767N2YNv9q3LNsEdpiCXTEk7DQ4qq/RNvviQwM/kWid5jKVf1Sib9U/rni86WEgYmmOo8Y/Fd+r+ESDOVPbASDf2pAjggKYQAR4McHfgQ3HHYuHDGwLPmnJuWIQaAhjt9+T9x+zIX40PZ7Yk0+Da9Y2UbUbFgBQEREg1b8BevyGcx8YSGuWfIglvauRmeiBROSLdGKifYH6+WS/5IhQ/wq/jwgQTDoD+UxARuIyod9/JA7beRfuml3IapHrhjkbQgLxfWHnVvR7w8YPvGpibnilOcCHL3d7vjEI7/DTW/8DTsmO1CwAUcDUlNhAoCIqIlFPf62P/AvZDBzyUJcs2QhlvauQXssWdzSrzjZvxiER3H+4An+FU375Y9V3GFwqf+QboGN9PlvMH7ZSHDD2IcanCsG3YUsYsbBzUedjw9tvycKNkDM8FKPCChVAliY4lwAEeCPrz2BHZLjYAQcDkhNg+8Ko0krbkTNbmOvg+FeK3ztjKpQLRwx5VL/a5YsxDUvDA78tX9Lv8oHDy73FxQrAzBMaX+RDnpc+R7S//kBDxkhah/wvBimKmDI1xnpsUR1TgAo4BkHq/N9OHGHvfGtfU7A0dvtjkBDBv9Eg7jFdhgjghsOOxcHjtsZ//vi/SiEAeLGRahafl1RFfHnP6r4zkBE1GRKqxylvuCf/O1uXPvCQ1jauzoK/JPFwN8WA/9ygA8Ms2wf/bcy6B5uOv8w0bgMTg5s4L6bdJ8NXTDwYoIaUTH4fzPbg4+9433445GfBYDisD/2NxMNx0BQHF2Lb+1zAg7qfAemPfQbFGARMyZKAhA1ME6DISJqElYVqtHKhxHBvcsX48w5l+E7j92EtYU0JqXa4DnR9kjRYn1psj8wYIifKf25YnBfcXjf0AF/g+4jpa87KICvHA5Y8bChRvzEwE+z5J+aQGXw/4cjzoMtVuxw2B/RhkVvZYKCDXDCDnvhpqO/gNCGKFgLZ0OzaIgaACsAiIganFUtX+wAwL3LFuOyv9+H+cuXwEKxU2snfA0rSv0HB/AVfx68ui+DP1f5iYq7bkqP/6CHbsIHN/suRI1icPBf6sJxubZDtMlixkVgQ3xo+z1x09Hn42MP/hoFgJUA1NCYACAialAbC/zbYwmICAoaohyeDwn8ByUASsqBPQN/orE2UvDPSf9Em881DpMA1FSYACAiajDRZP8QbnGP45EC/1AtoDr8iv+Aj1V8vDLwxzCfL/2RgT/RqGDwT7TtMQlAzYQJACKiBqFQhFaLW/o5WLDiRfz8ubm4b/kLwwb+/UH+MIP9Bq/qjxj4V/xlQ4H/4PsO+Rob/OAW342okTD4Jxo9TAJQs2CjGBFRnVNEE/sFUt7S76fP3I1p916Ne95YhLZYAh3xJCy0eBETDdsbMoxPpDjID6iY2DfoNujzpeSAKX69YQORisdXPnTwfTZ11Z+xDjUhBv9Eo29wEoCDAakRsQJgVCmG39yciIZ/XeigP/O1syEDV/wF6/IZzFyyENcsWYilvWvQmUhhQrIlGu5X/FEO7POvqAIof7L058GfUwyJvIsfG3hdVLkfIAZ97dLXGHSfQf+qYfHai5pS9HrxjFsM/g9k8E80yoavBFDEjBNV0A14H6PRwZ/vaGICgIioDlm1MBIF/t35DK5ZshDXLFmApb1r0B5LYlKqDaHaKPgfMMevIpAfNvAf7r+D3ohLHxsw/2+4+wz3+JHe1Bn4Ew2lxZX/9cWV/88y+CcaAwOTAF/ARx/8NQDAMwaW7QBU55gAGEU8PRBtOdbPDC9UCyMCIwbrChnMXLwQMysC/+1S7QiLe4EDGBBAa6mEX1ExvX8zh/sBA9oGBvx+ZOh9h2KPP9Gm8oyDldkeTGXwTzTm+pMAe5UrARRMAowF/nRHFxMARER1oLSlnyPR6Ja7Xn8eX1x4PVZk16PNS2BSReA/sMwfGBjkF/v8h60CkEGB99D7bHSy/wbjkk3s8SciuMbB6nwfg3+iKiolAY4vJQEe+jWMCgwYpFL94hBAIqIaZlWhqjDFgX3zli3GGXdfhmnzrkRPkMOkZBs8xy2u+Gu0CD94UF9xSF//IL5Bw/gqB/xh0OPKDxtmwF/psRsNSDbhPhzuR1TmGgfdhQxO2H4v/OGIzwJg8E9ULa5x4BeTALOO/AL6/ByMYQhF9YsVAERENai04m+KZfXzli3GZX+fj/nLl5S39FMAfnHFf+Cq/6AV/8qPVf5xQNA/+HGlh25kxX/w19z4Bzf7LkTNxBFB3gbwxKDrPafAFLfudLhmQ1Q1XrES4MQd9o7mcfzzCUxOdsC3YbUPjWizMQFARFRDtPj/Iwf+SYigvCfx8IH/oARAycb6/Bn4E1WVgSBnQ1hrccvRF+DQCe+Kgn9h8E9UbU5xF4DfHvZp+Bpi9ut/w6REW3FnAKL6wQQAEVENiLb0s3CNA0Bw7/LFuPT5EQJ/rQz8KyNpqUgGAEMD+40M+Bsp8K987DAP3cgHN/nTRM2s1OMfg4M/HP15HL/9XgishctSY6KaUK7KU+APh38WAHDnikVodeNMAlBd4bsKEVEVKRSBtRBI1PebT+NT912D0+dcinnLF6M1lkBHPAkLRVhsC4iCf6kIyot/NhgY3A/u8QeGTw6YEXr8y3cdmigYdIfhPkhEmyHmuFiV7sY39zkex2+/FwphwOCfqMYIJJrHIYLfHvYZdHgJZEMfzuAkOVENYwXAaOI+ZkT9NvY6GO610sCvn2jFX+EaA9cIuvMZXLNkIWYuXogVmXXoiCUhIkNX/Ies8mP4Vf+RAnKVAXcRyPA/4+HK/aMDH+6OI6v8dIP+Lom2liMGK9Lr8YldP4Avv/toBDaE5/ASjagWGURzOWLi4Dcf+DSmPXQtcmGIuHG4PeC2ogBYVDFq+O5CRDSGRg78F2Bp7xq0x5JojyeKgb8OGsw/aGjfxnr9B/x5cAXAJpb7jxjfs8+faFtwxKAvyGPqLu/D7w8/D0YECr58iGqZIwZWFSfusDduOvp8fOrh68qvW6YAqNYxAUBENEasWhgZOfCflGpHqMVS/yFBvAwM5of0/w93v/IHNz7gD8DQNoFh77TBfyOjFqJNZyBIhwV0eAn89vDPwIjAQrndH1EdMCIohAGO334v/Pu+x+ObT96EnVoncGcAqnlMABARjbJQLYwIjBisK2Qwc/HwgX9Q2tJvQBX/KAf+Msx9h8UVf6JtqTT0L2k8/OawTyMuDif+NxDdyDrwiIlYqiue4yKwIb60x9F4eu0buGP53zkUkGoeEwBERKPEFkv4Sxf0d73+PL644HqsyK5Hm5cYOfAHBpX7y/BBPgN/orrlGgfL+97GTw/+GE7cYW8ENizuAkL1pLR1q1Utn/MBbNLv0rdh+f6OmA1XaFFNEkTbA6aMg2s/8Cm8+44Z6AnySBkPls0AVKOYACAi2sZKF4GmGNHPW7YYlz0/H/ctXwLXcTAp2YZgc1b8Ryvw3yAG/kSjxRGDHj+HT+7WP/TPYfBfN7Qi4PeKW7c6InAqzolpP4dQ7ZDzsCCqCuuItxQfO1BQLB93xEA4Wb4ulH6ncePiN4d9Gp955Ppo3q5yHgDVJiYAiIi2kZEC//nLl8BC0R5LQAH4pcAf6J/gX9xbeMhgv8HXf4MHAW5N4D/stSUDf6LRVNn3f+0HPoWE43HoX51QVYRq4RpnQMC/Pp/Gkyv/gYdefw4JL4FcWMBvn5uLXODDiEFlGGjEIO/ncOQu++MDk/eGryFSbhyfO+BEJNwYWrxE//dDaXbMBrZppZrgiEFgQ5y4w9745j7H49+f4jwAql1MABARbaVSCejIgX8SIogm+2NQ4D94lX9DgX/5wRV/YOBPVDeG9P0bl33/daA0x0VE4IqDtJ/Dw8sW49E3/o5nV7+GB19/DtkwQDqzHjDR7zIeb4GBDDsLQERw20t/xW1LFgKqgBj85K+zkfLiOG//E9AeS+Hc/Y/Hdqlx5edGVCVimAioYY5xENgQX3730fhbN+cBUO1iAoCIaAtFW/rZYq+n4N5li3HpoBV/ESlu6beBwL/iPxsP/Ac9ZkM9o8MOCxxyp438KzftLkS0cez7ry+2WMJfCsJXZ9bjmmfm4Kq/3Ym3MuuRz/ZCYgkk3BgcMehsm1gO+EO1G6j/VnTEUzDSUvwb0Odn0VvI4PsLfgeIwf888kccuuNe+JcPfAwf2HFvtMWSAJgIqGWcB0D1ggkAIqLNFAX+CtcYuMZBdz6Drz70B9z86lMQkYEr/qWhUENW+Sv+DgyeADhMQkAGfBqyocu/4WYGDHOfTcFrTKJtgn3/9aMU+Jti4D936VP45eO34PEVL2JNtgdxL46Y8ZBqmwirFra4wuvbYJO/R6gWYUVM6IoDGCDR0gkAyIQB7nrlScz/5/PYvqUD0993Gr580OnoTLQCQPn5w1N0beE8AKoHTACMKq24EdFAw70udNCfa+v1MzDwF3TnM7hmyQLMXLwQKzLr0BFPFlf8LaAysPp+QOCPYQL8Yhdw+ePDdAUXPzZwYb/08xmukqD0NQbdZ8hjh8GrSqJtIHr9GQjy1h/U9698mdUg34bl4XxzX30Klz5xK+YufRqBWiS9BMYl2xGqhapuVsC/MYooQgw06hk3IuhItsJaxarMelx0369x5dN/wZcPOh1fqkgEsIWk9gyZB/D0Ldi5tROFMMDA92QamQJg68RoYQKAiGpYbbxJKoCwWKo7OPBf2rsa7bEk2uOJgSv+0P6BfZVB/rAl/RgmcB/8OR20sD/cfYZ7/Eg/wxE+zoiEaBsqTggRIOsX8McjPoe44zFoq0EKhSrgGQf3/fMZ/OzR2Zj/2t/gq0VbvKW8shuM4VC30EYBUMxxkWwZh7ezPfheMRHwxfediu8c+Qk4YhBqCEdYTVJLHGPK8wAeeOsl3PvmixgfS3EeANUEJgCIqIYNXjYfe6UL9VKp/+DAf1KqHaEqQtVibD9ST38pGTB4VX+E4X6VX2rEraCGaxUY5j6bgoE/0ahwxKA3yGHqLgdhyuR9YBn815zSeT5Ui/9+9Eb8+NHZ6M31oT3ZhmTx89Wkqgg0hOe4SLSMw9pcLy6aPxMPvv48vn3Ex/HBd763uFsAn1e1QhANjUy5Mfzne07B42v+CQuFjDAYkmgs8UxBRDSM0h7PjhgoFP/zt7vw/pt/gO88djPezvdhUqodnuMiUAugIvgv5SwGDPsTwMjA4L+UDBg8EwADHz9s8D/4sVsT/Fc/x0LUsKLS/wCdXgpXHfqJaKtQ7u1eU0rB/7p8Guf8+Ye4aO6vIADGpdph1VY9+K+kqlHvvzgY3z4J9yx9Gqf/6SLc9fLjMGLK71tUG0qtAB+Y8C58e78TsSqzHp7DSg2qPlYAjCKegom2TjUmANhiCX9pS797ly3G/z4/D3e+9gzGJdvKK/5B6aJQ0N/JO+yAv+EG8g36WPEv5bigopJAh9xtaIXAUBsJMBh/EI0JWyz9/78jPoeE40WrtFx7qRml4P+epU/jvNv/B2uyfejs2AGBDca01H9zKRSF0Me4ZBvCMMQZs/8LH9nrKPzxrO/CNYYtJjWk1ArwxT2OxgOrXsLcN1/EhFhLedYDDY8TAEYXEwBERBga+M9btgiXPT8f9xa39JvcOh6+hv2BP9C/Cg8Ms4o/QuA/7H0rPzRCdM4t/YjqihGDHj+LqbschJNY+l9TVKMibEcM7nz5cUy79QcIVdEWS23TwX6jLbAhRASt8RbctOg+WCiuPe1fMS7ewiRAjSi1ArS4MVz0nlPw2Jp/wtcQhq0AVEVMAIym2htiTlQ9G3sdDPdaGYPXzgYDf9Xyln6+DYfp56/4e2ngfmWgXh7kPyjqVhlaBFD6mw7+UMXHKx8wtDRgZCM+johGg0Dga4gdEx24kqX/NaVUIm9VMe3WH+LPLz6EpJeA6zh1uSqriGbQdLSMx20vPYqH3/gcrj/jPzBl14MG7GhA1VPZCvAf+07Bt5/5M7ZLtNV0lUnV8VplVDE1SERVUt2LYUW0emIkys7PW7YIZ8y5FGfefTnmLluMVi+BcfEkFMWeSik35Q/s768c7jfsgD8ZmCjAoOBfyl+s4nHDfHzEFX+W+xPVGtc4WJvtxYV7HIVksfRf+GKsOoXCSLTyes6tl+DmxfehNd4CEQNbQ73+WyLUEG2xFNblMzhr9n/hnqVPwzNOTc0waGaOiWY0fG73w7Fjoh3ZsMBzAlUNEwBEVH0jbVM/Kt9KEVgLQXSR/sCKF3D6nF+WA/+2isA/LG/lN3i4X2Xgj6Fx+ODHVPzjynmC4RIGGHjf8h+H3G0TA39eWxCNOUcM1hUyOH3nA/DlPY+BqoVjeLlVbaVzf9rPYdqtP8QtSxags2UCQrUNU4odaIiEG4cYBx+Z3YW7X30SAmESoAZEwb6iM5bEzMM+hSC0rAqiquE7EhHVrCiG3jYXZv2Bv8A1Bt35NH7yzBxMnXcV7nljEdpiCYyLp2ClIvAHhgnyR0gGlA94uMBfog+bQfcf9h886PsOvdPG/7G8piCqGgtFaEN89z0nocWNFbt3+KKsNj+MyuEvffI23PLcXExonVBX/f6bKlQLz7iwUHz69h8jH/pwxMA2SJKjnplipclJk/fBCTvshbX5NFxhiwaNPSYAiGhsbOj6t/S5Af3v2+aCeWjgn8FPnrkb77/lEvzHY7dAoZiYbIVVRVieOTtokF/pUAZUAmxG4D9cSX+l4aoMht5p5Mdvxl2IaPQYMej1czjnXQfj8Im7cvBfjQjVIua4mLv0afzk0T+hvW07FMLGC/5LQrVIuAn05TP4zO0/RmBDWKsNU+lQzxTR/Ilv7zcF47wkfA2ZIKQxx3clImpIUY//cIH/D/Cdx2/G2/k0tk+1w4iJJvsP7vE3GBT4V9wqpvdvPPDHyMmMYRMHQ+60oU9u8l2IaHQJBAUblAf/KQf/1YSgmIR5dPkSnDnrP5EPA0DQ8MFwqCESXhI3L7ofn7r9x9H2gJatANXmFKsADpv4LvzHflPQnU+zRYjGHJ9xRFQ7ttHFcqilHv9i4P/s3Xj/rZfgO09Egf+kVDs8E018ji4BR+jnHxL4lz6OgcF7/wfLOYRhB/lV/jsZ+BM1FMcY9Pl5fPHdRyHpuMXzEF+g1aRQQBWBDfFfC6+DbwMk3Fh5J4BGF2qIjpZO3LRkAe5+9Sm4HApYEyoHAu7aOgH5MOC5gsYUEwBEVFu24j3QajSxP8qwK/7nmTl4/60/xHcevwVv59KYlOyAZ1wEttgNOXi1f0AVwJYF/iOW+w9+LAN/ooYhEGTDAnZItOH8dx8JQLiqVwOsKlzj4FO3/xj3vvok2hJt0ZauTcSqoiWWxNmz/wuPLF8CRwyTAFUmEFi16IwlccEeR2Ftvg8ut2ukMcR3JyKqXRuclN/PqkI12t7JiODe5YtxxtzL8J3Hb8LaQnHFv7jHs4pGZ75y0F/+Zv3/GY3Av/LrD/+P3dAnN/kuRDT2RIAgtLjmsE9hnJeEcvW/6sJi6f9drzyBm5csREeyoyn3XVcoHOOiYAN0LbweaT9X/jhVT1QFYPGVPY/B6Tvtj+5CmvNCaMzwmUZEVSRD/7gZ1ySVgb+IYN7yJThj7hU4c96vMH/lC9ixdTxcY/oD/3IAXa7xx9C+/1EK/DH0LgO+3oYw8CeqWY4YrPdzOGGHvXDS5H1g1cLwQr6qFAojBt25Pnz2Lz+D58agTVL2P5zAhuhItuPefzyK/33iz3DEIOA8gKoSRHsctbgxfPc9J0GwWZc/RFuF71BEVFs2c8VfRDBvxRKcce+vcNb8X2HeisVo9eLo8FIo2Ioe/8EN/uWgf0Akj/67b+PAf8g/i4E/USNQRBdT/77fieCc9doQDYAFrnz6L3i7by2Sbqzpt8HzwxCpVAeuevov6M5FJed8tlZXqR3j8Im74qQd9sF6P8sqABoTfJYRUd2IJvuHQwP/eysC/3gSVopb+g2O+0WigL+00j842TBs4F/6BAN/IhooWv3P4qQd9sERE3eFFmeQUPUoor7/7lwfrnz6L4jFklztRvRziTselq1/E1c+/RcIwJ9LjVAA39z3RJhiVQDRaOO7FBFV2TCR7qDAvH9LP8A1Dh548yV8eP6vcNZ9V2HeiiVo9RLo8JKwqghVMWCZfsBtuO+5oftENxFASpUCw0bm2yjwH+HHQUS1KVr9F3xz3xOhYAlvLahc/V+2/k0k3RhXuosCa5GIpXBlsQrAYxVA1TlioGpxxHa74qQd9mYVAI0Jt9oH0Ni04kZEwze5VTT/lz/ff0erCgGQcD2sK2Qw86WH8LNF87Aun8H4eAoAENoteJ1VjgGAYmjkXdzDe0hAXvo+MuA/5eMf8I8c+jU3ejxEVBcccbDOz+CUHfbFEdvtClscOkfVU1r9X5PtwZVP/wWJWIqr3BUUioQbw/L1b+JXT9+B/zj8HFhVeJxAX1WlK5hv7nsi7nlzyaCkTLPGEM367x4bfKcioiobLnhXQKJtclrcGHKhjx89fzfef+d/47tP3wpVxYR4C0K10XZGUnz8kJL/EW4DdgAY9L1LhQCl+4x0nJUL+qUBg+X7jfTvHAbL/YnqkkJhAHxz3xOY6q8RUbCvuHHxA1i2biVX/4cRWouYl8Q1z9wNq5azAGrA8FUAHAtIo4cJACIaWxsLdouft2rRFotjzvJFOHzOT/C9v92Gt/NpTEq2wQgQwGLgUL/NuA1+QHGlP+oC2ECp/+BWgQ2W+m/gH7oJdyGi2lXu/Z+8D47YbjcoV/9rghGBQHDva8/AcTzYJp78PxKFIua4WNO3Fo+veAkC8OdUAyqrADgLgEYbWwBGEzsAiIaqqPgf+EEd8HlrFUknjoWr/gFHDCYnOxCqRWCLc/214kvooDaCkZTaCwa16w/7tyFV/CN84SH/jkF/HKkbYMhjiaheqChEgW/uw97/WhEWkzDzX3sGd770CFLxVFQhRkM4YpAOCvjBQ3/AHdO+D7MJu+/Q6HLEwKrFEdvthimT98ac5YvRWXoON+MJRgHw5TtqmK4morG1savlis+pKlq8OOLGRWDDin2cpfz/AxfTJUoGjHCL/jfcAnzF34Yc3whL9QPuN8x9NvTvZMRAVLccMegp5HDGzvtz9b+GlLaHnbv0KQShD5e/kxEFqkjEknh85YtYn09HJeh8U6q66NJA8a19piBZrGAR/lpoFLACYBTxNUs0ghGHAeqQv4aqg5b7S58vhfxbOPxvQ4+UAXfcQFXBRlZNuKhC1DBKZygRQS4McNz2e0KhsKowfK1XlSIaZJf285j9woNIxFs4/G+DojaAnmwPrn/+XvzroWcjsJbDAKvMFNsPD56wC3ZItWNlpgdx4zZlcqb5/sVji+lRIqoDw03jjygEKtFt5L7/qG9fRaL7bzD4H7SaP+z33YQGfgYERA0l2itEkAl97N42ER/b5SAAAsfwUqpW5II80oUcT7+bQACENsS6XLqiuo6qSSAIbQhHDD672+HoDfIwPL/QKOCziohqiGzgr6XhfBt7/IhT/zbwkBGG+4044G8TDoGIGo5jDHoLWVywx5GYGG9BaMNiYxFVU2m1/7rn52FN3xokOP1/owJrkYincMPf70UmKMDjbgA1wTEGjggu3OMo7No6HtnQ5zmGtjkmAIioxgyTBKj8UClI3xbfonK1f4OBOwN/omYnEORCH+9u3w7T9zgKALj6X0MUwPpchhPtN4NAkPHzyAWFah8KFQkEgQ0xLpbEhXschUxQgGGPEW1jfOciourY4PvZcFvwDfrL4BX7DX2pyoC/FPRXJhK2JvDf4OOJqFE4xmB9IYupuxyEcbEkAq7+14Ry/38hi+v+Pg+JeIr9/5tAoYi7Mazpexu/fe4eAODPrUaUEotf2P1ITIyn4PNcQ9sYEwBEVD1bkgQYqSxfRrhVfr7yy24w+N+MwJ/vyURNIVSLhOPiQzvsBSAaBki1I1RbXMnm72VTCQCrFhk/X+1DoQoCgVWLNi+OQya8E31+nls10jbFBAAR1bAR3vC2JPAeUAmwKXfaxK9FRA3PEYNeP4cP77w/Prj9nrDc+q/mtHhJuE06MX2rqKItlqr2UdAgCsAzDr6z70nRloB8XtM2xHcvIqqujQbSG7jDiFP/h7lt9Hsw8Cei4UVb//kDtv6j2lD6XTzw+rNYn+2BxyTAJrOqcN0YFrz+HPKhDyPCn12NiH4XwMETdsHkVDvyYcA2ANpmmAAgourbVgH6Zn9TBv5EtGGl4X97tW+PqbscBOHWfzWllABY8Prz6Mv1Isa97DeZVYXnxbHgjeeRD31WtdSQ/i0BBZ/b7XDkQp/DAGmb4SudiGrDJr2vbUbQvsHHbuLjGfgTNT3HGKzLZ/CxXd6HifEWDv+rUS1eHBDD9evNpKpo8eJ8TtegaEtAg/N3PxKdsSSHAdI2wwQAEdWOzXpf25z6/818w2TgT0RFgVqMiyVxwg57A+Dwv1rFtowtx59dbaocBnj0pD2iLQF5/qFtgAkAIqot1XxvY+BPRBUEgkIYYIdkO47abncA4AU4EY0Zq9E2l8fvsBdyoc8EJG0TTAAQUe0Zy0B8a7oKiKihGRP1/39u98MhApb/E9GYKs0b+dguB2Gv9u2jJADPQbSVmAAgotq1rYPzrewMIKLmIRD4NkRnLInzdz8SjhgO/yOiMSUQBDbExHgLPrbL+7CukOF5iLaaW+0DaGiq/Tci2jKjGaTzpUlEIzDGoLdQwOk7vwdtXhxWLQynpBPRGCuV/Z+ww964/MUHENiweP3SwBcxqgBstY+iYfGdjIhqm2LbvcfpoBsR0QgEgG8DHL/9XvCMw0FpRFQVpbkjR223O3ZOjYNvAxYw0lZhAoCIiIiogkBQsAEmJlpw9i7vAwCW3RJRVZTaAESAM3d+L9YXsjwf0Vbhs4eIiIioghFBJijg6O32QGcsCauWg7eIqGpEBI4YnLjDPujwkgiU5fG05ZgAICIiIqogEm3/d/wOe7P8n4iqrtwGMGl37JTqgB8GTErSFmMCgIiIiKhIIMiHPnZuGYePsvyfiGpAZRvAOe88BD1+jucl2mJ85hARERFVUAAtbhwpN1btQyEiKnPEoCOWhCuGs4xpi3EbwFHEFyYREVF9cY3B6kwvvrLnsUi5HgIbwjVOtQ+LiJpcacX/U+86FD/6+90o2AAODLQBIw5uAji6mAAgIiIiAgAIfBtifKIFJ0zeGwIp78FN21Zl0GJVYVUh2PzFk8CGxa/BcGFrBDaEb0ModIt6ywXR6nTpoexP3/YEAquKjlgCH9x+T9y27Hm0eQkoZ5TQZmICgIiIiAhR7BKoRcr1cMR2uwHoH75FW0ehgAJhMVCvrKpwROBs4Y/ZK36d1lgSYCC0RQSCzkTrNv+6vg1hRIqvIaYEtoVQLTzj4KDxu+BPrz2JcbEUk1+02ZgAICIiIkI0/T8XBJgyeR9YtbBqwPh/64RqoapRwC+AK1HAnvZz8G0IRwweX/ECHnr9eSS8RDlBsKmsKowIHnzj74htweObmSL62eXCAi5+8PeIOZsfFggEFhZxJ4bPHTAFccdFqCE64q3l5ExJYEM4xjAVsBWc4gnp4PG7YHyiFb6NdgNoxDYAGj1MABAREREhKmHOBXkcPH4XJBwPvg3hCfv/N5dCEVoLxzjlsvA+P4dcUMDvnpuH3kIG1z1/L3JBAUYMunO9yGV7ga2Yam7cOFpiCW7ZuJmMGORDHzMW/HbLv4gqIAY/e+wmuMZB3s/h6He+F++d+E4c8Y734NAd90JHvKVc9RFNs4/2tafNU2pJOmb7dyPhuMgEfjmpRrSpmAAgIiKipicQ+DbA+EQrDh6/C4D+1TbaNKXA3zVOOdibt/QpLPjnc/i/JQuQLuTwVu8aAIpEvKW8cukaB51tE4v955v7PaPWjVCVpdBbSCAY19K5VevyCqAnn4l+hyL480uP4Na/34eWVAeSjofDd94Px+zyHnz2gCmYmGwvPkahqjBMBGwWq4pQQxy13R64fdnzaPNczgGgzcIEABERERGicvWU6+GY7d8NABwAuIkGB/5vZ3vxm+fuwYNv/B1z/vEYgrAQBfwiGNcyDkBxFoD2P963QfX+AVQeprg1+uc6KNpjKZh4VKKeDgu44+XHcMeLD+KKp+7Ap/Y9Dse88wBM2fVgiAhUtdiOwETAxggEgYZIOB4OHr8LZnEOAG0BJgCIiIio6VX2/4cawlFh//8msGphxMA1Drpzfbjy6b/gyqf/gmXrVgJODG3xJBxpQWijAGVbBJpUmyr70EO1CNVCALhi0BFPQaQFb6a78cOHfo+f/DWOE3d9H77x/rMxZbeDB/Sxc0bAhnEOAG0tJgCIiIio6bH/f/OVVm2782lc+dQd+NXTf8HydW8iEU9hXEsnVBWhWgTKoL9ZlULSUsWHZ1wkWjphVTHn1adw79K/4cRdD8LXD/0Ipux6cPm+nA8wMs4BoK3FBAARERE1tVL/f2e8hf3/myC0FiLRALk7X34c59/5c7zZ9zYSsRTGtYyLgn6u9NMwFFp+brTHW6AA7nr1Scx55Qmcvc8xmHnKN9CZaEVgwwFbRdJApTkAR0zcHX9Z/nfOAaDNwgTAaNKKGxEREdWsQC3Gx1Ls/9+IUC0cY2BV8bFbfoA/v/gwYm4MnalxCBj402YobdnYHm+BheKWFx/Gg68/h+s+/C2ctNvBsKoQYUvAYAJBWJwDcNR2u+Om155Gh5eEbaR4QwFwrMGoYX0NERERNT0F4BqDbFio9qHUrEIYwBGDB15/Dqfe+F3cvGQhWuMtcB0Xvg25AklbJFQL1Whw4NpcH6b9+Yf44cN/LO4KIUwqbUCoFmYrts+k5sQKgFHFEgAiIqLaJnCMoDeXxbf3OwFtXoLlx4NE27UBMcfFPa8+hbNu6kIu8DEu1cHgjLaZQEMkvQSgiovm/QpPvfkP3PzR/4JrHM4FGMQpBv2f3f1wXPbiA+guZOGJaaBBgI3y76hNfCURERFRE4v2nlcbRr3t1T6cGmM1WoW1qvjhw3/EtD//ECIG45JtDP5pm7NqoVCMHzcZt77wIE7543fwwOvPwRHD59swYsZBLiw04HmLCYDRxAQAERERNa1oAGCIcfEWHDlpdwCAYf8/gP5t3UK1OOfWS3DRvF8BCriOy2CMRo0CKIRRhck9S5/GKTd+F3OXPg3XOPD5vCuzqvCMg6Mn7YFc6HNuCW0yJgCIiIioqQVq0RlL4ehJHABYolCE1sKqxbRbLsEtSxZgwrjJxXYArs7R6AtsiHHJNjjGwVmz/wtzlz4Nr9gO0OyiqhyLuOPiyEm7IxcUmLikTcYEABERETU1DgAcKrAWrnHwqdt/jFsWP4DOlvHIhz4Lc2lMBTaEY1wY4+DMWf+JR5cvidoBlJUAJaHlIEDaPHy2EBERUdNyjEFvIYfzdjusPACw2bcdC9XCMw7ufvVJ3LRkATpaOuHboNqHRU3KqkXM8eDbAP+18LriQECngQbebZnSIMDzdj8C70iNi9oAmvzcRZuGCQAiIiJqaoqol5aXzlHwLxDc/eqT+OhNM5DykrAs+acq822ItkQb7n31KUy79YfI+DkE1jZ9EgAA4o4LnrxoczABQERERE3NiMDjtn+wUDhikA99fOb2HyOEwhiutFJtCGyICS2duOW5ubj0ydvgGQeB5TwAVUXMuHyV0iZjAoCIiIiakkCQD33snBqHc3c7HEB/WW2zUSistUj7OXzm9p+gJ59Gwk3AcuAa1ZBCGKC9bTv89NE/4e5Xn4QrpmmHAgoEgQ3R6sVx7m6HobeQbdrzF20et9oH0MgsWJFDRERUqwTRe7VrDBJOc18SBTbq+//pYzfh5ufuQWfH9txyjWqOQiFi0FdMVP3zKzcg4cZgoTBNetUtAJKOBwXKVQD1Xg1Q78df65gmIiIioqakiLb86wsKCJu4lDhUC1cMHl62GD955Ea0t2/H0mqqWVYtWrwk1uf68Pm7/j8YkabfmrI3yAOqEDRG8NwI/4ZaxgQAERERNSUjglxQwDGT9kDccZu63F1EcMkj/4d1uT4YGPb9U00LNEQilsDsRffjoTcWwYg0ZSuASFT1cMykPdART8G3YZPWQdDmYAKAiIiImpJINAPg6HICQJtuG61oSzWDh95YhPmvPoX2ZDv3WKe64EBgxOBHj97YdK/bElNOALwbE+Ip+MoGZNo4JgCIiIioiQnSQaHaB1F1P3r0RlhVXhhS3QjUIhVP4d5Xn8RDbyyC08QDAdNBAWGxBYBoY5p74s1o04obERER1ZYmf58ur/4vW4R7X30SLfEUgiYNoKg+GQisKn746I2Y844fVPtwqsaIwFptnHNZo/w7ahQTvaOJiXQiIqKaZkSaegcA3wa45OH/g2rzTlGn+hWoRUs8hftefRLzX3umaasABEDCcRsqblbGqaOGP9hRIm0JFUGO76VERES1RyDIhT52So3DubsfDgBNtYe2QuGIQW8+i8dXvIiYl0DQ5JPUqT45YlAICpi39GkAgG2i57FAENgQLV4cn9ntMPQVso1xHlNVgeaqfRiNqgGeITVGoLh6uvf2WT/tU2CmJOOAIKj2YREREdFQzVoBEFqLUC2u+tud6M32IOY4YN0t1aPAWiTiLfjTkgVYk+2BZ5ym28WiYSoAFArHeLY311cI9RoAwPSZjKO2MSYARg8rAIiIiOpAM60YAtE1tmscAMDMZ+bAuHGEtrl+BtQ4FIqkG8Nrb7+BGxc/ACBKCjSbBjuPadLLsQJglDRfynssKUx/Nr2hXpREREQNoDnfo60qHBHMf+0ZrEl3I+64TbdiSo3FqsL14pj76lP4wntPRqz4nG6+7QEbYbJpdOxh3uFC9SjhD3ZUlbKP9fwiJCIialylfbSbSVhcKXxy5UtIZ3vhGa4HUX2zqnAdD48sXwLXOHCk+UIcI42U7mDsNJqa79VBREREhGiAVjooNNXqt0LhikE2KODJlS/BiyWacmo6NR7XOAjCAh7457MAGq4kfqPSQQGqtoGSADRamAAgIiKipiMiyIUFHD1pD8SNB9tEQbARgWscLHjjeTiO13SBEjUehSJmXKxPr8MTK18C0F/p0uikWMV0zKQ90BFvgW/DKh8R1TomAEYR968kIiKqTUYE+dDHMZP2QNxxYbU5+oVLwf7C159HGPjlYYBE9S5UCzeWxJMrX0I+9OGKaYrqnlIb0zHb74EJ8Vb4auv/XKaMoUYTf7ijSKA5aJOkH4mIiOpO1ALQTEoJgAdefxbrs+sRa8It06gxWVV4bgz3v/4c8oHfdPM90kEBQSO0AAgggpy0JXhiGiVMAIyG4n6VhVCusb25PjjG47srERFR7Wm2IKGkLZYCxPDihBqKqqLFS8AxzRfiNMQQQEEgyTgUmPn2WT/tw9XTPQhPU9ta8706xlBx/0o+aYmIiKhmKICMnwfqP1wgGiK0IXKBX+3DoC0lgIgyhhpFTACMIu5fSURERLVCofCMg3Qhi989PxeJeBKBbZ7hh9TYFIqkG8Oq3tX47XP3AACf3/WKMwBGFX+4o41PYCIiIqohChRXSFkBQI1HVVkBUOc4SH108Yc7iqQtoSLI8f2ViIiIakmzzj6g5sDndx1TVYHmqn0Yjcyt9gE0JIHi6une22f9tK/zxn+bKcn4dzXIBlB41T40IiIiAlTBDlMiaiiqxRvq8vSmcIynvbleP5RrAESD1S+s8lE1IFYAjC5VLWaw6vBVSERERERENOqKsZIqtDhInUYJEwBERERERERUdQJYDlIfXfzhjjZFCwz7kIiIiKh2sEeaGhmf33VKFQBaNJ7nL3AUMQEwWjq7LQBYsfdpppCHiIGyEYCIiIiqS6FI+3kIgyRqMAIAapH289U+FNp8FjEXqrive2U8h64uA2HsNBqYABgtU2dbAOjpydyPnJ+DEafah0RERETNLVSLuOPh2HfsD9/Pc6WUGkrBhmhNtOHYXfYHwEqAuiKwEveg0Pvwjcvy2HElY6dRwgTAKOuIJVtghNkrIiIiqiqBwKpGCYBdDkAQFBggUcMQCHwboCPZjuN2eS8AJgDqjlUIkKz2YTQ6JgBGmWnJKoAWFrAQERFRregtZAAGR9RgBILABkj72WofCm0JRwAmAEadW+0DaFgCRVeX6V65NjduO9wnMeckZEMLgOUsRERENUGbdk5vyovDiOH6BDUYRcKNwZHmW+Psr3bQQf+tAwqFEaOZQt6KvQ9AeZ4abXvN9+oYSzuudPCNy/Jq9V6JOYCAT2QiIqKaoBAocmFQT5fJW8010aXf5w44CRNbJyAfFCBo0iwINRTXGOTyGZz3nhPREkvCt2FTPbdzYQCrpVCjDs9qjjjIFzI9O3RECYDiPDXa9pgAGANiMKlplxiIiIhqUGgtWmIpXP/KX5H2c3CN01Sb9STcGFJevKn+zdT4jAg6EqkmCvujcxkAXP/Ko1iRWYuE49Xn69oqIGjrWPFWW7UPpdExATCa+rcCvJdbARIREdUWAZquAiAalBYi5cbwmfecgFw+U64KIKpXAkEuKGBi60Sct/+JANB0z+uoAqBuz2alLQDnr1/jZrgF4OhqrlfGWKvcCjAfZOFwK0AiIqJa0qxTwkUE4xItcIzDq2xqCAqgJZZAwo1X+1Cqoq7PZaUtAMXM5xaAo48JgDHQMSnZogKX77BERERUbaWV0XP3PwHtyXYUwgBoqqJpajRR/38aU/c+Gik31nT9/w1BFYC2V/swmgETAGPAlVgo0BzPQ0RERLVFgXoum90iAkGoFh3xFhw6eS/kClm49bx6SE0vUAvX8TBl14MhIvW9Gr6F6v48pqqimqn2YTQDJgBGk0Bx9XTv7bN+2mchV0kyBgiCah8WERERRcG/IwYtbqzah1IVnnHwn0d9Ckk3hlA5cJvqkyMGmXwGp+15BI5/14EI1TblNoDReawOkwAKhWM87c31BCrXAACmz2S8NIrcah9Ak1CounBM9LoU1OXrk4iIqFEoFJ4YdOf6sHDVP/ChyXvDqsJpkpVDI9GErUN33BMTW8fjzb61iNXr9HBqakYEYejjhHcdCIUWX8fVPqqxoVAYEeTDAAtXvYyYicFarb84QxVQpOItTr6v2sfSBJovPTbWijsBGJUHNF3IQ+DA1t3LkoiIqOF44mB9vg8LV70MANB6L6HdDAJBYEMYMbjgwJNR8LNwmmxqOtU/gSAbFLDzuMn4+L7HAZCmm/5vxCBvfSxc9TISTqz+zmMKC8+FQu7rjOUK6Opqrl9gFfAHPNqKOwF079g2H3k/w3dXIiKi2qAApIlbAFxj4IjBlw/6MHbq2AG5oMDBaVRXXGOQK2TwpYNOx8RkO4ImHf4nELS4sfqs4BFYiblQ0XtfPrW4AwC3ABxVDEbHSMeKt9oAtMHy+UxERFQrmvldWSDwbYjORCu+dNDpyBUyTbd6SvWrvPrfsQO+dNDpUKBpn79GpL6HABqBKCZV+zCaRXO+SsaSQNHVZdavcTMqmI+YCwCctENERFQDBIJcGDRtIsA1BgrgSwedjp07dkA+9JtyBZXqj2sMCoUsvnTQ6ehMtDbt6j8A5MKgPhMACoWI0Uwhb8XeC6DcPk2jhwmAsbDjSgffuCyvYu5H3INKVAfAG2+88cYbb7xV7xZYi1Qsgete+SvSfg6ucVCXJbRboTQLoDPRii8edDoymfXwHKfah0W0Qaa4+j+hdXxTr/6HNoqVr3v5UazIrEXc8WCLZ7G6uRlxbM4v9PRk7gdQbp+m0dN8r5QqEqsuQvYAEBER1YpSBUBYj6tn24hrDEK1+H/vPwsnvPtwrM/2wDVMAlDtEhH4QQG/O/2b6Ey0wqpt2tV/AMiEfn1WABSJQb6zszNV7eNoFkwAjIXiXpYBcLXty6fhGO6zQ0REVAMUgGecph0ECKAcOLV4Ccw45lzEjIvQBk0dUFHtco2D9dn1+Og+x+DU3d+PUC0cae6Qps2NA/UYWggCaYlDYX7dPe3HPbh6uscBgKOvuV8tYyzZncsJbI7vp0RERNWnUHhisDbfhwWr/gEAdb2KtjUciaoAjthpH9wy9ftIF7IwwgsWqi2ecdCb68UJux2CP5zx7eJWls35PFUojAjyYYCFq15GzInV5/lLVY3YdajLDEZ9YgJgLAgUV0/3Vn/lirSKXCXJGCAIqn1YREREzc4zDnryaTzwZpQAqLs9tLchRwwCG+Lk3Q7Gx/Y5FuvT3XCErQBUG4wIckEBnnHx/WPOi9pURJq6UsWIQTYsYOFbLyPuxurr/KVQOMazvbke38q1AMpV0zS6mAAYSyIKVReOYY6LiIioBigAiGBSorXah1ITHGMQWIs/nPFtfHS/DyLnZ5kEoKoTCKBA3HFx27Qf4PCd9kGoFm6Tl/4DQKsbR5uXgNU6nJ2ngACpeIuTr/ahNBO+asZKcUsLo/KAZgtZGDhRmq7qszd544033njjrWlvVi1ijocH3nwJ+TCAEUEzj+kRCIwRuMbBDWd8G63xFHJBrul7rKm6Yo6Lnt7V+Nbh52DKrgehEAZN/5wsrfYvWPUPrM31wpPSLib1coNFzIFC7+2M5Qro6mruX+gY4g96rBS3tJjsvXG/ZgsOTJOftYiIiGqAqiLueHjwrZfh24Bvz4i2WAvVIu54+P0Z34aBwLcMuKg6POPi7b63cfYBU/D1Q86Eb0NuVYn+eSUPrXoF6/O98IwB6ip5aUNJehDoYy+felkeWOxyAODY4Jl8LHV1mR7s7MDIfHgOANRhrQ4REVFjUSgSjoeCDat9KDXDEQOF4uTdDsGtU2dAbYhckIfLdgAaIwKBIwbd6bdx9j7HYtZHvocWLwHXmKbu+6+kiNp2xDj1FTlHEwxdzeSzAnkMALAfeAIeI0wAjBWBAovdZdN+kRXoY5KMAeATnYiIqJpKwf/y9Nv4zT8eAQCElvl5IEoC+DbESbsehD9P/T7GxVPoLWQ4E4BGnREDVYu+fBof3fdD+NNHLoJAYFUZ/CM6b7nGQa+fxW9ffgQtXrL+zlvGGM36zmR32X0AytXSNPqYABhLxcyWQB7TTD4LA7epGw2JiIhqhLUWjuFl0WCecRCqxZRdD8ILX/wtztzzcKxPr4UjXIWl0eGKg3yQh9UQt039Pm46+yIYiZ5tzbrl30hSTgxBvQX+EQvPAYzM78HODvv/xxZ/2GOpNAfAXXafZn0HhlcaRERE1WZVEXNjeOitV4qDAA3z8xUcMQjVYly8BX8663v42H4fQl8+DWi0Ckm0LQiifv/eQgbj4inc8rEZOG2PQxGqjRIADP7LKgcAri+k63E3hFCSMQj0sWXTfpFl///Ycqt9AE2nq8v0oMeBYD5c5xT41gLguycREVGVqCriJoYH3/wHfBsg7rBAbzBHDKwqjAhmn30R7nr5cUy95QfoLWQwPtUBPwz4M6Mt5hoH1lp0r38TZx8wBdee9q8YF29BqJbDJ4cRvRaLAwBzfdgu1Qm/fmaYKASuptn/Xy18RY2lyjkAyjkAREREtaI0CyBfPxfRY86IwIjAqsWpexyKv5xzCU7a9SCs7XkLoYZwjcNVWtosjhgYMViX6YECuGTKl/Gns77H4H8TKLReBwCy/7/K+Koaa6U5AIZzAIiIiGpBKfhfln4b17/yVwAcBLghRgxCDfHBd74Xd33iR7jk+OkYn2jDuvQ6+GHARABtVCnw78mnkStkccru78efP/Zf+N4Rn4ARiYJbBv/DKg0AzAQF/O4fjyLlJertfMX+/yrjD3yscQ4AERFRTVJV9BRyzMtvAkei4YAGgu8d+Uk8d/5V+OGHzseEZDvWpdehEAbRNm68zKEiEYlK/VXRk08jW8ji1N0OwR3TfoC7Pv5DfOidB8K3YXHgHxNIG5MLfWTDAkz9/ayi/n9l/3+18KxcDbOmOj3Y2REjCyTmAkBdpe2IiIgaTWgtWmJJ/P6Vx5AJCnCNw0TARjhioAACG6Iz0YrvHvFxPH/+VbjkQ+dj+1QHCmGA9dk+2OKwwFJlAIO7xifFmyMGnnEhEBRCH+uyPUg5Lk7Z7WD85Zwf4C/nXIIpux0MVYVVC49DJTeqtNp//SuP4c1MN+KOV1/nKgNX03lfoI8DYP9/FXAI4FgTKK7uNMsu/EW244Zv3CWucwIEHARIRERUZQaCTFhALvTR4sarfTh1QYBysiS0Fp2JVnzviI/j64ecicdWvIBfPHYTHl/xItZk1gNqkYi3QEQQd7xyGsAWgz9sRWKgrgKgGrTVSRlBuWRfIPBtgFAtcn4OWsghnmzDpNQ4fPF9p+GCA0/BdqkOAFHVjUJhuK3kZlFE1UpW6+x5r1C4jtG8v2bdTuPmAWD/fxXwlVYNCoFAt7/+3yblHPuKOKYVgVWe+YiIiKrHNQ7W5nrws0On4V/2PR6BDbnN3WYqJQIqf26rM+tw/fPz0VPI4Lrn70XGz2N17xpALSACODEkvVh5a7MtYcRwj/itEGzF8EuBwEKRz6ejD1iLllQHko6Lo3c5AO/d7l04/B3vwZE774sWLwEgep5YZZ//5tJiEJEO8jjwth9iZW49YlJX48R8aU966M3+T7e77CJ0dxpcONOv9kE1G1YAVJHtyWYwLpYB0FrtYyEiIqJoNZpzALacQMoVAdFWZQbbpcbh3z7wUQDAtw6bilxQwG+fm4dMkIcnDh5b+QIefv15xL1EsRJg8+XDAPmwwLWULSAAxiVat/AnF+0KkXA9fO7waUg4MeT8HI7a5QAcMvnd6Ii3DLh3YEM4YiAicJiw2WK50EemPvv/AWho1a7DtNkhrp7ODFAV1OOzpjFcPd3D9KuDcf/3rz+XjtS/6PqMD8Cr9mERERE1K4GgoAF2SHTg2TO/hxY3Xl5xoy2nqgiLgf1IFRXr8+nyTIHN4dsQnnHw88duwvcXXIdxLePqaT/0qiqV6o9LtOLpz12O1lhyi57vpYn9pdX9wUqD/Tjcb+uVqpJ+sXg+vvn4LIxPtG9V9caYip4oAquBH2Z3Sp971VulquhqH1qzYQVAtXR2W4io/b+vz5Fc4asQMai3Ph4iIqIGI8U5AJmgwDkA24iIwJUo8FcooCgnBBSAZ5whK8WbShGtZiXcGKs2tlCpAiDpxrbq65QCUQXKAT8gHOy3jYVqsb6QhdXoGV9Hz3orcc/RTP7+dNZ2Y9ZUBzK7TrIXjYVlF9VSHHjRM7nzfs36a+EIxw0TERFVkUIRdzy8mV6Lm177GwDU2/7aNU8g5e3gXOOUg0Pdwv/5Nii3G9CWK/8cYbf4d1H5O3WKQ/243r/tlH7GCuAPrz6BlJesr/OTwMJzQiu4ExfO9NHdyTi0SviDrxaB4urpHlYvVgj+KC0JQBBU+7CIiIiamarCdTzcs2IxsqEPI8L8/BiQrfwfbZ2t/fnzdzD6SkMy71/5IlZl18Fz6mj4X7TVg6c9WU2KvREAMH0m454qYQKgmjq7LabNDkVwp+b8bNQGUC+vZCIiosZjVRFzYnh09VI4IjCcUk5ENSAsJgCeevt19ObT8KSuWissYi7U6ry3enNr0dVl2PtfPZwBUE3FNoCdvI6Fy7LrHPEcB7bYHEdERERV4YqgEBbw8Fuv4IM77FXcrowrnERUPY4Y+DbEU2//EzE3jlBL7fN1ETeEkvAczRYew4UzfXRNjQEoVPugmhXT2tU2a6rTgx5HjCyQmItoU1wiIiKqhqjP1mBdrhdzly9GqHar9qcnItpaUQW9oLuQwX0rX0TM9YrnpTo5Nxm4msn7Cn0cALAfOPyvipgAqCaBorvTLJv2i6wF7oTnhBAwAUBERFRFobVIxVO45fVnopkAhnN6iah6SsP+bn7taazP9yJu6qz/3zFGc/7a3p3GzQNQroKm6mALQLVNnxngQiAp9sb8+uzPYMRDqNx0mIiIqEoUCk9crOjrxoOrXsYHJ7MNgIiqx4jAtyHmrlgCIy7U1lXHcCDJhKd+5o9YvTgagi4z/WofVDNjBUC1CRSzpjpv9ebWAnKfxDwArAIgIiKqJlcM+vwM2wCIqKqi8n+D7kIGC9/8B+JurL62vRQxmi8UYOxdmDY7RGc345wqYwKgFnR3Glw407dq5yDmgm0ARERE1RVai1QsagMI1bINgIiqIrQWCsVNS5/C+nxfPZb/O8j6PT2TO+8HwPL/GsAEQC0o7oOpcfsH7cmshmO8+nllExERNR6FwjMulqfX4sk1/wSA+lp1I6KGYEQgEMxf+SLEmPqqRhINJeGFauRyrF6suL/L5fZ/1ccEQC0QKK6e7vVNu2y1ivxeWhKAIKj2YRERETUzB4JcGOCSZ+fAtyGH8xDRmArVwojBfStfwB1vPItWL4mwXjYMUyiMcbUvp5ryL8e02SGOm8Hp/zWACYBaUeqHkXCO5go+RPi7ISIiqiKripQXxxNrXkN3IQMjhgV6RDRmVBWhWsxbvgR+6MOpr/DASswDFPf3Bm/1YtZUh6v/taGunkUNrdgP0zO5837N+WvhCJsNiYiIqkihiBkX3ble3LT0KSi0vB0XEdFoUkRbkIZqccvrzyAVS9bX+Udg4TmhNbgT02YX0N3JuLNG8BdRK4ptAFi9WOGY/5NkXNkGQEREVF2qCjEm6r+FwHArwJrE+Qxbjj+72lT6vTy55p9Ynl4Lr96G/4l42psNk2JvBFCeeUbVxwRALenstpg2O4TVu+GHAv5+iIiIqipUi1YviTveeBb3rXwBRkz99OA2kYTrQZic2QIa/eyqfRg0hADwbYhLnp2DXBjAqa/fkpVkDKr461u9ubUs/68tDDBrybTZIWZNdXo+879zw0xuriRjDhQclkFERFRFjhj4oY97V7wAAPU1hbvBuSa6lP3cASdh+7btkA0KkPoKlKrGNQa5fBaf3X8KWmLJ4qBL/uxqgUJhxKDXz+GJNa8h5cXrq1LDCNTagnVxES6c6Vf7cGggJgBqTXengULgOnPgOVH/DBEREVVNaC1aYin8aelTWJPrg2s4pqfWJFwPjnGqfRh1KBp0ybC/toTWIlSLmS8+iHX5Pnj1dM5RKBzjIFPo2cXpeAyAlGadUW1gAqDWTJ8ZQKDqBn/QnuxqOMarn1c8ERFR41EoEo6HV3tWYtbSJ6FAfQ3jagKhtUj7ObYBbAYBALXoLWSqfShUoRQ/h2rx6388DM+Jwdo6CgVEQ0l4oRq5fDEWh7i/i+X/NYYJgFpTHAbYN+2y1ar6e0lxGCAREVG1qSo8xysOAwSHAdYQq4q46+GDuxwAPyjwd7MJBIKCDdGR7MBxu7wXAJ/TtaI8/G/1P7Eqsx5xp96G/xlH+3KhpvzLMW12iONmsJ25xjABUIs6u4vLCnK3chggERFR1YVq0eKlcMfrz+DhVS9DOAywJggEgVrEHQ+HTN4TQSFbb3ulV01gQziuh2N22R8AEwC1Qoq3Hz1/N7JhAaa+GjSsJGOiir/2Bm/1cvhfbeIZshZVDAO0mdxcJGOOKkIFwBtvvPHGG2+8Vedmiv/90fP31NcleYNzioHr+yfviY6WcSjYgMPsNsKIIAx9HPuO/RHYsL4GzDWwUC2MGDy86mXMW74IbbEWBGqrfu7b5JsR2NLwv2mzC6P1c6KtwwRAraocBuhyGCAREVG1BWrRGkth/orFmL/yBTisAqgJpZXr4975XrhODIFlxfHGOGLgF3I4ZPKeSLoxBGqZNKkRvg1xyXN3l5OOdYPD/+qGW+0DoBFEwwChs4I/2N7Mf4rjjIcfKgwLaYiIiKpCotXmvJ/HvStewPGT94ZVhcO4qepCtQhsiCN22gdzXnkcccdDyFXtEfk2QEuyDYdM3hNAfxUFVY9C4YjB+kIaT6xeirgTQ1AeNlrrz2UBoKEkPNf6wRWLsTjE1dNdCLcArEV1lVhqKgLF/V1O37TLVkugl0rCCyEIav71T0RE1KgUCMIw2hLw1SfQXcjU1/ZcDUogsKpIujFM2e1gBH6e/ewbIBDkwwATWzpx/LsOBMD+/1pQCvZnvvgg1uf6EDOlpqM6OL+oKoxxtDe7WnJ9l2La7BDTZ3KIeY1iAqCWFadmWi93hfblQkDqaAwoERFR41Eo4o6HpevfwlUvLASAilU6qhbXRJe0H9/3OLxrwjuQDQosaR+BYwQ2yGP6gacAiIYB8mdVXQqFaxx0FzK48oUFiHkxhHW19R8CaYkD1v6+54Jr1+Lq6R5rlmsXEwC1TKCYNdXp87p7VPWvkvAAcBYAERFRNYXWIhVP4qoXFqC7kIHLKoCqEwh8G2Jish3n7HMscvl0OSlAlQSFMERbsh1ffN9pcMTA4c+p6gJrIQCuemEh3uhdg6QTq69zisJoIRAY3A2gYkczqkV8xdeDabMLjpH/VCjTs0RERFWmUCQdD2/0rsFVLyyEgFUAtaBUxn7irgch5sY4oHEYrggKfg6H7rgX2uJJhBz+V3WVq/9XvbAAyViyvs4nilCSMaOZwoKez1w2F7OmOpg2m5M4axgTALWuuCXguk//cqGmCwskFXeg4IuKiIioigJrkYyxCqCWlHZlOP5dB+JDux2CdD4DV3ipW8lCISK46MhPwjOcBV4Lhq7+e/V3LhGII9oFMJtUD3hWrBcKcVz5L1VbAAe1EBERVRWrAGrb9w7/OIwIbL0FUqPIFYN0PoMTdjsER+28H0K1cJggqaoGWf13bDo7d915ly3ArKmGq/+1j6/6ejB1toUAO8bG/RWZQg8cLjMQERFVG6sAak+pCuCod+yHE3Y7BBlWAZRZRG0S3z3849U+FCqq+9V/gYXnAMaZA4Wgu5MvtjrAX1I9ECiunu4uxuJQjV4hSQ8QcGsNIiKiKhpcBQBofa3eNTCF4ruHfxxWLcJ6CqhGiSsOerI9OH63g3HUO7j6XwsUCkcMuvN1u/qvMMazvdm1Grd/gADc+q8+8JVfL6bPDDBtdig591Lbl1sLY7glIBERUZWVqgCuXLIA2cCHawzLzqvMEQOriqPesR+m7vdB5Ao5uOJU+7CqRiCwsBiXaMVFR3wSqnx+1oLAWhgRzHzpIbzes7oeV/8DScUgqpf2TbtsNa6e7nLrv/rABEC9iKoAvJ4LfrFWVC+VVExYBUBERFRdCkXcuFiZWYcvPHwDBMIAqwaICKwqfnPqv6Ij0Yq0n4Vp0hVv1xj09KzGt474OI7ceV8EXP2vulAtXGPwyFuv4MfP3oX2RGs9rv67ti+3FnnnMgDC1f/6wVd/PYleWIK8cxmrAIiIiGpDqBatsQRmvfI4Hlr1MowIAm5BV1UGErVouDHccMa30OrFAdWm2/LOEQfpQgYfPeAkfP2QMxHYEK7h5X8tEAh++OwcrCtk4EqdzQ+JVv9FVC/tueAXa7n6X194BqgnxVkArAIgIiKqLQYCRwT//dzdkKYLM2uTIwaBWpy82yH498PPQU/vasSc5tn6zohBLsihPd6CG874Flq8BIwxfHZWWakC4+G3XsG9yxZhXKIVgdbR4Hyu/tc9JgDqDasAiIiIak6gFi2xFOYvX4w5y/5enkZP1eUaA9+G+PohZ+LsA6bg7XQ3XNP48wAEAmtDOBDccMa3EXc8hGphGPxXlUIhANJBHt//253RBXy9XcVz9b/uMQFQb1gFQEREVJtU4TgOPvfgdejOZ6J5ALwuriqBwDUGKS+BWR/5Hk7Y7WD05nrhNXgSwIgg42dx88e6cPJuh5QnzlN1RYP/DC5dfD/m/vNv6Ei01FeikKv/DYFngnrEKgAiIqKaY6FIOjGszqzDzJceimYB1NNgrwYlEIQawhGD7x9zHjzjohD6DTsU0DMu1qe78bF9jsXJux0C34YM/muAhcIVg2xQwJUvLEBrqh1+WEel/wBX/xsE64Dq1dXTPVw402+//utd0pa8WPtyPhRetQ+LiIioaQnKq/6OAn+Z8jUcNmk3rr7WiLDYez136dM4a/Z/wRgHnuMhsHUWhI1AAMQcD2/3vY2z9zkWf/rI9wAADvv+a0Lp+ffJB67F7KVPos1L1s/qv6CYwTBQa7slZ97dc8EvuqEAEwD1h+9G9aqyCqA3txbCKgAiIqKqUkBV4cLBukIGP3x2Doww8KoVjkTzAKbsehD+PPX7CG2IddnehpgJIBKNnnx73Uqcvc+xmHX2RTBiGPzXiPLgv1Wv4E+vPI5WL1E/wT+AYqAfSJKr/42ACYB6VTkLAHqppOKcBUBERFQDAg3REW8tDwQ0HAhYMzzjICgmAeZ8/Ec4adeDsC6zHjHHq9sw2TUOgjAABLjkxC/jTx+5qFxxwuC/+hQKVS0P/nONqb9hjKXe/zR7/xtBnT37aIDidrbt1/xLp42H/xBjxiG03H2IiIioygwMChqg1Y3jtWk/QsLxAEH9Xfg3qFI5tgL46M3fx63Pz0N723aACGwdJWtc42BdthcJ18OfPzYDJ+12MKwqRBj81wrfhvCMg/957h5859EbMaFtPAphVMhbH1sACAD1pSXh2nRuRt+5l84otSJX+8hoy7ACoJ5VVAGo6mXSnjSAMhtHRERUZRYWceNifT6NLzx0PYwIVOvhYr85OGIQ2BACYPbZF+GSE78MCJD1c3Cl9lsCRASOGKzLrMdJpWqG3Q5GIQxghGtBtSJUC884ePStV/DjZ+9CR0sH/LB0qV4v5wO1cIxr07ms4ep/Q+DZod4pBLOnmu1zuyQy8OdIInaUZgsWgtp/9yIiImpwIoJ0IYs7pnwNJ+/8HtjiyjPVhqg8O9o2755Xn8J5d/wEq7O9aIklYCA117ohInDFIBcUUAgKOGuvIzHrIxfBiJSrGqg2KBSBtSjYAGffeyXuXb4YHfFWBFpnQycVIeKug1z+zN7PXnE7Zk11MG12nf0jqBLPEvVOoFj0lqw69+dptXKRQpnUISIiqhGiQNyN4byFv0U2KEAgsHWz8tf4BFLcrjHESbsdjCUXXouz9zoS6VwaPfl0NEivBoJqEYFrHPhhgO7MOnTEkrht6vdx09n/CUARWgb/tSaw0er/ZYvvx9x/PoPOZFtdBv+SjBmbKyxg8N84eKZoBDMWBJg11en77C8X2kx+gSRjBuBAQCIiomqzUMSMi/X5TLkVwNraWlWmqJc+VIvORCtmf+R7mPOJH+HU3Q5BrpAtJwJc44x5ab1T/L5+GGBdeh0mJNvxww+ej8Vf/A1O2+PQaDZbcdo/1Y6gXPr/Kn78zBx0tIyrKP2vL6oqItIFhWDRW1xobAButQ+AtqnoBWrkAbC9g4iIqCaEapHw4pj16hM4792H4+Sd9mO5dg2KhgJG1RlTdj0YU3Y9GHNffQq/fOIWzFv6N/hBHol4CxJuDKpaHha4Les5SgkGx0Q7R6zPZ4CwgJ3HTcaXjvwkvnTQ6ehMtAIArFoYPodqjkIBjXYD6Xr6dvT42aj0H3W2cK4IpDXhhr2ZBenPXr4AyakOZsyuzywGDcAgsZEUy3Jaf/u126QlfgayhZCzAIiIiKpPihO//dDH/FO/icMn7YZALVwGcDXJqoVAIBJdKs9d+hQW/vM5/GHxA3ht7TLAiSHpxeCIgWdcWLXFhEB0f92EtEC5mkBQTgblQx+qilw+DdeJ4ZR3fwBHv+M9+PwBJ2FCsg0AENgQjjEc9FejAhvCNQ4+fv81+NMrj0el/7bugn+FEYu4m9V8/tS+T1/2EGZPMyz/bww8czSSLhhcrDr5jouTveu73xAxHQgt3yGIiIhqgGsc9ObT+OCO++CuKV8HADiGE9trmVULqZiqvybbg989NxcLX/87Hl22CNnQRzqzHhJLlCsDBIK46w37W1VEgb9vg+IuBAJFFPADgkltE9ESS+CT+xyLY995AE7c9eDyYxn4175SZc/dyxfhtHsuRXs8hbA+W36ibf96shf3fe6y73Pbv8bCM0ijiV6gQct1X+tyOlu7tLvPh4hX7cMiIiKiKAnQne3FObsfihs/eEF5tZBqW6gWqjrgd7U+n8bjK17EI2/8Hc+u+Sce/OeziHsJBDbEqp7VgFpAhrnUthaJZBs6E22wapFwYzhv/xPQFkvhsweciIQbQ6uXABAlDEIG/nWhVNHz6Fuv4vi7fgbP8YBigqfOWDhGNLRZk3De0TO1fR0wQyH19w+h4fFM0miGbAvoHalZX9kKQEREVBscY9CTz+DOk77OeQB1RosT94dL2qzP98ERB/kwwG+fm4t8WICBGRAAOmKQ83M4apf9ceiOe5f3iW8pBvwlgQ0hInxe1InoeRH9nk+deynuX7EEbfGW+iv9B7jtXxNgAqARdR3rYsaCoPV33zjGtMYWaDrPWQBEREQ1gvMA6p8W/99qdPO2soqjFCg6YgABV/vrTEP0/QODB/8dx+C/MfGdphFVbgvYm7sdyZgDrbfRo0RERI1JoXCMA99GU8IDaxENDmeFbb0QREF6NAQwCv619D9VBDaEP8yt9PFQbf/9EbUWuMYZMG+A6kOoUUXI3csXYfbSJzEu2Vqvwb/CiGgY9omD/0RXF+PEBsVfbKNaNFuhKm0Txn9C84W1cAyvLIiIiGpEYEO0xVswb9kifHrBtXCNiRIBVLek9D8RuMaBN8yt9HFHTP/9GfDXrUBDOMW+/7PnXYFWLwFr6/RyWxBIKm40Xfhp32cufxA7ruTqf4NiAqBRzYDFzAvdlWfMyKrVy6Q96QDKvTuJiIhqRGBDjEu04qalT+LuZYvgFasCiKj2KRQGBqFadD19O3wbwjFOva63WTjGselc1rS4l0O7DKbPZNzQoJhybGSVAwE1mCOp2NHalw9hOA+AiIioFpS2gQvDALdO+Qqm7LQvhwIS1TiFIlSFADjnvpm4eelT6EzUad8/AEBCSXiOZrMc/NcE+O7SyIrbdaw69+dphX5XQ9sH11igPlOTREREjSZquzUwxsFZcy/Ho2+9CkcMAuW1N1GtCmw0tPNTD1yLm195AuMT7fUb/CtCxFxjM/nbGfw3ByYAGt202SGunu71nXfpQ5rJ/0zakx6UrQBERES1wqpFzHGjoYBP3Y5QLQwMrDJfT1RrfBvCMw7uXrYIN736JMal2uHbur20tvCMqB9k2yaM/wS6ugwWzeaJp8GxBaAZKAQzp7vbdbrxXNa9SxLekZr1lVsDEhER1Q7XOOjO9eHsXQ/CrA9NhyPRHvIcEkdUG0rtOXOXL8ZH5l0Bx7jlNp66pAgRdx3k82f2fvaKOzBrquHqf+NjBUAzEChWvKirp/2qT1UugjH8vRMREdWYwIYYn2jFLa88gXPuuwbpII/A2voNLogaSKgWAsE9yxbhI/OugIiBkXoO/jWQ1oRjc4UFxdJ/Bv9NginlZlLs6Wn9zVdvk1Tsw8j6lgMBiYiIakvc8bCm5y3895Gfwn8ccDLyYYC441b7sIiallULIwbZ0Mcuf/w2+oI8Eo6HUOt0606FwpEAnptXv3Bq38sTHsZ+i4UJgObAleBmsmi2oqvLtE0sfEILQRZx14HW65mLiIioMRXCAB2t4/GTZ+Zg7vLFiBfnAxDR2ItmcQhCtfjMA9ei18/Wd/AfCaSz1dNM7md9n7n8Qey4koP/mggrAJrNrKkOps6ybb/56mma8m6Eb+NQdcDnAhERUc0wIvDDEFCLP0/5KqbstG95+BgRjY3SIE4FMG3+Vbjl1SfQkWyv7+A/6vs36gd3tm4f+/iqWGsex80IS7uHUeNjBUCzmTY7xMwL3d4vXPEXZAs/lY6Uy10BiIiIaotVhee4kOL2gHOXL4ZnHFYCEI2RyuB/6vyrcMvSJ9CZGlffwT9g4RpRP8y2Z/PnrDrp52k8MMMy+G8uXPVtRsVdAbZ/V1us783CHJOKH619+ZDzAIiIiGqLEYPAhlAbshKAaIwMDv5vXfoEOpPj6nm7vyIJkfAcyebO7D3vijswm4P/mhErAJqRQNHZbVed9PO0IPyuhrYPrnDMMBERUY2xauEah5UARGOkYYN/ixAx12gmf3vvZ6+4ncF/82ICoFlNmx3i6ule33m/egiZ3M+ks9UDUOdnNiIiosbDJADR2GjY4F/VIu466gfZ9gmFT6Cry2DRbC78NSm2ADQzheCBLmf7Ql+8b1XhRvHc05ALuDUgERFRDWI7ANHoadzgHwrHBHClIBn/472fv/xOzJ7G1f8mxgqAZiZQPDDDrjrp5+n2bP4c9UNuDUhERFSjWAlANDoaNviPBNLZ4iFb+GnvF674C2Ze6DL4b26sAKBoa8BF+2rbLmtO1ZR3IwKNIbQuhM8PIiKiWsNKAKJtp6GDf4sQieKWf4h9fFW2t4DpMwNO/W9urACgaB7Ajiud8taA41o4D4CIiKhGsRKAaNsYEvy/2kDBf7nvv7jl37k/T2PFzJDBP3GFlyKlrQGTbbE+W7hRYu5pyAcWwnkAREREtaiyEuDWKV/FSTvvi1AtHOH6DtHGlF4roVpMm381bmmo4L+i7z/rf7z39Yl3Yb/FwtJ/AlgBQCUCxYqZ4apzf55uzxfnAcQ4D4CIiKhW9VcCGJw97wrc+frzcMTAqkKVi3xEIykF/+sKWUybPxO3vNJAwX8kkHEtHnLFvv8dVzoM/qmEFQA0UOU8gCTnARAREdU6IwKriqyfx1nveh9uPH46TPFt2wjfvokqleZlzF2+GOfe/2usKWTR6sYRNsqaV6nvvxDc2To59vFVr7HvnwZiBQANVDkPIFeaB6CFah8WERERDc+qQiBojSVx8yuP45z5V0OhMCKNE9QQbQOhWnjGwT3LFuOsey7HOj+HtkYK/lUtYk7U95/Pn7PqJPb901BMC9NQlfMAtPAnk0ycpn3ZEEY4D4CIiKiGecZFd2Ydzt79UFx7zHkYF0tyLgA1PVWFIqqIufP15zFt/lWACDzjNlDwD4VjQjgCyfkfYd8/jYQJABpetJigmDXVaclNvt/EvaM1kw8g4lb70IiIiGhkjhj0BXlMjCVx/QfPx5Sd9kXeBogbvoVT8wnUwkCgUJwzfyb+/NrfkPTi5daZxiE+kp4nPZkzei+48g7Mmsq+fxoW08E0PIHi/mNdTJsdigbf1VBDuI7LqUJERES1LVSLNjeOdX4OZ91zOe5Ztghx40bDAVkJTE0kVAtXDEQEU++9Gje/8jhaY0kIGiz4twilPelpJndH7wVX3oGrp3sM/mkkrACgDStmD9t+/aXTNBX/E4cCEhER1QdHDPKhj5jj4lsHnIRvv/dkuMVtz9gSQI3OqoURg/tXvoQfP3Mn7lm2CJ2JNvi2weJiixBJV9QP7kq/Y/xH8MADwMUL2PdPI2IQRxv3y6/F8Y3L8q2/+XKXTOy4WN/uyUMkXu3DIiIiog0TiTL2PX3dOHvPI8tzAQIbwjUc7UONJ1QLAWDE4K7Xn8PH7r0SWRtgXLwFQaMF/6oWnms0tJn2XH67lRfOzKALBjPQIIMNaDQwAUAbN3goYGviNF2fDWHAKwciIqIaJwBc46DHz2FiLIXrjvsCTtp5v2j3AAGL+qhhlKpbrCqmzb8Kf37taaS8BBzjNGLwr3AdgTGh5PyzOPSPNhXP+LRpBgwF3OHP4jmnIhsokwBERET1wRWDdJBH0o3hW/ufhG8feApbAqhhlJ7H9698ET9+5i7c88bf0ZFobczZF9HE/wCuFCRTOKf3/Cvv5NA/2lRMANCm0y4DmWEnXz091ZOIrxbHpNQPrIiYBjutEhERNYzSxV5pGzQA6O1bi7P3PIotAVT3Nlbyr4heA41yrSoAVDVvJrTHwzXrL858/lczSu261T42qg9MANDmmTXVwaJ9NfWut0+RmHsbrBUEISBcOiAiIqoXXrElYLsBLQEWCrAagOqGb0N4ximX/N/ayCX/JQpf2pNe2Je7s11i56zK9hYwfWbAoX+0qZgAoM1XLDFK/fpLp0kyfhusdRCEChE+n4iIiOrE4JaA7x54KoxIOagiqlXRqr/AiOD+FS/gx8/OwT1v/B3tjVryX2IRSkfS0XTuznTizTMxbXZYbtMl2kQM2GjLXD3dw4Uz/dSvv3SapGLcHpCIiKgOGYkih77Mepz0zgPxrfeegg/tuHc5iGI1ANWaylX//37mLvzP8/egL59BR6K1cVf9gfJ2f9YP78om3jwLi/aNgv4ZMzjxnzYLgzXacsV+o9RvvtxluD0gERFR3YoZF925XrTGU/iP/U/CdyqqAVzj8IKRqq5y1f++FS/gJ8/OwT3/fAatqQ4YCEJt4Di4Yru/jtJ2f8XZXNU+NKo/PJ/TlqvYHrDHFv7ktCZO096sD4HHQiQiIqI6UZyQ5pho+7RSNcC3DzwFH9xxbwCAVQvDagCqAi3+v0D6V/2fuwd9hQw6E20o2AANN+mvJJr4Z+E4gDGqfnBm5rUJc7jdH20NJgBo61RuD5jd4TZpSZymPcUkABEREdWdcjVALIX/OPBkfHmf49AZT0GhUFUmAmhMKICgYh7FvGWL8Yvn78Gcpc+gtaUJVv2BKPh3i8F/Ln9mhtv90TbABABtva6u6Epgv8XCJAAREVH9c8QgUItMIYMdkuPw62PPw2m7HAAAbAugUReqLc+fWJtP48KHfo+bX30SgKAj3gLfBtU9wLFQGfwXCmdkPv+ru0ozuKp9aFTfeO6mbYNJACIiooYiAFzjIBcUYG2I43faB99878n4ULEtILAhHCYCaBuyGtXwGxFYKP77b3fhyhcWYnm6G61eojlW/QEG/zSqeM6mbYdJACIiooYjIhAIevNptMZS+M6BJ+OL+xyL8fEWAANXa4m2xNBy/0X4xfNzMWfpM0gm2+AZpzkCfyDKgniOMvin0cIEAG1bg5MAidhp2pcLYYQbChMREdUxVwx8tcjk09ipfTt8ce9j8N33nQpTHM4GcD4AbR6FIrQWbjHwv2/FC/jZs3fj3uVL4KtiXLwFgQ2hDTfdbwQKhWNCuAaazZ+VOf/KOxn807bGBABtexVJgFR28v0m7h6tmXwAEbfKR0ZERERbQQA4xkEhDJDN9uKUXQ/Ev+w/BSfuvB8AQFWhTATQRgwO/Nfm07hqyQL89zN3o6+QQVu8BQI0z6p/mfhIep7tzZ6RveDKOxj802hgAoBGx/3HuvjggiBx7ZePchLxBxAEgtACwisCIiKieicQuMbBunwangim7LQvvr7/CZjCRABtwODAvzufwa+WPIArFy/A8t7VSMVb4BUHUDYdhS/tKc+uT9+R+cIVZzD4p9HCBACNnuI2Jamrv3SatMRvg7WCIGQSgIiIqEE4YqBQ9BZyG0gElOYIULOKAn+Fa6JLwMGBf9xLIuF6CG3YLMX+Ayl8aU96ms7dmd5l/Fl44AHg4gUhpDl/HDS6eC6m0VXMXqZ+/aXTJBG/DaoO/DCEgDMBiIiIGsTGEgEAEKiFUxwoSM0hVAtT8TsfOfC3zdPnXykanRFKR9LRdO7OdPLNM7FoX8XFM5TBP40WnoFp9JWSANd8+VRJxW4AMB75gEkAIiKiBjM4EXDiTvvg/x0wBYdN2g1tXgJAaftAw0RAg1JElR+CqPIDAFZne/HrFx/C5Yvvx4reNQz8geiHZIwi7hnNB3dklnaeDSDqfZgxowl7IGis8MxLY6PYDtD+8y+M9yckrndak9wikIiIqEFFiQCgN59BzI1h+2QbLtznGHx5nw+iM54CEJWFW43mBPCCtP4pFKEq3IpOz7nLFuGXz8/D46uXYk2uDzE3hqQba+7AHwBULVwHMGKt1bOz5152B7q6DC6+WCHSxD8YGgs839LYKSYBMGuq05KddJu0MAlARETUyBwxsKoo2AAFP4cd27bDV/c9DufvdTS2S7aV78f2gPqkAOygMv9eP4e/vvUq/ve5uZi3fDF8VSS9GGLiICwOh2xq5eDfqOYKZ2bOv/LO8jUy0RjgWZbGlnYZXAxgv8XCJAAREVFzEAgcY5ANCigEBUxMtOLQ7XbFvxxwEj4waddye4ACCNkiUPNCtVBFeagfEJX5X/Pig7hyyQK8le1FISigLZ6EQGDVNnvYH6kM/gu5MzKfv/ouTvunscYzK429rq7o3YJJACIioqYiEDgiKNgQWT+PmOthUrIdX9rnWEzf+2hMTFRUBdgQIsIWgRpRmuQfJWciPYUcHl+9FL947p4BZf4x48KIIGzG7fxGwuCfagTPp1QdTAIQERE1LQFgKtsDggLGx1tw5OQ9cfQO78bn9jwSExOt5fsH1kIETAaMsSjot3DNwLnN85YtwgMrXsAfX30SyzPrUAh8JGPxqMwfClWu9w/A4J9qCM+hVD2VSYDMpNsQJQHC4uIA+N5BRETUmErv8yJRVYApVgXkggIQ+tilYwd8evf347id9sXhk3ZDqxcvPzawFoCyTWAUlAYzWlV4g4L+Vdn1uP4fj2Hhmy9hzj+fRRj6iMdScI2BI6a82q8aBRi8jCs+zy1C8RwHRkJNF87MXHjlnQz+qZp41qTqKiUB8IBJ7br/LYh5H0bet7BWynvHEBERUcMrVQWICHKhj0IuDS+ewo6pcfjUbofguJ2HJgMAwLchjERJBDAlsFlKA/lCawHIgJ5+AFiV7cEN//grFqx8CY+sfAlr832AOGiJJaKgv9mn+W+MRYiE6wBYi2zuM5kLuPJP1cdzJFWfquDiiwUzZtjk9V/7sBi5BaEaBCEgYjb+BYiIiKiRSDEYDWwI31oU8lEyYIdkB87b63B0eEmc9+7DsF2yfchjmRAY2cYC/rSfx0OrXsZf33wZz3Qvx4LlL6C7GPTH3RjijgNVsLd/Uyh8aU96tjd7p9edO7fn365dy2n/VAt4TqTaUTwppq7+0mlIxW5DGApCayHiVvvQiIiIqDoGJgNCFApZwBh0xltx7E5748DOnXD4Du/GYZPehfZYasjjfRtCADjFYLdZUgKlYL9U0i8jBPzZ0MdvX3oEPX4W1734KN7MroefzwBeDHGnP+jnJP/NoJqX9lTcprN3ZlNvnVnaBpvBP9WC5jgDUv0olkWlrrnwVCTjd4jjGE3nQxhxNv5gIiIiamSlIFahyIch8mEB8PNIJtuQMi6OmrwX3jd+wwkBYGhSoPS169WmBPvAwIC/18/idy8+imxYwJp0N6CKWCwJzzhwjVP8Wgz6N4uqQkRlfKux6/ruzN751pnYd1/FxQBkBssmqCbU75mOGlcxCdBy9ZdO0LbYt8VxTtB03ge4QwARERFFSjMDjAh8GyJUHZIQOGKHPXHopHfBMw4u2PtouCIjJgUCG5aD3f4WgsrvV73L5sF99lEJfzRob/CwvpIePwcAePytpXh45UsQ4+DXLzw0JOAXEcQdFwJBwJ7+LRdN+jewNoDjXJJ55dkfYsaCAF1dBjMY/FPtYAKAalN/mZRJXve1200qfpquj3YI4LOWiIiIKpUuDYYkBIq7CkAEO7ROgB/6OHLynnj/dlFS4Py9j4ZnHBjIkOGCg1UmCCoNlyzYEtFAvYH/pg0F+JW682l4xsFfK4L9a154EHkboKeQRT7XBxgHnpeAGRTwD00v0GZThPAcByIh8oUzM+dfeSe6ugwunqEQ/niptjCUotp1/7EuHjjOlnYIkJj3YY12COBwQCIiIhrR4ISAQpELAwhkQFJgUut4KICEcfH5vY5EwvGQD/I4cvJe+MCkXaNyeolWH1o2kiAYTT2FTPnSp2AD/ObFR5AJCvDE4LHVS/HQihcR9+JYm0+Xg/2Yl4iOXQw840BRqhxgwL9NDTfp/5dfi+Mbl+WrfWhEw2ECgGrbcDsEWLjww6gagIiIiGgTSHFNvTIpkA8DAFHvvF/IRndUi1iiFZ3FVgELRcJ4+PxeR8Az/XOJHYmSCUdO3rOcLNjcSgBFdDFeCurzoQ9TXDK2UBgIHl8drerH3FjUlw/F6r61gBbDeMdD3I1BVeGawcE+w/1RowAUoXQkHU76p3rCBADVh8odAlpi1wMYj1wQwjAJQERERFumsq+/f5eAaEhgUNzqTjAoQVCpIllQCua3xJCgvlJFgA+Jvkfc8crfqzSsDxAG+2NF1cIYSNwzWijckVk68WzMmBEw+Kd6wAQA1Y/iSbX9518Y73cmrjdtSc4FICIiolExeOifY8yAj5QC/spkwZZ/r4FBfaXKAL//ezPQr5pSv79BoFbPzp572R3o6oqyRxz2R3WAYRPVl1JmtavLTe265haJxaK5AKFVbhVIRERE1bAtdghgUF8HFD7irgdgLdKFczMXXnknV/2p3nCQGtWXKPg3AGzms1ecoTb8MFxHpSXuQDWo9uERERFR89Ft8D+qYaoKwMqEVk8LwZ3uqr53M/inesUKAKpf2mUgM2zLtV86QVPxb4kxJ2pfzgIw2Abb8RARERFRk1OEiLkOgiCA41ySeaXzh+z3p3rGKInqW9exLmYsCDB1qpM6fdKt4nlsCSAiIiKirVdZ8p/zz82cf+Wd6OoyuHiGFjdrIKo7TABQ/Zs11cHUfRUyw6Z+//XTofizuMbRTD6AiLvxL0BEREREVKSqEFEZ32rs2r47ve58tMXf1dM9XDjTr/bhEW0NJgCocQxpCZBSS4BA2BNARERERBuhCBBz3ajk31ySeWUCS/6poTAoosZS2RJwWrElwA+AwEbbBRIRERERDaaqgABxVwCsRZ4l/9SYmACgxlPZEnDd10+Hwe8ATEA+iLbs5bOeiIiIiEoUIVzjiOdCc4U7nFW9n+v97g1vs+SfGhFDIWpcCoFA2370mQnh9m2/lUSMAwKJiIiIqF9p0J/gbYT4bOa8S/8CACz5p0bFBAA1toqTd+q6r58OKQ8I9AFxWQ9ARERE1IRUQ4hIedDfuuKgPy1eG7LknxoUgx9qfAoBugQyw7ZceeGJtj357ybhnag9GWioIQSOADzLExERETU6VYUC0poQZPIhHPODzNLioL/SLCmiBmaqfQBEo06gkBkWXce66S9dPS/7qf89xfZkZlirbyPhOVCoqjL+JyIiImpkihCuI0h4oqHeE1o5JfPZy2cAsFAIg39qBqwAoOZS0RLQdtlXJvgp/a1JxLhTABEREVGjGjjh/+1Q9XOFcy+7AwA46I+aDRMA1IwEV093Syf72HVfP90p7xTgKyCWiQAiIiKiuqcAAjjGE8+FzRXuyK3q/Ry+e8PbUAhmTzUc9EfNhgkAal6VQ14u+8yERKrttyYZ+zCsQnMFDgkkIiIiqlfRkD9HWuJQP3w79PVzhc8XV/054Z+aGIMbooo3gfgNX5tijPk3ScSmaE8GKA4JrPYhEhEREdEmqBjyp5lCqKI/yKV7L8fXiqv+ACf8U1NjAoAoEr0VCBRTpzqp07a/SEP7NcS9CcgV2BZAREREVNv6y/0dAxVzj836P89fcMU8AFz1JypiAoCoUuWbw2VfmZBIKdsCiIiIiGrZ4HL/oUP+AnDHZyIATAAQDWfAkMChbQE2AOBAhK8fIiIiompRhICKtCTMsOX+HPJHNAQDGKKRDWgLSJ466T+h+lVpSUzQTAEIuW0gERER0ZhTVQCQZExgARVhuT/RJmICgGhjKt9ErvnC+IQT/5oAX0fMG4+crwA4H4CIiIhotKkqRPr7/I3cbYH/zX/ql/cAYLk/0SZgAoBo0wju73LwwRkBgIHzAVShmYJCOCiQiIiIaJuLVvxDOI4rSW9on7+qABcLZIat7oES1T4mAIg2h0Iws2I+wHVfOck4zv8TxckQgWbz3DGAiIiIaFtQKKAhXMeVZAyazq21FpflewqX4t+uXcs+f6LNxwQA0Zbpnw8AIP6Hr5xk1Pl/oholAlgRQERERLRlKlf8U1HgryqX5jR/GS64di0A9vkTbSEmAIi2xqypDqbOshBhIoCIiIhoa2xK4H9/l4vjZoSlRRgi2jxMABBtC0wEEBEREW0ZBv5EY4YJAKJtaZMSAQgBcSB8/REREVETU4SAamWPPwN/otHFAIRoNIyYCMDJiLnQdB4IwwCAAxG+DomIiKh5RIG/QSIm4rnQdDYa7ofCpQz8iUYXAw+i0TQ4EXDdV04yXuwYZHLTpTUxUbMFIAgDQITtAURERNSwShP9FY6kYgIFbN6/B9CFudDOxIUz1wBg4E80ypgAIBoLs6Y6mDrblt/MrvmX8QnJf01Evy4tyfHqB0CuUNpC0ICvTSIiImoElf39LXGgEEAFd9sw/N/8eVfcU74fA3+iMcEgg2gszZrqYLt9BR+cEQAArp4+MeGY6YAcYxLeSQCg+QBQG0DZHkBERER1SaGwAAxcI5KMQftya5BKzLR+YWE58FcVPHCxw8CfaOwwuCCqBoXggS6nnAhAsT3Acf4fQnsEPKcd+QAaWAXAqgAiIiKqWQJE0buqQhCKGBcJL1rtt3aNAlfkbeJSXPCLqL9fIZg91WDa7LCax03UjBhQEFVTKRFw3MVhaU4Abu+amHhr1VdU5KtizETEXCDnsyqAiIiIatHA1f64C/XDHhjzqPqFX+Q971F85rIeAFGZ/+rFysCfqHoYSBDVisFzAn75tfZ4m3+4eLF/gbWHi+e0az4AAhsN0eFWgkRERFQdUdAvqhDjSsKDFgLA2jVQvdydtP0VfWfMWFO+d1eXi4tZ5k9UCxg8ENUaVcHFFzuY0d8e0Hp718TgrVVfgZivwshEScWhmTwQ2mgrHbYIEBER0WgrlvhDjIu4CzEG6gf9q/293qP4RnG1v7/M3wIM/IlqBQMGotolmDXVDKgKmPXl1nhGj0A8fpyk81+AYyZJzIWWWwREmAwgIiKibaa0fR/E6S/xt30IwodhdYEzftK16Y/OeKt8/64uFxdXtDYSUU1hkEBUD4apCsANX2uPh8Fh4nj/GrUIuO1qLVDaRQCiULhsEyAiIqLNUCzvhwXgwTEoVx5aXQO1Q0v8gaiVkav9RDWPgQFRPSmV01VuJQig5eauSeHat74AI8fCdY4Uz2mFEWi2UGwT0IAzA4iIiGgEA3r6EXMhcQ+azgGhfUtb4tcin38gn5JHMO1XfcXHCO7v4hZ+RHWGwQBR/YpaBAZN0m29vWtisOqtC9RIm1i9AK6JZgakizMDAB+AKd6kf+8eIiIianj97/sKQQBVgSkG/Y6B+mEfCsGDaEs+ZtOZxwtZ8yC+Wg76WeJPVOeYACBqBKXtBCuqAgBEMwN69Agk48dJpjgzoCUBzftANK03gBRbBQCwQoCIiKghlUL+gaX9yRhgNQr6g/BhqC5wxqeuTX/0528NeHRp+77KuUREVJd4sU/UaFQFMy90sWKyDpgZcPmXW2OePdq0pQ5FOvsBxNyjxa1oFVAFwlJCQF2IADxHEBER1aOhAb8RwBtQ2r9GRa4R1V53+0nXDOnpv3q6h85uy6CfqLHw4p6okY0wMwAotQq8eYGK0yZqL4AgIalEKwTDJARYIUBERFSzFFos7e8P+EVQ7uXvzQCu04NC+AhaE3+1vbnHC/6g0n4gWulnTz9RQ+PFPFGzKCUDujsNLpzpD/jc5V9uRWcikcikN5wQsAoAPhQGAgMFkwJERERjTYsBeqmH33FcqI4Y8Gs681jLTpMfWXvqjJ4BX6ery8WOKwXTrw7Y00/UHHjhTtSsSq0Ce07WIbMDhk8IxABpl7Zk/wwBESAM+y8aWClARES07Qxd2QdK5fwiUQ8/AO3N9iDmAn7wMFqSj40Y8AMs7SdqcrxIJyIULy+AmdOHTwjc8LV2AIjnwiOkJfYBpLMfgOceiUIAaUu2QwRQHVop0P/13fKfmRwgIiIaaLhAv3JlP+5CXAcwBtqXBVR7oCiomGtEw96c1WvGv2NyYRMC/ui7EVHT4oU4EQ21sYQAgPF3dbWvfWWNl4j7F8K4nqrGBPZCiHgQaZfWJGCL1zClxADQP1eg/3u5A74wEwRERNRItCLgHrqaDxQn8sMWA32v+LaoWrmy/yggD2tL3EOm8FA+7v4VAPCZyxjwE9Fm4YU2EW1cKSEw0gyBklKlQD44DC2xI6QvH6oiKYKohcCqkbZka3GHgYFVA6XTUZQ0GPj1K2cODIdJAyIiGgu6kWBaMDBhripwjAtI9DZXGeSr9q/oh7oOcddBwX8EKo+qEUfUZnM5d+b43Sf6w67sA9HQvpdWCqbPDIrfn8E+EW0QL5qJaMtUVgkAGKlSAAAw68utyDsGmXwsYeQCNSYuoaoC8f7kAASiCmMGVA9ABOoHQD4AjAy/jjFc0oCIiGhbqgzmh36yvydfiu9VgijR3ZftA2ChYhFzDPzgUag8CgBoTUAz+UfzyD/aMeEdzvqPzFg34ve/eroHAOXVfYABPxFtNiYAiGjbGVwpAGw4MQBEAwc7HIOgx6Cn3cZbgsMkFT8c6ZxVVU8gIUQPh+cejkJoIWr6v58MTRoIT2tERDQKKoP5AR9HKUFdUMU1AuQBAMYAGhZyVq9BLl5AS1rH7/gOGXE1v6QU6APgyj4RbWu8Uiai0acV55pSxQCw8eRAhfF3dbWvXfGGIt3S/7XahyYNoDAb+DJERESbb3AwPx7A2orPjwewPrT46q/6NunrVQb5XNEnojHEBAARVZcOOg9VVg+UjDRzgIiIqJaUevIrlVbxSxjkE1EVMQFARPVhcKKg0nBJAyIiom1tcDA/GIN7IiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIi7GYNbAAAAZxJREFUIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiKqEf8/6fa6d4EJNdUAAAAASUVORK5CYII=
__ICNS_GO_DATA__

STOP_APP="$BUREAU/Arreter Cabinet Kine.app"
rm -rf "$STOP_APP"; mkdir -p "$STOP_APP/Contents/MacOS"
cat > "$STOP_APP/Contents/Info.plist" << '__ICONE_PLIST_STOP__'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Arreter Cabinet Kine</string>
<key>CFBundleDisplayName</key><string>Arreter Cabinet Kine</string>
<key>CFBundleIdentifier</key><string>fr.cabinetkine.arreter</string>
<key>CFBundleExecutable</key><string>lanceur</string>
<key>CFBundleIconFile</key><string>icone</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleVersion</key><string>1.0</string>
<key>LSMinimumSystemVersion</key><string>10.13</string>
</dict></plist>
__ICONE_PLIST_STOP__
cat > "$STOP_APP/Contents/MacOS/lanceur" << '__ICONE_STOP__'
#!/bin/bash
APP="$HOME/cabinet-kine"
arrete=0
if [ -f "$APP/serveur.pid" ]; then
  kill "$(cat "$APP/serveur.pid")" 2>/dev/null && arrete=1
  rm -f "$APP/serveur.pid"
fi
# Filet : couper ce qui ecoute sur le port 5001 (le serveur)
PID="$(lsof -ti tcp:5001 2>/dev/null)"
[ -n "$PID" ] && kill $PID 2>/dev/null && arrete=1
if [ "$arrete" -eq 1 ]; then
  osascript -e 'display notification "Le serveur est arrete." with title "Cabinet Kine"' 2>/dev/null
else
  osascript -e 'display notification "Le serveur n etait pas en marche." with title "Cabinet Kine"' 2>/dev/null
fi
__ICONE_STOP__
chmod +x "$STOP_APP/Contents/MacOS/lanceur"
mkdir -p "$STOP_APP/Contents/Resources"
python3 -c 'import base64,sys;open(sys.argv[1],"wb").write(base64.b64decode(sys.stdin.read()))' "$STOP_APP/Contents/Resources/icone.icns" << '__ICNS_STOP_DATA__'
aWNucwABpshpYzExAAAGlYlQTkcNChoKAAAADUlIRFIAAAAgAAAAIAgGAAAAc3p69AAABlRJREFUeJytl12InOUVx3/ned/53I800Uao3WgS82FXBZsLSylktWgjeGd3CRXSEkqkLb2wvQkVmQz9gN61Bi2kQgi0QhPvxH6Bsla9qF5JshtrjKBJk2iTkN2dnY/3fZ5zevHOzM7OTnY3pQcO8877POfr//yfM2eEVcRAqFSE8XHpvJuemZHVbCbGx637ZWbGqFZNwFYxuUnwkyejWzb6H3zFKzYbIoLJ1FQwEH5Zudejd2LZ3hUGfeI7jiX2SSSXftUIZ2VqKmS+TURkGRrL4Ozd4KvP/VAieVpN74vjnFu7zgHJ+FSduBkLdiyq/PwFAetPopuAmWXPR46MpC79U65U2kcrIfEeM9P+zNeSdiCXj2Mo5AmN1t+jQjrF4V/Pt2G25QlUKo7ZWWnt3vbnwtDQY83aYgIWi4jry3W9KXQSURBfHB7KN2q1N/4Zlb41ASrVqgHm2sFjqVa1uXPr9wvF4mONufkE0zxmzlTJNNyiZnaYOUzzjbn5pFQqPfI1v/i0VKtqlUrULat93aJ6q3a6mIt3NtIU1628Lc6tjYIqN7txZqbFXI5mmp4vX6+Nc+yYB3BWqTgBW0hqO0VkV7OVOjGcqdGrWltE5+dXVfOefruOYrhmK5FIoh21jRt3CxiVisTMzgqAXr40Vtx4m9TinDrDmWl28iJY6om/uodo6/YeOkintOyj0SB9+x/YYg2iqAcIa/txmIiWW43IX58bA05PT0+7ePrzzzN3SeL06n/QXN4YHYVcLkO12ST68hjFAwdXhx9geJjmH04gQ0Pt42gfnQiWJujCApokBJ90G9NSXwkZJbW2gNXrSLmMDA9jIWAjo1mlqiADeKAKziEbNmBdnghgWLMF9UWsXs/IWSgQeky7CXgfUCeogYQAc3OwuAjeI2NzWeB2NQPFOcwHLE2h0cSaDazZxJKkm6AB6gOEpRR6OqvH1EEIWCeIKrZYR2sLa8MPWNIivXwJVyq1gwi4Hl9mqHMEv2Sz/AhEsdADs4HZ+hugBUXTFCkU2y8MwpK9mWFOByMQfECdQ/vO2VRRvYUk1DIfHRL2rll7jSUIlh2BBoeF0IOAYUGzd6si0V5TxdqB8D7zE0VdAmcIOPwgBHwAlbASgeCXyNdx2i/aPu9CgTB3A1PFlUpZE1q4AXGMK5VRbfsfyAGfkW85BwyiiOTTTwn1OlG5PBiAKLvWjffepfD1bzCy/zvk7r4bS1OSs7PUXnmF5OwMbngYC0oYfAsyElkvAgpEMeHiRa786AdEO3YAnR4obfANcY7w2WeUH3yQL/7m6LLc4rEtlPY+zPVfVKm//jq2cePy9c5DCB4lXnEEmCG5HHruQ/zMmZXVO4fWagw9/AhfOPA9AJIrVzgzOUlp2zbuPXECKRTY9LPnaJ39gHDtarfLAiz94nmyrtevqqj3WD6PjIwMVDcywuiB7wLQunCBi0eP0jh/nrl33uHy8eP4uTmkVKK873G0VoMovxKB1FIthBhVGzz8DLhWIGAKxSLx2BbMe2afeor6uXPkbr8dRPjomWdYeO9ddr7wIrnt20kA875LAjcxMaEAQf3Fuk/NVEWDsi5t9whNfdaCRShu3ZqRVQTMiDdtorjlrqyGJHH1JCWJ44sAExMT6qRaVQO5Jy7/y3v9sACmIejSJLSKhoAhhBs3aM2cQaKI3S+9xF3PPkvrwgXC4iLjL7/MlsOHQUQ5fdpardb5xsGDHxiIVKvZSDa9d28kb77pNfjnS+BM1ds6UbDgsSji+vHjmPdILsfmJ5/kjv37+dKhQ4w+9FBGzMuXfHj1VReVh39739RUMr13bwTYiqH03Mfn/3ZbHH/zmk8Tg1jArT6KGbgIXZhnZN/j3HGkSrRhwzL2JJ984ps//Un+8uzs9K4Xf/co09PdoVR63AjAx3v2jJr6Uxui+NFFVZoZ+QJriDhHWJgnf/dWRp94gsKuXVgrifT999G//oXr166+Ubhn57e3vPbajQ5925/LapH2gnz0wAM/dnDIw3jRyfqG8ijCmk200QDnaKoSBT9rw0O//+OZs89XRbQnBisS6EuCkxDtuf/+r6jInT6EXP/egZKPiAplnHkvueK/t7311oyIhH7fa4pNTv7//pxmvgaCuCqybV4Ik5PSGV7XKxObNxunTnWIdtOq/wsz0DhAEXxJYgAAAABJRU5ErkJggmljMTIAAA2EiVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAANQ0lEQVR4nO2be4xc1X3HP79z79yZndmXnyXYMraDIZhgUyBOUNSs80cUiaq8wrr8kaYltLz+SFFbBOKhzdZENK2iNHGVhBBSReKP1qs2IlEDNFKMRVGpEFADMUscKKRge/F6zHp2Xvfec379497ZnV3P7O6sd1e05Std7WN0z/m9X+cMfIgP8f8acjYvKwhDQwKYJaKnUziGh1VAV3RXHRoyOjTkr+imc0CHhnwdGlqUEjqyAAVh/34je/ZYAH34lgzFjR/H2kusuM3q6EdVlsscHICIisgEyNue571Czb4iw8MhgO7f77Fnj+vEIhYsAB0aMjI87AD0L+/f5jzvZnXuOiNygQTBWTrTIqCgYYiDIyI8bsLoURl+aHQ2rfNhQWTr/kFP9ozYE3fd1dPfGwyJmNu9IMgTRkRxjKpaZGX9MCFc/IzvQ5DBhmFNlYf9yXBIvv71Cd2/32tY6vzrzIHGQvV7/+JSr6vrMS8ILo6rVZxzMWAQMSut/CnaAFQd4ETEz+Tz2DB8vR5W/qCw9xvPHxga8j87PBzPtcactOvgoCcjI7bywF0DQZD9iWdMb70eRiC+yIob/ZxQUFTjbBBkrGq5Wqlf1/PQX/98Pktoy0TDj+r3332JyfjPCvSEcWw9EW9lc87CIYBTtRnf9xAq9ch+prD3r16YKya0DNiqKgBjQ3d0Y2TEF+kJw8ga8NQpfEAfdYqAF0aRNUjeF0aKd9/d18zTggTAyIiR4WHXHeW/GmSzF1aqtVgkYV71A/6kQqhWa3GQzW7Jee5rMjzsGBlpyesZUmmYS/W+P98i4r+GcxmLiiAfKJ9fANSIOEDroh/ve/BvXm/lCq2kYgCc5bZskMlaZ50ogir/yx6xNtZsNvAzVu9ox+8MrWrj74cf9sv/9fpozs9srceRE1m24m5Zoaou6/umFsfvFLI922R4uKYgzZXiTMaGhkRAwyNHLs6I2VqPIkXFqIOOnkQBZ/F0uF+bBxVTi2LNev7GSn1yJwCDgzN4nt3QGMBFnru0kMkSVatWRPxO0p4Yg1oL8Zz1xxwLCHg+4hnULaianRuq1vd9v2rtbwP/wfbtM6y+ZUen709sZu0aVCRR50IhgqtUkO5uZN06FlMrqSpaLOIqVSSXS1W5eKgIxDE68f7mVp/PFMDTTycvnZ7oxcVorgu6upI8qzp33SgGrVbJXP4Jgt+7FtPfn2izk+SR2r4bP0n9n0eID7+K5Lo6F4KS7GsErdbgVBHKld5mHhtoGdyciBBF2PFxXLGYmLSR9rkX0HoNs2EjuS/dhFm9GozpjHkaRHuY9evJ3fTHyOo1aBQm63dQC2AEdRZXLGLHT0AU4aSTQqhJ4loq4d4bw5VOp1YgiYibUw6gYR3vou3J53beJmxuWItks5jzt6H1WkrIPGmPRnxXXKmEGxtDS6XpNdsYUcsY4CApLRsMxzFaPAWlycS/u/LgeTMIcA7UeMkCZ1szpYyo56XRHM5sthWQaTdzFq1MopMliKKp/6s2SuXWEmg91kp9XpsDoAhEEVosIv5pJJ9PBJHJQFom6FkGrBloBOCpx037tkiypypEIVqpotUK2sR4SlCjZW47rGgjAGaY92zCNI7RiQkolSDIYgqFZPNO8uVC4BLfF021bVLLiCKo19FqFQ3riXZnMT4D7XihXRp0Dk27q5YQUrNTqFawYT3xu3K5NQGLhEoa2OIYrdfRKIR6mPxsmHQz4y3oVUj46MgFcNMRtSVlTb83fO1sip8z1k8D6+Qk9vgxXKGQ+HVqCDO1zZwCV8Cpa8d/GwHMqCfnI5ZZ1fXSQet1XL2O19VFEvCa9uwk3iRTs5Yftc0Cc1rAGRsoqo72oWZxUBEgjeSLDLCNGsK1eb+1BcQO9d2CBSANYS2xFSQDmJSORcaVhgA6qgOA6VHTQiA6XS4vKXTm2GuxmOP91i7QNPpaEJpK4iWFNrni2ViAU7STGEDjpQ5jwFJbgKJLI4BOXcA5d2YlOOcuy2UBrWNAczKYdwnSINiRBahDO4wBZ6OlttCm2JJmBLQpOBsz9b85aXUKbfqz1pUg4Dq1ADvdjS0JVFGR5HGKlkqotUiQQTKZREFhHbUOyWWT4UmLQDzlAm3spU0vME8leAaxDgTi995LqsJGbb4oJDlfxMOeLOLKZSSfJ/vpT5P7xC4yW7Yivb0Qx9ixMcJfvkr1358lfuMNpCufCsfScJQpF+isG+ygEgQ0Vkw+T/nALyhcdz25bRcshvNpGI/Kiy9Q/vm/0vO5z9P75ZvJtFgzc8GF5H7nM/T80ZepPPUkp3/4A+z7pzCFAsS2aXaxApUgxiC1Ksf/7E66f/9Gsh89f3EjMeeojb5G6e9/yJrbbqfvpptToqaDofh+4iJxjBiD5HIUrrmW7BVXcPKB+4iO/AopdIO1qDQqwdZbtp0HzNkNtoK1mEwAk5NMfPtbOG9xRwliPDh1inV330PfH96UTJdEEgE3tiqV8Lq7kUxm2ufjGH/DRtZ9428Zu+NW4nffRXK5qc62o0II1xjuOzq5+qHWIp5Hrr9/4dbTDM9DSyW6rrk2YT6Ok8kTJFOnMOStBx+k+NRTZPr7Oe++++gfGEjo9f1ECatWseaBrzJ2+y1JLGq4cpsY0HooClP5t/PDSYeLY9Tazp8whEyGvltuS6lLyHNRhKpy7NFHeWffPmypRPnwYY7ceSfh2Fiyr7WJsKwl2L6dwlW/i5uYAOPNWaO0HYqu+KmuCG5ykuyuT5LZsiXRWDpZNkGAGMPkoUP4vb2I7+OvXk1cLBIePYp4HtKYUaapuPuaa5Egi9o4cYGOukFHWjzoyl1+MuDimK5PXTkVDBHBRRHHHnmE0ksvURkdxeRyibZVMV1dvP3QQwTnnMNvffGL9O7aNSWEzLYL8M87j/DNN6Gnp8NSWFU76gWWAtYimQyZrVuTWgJFRHhr717e3bcPr68Pk81OZQAAjOH088/jajVOPvkklzz+OIWLLkqyg+/jb9pEffQ1lB5cyszTs7ZtNxMsdZQGlwJWwc9gepIDHPEz2HKZ4lNPEXzkI4jvT2l+mlDFy+fx+/sJjx+n+MQTFC66aCrgmd4+nE37GudKALtnbTsjBjzd+MW5t9z0Me+KPI1Apo25onOYICCzahW2ccDRQiEKaBzjwpDshg0zP4vCJHskmeCtVnKfIYAT69crQKxyqBxbVNVbqSCICK5axR4/nhCfusR5995LZu3aRAizU5kIWq8TT0yw/oYbWHv11dOFEhAdO4Z6xqvGMTHuPwFGUh6nlpglzSSGbt8evNFbeD1nvM31pIhe9gsS4vvYYpFVt97Gmq/8aSKANAuE4+NUjxzhnW9+k9PPP4+Xz6fnkXXOu+ceenbtonvHjmShNHvYiff57y9c77zJSROKHA0w52967rlqg8fGvjMYE9ADAwO+HD4cGqf/1CWCc86xAhbgrIVslvKBX6BRhEzN+h3B2rX0XXkl2Y0bcbUakqZFF4b0795N944dSXyg0flB5ZlnCI8edYVsFqP6403PPVc9MDDgz55fn6HZ3QcPOgBr7PdKcRwaMC6hcnnjgLVILkdt9HVKP/0JNC5aGJMcjFjL+htvxOvpIRwbo370KGuuuorcpk1TPQGqCElMOPWjH6kXBFIKQxurfKeZt1lKPxONG6K/uuLyb63J+F8ZD6PYGFn+6/HpQawUCmz6h38kc+6GqZTWyO+V0VFO/uxnBOeey7rrr8cEwVRwVGsR3+fk3+3jxL5vx+vXr/dPVGvf/9gLL97a4OmMLVvRoekXIY488US3cfbFnJGPlq21RsRb7swonocrl8leeAEbv/8DvDVrpjUMU+XxNLFJ+S1pzzAxMsKxoQdsobfXi6z7jZ8LL930b69MAC2/WNH+qmxyFOkOX37JZXkJnlHVfF2dNYi3dOy2gefhJksEW7Zwzt6v0XXZZdN0pe4gIollpALRMOTkd7/D+Pe+a7OFbs8TqZdduHv7i688N9dV2QVdln750ks/1+uZHxsolK2NjYg337tnB0U8H1epgOfRd8019H3hBnIXX5y0wE2Ix8cpHzxI8bHHqL58KO5evdpHtTYR2xt2HDr0L+1Mv4F5mTgwMOB/9uDB+NWdO3flDY8VjLftVFKRxQhm6nLAkkMR4yXdZek0kusi2LyZYMsWvP5+NIqIjx2j/utfu+j4cWeygb+6p5dKFL056aIvXXLol882aJ9rl4V9YSKV4ks7d/b3iO4V5Ja8MUHFOerOqbSduS4NxEsEofV60jKnjZL6vpfL5aSQy1GN40idPjper9//ydHRk/NpfmrthRLRiAkAR3buvNio/olTvdoY2dIlJllpOQNk07G4SHKZsuYs1rq3BX4aO/fIx1599WWA/eDtWaBSOv/S1OCgaUj2N5/a2FUrr9ppYEeM2ywqfVZ1WatGEVEjOuGpvOXBy0E2e2jDCy9UILFURkY6+tLUoqBgdHBw+bPBAqGDg54uslw/6y9OjoBZNzAguzmz114uNPY6cfCgDsLya/xDfIj/u/gfqM77LUL1YpAAAAAASUVORK5CYIJpYzA3AAAb14lQTkcNChoKAAAADUlIRFIAAACAAAAAgAgGAAAAwz5hywAAG5ZJREFUeJztnXmQZVWd5z+/c+99W661b0oDBUgtNLvT2lAFtms74URjZNmtdOMyImMEg6I0tk50Zo47tEE0zoQzdNvh4LQTU6lgN3aLLQolaLdCClZBgcUmjoW1V25vvfee3/xx7818lZVZ+V5lvpePqvclTlVQ7y7nnt/+O79zDrTRRhtttNFGG2200UYbbbTRRhunC2SxOzAdCoIqDAy0XN/mhYEBRQQBXeyuVGNRB1lB6OszbNwobNqkbNtmW22AGgHdvt3hqaeE3buV7UNWZPG+uekMoCBs7zPQh2zbFh73+//szzFKN7gdaNml3OweLjDSQOiEWC9POj0mt9ySn36Jbt/uACyGADSNARSE/n5HBgeDyX+7/fYOShMXh6KvU7hEVM8FVoP2qJIFTLP612BYoCTCKMg+EXlORR5Xy7+5AT+XwcGx5ELt73cZGAhFpCmM0BQG0O3bnUTatb/fDTz7JiOyTVXf4BjnDDwPVCEMwVrUWqwqGnfwlWoTkr4LYEQQY8AYcAyIgSAgCIOXjZgHrbDd7TjyPbnpy2WItUITNEJDGUD7+w2Dgyqgh/pv7O71et+L8kHHdTfjGKj4+EGgCGE8WCb6W6ThnWsiJimokYsrYON/M57jmkQAwiD4JfBVx5evyuDgEYDtfX3OtqGh40zlQqFhY6z9/a4MDgYKEn76U9eLOLealHcWfkDFr1gRsYABMacKoeuFAqqqgAWVlOcZPI+wXNlrLX+1c+/+/37ZXXf5D/b3u1dXmc6FxIKPfeLZy9BQWOn/5GWO59xhvNQVVCpUwiAAjCCnim1fUChqAZtyXJdUirBSecwG9qOpwc8+ov39hoEBXWjfYEEZQPv7jQwOWoDKwF981DjOFxzHTVVKpQAjEeFfqQa9WZBYK6iGqXTaDW1ordX+VP9nPwPHjvECvW5hkHRMb7wxHSzv/ls3nb7WLxbVqloj4iR0P13Vfa2oHidVDRExqVxWwmL53qP5ynUrbr99fCGZYEHoMUn8W2/tCTrcf3DT6a3lfCFAxJE2zecFBUUJ0rmsF5TLj5Vs6e1dg186sFBMMG/iJB05cuutPV059wE3lbqsXCz6IuLN99ltTEFV/XQm4wW+v7tkS1cvFBPMiwEUlaG+baZv9Wq3sqzzX1Lp9JZyoeSL4LVN/cJCAGs1yOQyrl+p/Hw0H1y1PJfLz9cxnJ833j/gbBsaCku9ub9LpTNbSoWij+CpEsc47bZQTRXEiFsqlnwvnbmkM2O+IYODloEBR+chyCd9Y5Ldy3/yzz+S6+q4o5wv+Ahttd8EqOJnOnJeMZ8fyH3mtsHqTGu9OCkG0L4+R4aGwon/cuuFadd51IbWhGqNxBm8NhoNVUFC13PdSmCvyH368z9OaFLvk9yTeLsMETl/paBwl2s8r+j7oYicDjO5rQKxqiKAaHiX3njjJSxd6ivUTYS6fYAH+/sju+8X3p/JZl9bLJUCQZzFtpGnWxNwyuVykMlkNxa7Uv9ZBgct27fXTc+6VLZCVLow0N9RCgrPOMZZ6weBirRTu4sDta5xCFVHMqE5jy984Qiq1BMV1Ee4/n5HBC34E+/NZDLrKoFvI+K3gEiclk2MHwY2k0kvzZvgwwLKwIBTCykT1KMBIra6/nq3sLRrV9rzziv7flv6FxmqalOuK+UgeLkj3Xkeg4NFoObaw5qJp9u3GwHNL+2+OptOvabsV1SEtvQvchPBVILAdmTT64rlwtsFlP7+mrVA/U6D6HvEGCUqc2qjBSCooigSvgeA3btrkv7o3hqgcXih/f25fHn82Yzjrq2EgaU9r98SUFDPGPFtOOKndX3v4B1HVFVqcQZrI2BfnwEoVvIXZ1xvbSkIrCJm8RVgu8UUlnIY2lwq3euW+T0AhoZqom1tiaCNGwXAhvb3nXQKKpW4nKuNVoGoWowYseb3gX/mqadq0u61EXHTJgUQ9JLJcsY2Wg1CaAG9JP7/mny02jTAtm02eqKcq0EIIFEtY5MRJT+bX2Ki8R+L8c01QlUlDAIsur5qcmjOqvo5GWDSAfxoX3Y8DNYEjoNaG6X+m0IJjXxNAXyfiAGbSwgRAdcF1wO1MSO00ryXgqoECoThyrEdO3qBwxplBU9455wMMNDfLwwO6sFfBb2Z7gPdQe9SSGdkciAaOQ4KOAYtlyEMMStWYJYtR5y4242mQcxnWqlgD+5Hjx5F0mlwnKiyvxV4IOZFMQ5BqYg9erRTQ38JcDheYDs/DTAADAKpDrfDBjYTHDqEdnZiurpj3dDAdIAxaKGAWbOW9Nv+Pc75G5BMpnHvOwF0fJzgF09Qvv+fYGIC0imwLZAKEQMoOjYqdnxcXREHx+sEGNq9e04WrXk62IShax3XAOjYGLZcxvT0QCodq8WT/oRZXmjQYhFn/blkr78Byeaif18kOyxdXXhXXIlz7nkUvvJlGB2JTcIi+QVCRHy/go6OoKUyGIMxQiUIai7MqT0VbBxFI0dIjIFKGXvoIDo6Eg2CSbTNAjQBDXykp4fs+z8YET+Max1EFqfFaxfNqlVk3/sfY79wkSL/eNZfx0axBw9MEn/SUTVhzVxZVywf0x9VReN9HOzYGOHBA9hiATWCxovd59VEsKUi3pVbka6uiPhOXZNcCw+R2PZbnDPPxLnwImypgBrTJLJrNLbGYMvFaMxHRyN6GIlokgQqfu2fVWcyZ4auGRN554cOo4cOg1+JtQFTHFPv51oLqRTuhk0xR7dYzkkVd9MFqLU0nPSJiUnG+fAh9OCheJyrpP6Y+2pHfSVhMz5bSWJzLRTQUglyOaSzE0mWfddrJ9VCOoNMOpp13t9oiCC9S1ATRwON6p4IGEGDAEYn0Hw+Eo5EIGYalzr7UhcDaLxmf9Z3mJhY4+NooYDEjDDpLNVISFWwr4CMo1Uw9Qvd3Ej8jiBA8zHhwzAivJldIJSIRvXgZIpCZ0fybmNALZowQjaHdHSAFzunCTO8kouIT0aznehZ1Q6n70eELxQiwotUSf3CvDJB7QxQIWb3OmAErMWOjyH5CchkkY6OKJlizOyDqDqpbVoVClP9nw8jJMRVRculSNqLRdTaeEcRSUS7xo41UAPU7WZUaQRFoZBHi3nESyO5LJLJRilWOHYgW83mLwSqvymRdIAwREvFyH+qVKa0QRxd1CMFJ2ON6mCAMug8Q7H4o7VSRsslcMaQdAbJZqdSrABhUOXZtjDq1QCJGg9DtFJBi7HTnKj5asY4WSFoqAaYywmsFcmHWosW8lDII46LpNNINou6Lnit7x9obKpmHvR4nVTC9GEIpVIk7eVy5NnDNPs+v5FNnEA/qH03mYV1AmvFdHUIaBigeT8yEwi2s4OWrz2YLg2TWUMi38f3oVKJCF6pRJqt+rrJ5yzed9aZB2hwR8VEAxMGaLHY2r6AEjloJt7zKwwjqfb9iNi+j4ZBFLdPqnczdXOjvq1RJqACUb9ppGXWqT9bPUS0IXZsDFsson4litmtnSJAQvTqLGaDGbqeYCFBnSagSRJ5TAq5NaFBgB05gs12AFU5jWZI+Yl7VtfVC5AKbgBam/ZTEDOZ9Jrq7yJ3vKGpYBYoCqjpPa3OAUmyarEk/XhEtGmUBigDzZqRfSVogOmTcK2ChvoAzeJ0beAM20JiIVLBCw1VqGNT2bYJmAe0aSNSG6ZMQO0RVNsJnA9a1gTUXhJU31xA2wmYhpblgJpR51xAcz73FZAGAFqvn41PBDXVCWyRUZ0N1Q5gK/W1zr60WLVlG83G4kwH1/SeFpKqGZBMvc4+Hdx8TE4H13FPWwOc5mj7APNBq/oADUkExRVhTY0CWhynXxTQzgRNQ6vmARpVEtaU79STY+VmY1L903r0rwM1M0CZaKPgxn9v9JZXwnzQVO59pp7G5WKTeXk99jdhwX2Ixk4HU2HeZeG1otWlP8F0AlYt8qDiR+XvybJ2YxCJVvEmG0uI4yCpFKRSk1XS8/72hi4NawZdVEEMtljEjo/DsmW01DKymODh6AhUl18bBwI/6rNxcFetwj3rbLyzz8ZZswbT0xMtlvUDwrFRwn37CF58Af+FFwj37UODIFpL6Xlgw5Mf61OhIgjHwY6OUNr5C1JnnRUtk2r0O2uEEm0aVRx+DLUWNQaCEDt2FGfpUnJXvYHs1W8gtWkzpqtrzufZiQn8Z56m8OAPKT3yMOGhg5jOTnDciBHq7JvWuYNv62kAiDZhSGcY/dY36frDtyOu2xKbRGgQIK6Lv28f+QcewOnuQcfGkEyWrndfS+c178RZs7bqBj3xPkIimM5O0pddTvqyywmvex/5f7iXiXvvwY6PRwwU1nkKTH1BQIuGgaFishnKz+1h/22fZ/Wn/nJyd45F2Z8QEGMQ1yXM59k3+JfR6t0gIH3Z5fTe+BG8c86JLkwInpSFz8W0VckEZ+VKuj/4IXJveSsj/+1OSg8/jOnpnoqKalaDDQoDmxn1aGjxuroZv+8+/NExVnzoP5FZv35RTUH+8Z9z8Mt3Ev7yGTxj6Lr2z+i94cPxYpZk/X6d2fXp6wGtxT3jd1h+25cY+9rfMfrVv8FkczVtlNHYRFAFcJonfQKgSrqnh/LDP+Klxx4lvfkCUmeeiXippu7Rp4UC5WefpfLM07iAa4SlN3+Mzj9655Sar8U8VUcLM6FqHyKA7ve+H3f1Go587tNIOlPbbimNzQQ2FwJIGJLq6sKGIf6jP6P0rz9uepRoRHBSKTIdnTAxzrJbbqXzj66JogDHObHUq0ZOrOMcs1BUjJmdEZLnBQG5t74NjOHwYD+mo2PuzjY0CmjSdHA1om3KLU7sMBHvQtZMRFvyOdgjh+l5/wemiO/OMXxx+CqxVAdjYzhdXdH/w7H7/cwE142Y4M1vIdi/j5Ev34lZsmRWxzChTT3Twa05GzgNiZxI/P6mM4DjoGOjZF/77+i9/obaIpKY+MHICHu/8hVGHnqIYGQEp7ubniuu4FUf/jDeihVz5zjiCKj7T6+jsmsXxYd3RJtnnSg6aFxZeOulvpsBDUPIZFjy8T+PJDZZ8Tsb4t/Le/fy9HXXMbFrF05nJ+I4VA4dYmLXLo5+//tsuPtusmefPbcmiG3/kps/TukXT0Srjx3nOIE8GdrU4LIOVr1BT79mDHZsjM5r3ol35plT3n4NeOGTnyT/5JOkV6/GZDKI62LSadKrVlF88UWev+WWaEn5XFnOmOmc1avp+pP3RNnGxCGcqdWBdkXQCSHgBzhLltL9rj+uKSWtsTRP7NzJyI4deMuXYyuVqTy/KrZSwVu6lLGf/Yyxn/408mvmSvjEcwxd11yDu2ZNpAUWID1eBwOUJ2vgTptmhHBinOyWLTgrVk5qhNmg1qK+jwYBE7t2RTuEnAAahkzs3IkGQdTmyBpiLaa7h9wfvBE7kY+2jp2h3/W4gfVpAD3dmoLjkHvTm0+sXuPfxBhMOh2p+lQN28lbi/G8SdMgCXPNdl+s9nNvfBOSbFc/U7/rQGumglsBImi5jLt6NenNFxy/20eCKrMw/vjjFHbvRoOA8eFhTCYzO9NYi8lkGPvZz6IpYRFy559P9+WXT00pT1fx8ftTrzkf79Wvxv9/v4kYoU67X425GWC6D8hpwgYmYgBv/TlRAmYmTz0mUnnvXp7/xCcYfeQRbLkc3Z5KYXK5WdW6WovJ5Tjy/e9z6Dvfmbyn+7WvZf0Xv0jmrLNmZgJrEc/DO+98ys89j8mkJzfTOhnatDXALBDABgGp9dEkj6oem32OpS44epSnr7uO/FNP4S1bhhNn66oLP2aFKiaXm7wHYOSRR9h97bVsvuceUitXHscEST9S554DYRifCnUsXQLVmr3Dmn2AUhhaUbWLb5eb29y1a2YcD41j/ZfvuouJnTtJrVyJhuFkq/k4GWuPuS+1YgXF557jN3feGZmhac9JKOuuWRv9XqWWRSMGSfu1p4JqOjMIwNXUhNWw7Aq5cLo0nIJQtagIpqcXOH7uSRwHDQKO/OAHuF1dc3r8tcL6Pk53NyM/+hG2WMRks8dqgfhv09MDjoPaSedURZCKxbopHQfoGxqaU2XPqQEGYr3vFQqjqI4ZiI8mbwHxbGSLB1281PGDEqv/MJ8nHBtb+AMtjCEcHycYHZ31EvG8mBmi/iqKAUR1wiE9kvR0zlfNdUGcb5J1w8MF0H2uAGq1mbRYtGZttAfgcYMSSaGTy+F0di786WHW4nR04HR3z3qJVvzpYaC6kZ46sAdGoLYZ87oOjxaVZ10Ea1sgSdPghoDaEBtL4XRR0jBEPI/erVsJJiYwXs0HdZ2YIJ5HODFB9+tfj5PLRf7ENCcQwI6NYoMgor0qaq1G2yvrC1fv2BFoP2aGbh//vpp6deBAPCsbPt6YYwtaELFk+b99ecafJY7V191wA7lzz6Vy6BDiulOtVrMQl5qJ40T1hkeOkF63jlffdBPo7Cd/+r/9LdiwWsrViYTzCQAe2rqAp4evXKkAIfYnpShnbeaTfHglQOO0b+XZZwGOJ0SclfNWrGDD3Xfz3Mc+xvhjj0USq4pJpzG5HCccJxFsoYAtlSJ/wxg6L7yQ9bffTvpVr5ox95D0o7JnD4iJowAFkMBarOXHwCTN5kJtDDA0ZAF60h3D45Xi/pSYVb7qqX2EvLWQTlPe8yy2WIjq8qYnZuL8fPbss7ng3nsZefhh8k8+iYYh+Z07OfLAA7NmA8UYwkKB3i1b6Lr8csQYchs20Ltly2QByYzOpTFoEFB+5mlIpaL5B1BXxBkLgnH1Kv8KMFBDBAA1MoCAal+fI0NDE8//3uU/zDnmj0d93yJy6jKAKuJ5BHt/Q/nJJ8ledvnMtX9JfYAx9F55Jb1XXgnAge3bOXTffVN2fDpMtPild8sW1nzgA8f+Nhvx49xDZc8eKr/6VZRCjmYZbc51zTj68HmPPHFQ+/uNDA7W5JnWT8CQb4RWRRMnc7E99UY2BPV9Ju6/P0q6nKiGTxUNQ2x8GIQtl+cOD4055vrEfMx2n8YaaOJfvhcdxmUMaNTVeLXhNwAeeuihmula84UyNGQVJDy67PtjQfBC2hhjNYoHT9n/bIh0dDD+gwcIDx+O7O9sNj2u/ZN4dq9j40bMHDWDYgwdmzZNOY5VhaPHIZ5ttBMTjH/3u5DLYcMQRW1KxIz4/v6K8f4R4KodO2peTVKPBlC2bnXOe+7+MuhXsmIEa0/t1LC1iOsR7N/PyP/5xoyp2emQ2CR0Xnwx3a97Hf6RI9HUcNWZQJJKEYyM0HnRRfS87nWTxD3h4Mfqf+xb36Ty65cwqXSUp7DWdhpHBP52w09+Mv7g1q1ufGZJTagro5uo/RcuvbTbGvakjFnhW1XkFHYGo4QAOA5nDH0Lbxbv/BjEv5defJGnrr2W0vPPR9XAxqDWEk5MkF67lg1f/zodGzdOHRF3oueJEB4+zEvvvAabn0AcF0XVQ9SqnShgXrPp0Uf3D4AMUvsCwboIJ6APbd3qrB8eHrXw2Q5jxKq1i520aWyzqOMQjo1x4LOfAagOvWYZ1cgnyJx1Fhfccw9r3vc+UqtXY7JZUitXsurd7+aCb3+bjo0bIy1To/Qf+OLnCQ4eAM9D1WKtDTsdYwLVL21+9NF99PWZeogf07RuiPb3y/B3vuN0C491OOZ382EYCrLIx3s3FuI6BEeOsOLmj7P0Qx+aXCh6QlRpClssEoyO4nR34+Ryx/0+G5L3jPz937P/vw7iLlkSzRyiNmscKVv7Qlb53bXDwyVA61H/cHJxvA7t3i2XDQ/7qlwfWrVRgbLq4hvtxjUNApyeXg799R2M3fePiOtOHf02G6qiA5PNklq9eiosPIG3PznQMfEnfvgDDnzhczjd3Qnx1Sg2WlskN6wbHi7Q1yf1Eh/mscIuzguET1988adWpLzPHA58X5CFSYi3KuIoQEslVn/u83S/4x1TE0FzhXzVJmOuat4ot484DhM/eICXP3ZzFCGYWNRQf5nreQcC/682Dj9+S0KLk/qkk7kpuffBrVudq3fsCPZccvG3l7jufzjs+4Ex0tLrDecFZfKYOFsssPymj7DsQzdEP8213q+m508RHuDo3Xdz8LYvRgmfODto0WCJ67qjYfjgucOPv5G+PmFoyJ6M9MM819jGUYE8tXFjLpvNPJQz5tLRIAiMnMJMAJNEDkdG6Hrzm1nxib8gdcYZQMwI04+BPRFih1JVJwnv//a3HLz9Nsbuuy+aEo41j1UNulzHLVn7TNkUr9jw6DNHBur0+o/7lJO9cbL/sUzsueiiFY6Rh7LGbBwLAl/kVDcHUVVQODqKs2QpS/70z+h917twly+fuqZqQwuBKROSPGJapXE4MsLIN4c4+rWvERzYH1UjxQtKEuKXrf6qKOWtm4d3/zoZ+3l+xvyRdGTn5s2rOlLuP3Ua59KRIPA51ZkAjeJx3yccH8dbt46ut7yF7re+jcymTUgmM/cTKhVKT+9m/P7vMf69+6n8+iWcjk4klZqcQ1BVv9d1vbwNnx5Reduljz/+0va+PmfbSdr9aixYad92cLZB+G/nnNO9vLPj692u+46jQWDjKUMzyfUL9cIWgTIlyVqpYPN5JJMmdcbvkN6wgcxrzsdbtw5nyRLE89DAJxwZwd/7MuU9v6S0ezeVl15Ci0VMLhedop5IPVgBlrqumQiDB44Y908uGx4+tFDEhwWmR7VK2nPRRf2eMGCAgrUB4IicVKTyCkBSODe1w4eWy1GzNmIQ1wGJF3yEAWqj9K+kUtGp6Y4THz1rEysRZoxxjQgV1dv/9+NPfGIwWgEwb7U/recLi8QxFLBPX7jpqrR4d+SMXDRhLb61gURTyKdw6jhGXOCRQKvCwOrikurzhhUU1dA1xu0yhry1z/ihvfn8Xbu+qyAD83T4ZuzmQj6sGkls+s/nnJM+r6PjJoPenHWcVYXQUlYbxi82jexD6yGp4j0GSry2JyXidBiHvA2PGOGvxyxfumjnzvx84vxaetQwJH4BwM7Nm1fljLke0fdljHMWCgW1BNZaIq6Op8pih/kUYwxNKK8kEwkKiCvGyRqJNp+09jei/K+86v+4cNeu3wAspL2fCQ0fZAWhr88kHPzkxo2dadd9O6rvUnRLxphlrggh4KsSRCFPkoQ9JRwGiZoYEVwETwRHIFQoqj0qyo+NMf8X171v/fDwKEQadD4Jnnr61hQoyENx5jD5t72XXrq8WC6/FsPrQ8slCmcrukqhy5VokvtUYAEFQtUQmBA4IMILBnkC+IlR/en6J5/cn1z74Nat7lU7doTN8pabrmYTjTA0NERiHqp+M3vPv3xJwSn0qmqXNeaUyCjaMAxTIuO5bHZk7dlnH51uzxXMfFO6r0goiPb1OQ9u3erq6RAZxFAwD27d6mpfn6OL7Ou0mqMlMfsLwFDr9e+k0Dcl1QrJ2so22mijjTbaaKONNtpoo4022mijjebi/wMyIvSZlE40TAAAAABJRU5ErkJggmljMDgAADaEiVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAA2Q0lEQVR4nO2debxdVXn3f89ae5/xjpkAkxDmQMKoUK0MN1jROtWK3mjrQJW3FJC+tTgAUry5aqwDiK9Tqfat2k+175urtvraqqAkUKBMoZGQxASQecrNnc+891rP+8fa+5yTS4Y7nH2mu76fzyLJ4Qx7r72eZz3rGdYCLBaLxWKxWCwWi8VisVgsFovFYrFYLBaLxWKxWCwWi8VisVgsFovFYrFYLBaLxWKxWCwWi8VisVgsFovFYrFYLBZLA6FGX0ArwACBGdiwwfTX2rUEDDX4qiz704+hoSH0r1nDAIANg0wEbvBFNT1WAVTBzIT16wXWrDH9snMn09CQavBlWeYBDwwIAAIAsHYnY8capsFB3dirah4WtAJgZsLQkMCOHYTBQUU48IzBX/pSGjrTDcjOUrGUEq7sdbRmX+sF3X/NgiME+0KQo7xJuIkpsMqCchN0zZemDvYZHhhwgr/qhawQFtwArpoRXvbgeePGIwD/JECdqoGTwHwSM68AsISBbgApRwiC4wBsrcumggjwfSitGUABwCSAYQjxHAGPMvRjDHqkVBK704ODz1Z/lJkJGzZILEBlsCAUAAOETZsEduzYz/zjL3/2KBSLr9E+XcDA7zP4ZMdxuuFIAARoXW6sNTQzGACDF9QgaRUIRASQIAIJAVQ3AFA+/JKfBfGjYLqPJN8phbyHrht8MvyOsjLYsEERUdtr+bZWAOFsT4ODfvm1zw2coJjeBOg3MfO5jhvrghCAUmDfh6+VBmAEnIlATMwgItNV1OZ91upwuIxj47oFE4PK5ppwSAhyHMCRAAN+sZgn0P0g/Fw6zn/QtZ/aXv6uTZvk9Emj3WjLwcwDAwJr1xKtX68AYN/AQNfiOL9NM96rWV/oxBMJaA32PPhKKxhvMQEQBGrLPrEY2KzdGIAGg6QgKdwYICX8QkEJoruY8C8S3o/p+r8dBsoTCdpREbTVYJ8u+PyZ64/XEJcy4X3SdVeCAV0qQbH2YQXegrLFoAFmAjlOPAYIAVUsDRNhk9D89/Spz24H2lMRtMXgD9f4oeAXB647VbjO1QS8W8biKZRK8HzfhPOIhDXjLQeCAQZDAwxXSol4DKpY8gn0E0F0I/3N4L1AsDTo79ft4CNoeUHgTf2S1g+VZ3yfxPUEvFfGYjFdKJrZniHLi3iLZQYYy4AVgRwnEYf2fIDwI1/pjfFPffa/AaMIwkmnVWlZoTAx/PWC1g+plwau7FgkF11Dgv5KurFOv5CHZlahQ7jR12ppYRhsoj4kYskEqZLnEeNbQolP0+Dg3lZfFrSkcFTP+t7gJ99OQn5RxmInqUIhWN+TtGa+pdYwsyIi6SaTUKXS82C+wfnUZ/8RaF1roOWEhAcGHBoc9CevvnpJsif1Fcdx3gutUfI9K/iWyAmXBjHpOHBdKK/0c8/3r0oOfv53vGmTxPr1+mAZpc2IaPQFzBRmJh4YEDQ46OcHrv3D1KL0g0489t5SoahLvqcJ5Fjht0QNAUQgp+T7XMrnlXTdN7mOe7+/4fr30vr1igAOlwWtQEsIDPf3y7Aox9/wyQEh5QYCUPI8n4icw3zcYokMzaxcKaVwXWjP/4bQu6+mwaFSqywJml4BbB4YcC4cHPTHr72iN5VY9D03GX9bKZvTAEBELaNpLe2LZmYCdCydkqpY/K9SsfAnqY03PRUuVxt9fYeiqRVA2IGF66472UnKH8mYu6aYzfsk7KxvaT5Yaz+eTDpK+c+XSoX1qc/ceHezK4GmVQBhx+Wuv+aCWMIdkkIuKxaKVvgtTY1mVnHXlRrIFYvFS9Kf/eIPm1kJNKUCCDssf8PHL3Ri8Z9JUKroeUoQyUZfm8VyOLTW2nEcIaRAseT9aerTn/+XZlUCTbeGLs/8n/r4u9144hfQnCqWStoKv6VVEEIIpZT2fV8n4/EfFG649iM0OOg/eNllbqOvbTpNZQGUZ/7rr1nnxN3boNlRSmkSJFonsmqxACCANTMRcSweF/l8/r2pz37hBw9edpl79re+5TX68kKaRgGEYZPc9dec58adX7LmpPIVC2E9/ZbWRTOzEEI7jiOLhcL61MYvDTXTcqApFMCm/n65fmhIFQauPUkK5y4iXloqeVoIYYXf0vIws5aOAJH0vKL3+tTGL9zVLHkCDVcAAwMDYgOA8fHxrnRP6l7XdVcXikVFds1vaSO0Zh1zHcHAsF8qvDq58aYngszWhhYRNXSGZYA2mC27dKIz+c9uLL66kC/4BJII922xzbY2aIJIlDxfOUIuJen+kAcGEti5k0wOUeNobEx9YEDS4KCf+5tPDCTSybcUszmPBLmm1yyW9kIQZL6Q95Pp9Cvzuew3U0NDH+INGxwADfMHNEz7hPn9+es/9vpYPHGb73m+Bmw1n6XtYWY/kUw6hVz+Q8mNX/xOI/0BDRG2cN2PYrG76OIRR4ijSr7Pwub2WxYAmpmlEExC5JVfOiOx8cbfYWCAGuEPaIjAbVi7lmhwUOeE/kY8EX9FyfcUEYkmWKrZZlvkjYhIac2ulGmQ/C4BjJ07CQ2YkOv+g6G5U/jkNW+JJ9yfFUpFH7D5/ZaFBzP7yVTSyWWzH05/7qZvNmIpUFcFEJy6QgASeT+/I+Y4q0qex7as17IQYTA7QrJmzvhanpzeuPFFbNhQ16VAfQVvaEjQ4KDOFbPXJZPJY0qeMf3reg0WS5NAIPKU4ng83kXwvkhE4VKgjtdQJ3hgQGDDIGPDNSuLCr8lcFwxk/X6WxY6BCjpOLLkqVenP/fF+6t3wIqa+q29164lIujsderTqVQymcvlfSHIsYfsWhY0BGhmxIVAib0vALgQa9bUTSrqMvvywIDA4CAXr732RDj8CLSW2vy2nf0tFgDMrBOxmCj5xQuTG2/aUi+HYH3W32vXEgGsyP9kPBZzFbOGFX6LpQKBhSBoTQMAgB076mIFRC6EYcFD7pprjiZH7yFGTJujm60CsFiqYdYx1xXFkvea9Odvuq8evoB6WADm6CShLk/EE3GltQKCA7lts822cmOGltIBQB8BAPT3I2oinYUZIAKYP/rRdN7FY67jHOn5voYN/VksB4KFOcO2oEmtTm388jNRlwxHK4gDA5IByjv09mQycWTJ95UR/iZQt7bZ1nQNpLRS8UQ8Cab3wRCpjEY9E5tz0oS+BKwZVL5Ri8XyMhgAhPY8sNbvC6JnrekDCE2X/PUfPZZI9BWLHgjW9LdYDgURiaLn6ZgbW5MvZX+fAOb+/sh2x4pSIAUAaM1vTSTiccWB889isRwSBrTjuiDwxQCANWsik5soMwHN+X1Mb4HSAIis9W+xzACGYM+DZn4j9/d/IlgGECJYP0diATAz0eCg5o9+dBnA53klD2C25r/FMgOISBQ8nx0h15ZOWLU2OHI8EisgGgtgaEgAUDlHn5uKJ9PZQkERkbQGgMUyM5hZJeMxJ5PPvQ7AwzCTdc3DgdHMyjt2EAAQxAUwcU0r+xbL7CBohoS4AACwc2ckMhSJWcHMRESc+cRf35+Oxc7Jep4iwO7zb7HMFGYddxyRV/6zHTn/BPra14pgJhDVVBHU3AIIhZ+vu24pA6eUfN+u/y2W2UJERaXYIbE8E4+vBgA2u2nVlNoL5vr1AgCmdO6UtBvr8LTWRGTDfxbL7CBmVol4nODo04LXai6vtXcChjFLhbUUF0AJGrAWgMUya4LdcoTGaYd555yJLA9ACLEaBDAYNv/HYpk9DABag4lXAwDWrm2BPIDAW8mEk6AYsOa/xTJXBCsFrfl4AAh2CKqpPNVaAVC4gQExLWetAM229t822+bWyFMagsSylwYGOgCAa7yJZk2XAIwgX7H/NcmpbHap39UJ81JtL7o1ILMbQpAR0f4Ez5gZsDu91gxFgM5le90XhhcByATnatSsgyPxAYwkVy5yx0d7PL8EdHUBJBbOoKBA8JUCSiWwUgvk3s19k+MAMTd45nph6v5aQAQiwB8fYyeXi2mllgJ4utY/U1sFMDBAGBxkl0WaBJIqkwEXSxA9vaBYDNBBJmMkZQ0NIrwXAiAEuFgEPA/U1Q2x6liII44A9fRUvbndCB6k50OP7IN+8QXoF18AijlQIglIaZ477f92yzSqZUIIsO+Bx8eJC3kdi8epCN0FALU+OCQSC0DDT7twoUgwPA963zCoswvU0WHe0E6bAjPCjc/AmQzE0cfAfe25cNaeCtG7qNFXV3+0hnr2GXgPPgD/gfvAmQwolaoof8uB4WAWEQKczYInJwClwEIyQBAaHVH8bG0VQKCdCHJxQgpkyuf+MXhiDCgVQN09gOO0z4AQAvB9MDPif3wxYuv+wNwfsDDXw0JAHr0K8uhV0Of3ofivQ/Af3gZKd7TPM48CIYzAj42Bs1lAkGlglgSAeCkAYO/e5rcAmFm/bNgLAc7nwaUSqLsblExXBKRVjQEisOcBrovkpX8B5yQTrjUmL1XaQiN4rmLpUiQvuxLFn/wYxVt/DtHRaZVANdVLx0IBPDEOeJ5RBi9/byQdF00ikA9T+jNdC5AAlAaPjAKpAqiru3WtASJAaUBIpC67EvL4E4zjT8oDP8CFRKj4Ausn/vaLAZBRAtYSqCACeZgIZn0gcJ5Oex8jgkJgQ4Q7AoXBzGkEg4NzOXCpaHwDqbR5b9lcbmYvIZX/0MUCkpdcur/wWyqESkBrxN/+DqgXn4f/yMMQyYXoE6ga06EM5HNmre95gAjHzoHGfXSyEJkCOIj4A2AjQoLASoHHRkGFPKirG+S6JvWxaYUfABgkBHQuB+esV8I95/fMYLbCf2CqlkCJ9X+C7O8eB/s+SNACc4+E416AfR88NQnO5QAAJARwkFEfvhaVuozOVj1EhlPFN0YAGd+A3rsXenLS3HCTm9CaGexIxN/whwvPyTcXiACtIXoXwXnNa6HzOfBC2yCaCEwEnclAD+8FZ7IIz8cty8OhWkQ0x1MIBgNPTEAPD4PzefNaMzrQyMT65THHQa5cZV5rcoXVNDAjds6rgVgcvFCWAGRCeygWzdgeGwt8R80xZurvAzgUQgBeCTyyD0gmQZ2dQCzWVOE0JoC9Epw1a4MXuDkVVbMRDHi5fAXEUUdBP/+cSQ5rkucaCWGIeHIKnMtWXpu1bLSgD2BupktFmDiXA+cLoHQa1NkBSKc5UkvZaG+5YmWDL6QF0abvxJGvgHrqSXAsDmpHBSAEoBV4YhKcyQBaBRYt5qbwGEBE5wNFeS7A3CgHAoJlwdQUOJ8HdXSYjLIwtTSModYbpYFYvJLlZ2f/WSOWLGnPJYAQxomdyYIzU5WYfujvaEJd14AowCyRgTYdHwdls0BnByiZCl6v7yAK70kTVbL9LLPHcc2qrtHXUStEUOyWy4EzU+BiqbL2nydR91FEo9iH8S/W4PLLBRIE9j1gdBTsZioWQaB162kRcBP5JFoR5krIq1GG3LwILzqocuVA8FEsBoJf68qn6NYATeYDOBxBhpnngUdHTaFJR2AR1EsRRByWWTCEJkAr9WVV6u4BBT8qUz/CPmpNO5amKYJYlSKQItKoQSuN12YmlP+Wmv2DZWdZ8Esl83qThPTmQnOFAWdLWRGUjCJwJ0GptEktdsKoQfU11CDFmLnJMxWbmapdg8r/bra+rBojDGPOB3UfnJkyOfulUmUJUCbK+2i1MKACIOvh5amqHSAAng8eHzdLg2TSKIL98ghqsA8BVw0Oy5xgoImXAMEYCdfyvmdm/GwW8P39Kzzr5QeK8HciUQA+GvRsw4ejNXhqCshmQYmEsQricVNwYR14loNClfV9sWgEv5A3hV418urPllCOIkoDaFEfwEwIHpZJKMoDrgtKpSCSScBxzXvaMRZtmT3lfRx9cKZQrlQFsxlHLbzGPxwRRgGaZKYNUy9LJXCxCDU5GVgFKVAsXonhzvRam+GeWp2wvxs5Rqr2LOBiAZzLm9m+2swPx0ajYTbZhBHQvhZASPgAqx94NmtKMR0XlEwaq8B1K/XrzfDQLbWneqMS34POF8D5nMnYC2s6qmf7BTAO2l8BHIjwIfseeLIElZkCuTHjOEwkTATBKoP2YD+h983avpA3uzcv9K3b0HKJQDWEsN+D52IBXCwAQoDcGJBMgOIJkBNYBmiwydpu1KLWfb+obnVEiMrPjH0fKBbA+QK4VKqY0jRtbd/Mj7UVE4EYTR4vn35pVaEdLhaAQt4og1jMRBDiCcB1wUK0Vx57g6iMj3n0ZHVUtyoCBM8zCr1QBHsl48UHgsKcqjTdFniIpodaLAzY8uxnGRTBhQIgJsGOC3ZdcCyOlhg97UwYpw/2HORi0Zj1paLZqbnavG9jL/58sQrgcJRzvDmYWYrQyAB+VJFZC4D9LHrzZ7iWh6kO9bxyZIe9UvA82Ar9LImuGpDdNlovV68vmyQ01MowDhEGDLI6RWVJBq2NwHseuFSqCDxXZe2R2V+v/Jl2otUyAduXWniuLPsxPbWWNeApczZeOMv7vlnHTw/p1i0Xv32xCsBSf8Jj08OZ3ffNXg+eVxH28kGywcy+gEN1URLZyUDchpZyaLnayWaOhHVUuSzUS3uBXB7keZV9AUMBf9nsjgXb5+Ux13p7ArarpNhlwHxh3wOXCoBOTSur5Wl/WgxhJWvtsUsAS/15mTlvBb5RLNxMwLnSrvdVTxjWkJoNEfZRtEeDWSyW+WNTgZuDMC2z3e6rEdQkFXgBEI65qNLObLqUxbKAsT6A2dKu91VvrA9g5tgwYDPRjvfUKNp1jNSa6PrILgEslgWMXQLMlna9r3oS5rXYvpwZrRYFaNi24BFjl621wfbj7IiynyI8HNRFez7idrynesNgawLMgui8gJEVA7W1/LfjfdUbawbMnJbMBLRYLE2PVQAWywKm/U8GqjVNe6hlC3HILcEsL4M5qmrgKGsB2k9G7LK1tth+nBnR7QZglwAWy4LGpgLPmna8p3pjNwSYHa0WBgTa99m2633VGyv/M8eGAS0WSxRYBWCxLGCiiwIwg9ssxGOiV+E+Nu11b/XEeLWD8dFmYyQKdIR9ZC0Ai2UBYxWAxbKAscVAs6Ud76ne2Cjg7Gi9LcGsBrAcinDtbzXAzLA+AIvFEgERRgHaz8FbrmFp9IW0AVxtBFgOSZRyZFOBZ0073lMjsEuAmRNdOZBdAlgsCxirACyWBYwtBpot7XhP9caGAWdH64UBgfZ9utPviQHQgd5oOShWA8yO6PrIngswC+yQnR+hqrT9ODsiNADsEmDW8LQ/LXPDaoGZ05phQIulTlDwH6Kqf1dRVtqBxrFKp4z1AcyadrynRjBHE4AAkKgIu9aA8sG+ApQCmMF6f4OZhDCfkRIkJRA2IMhI0k3+WFvMB9DWpQAkoPM5qPExuCtXWh/gLAi7SQ8Pm3/NVP4JgBDmL8oHF/NgrwSAQIkERFcXZHc3ZG8vKJmCWLRov4/r8XFwPgc9Pm7axAR0JgNoBrkuKB4HnEAUtG6+FNZWXAK04/zPAEAELpbgPfUUEqee1nyDpZkRJu2k9PRTIMcp993BepCIACHAvg/OZgCtILq64a5ejdgpa+CetBruccdBLjsCoqurMqsfDGboqUmovXvhP/EEvEf3oLRrJ7wnn4QeGwOIQMkkyHUBzWCOajPu2VHdP1tq/N22GnDWMEgI5B96EJ1vfVvFFLUcGmaACGpkBMXHHgXF42UBe1kPCmPi60IBXChAdHcjce65SJx7PuJnnglnxcqD/8aBilCIyk10dRslcsKJSF70BgCAevFFFB95GIW770Jx64NQIyOgeByUSAJgYxU0lFbcFbhd0RoimUTugfuhxsYge3rKg9tycFhrkJTI3v2fUPuG4fYuMmv2sN8YgCCABDifA3se3GOPReqiNyJ54evgrDx6/y9UgUBUCXe5HfJCpikJKSGPPBKpI49E6vVvgHrpJeTv3ILcL3+B0u7fgqQEpVLm/ZobtNxrNR8A0J5rAABgs25Uw8OY+H8/waIP/BlYKeNcshwYZhARWClM/Ou/QsQSgGIQCBSOESnBxSK4UEDs5JPR8a71SK67EJRMlr8DWpetg8Oa+wfjQEoi/G4iyCOOQEf/u9Hxjncif/ddyAxtQuk32wDHMdeioorIH4LoaoGsBTAntILT0YnxH3wfHa97PWIrVlQGp+VlsFIgx8HYD/4ZxV07Eevtrcz+wjgD9fg4nOUr0Pm+9yP9lrdWnHJKzV/oD0f1d4fKwHGQ7FuHZN865G//NSa/+x14j+4xvgYhmmBZUBsiHLHT0z1bvxHYTB7MIEeCM1N4cfBT0MViWw2KWsK+D3Ic5B7aipG/vwVOZwegfNOXUgSzfh4d7343ln37fyP99j82wh+E9CBlfZdX1cogiAgkX/cHWPatf0DXZX8BaAXOZYP31HP8RUNkCqB6qdVuzfhkNJyOThS2b8ezn/hYWQmw8mEjAwC0Ls/8uW3b8Ow1H4cQAkTC9J90oMYnII84EktuvBk9f3U1RE9PxcSut+AfiNDy0AqUSKDrg5di6df/Du5Jq6FGR8FCmmmhHmMuqluM7qvbE0IQngIApeB2dyN337146qorUHzySZB0gkFjBIC1NjPJAmisFTicuYUASYnxf/8ZnvnoX4M8D9J1TR8KAT0+jtTr/gDLbvkW4mefs/+M32wIaa5NKbirT8bSr/8dOt7VDz0xYV6n1hUj6wOYI+HcREoh1t2N0o4deOKyS7HoPX+C3rf+EdxlyxZcflD1/ea2P4yRH3wfU5t/DTeVghNzjfJkDc7k0H3ZX6D7g5eaN2vdnIJfTbg00BoUj6P3Y5+Ae8KJGP/KTYB0gtwBhVbLCoswChCx7dJAyo+Y2ZhQvg+3Iw3llbDv776B0U2bkDr7bKRfdTYSxxwLZ/Hixl1snWCvhNKLL6Kwezcy992Lwo5HQJ6HWFcXZNBPpBTI97HohgGk3/Tmsue9pZynQiB0FHb88TvgHHkkRgZuABeLoHgMUBH4gZhh8wCaECIySoAIUBokHYieXqhCHplbf4nJX/wccF1QPAEgdOW0n1IkBEueQh5QCjIWg5tKQSaTIK3N2l9poFTC4s9sRGrdhYDyAdmiwy+0Bnwfidf8PpZ86Sbs+/hHwcUSKBZrKWdwiz6BxhPWtVcrAQZAWoMcB7K724RvtTZ+AISi31om4uEoL4UcCerqAgkBYobQ2vRF8G94HpZ+ZiOS6y4EfL8S5mtlHAdQPuKnn1FRAp4XLAdaQwlEVgzEbvsdDnpAyhWobPxBAASbe2ew+d+CKvN+O3XJtOpbYm1memMTmJwbAJzJYMmGT9dX+MOxF3UkQTqAb5TA4o1/i+GrP1KJHoQDYp7PnJkjyz9qocVXk8KhABAEBQMfpmMFCDJoDgiSUf53WzTGfvckTG5fcO+AkA54YgI9f3EF0n/4pmiFn9lEXaanCAPgICITmU/KMUogcfY5WHTNdabSMIwM1OInI5w02sAOaw7K80ygBACULSAu/6/2Mv+rlzM0/VXHgZ6YQPqiN6D7gx8yYb6IhJ/DpUZVJMGfnASYITs7zX4A4XujStsOkpfSb3krvMcfw+Q//xPEosVG6TUxVgHUmLLwoyLwFL6wH62+FqAD/hUwcX4uFBA7+mgsuua6cl5AFIQCzb6P0VtvxehttyG3Zw/80VGAGU53NxLHH4/e170Oi9/0Jsh0uqwwao4QgFLovuLDKO7YgdIj20HpdFP7A6IrB2a3bcOAM6Hd5vqXwwf8q/k3A76PRdddb3LnI6qTCCsMxzZvxtOf/zyyO3YAzKBYzOw3AKC0dy+yO3Zg309+gme/+lWs/MhHsPTii6PxEQTLDnJdLL7+b/DiB//MWABh6HBORBtOtz4AS22REnp8HB3970b8rFdWinlqDCsFEgLPfeMb2HXJJcjt2QOnpwdOby9EKmV2+nFdiGQSTk8P3EWLUHzuOey56io8sWGD8RlEkasSWAHO0avQ/eeXQU9NNXWSUyQWgALathrYcgiIwMUi5IoV6P7QpdHN/IHZ//y3v40nNmxAbNmy8usvfzOXx6FIJCBTKTz7ta+BiHDMwEA0PoGgMKzjXf3I3voLlPbsMaXEc1wKRClH0VkAja7Ysa2OLXjeJMC5HLo/9D+M6c9c8zBcKLCT99+PpzZuhLtsGZi5nGtxSLQG+z7ir3gFnrvlFuz76U+N/6DWMbYgBEiOg57LrwzqHFDV5tDHUWQYwi4BLDWBTSVkLovYmjXoePNbIsvvp6DQ6ukvfAHMXE7EmtXVag2RSuHpG2+EyuWMQ3CW33FYgrqBxO+9GonXngudmTJ7HzSZXWwVgKU2EIFLJXT96XvN4K+1QMHM/hACkw88gKkHH4TT2Tm32VtryFQK+ccew+gvf2muPUJPfff7PxBN1KEGRLgEsG3BNCJwvgD3uONNnj9zNGG/QKmM3nYbtOfNb3nBZnPXsdtuM/+OIkcjsCziZ56F+JlngbNZkyA0lz6OCHswiGX+kATnc0i/+S2m8EmpaMz/QKnkdu82+fbzsDKYTbgw9/jj0eUFAOWlUMfb/xiF++8L9MxsrjtaObLnAljmj/JBPd1IB9tsR5Z/HwipNzJiko3ms8xgBkkJNT4OlcnAichpGV5z8rzzIVesgBodATmzU16MyPYEtT4AyzwRAjqbQ+KVZ8N5xSvs5qjTIQKUgkinkTrvfHA231T9E82VVJ8Pblt7N5gBnupbBwCzmtkORbmwpxFptFxVWFRDZ2bqgnUgR5rzBWbavzr4MyIiPBlIINIrtzQHyofo7kLila8y/56nCX2gwp66EiwDqn9/3slCwYwfO/VUOEcdBX/fvln4MMqaNhJsMZBl7giT+BNfu9aY//P0/lcL2sTdd2Ns82bkdu+GNzKy3/uKzz4LEY/PzzoIfQCZDHasX1+5bmY4vb1IHX88ui+4AL0XXghynPk5CoPcBZFKIbb6ZHjP/drsHBRBqHS2ROcE5Ka4P0uEEAi65CG25lTzwjySf8LCnol77sHTN96IzNat0J4HcpyXzb4iHq+Nsy6I/+f27KkM1uAEo/EtW/DCd7+L9Nq1WPE//ycWv/nNmJeTMPj+2OlnIHPrrUCwnfjhPxd8tPVOBorWdLE0GgIHzzh2ysnz+qZybv/f/z2e+tu/BTPD6eyEDLdXn/6BGvsFRHj8WAABZUHP7d6N3/75n2P5lVfimOuuq2QfzlYRBO+PrT4Z5LpBBGM2SwC7KailqWCzRXYygdhxx5uX5jA7hsL/3De/iScGBsx26sEsXDemKZRqsZSpFGRHB565+WZwoYBjP/OZufkEQgWwahVEdxe4WCwfi9ZIbCagbXNrILCvILu6IY88yjzzWSqAUJDG77wTT33+86aqL/DANwtcVUD0/Le/jb2bNs2tgCjoG7l4MeSSpeCSB2DmWYGicoxqTYlEAZBg0f4bYixwiADfh+zphezurrw2m68QAux5eOpznzMz6hwKe+oF+z5kZyee/tKX4I+Pm+ud7bUGORLOkqXgWW4VpjUiCYvUVgEMDZke8cR4iVWwOWy5XtS2NmusPIhFvXMSXA5OBx67/XZkH3kEsqOjqWb+l8EMkUig+OyzGP7xj81Ls73eoI/kksXmFKFyWvAhGyloAGoMANYtWza7jj4MkfgAfCEmg+oq4sp+DJY2g7UGJVPBP3hOPoCRX/wCkezMEwVB/cDorbfiqA99aM65AZRKgzWHX3nYn1TMIE0Tc/qxwxDJEiBOlNeaC4Jhpb9tIUAx5KLg2LNZCnBoQud274aIxeaX118nWGuIWAyFJ5+EPzU1a8snfKdcvBhlw/jwHyFPMxRzBgAwNDSHKz84tVYADAAykRglwoRsu22wLTUhEBo/k4E/Omo28GwBBRDu8uNPTsIPk5Mivm5BRCWlfcG8N7yKmn5/Lb8sFPejbrsty+B9jlnjcKPXqrZF3eZIq5j+06nJdYdJ/gdvDIZDAIHHPObR8Nfn+cP7UXMLgAcGBACQpuclCNDMkYw525qjzcXKC0NiHR2QPT1lh2DTE+QnyI4OOL295dfm8j0z7F+WIIAxfNL9908Ctd9uvuY+gC1btggAYPCj0pySw7X+DUsTwAwIghobM/+ebQ5AkFufOv54cKnUGqcmBdueJY4+Gk5PD2br+AzfqUZHzAaqh/sAM7tEYMITALCpv1+ixvJU8yjAuvAvzLuBMARgdUD7wWBB0NnMHD9uxkTvRRdh+N/+rSUsABICulhEz7p1AFCuX5gtOpMpy8Whg2TMgggCtBsA+vfurXkn1T4MGMQpNfSOotJghk0KakcYIJJQo2OYSxVguBPvoje+EckTTkDxuecgEonmPUaLCLpUgrtkCZb195uXZlsdGCg5tW9fUIjEh54bGWBm+Ky3A8CWuVz3Yaj5EmBDkAzkkrsrp1VeEtloYDvCDDgO1NiYOf0mfG2mBJV4MpXC0R/7GHS4PXeTQq4Lf3wcyz/8YcSOPHJufotA6fnD+8pHlx0KBsmsUgD0IwCw7o47aq4da97jg8HKaNU99zwPpj1xMetdEC2tQBAS0+Pj8F96qfzabAhz6pf80R9h+eWXo/j880YwmkkRBGf9lZ5/HksvvhjLL7+8fCzZrAj6Ro2Nwh/eCxxmQxAGOCaIfOaXksUjdlZeri1R9DRv6euTAEDg/4oRgbTWjT+9xraaNyLoXA6l3z1uHvwsFQAQ1ANojWNuuAEr/vIv4Y2MQBcKlX0AhCgfullutWb69wc7ApHjgH0f3t69WPbud+PEL3/ZKL7wmmZD0Dfe009Bh7UEWh+if7VOCAJYP7R8689yPBBN7WCkqlaD72Rm8EI4LHcBQgCgFYq7ds3jS6hcX3/shg046etfR3z5cnijo/DHx6HzebDn7dcONXPOBfb9/b5fF4vwJybgjYzA6e7GcRs34qSvf72yb8Bcyp6Day7u3mNKgQ/3HUEIkDXdCQDY0heJrEZSCxCuVdjRd016qihIxI0JYBVBO8HMgBtDYfvDAObgFAsJhIG1xtKLL8aiN74RIz//OcZuvx2Fxx+HPzER/iAAQGUytcsdIILT21vZBIQZsrMTiWOOQc/552Px294Gd9GiitKZ628Gnyts24awVvZQaoyJZFZrgOh2ABi6446az/5AhALJZrsD/dhrXn1Hh5QXZJSviKh5z0m2zAnWDBGPYeXQj+AE9fzzEczpm22w1lBh3n3AI+vXI79nj5mR5xo1IAJ7HtzeXpz64x9DhucCAJDp9H5OunlvChr0CReLeLr/nfBfeOGQewIyQyeEEAWtHi9MZtacunNnCUZWW2gJ0GdMFgH+d5dgpotGr1ltq3kTjoQaGUHhoYcAnuEpvYcgLBJipcrJQk53N5yurnKbUy3+QX+Q4CxaZL67uxtOd3d5E9BwW/B571AcXGtx1074zzxjhP8w6/+kIBBw66k7d5Y29/U5QDSO9OgUQLAM8DV+NuWXZ/9IbsLSYIiQ3Xx77Zx0oROuaqfel7UaUvYrVAlleWvyGtxPuP7PbtkMLhUPn/VIJEpaA0z/CtR+D4BqIlMAZI4/ECfdf/9Oj/netJRg5ibN8rDMFVYaIpVG7t57oYaHozlqe7qXvtbff6DfqBWBBcHFIrK3bwYlU4e0khjG/M8o9cSY728BQDQ0FJncRBoF2BIsAyTEPzlmcxBjAzSB6WpbrZo2JbJ79yLzK3PSbmRHbQeC7/T0mOXBfAQ1LOzp7IRMp8uv1ZqwL3L/dQ9Kv3scFJ5ncLD+1FonSUAC/+fsrVu9zSakHoHGM0SqANbdcYcCAOm6Q+OeN+YKkhqVDZFta4+mWYEScUz827+BfT+yjL5QmFInnmjM9nlAgRMwceyxxuEXkdIKldTED38IJkIQFj9YYxDJSd/zWeO7QDTZf9VEqgAIYO7vl6vuumuMQf/SYZw3Tbzxm2VOaIZIpVDc8Qhyd91Vnl2joufCC+fvmAuusaevDwCisVpMGA/FXbuQu+duiI6OQysaZtUpJXzwL49/4IE9m/r7JUV3MDCAepwOHNQGaBJfn/J8RSCJsAjKtrZprBkQEmPf/Q4AzM88Pwih97/nvPOQXrsWKpudm7VBBF0sIr58OZa89a2V764xHPzW2He+Ay4WQXTobcAZEJpBrqabAaC/5lf0ciJXAAToTf39cvV99+3ymH/WJSUxa93wEWtbbZtWkB1p5B+4H5lf/cqcGxiBFcBag1wXK6++GrpYnFPdADkO/IkJrLjqKuNPiGJDkiCEWdi+HZnbfgnR2QlWhzg2m1mlpaRJ339o1QMPbB4ABA0NRW4t17XqIib503mtmFpi9wfLbGHWoJiLka9/FVwoGCsgcNzVirCAaNEb3oAVV12F4gsvmDX8TIZUWNjzwgtYtn49jrzkkvkn+RyEMPQ38r9uNn6Rw1wfgyEBEsSfJkBv6O+vi4zURQGsHxpSm/r75TH3bn2ooPX/65KO0KEvoAkmL9tq0ABAMSiZRnHXbzH2ve8aKyCCtTUF1sWq667D8ssvh7dvHzg8SHR6oQ6RiekHjj5v714sfec7ccIXv1iepWtNqFSmfvpTZO++O5j9g3444OTPKi0dMeGrh064f+tPuU6zP1BPC2BoCAyQgPhkzvd9ASI2uYENH7u21aBx8KfvQ3R3Y+Rb30Jxz55K1VstCYQaAI777Gdxwpe/DKenB97ICPxMZr+CIfZ9qGwW3sgIyHWx6oYbsPqWW0wacRTVhYFS8YeHMXzTjRCpNFjp/ftoemMAYJKaryWAUafZH6hzcQ7390saGlK7zn7VN5e4zhVjnucTkT2gtN0QApzLIX7KKVj5T/8MuO7cTtSdCcFxW97oKIZ//GOM/epXZt/+yUkAJq8/vnIlevv6sPRd70J8+fKycqj59TCXtwl77qorkb39dsju7kP6QphZdTmOHPf9/zj5wYfesqm/X66v0+wP1FkBDABiA4Bd55zTG4fe5RAtLmkGqL6+CEvEMECuA39kBL3vez+W3fApsw6ewS44c/q5aet4f3IS/ugomBluT09lB98DvLem1xHc4+g/fBvDX/wCnMVLzBmAB5EyBtgBtCDyffJPO/6+bY/BqKW6ZczWVfAGAY3+flrzwAMjWuNjSRKCmXXj7VfbatoAsOfD6V2E8e9/HxNDQ+XNNaKguoAIzHC6upA45hgkjz3WCH/V/4tM+JUR/uydd2LfV74C2dNbud+D9ZNm1SkdWdL6cyfct+1R9PeLego/0KD6/HApsPvsV97aI52Lxn1PCVsq3H4E+99zoYDlt9yC1LnnRWoJlAnTasNriDjoFFoVxd2/xTPvfz/g+4DjAIcofWGGSksps0rtOLGj88yhZcu4f2hI13sb/caY3kNDzMYheGlOq4mYEMSmeKjhk5dtNWzMZlcI18HzV/818g9tjdQSKENk8gPmsnXXLAmFv/TEE3juyiugiwXAdXAYw5YFAT5rJRiX0B13+AAacoZGQxQAmaWAOPHBB5/Ja3VFkoSAtkuBdmysNOC40MUinr388vopgTrAvl8W/mcv/RC8l/aCEklzz4fqE82qWzoyr/X1Jzz00NbNfX1OPR1/1TQ0IYf7+hy64w5/96vO+uZix71in+f5wkYF2hMpTXJQIoHlN38Fqde+trK7bgvmhYVLmeKuXXjuqg/De+klyHT6sNmPzOz3OI4zofx/P2nrf791c1+fc6Epmqv77A80WgEAhP5+gR075GOJ+H+mHfl7k75v/QHtihAmRq8UjhjYgO53vsu8HoTyWoLQvyAEMptvxwvXXgPO5yGSyZkIv0pKKT2tnygK55xTHnhgbAMC53iDaLjq5WDvwEfPPnulw+oBQeKIvFZagFpkRFhmhRCA1tCZDHovuQRLP/4JkOtGGp6rFdXXOHLL32Hka18zOQ4xF1CHlmEGtEsEARRz8M5bs3X7Q/WO+R+IhgsZAZr7+6XxB+AdYM7HSIC5cVrREiFBiazo6sboP/4jnrnkAyg++mhF+CMsI54zwQYeJCW8F17Ac1dcgeEbbwQlkyBnRsLPDqBjRCKn+X1rtm5/qJHr/moabgGEBGshf+dZZ13cIcWPSlorHyyoFReIlhlBjgM9OQnqSGPJ5Vei9wMfALluJXW40cuCadcx8aMfYfgrN8PfuxeypxvsH15+GWABVl3ScUY8/6/Wbtv21dD3FeWlz5SmEq6wY3aedfp7OqXzLwWtlc8QZoNUS9vBAKQEfB9qahLJM8/Ckqv+Eh3B6bvl1Np6OgrNtlz7hRDzW7di+GtfRe7uu0CpNEQ8ZoT/cGd7sBH+bsd1Rr3Sx07Z9vBND77qVe7ZW7fObzujGtJ0glVWAmec8ZFu17k5q5TWbKzGRl+bJSKIQEJCZzNgZnScfz56P/hBpH//tZX3qEDgKAJlEDj2eFqmYP432zD2ve9h6rbbwJ4H2dlpqhtnUOJsZn6obsdxxjz/Sydv2/aJZpr5Q5pOAQBAqCV3nXnmn6ak+L7HDE9rLcg6BtuawNTWU1OAEEidfTa63/lOdFz4Osju7sr7tNlZkqo+MyulUC3wYdJQ+NX5PLL/+Z+Y+OEPkf2ve8DFIkRnp3nPDP0TGmAJcKeUYtJXH1u9bdtNgfA3LNx3MJpSAQAVS2DHGWes75DiexpIFLRWgtDcrmLL/BFmI1ydzQK+D3fFSqT7+tD5B69H4ozTIbu6X/4ZPvyhJNOFPUTncijs2IHM5tuRuf3XKP3uCWNydqSDvQc0Ziq3zFCOIBkjQlbxX52ybdtXQ//WjL6gzjStAgAqlsCO0067IO3ITY6gI6Z8ZZOFFgrBOpyLRehcDuQ4cF/xCsTXrEHqrFcivmYNYscdB2fJkpnXF2gNf2QEpSefRHHXLuT/+yEUHtmB0rPPgEsliGQSlEhUfAGzgJn9pJQOgGxO+392yrbtP2xGs7+aplYAQCU68PBppx3X4Yj/k5bOOWOe5zORpBa4fksNCDYAYWZwqQQuFExMPhaD7O6Gs3QZnGVL4SxdBtGRhrN02X4n6amREehMBv6+Yfh7h+HvfQlqfBy6WDQnEMXjphHNeI1fDQMMZtXjOE5e68cz8N9z+n8/8mCzCz/QIgIUVg/es2JFctnSxV9LCXlpViv4mu2BowuNwIwPj5uE75vjvX0fUMq8Nl2AyUwVJKTZNsx1AccxAg9UDuqYA5pZCyLqcSRllfrJBNOfv3LbtuFmNvuraQkFAFQyBgHgt2eefmkMdHNMUOeUr3xYa2DhUlXuW954c7pDMNwezMzVlXTeeRDO+ikpHc3seeBPnbTt4c8DQDNk+M2UlhKasHaAhobUb047bXWHpFtSQq7LaA1Pa1tDYKkLzKwEkeySEjmtthUVX7Fm+/Z72WTWciPKeudKS4XVCGAaGlKb+/qcM7Zv3338tocvzCj9lxIY7XEcyQCzPXnIEhFs9qzQXY4jXaJcRvmDuzO516zZvv3ezX19DgF139BjvrSUBVBNtbZ9dO3alcJxPkOES1wiZJSJ2xCsRWCZP2y29uGUkJIAeMw/LQCfXPub3+ww/x9138qrVrSsAgipdrb89oy15zosBxxBFwkAGa3ZnFZBwvoILLOEg+PsKSWlkABKzPcy6c+csO2R/wDKY6/pkntmQ1sIBQM01N8vQsfLnjNPvUho8XFBuCguBDJKQTH7gSJoqWWPpb4woMGsicjpkBKaGR7zvcS48fiHH/5R8B4BBDtbtThtoQBCpj+Y355++nkOcLkGv6NDylRRM/JaM8AKIGHrCywAwAxNYM0gkRAkEkIgq5RHRD8XjG8e9/DDvwSMsPzffsj1Q2gbP1NbKYCQTYDcAfBgRREc6wLv0eD3SNDpSSFQYI2COaPUZxNBIljrYEFgQngw+b0EmSBBCUEoMcPTvIeAH7EQ3z8xWOMDlVyUBl52JLSlAgjZBMj+/n6ED44B+t1pp51HwNt9wkUATu8QAhpAUWuUTIGICo60pCCwTDD/aeu+akPCSD+DuRyaYyIZI6I4ESQR8lpDMe8h4NeSxE9yvr/51J07S+aDEEP9oHaa8aezIAb1ACDW9fWJ6swsBujJM844w9N6HYHP18CrAKxKSwkBQAHwmeEzQ1W2J9JBNknLOn3aGyJQpWhYEsEJmikvAnJaQzO/AMY2R+BOwbQlq9RDodADxrm37o47dDus8Q/HglAAVdAmQCzt66PpaZq8alXid52dJ4Ho1BLzGUR8ImscD+AIJupxiOLBnm5wwhRSS9NAMAqbAQTl4x6IxgXwEoAnGHjcJfoNgO1eqbTnlN27p6o/v7mvz1m3bBmjAYdzNJKFpgCqIQZoS1+fGL7jDl6PA5t5w6tXd04JsYhcd5FPqqfgoyMmxGKlFGu5oPuvaRAKLKUkn3k8LvSkr2gqIeU+5bqjx2/dOnGgzzAgwmff34IJPLXCDuAADvab2dLXJwBgeNkybpV8bsuh2QTIpX19BADr7rgjSBJbmAI/HasADgMDtME0hOe2b9m71/ZbE7Ju2TIGgKGhIfQHZT9W0C0Wi8VisVgsFovFYrFYLBaLxWKxWCwWi8VisVgsFovFYrFYLBaLxWKxWCwWi8VisVgsFovFYrFYLBaLxWKxWCwWSxPz/wHqpQr1HGaRxgAAAABJRU5ErkJggmljMDkAAGxViVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AABsFElEQVR4nO3dd5wdV3k//s9zzty2fVfFNi4YbEu2bMudYopM6O0bIKxCSCBAiA0OJjSDwTirBYxNDQmEYMovlFCipX7hG0IotsCY4iLZsoV7w7jIkrbeOjPn+f0xM3fvriVbZXfvnXs/b16D5N3V7t17587zzHOecw5ARERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERELU2a/QCofahqdD6tX28wPAxgLPrETWt4nhHtq+OP1+g9FL+Xhjc6AIAIBNCmPjZqC7ww015TQKAaBfg1cVA//njFTTcpRkeVFyWipaEjIwbbtskj3ocbNqiI8H1Ie4UJAO2WAoLh4dlADzgZHXWP+m8uuWQQlYr6xh2TyXs9qASAB/gBTrKeGQjDUCWpEhDRI4iIioioqO+rXu0548MY8RAEsOFNGOh3uPy6KRkbC/f0PXRkxAAwAIBt2xQbNzomBbQ7vBgTgLh8P7bexOX63QZ7/cQnCqhUenxXOs6IHG097/CgFjxePHMkAtetBqvgoJ41g8h4s/UAawERsEBAtDfi90rQEONVEdRqk2KsUw0fFLEPwrkJsfaGMPAnMvnc9aiZ28czM1NDF3xkcv53rCcFcaXgsZJ56gxMADrUvDv8RwR8HRnpQs4cD3HHO5GjtBY8CcBxEOmzGa8f1gJGAKeAuii2BwEAIHBOAW2M9rzYEO0jgYhitmLmGRvd1VsDGBtdvY2N3n+hQ1irlRVaNGJvgmCzqt5jBZtRM1tldHRX4/dWQDAyYnH88YrhYVYIOhQTgA4S3eWPGQCQ9evnlBB1ZGQIXnCyc3imipwJ4Fhr7eHIZKJAHzogDACnCFzoVKGQ5OokyXlkoAqICE8sooWl0ZsLUXItqtF/alwvMJ4YI0YAz4sSg7iKEPi1XSJ2qwCbjWd/CXHXygWj98753rPDBo851Eftg9fpNqeqgg0bLOa9sXVkpMvPmZOMC58H556hwCleJjMEzwOcA4IAfhAoAAdBFO4FAhWJmpCJqJVoPUcQ11CBMxljDTJxUuAcglq1JJAbRcxvjAt/MeUFv+5/36U7G75PVB1gMtD2eCFvQwoINm58xJ2+fviCZQi8pzlrXq6KP7MiRyCXje7ufR++Cx0AlwR7gZim/RJEtCBUVetJgUKsMdZkPMB6QBgi8IOdIvi1hXwPHn7RWB2oVwY2bAg5TNB+mAC0ER0ZMTj+eGkM+tMXv/egguReBNU/V+ee7mUyy2ANUPOjO3xBCIhA1bByT9T+FNCoe0cVSYUgmwEgCKvVEkS2wMj3Aq39KH/hJTfX/93GjZYNhO2FF/yUa2jmq78x9bzzcsFBAy/wxPx5qPoim8sdBBfd5ddc6CRqyjO8wyciVcSdvEBUHcgAnkVQrlTFmP+xIj+Y0ep/9154yUPx1wvGNhqsX++49ke6MQFIqaTMP6fEf/HIsQ7uVRD5S2O9YyEC1GrwwzAEBBAY4WtORHvQWB0wYjybzQLGIKxWtwvwg1Ddl7MXXXxV/es3brScRZBeDAYpk3TyJ4Ffh4ctTj7hz0IN36Lqnu/l8zn4Pmp+zYmIg8KKiNTzdL7iRLQnDdeJpDKgCmQ9a5HNAr6PUPEbOPdFm6uOyXs+Ng0AunHY4qY1HB5IGYaDlEi6+WV0NACAHSPn9Q3Y/lfCmLdZIyfCWoSVKkLVUNjAR0QLSKNJh04Ak8nlBCJwQXAfVL9UCcwXu0dH7wPYJ5A2TABa3PzAryMjK53nzlWRv7OedxicQ61WUwEcRFjiJ6JFpUAIVWQ8zyKTgfNrUw74jvODT+ZGL7kRYCKQFgwWLWr+GP/0xe89qMt5b4bIm0w2exBqNfhBEHK6HhE1Q1IVyBhjJZ9DWKvVFPj63ERg2GKYexG0KiYALUg3DltZH232Mf3e9x7U1dUQ+KtV+C4M6mP7RERNpFEu4KyItYX87hOBkREPo6MhZw20FgaQFhIvugEZHXU6MpINs3qOAO83mexKBn4iamVzEoF8HmHg10T1MuObD8no6HYgalp+tJ0MaWkxkLSA+eX+4OL3v0rEXGisdwJqPmouCKASB3628xNRq2m8LqmqwhkR6+XzCP3adig+bYObPyqjY7XGG53mPV4CGEWarrHcXx157wnWsx+1nvdCOEWtVgujufu84yeidIn3JnAZa63ksghr/o0qeHfm/R/8MQBcPjLiPStubqbmYGBpksbu/l3veU9/f2/uXU7duz0vk62VKw4GYHMfEaVd0iyYy2YsxCBw4bdC3x/Jj156K6sBzcUEoAka7/r90fc9X4z9V5vLrfJLJahqKCK22Y+RiGghKdTBAdmugnFBMKkaXuRddPGngWja4PwtymnxMQFYQsk2mzI6GhTPP/9x2d7ch6wxrxcAtZofwIjlPH4iamdONcwYY00uBxcEPw/D2oXZkUt/x2rA0mOwWSI6MmKSE9sffd/zjbH/n8lmH1crlxzAcj8RdY76sEA+Z8MwDBCG53sjH/4UEE0ZFPYGLAkmAEsgOaH1/PN7XX/+YhFznjiHmh8EYsRr9uMjImqGZMgzU8gjrAU/KRZn3tp/6Sdv5boBS4MJwCKKts0cNrJ+LKyOnH+qzRS+aLPZU2qlolOFGM7nJ6IOpwqFapjtKnihH+wMA//c3OglGwWAa6ic0sJjAFokjSX/6gfe90Zr7CetmN5qpRoY3vUTEc3hVMOMtdZkPAS14FPX3//wu0///Od9NgguHiYAiyAp+e8477y+wZUDnzCe98agWoVzjh3+RER74FTViLhMV8GG1dqvg1r19fkPfew29gUsDiYACyzJVivvP/8YL5v7T5vLPalWLIYADJfwJSJ6bOo0yBbyXhj4u3zff3Xhgx/9iY6MGIyOKvsCFg4D0gJK5veXL3r38zOZzDes9YZqlSob/YiI9pGqhp611ngWYRC83Rv58KdUIdgwIuwLWBhMABaAqgrGxoysXx/WNlx4TibrfS70AwRhyJI/EdF+SoYEst1d1i+Xv5D5ReZc2TQacFOhhcEE4ADNafYbfd/nsrncObVyNVR1IsK5/UREByLeUyDMdRW8sFb79UwpfOnApZeOsznwwDEBOABJ8Nfzz+8N+vKf8rKZN1SL5RBQjvcTES0gdRrkugte4PtXh9XqX+c/9LHbmAQcGN6h7qeNw8NWRkfdxAUXDAa92Z972ewbqjOlQASWwZ+IaGGJEa9SLIeesWd4udxvixddcIasXx/qyAh7rPYTA9V+SLLOiQsuGOzusj/xMtkzquWyLyKZZj82IqJ25lTDXCZjHTBerfnP7/7gpVfrZWdn5JzP+81+bGnDCsA+qgf/t799qB78S+WAwZ+IaPEZEVvz/dAAg9ls5ifF9737SXLO531WAvYdE4B9kAT/4kUXnNGzrOe3nvXOqJTLIaf5EREtHRGx1VrNiepgviv/s/L73/MGGR0NmATsGw4B7KV68H/f+afnCvn/tcYMVqrV0HCaHxFRU6hTZz1rvGwGlXLp7MIHPvoFrhq491gB2As6MmKSMf9sNrPRGjNYrVQDBn8iouYRIyYMQudXay7jZS+bvOBdT2UlYO+xAvAYkql+ExdcMNidtz/xPO+MSqUaGsPgT0TUClTVWc9CRCaqfvCC7g9eejUrAY+NCcCjmBv8zU+8bPaMSrkcGjE2Wo6aTx8RUXNF12J1zmWzGeOA8Wqp/PzuSz9xNdcJeHSMYHugqoINGwRAPhD/Ci+bPaNSKgXGGC/ZiYJPHhFR8yW3Yy5OAhQyXq7563o/9JGtTAL2jD0Au6GAYMMGK6OjroraZ7187oxKuexLQ/CPv44HDx48eDT5QPynGGOqtSC0xgzmPPv1iQsuGIwXC2Ks2w3exO5GfUvfi97zuVx31zmVmRJ39CMiSgnnNCwU8rbm167OavYsbNhQBgAR0cf6t52EWdE8OjLiyfr1YfnCd5+T6yqcUy0y+BMRpYkxYsvlcpDN58+ouspnRUSxYQMbt+dhBaBB0jVavvCC5+QL2Z/WarXAKawIJKovNfsREhHRo0ru8QVQVT/f05OpTE2NFi7+2AYuGTwXQ1os6fgvX3jhE7wsrlbVwTAIwS19iYjSSQEYEd/LZDKVUmW4+5KPfpvTA2cxAQCijv/16w2OOCJf685ekc1kTi9XKs4Yw+BPRJRiTlUznlWImXS+vy73oY9sTW74mv3Ymo1j2wCwYYOVsbGg9P7zP10o5E6vzBQDY4w3W0siIqI0MgIJgsDlc7lB38rX9Z3vfCqO31ZRVen0psCOv8O9vD7u/+7XF7q6Xl8plgIxhokREVGbEBFbqVSCTC5/YrlgPi3rx0I2BXb4EEBSBpp+77vW5vO5q9S5fBiGRkQ6+nkhImpLqkGuq+BViuU3FC7+6H90+iJBHRvoknH/HUce2dXfZX/ted6JlUqV4/5ERG1KVdVa68SYiqu4M3OXXHJDJ/cDdG6pOxn3v/Ddl2Zy+RMrxVJgxHgc9iciak8CkTAIkc953RUbfOWas89+ErZtc53aD9CRCYAOD1sZHQ2m3/vu5+az2XOrpXIAEa/jXn0iog4jIrZcrQaFrq6Tj1+BC+Xzn9+gGzZ4ADpuamDHDQEka0IXUVyZUW+LEbPSDwLlfH8ios4Qr+sWZjOeqdXC5xUuvvRnOjxsZWyso/oBOrECYGR0NCi/7/xLs925g8qlUiAinPJHRNQhBIBTFQACcf+mZ599AsbHO24ooKPuepPSf/m95z87k8u8plIuh1HwJyKiTmJETKVWC/P5/KrSst4LZWwsxNhYR8XEjhkCUFXBhg0CoKemleustUfVar5j6Z+IqDMpoFbEGWtdteY/pefDH7uuk2YFdE7wGxszMjrqSn7xPdlc/qha1Q9ExLDyT0TUgRQQQELn4BmT8UQ+pSMjBtu2dcyNcUf8ojoyYjA6qlPvP39Vwdgb1KkNVY10yO9PRER75lTDrq6CLZcrr+u6+KNf6ZQFgjqjArBtmwigGYd/zXheNnQODP5ERARElQC/VlMrcunEBRcM4qabVKMmwbbW9gmAbtxoZWwsLF14/nAhn39epVoLRaTj14AmIqKIiBg/CF02nzs4a8IPyuiow/r1bR8f2zrDUUAwMiIATMUvb8tmvaOrtZqKcLlfIiJKKBRQA1FjjHMarsl/6GO3tXtDYHtPgRseNjI6GpYvfNeb84X8MeVyJb77Z+cfERHNEkCcOpfLZL1KNbwYwPp2bwhs21+uPn7z3vcO1bzwNhEz4IchDHf6IyKiPQvzuaytVINnFS7+yBXtvEJg+1YAxsaMrF8fFt/7zvO6cl2DpVI5EBFPefNPRER7oNH/qXPhCIArsGZN20aNtrwbbrz7r9rwFhEzFIQhhHf/RET0GFTV5bNZUwvCtq4CtGcz3NiYEREtiX9eLl9Y5oehY/AnIqK9IqJiBHEVAO1aBWi7oKiqAhHgggt4909ERPulE6oA7VcBGBszAmhJwvNy+Tzv/omIaN8J6lUAHRkx7VgFaKvAmNz9P/jOd3YN5HCHtd5KPwh4909ERPtO1eUyGRMG4RnZD3/smnarArRXBSC+++/N4JX5XP4gP+DdPxER7R8HqPEsfOf+odmPZTG0VXBUVbliwwb7pMrM1nwue2ylVuN2v0REtF8UUCOAgfjO2eMKl156ZzutDtg2wVGHh62I6Om10rpcNrOawZ+IiA5EtF2wumwul3UI/hYAcPzxbXPj3HYB0sC9w3pWVKTtGjaIiGhpCWB834eBnqMjIz1Yv961y06BbZEA6MiIkbGxcOLCdx3lGfusSrWqpk1+NyIiah4RET8Iwnw+f1A5KL1UAMWGDW2xo2y7BEkDABmnr8nmsgXnNESb9TcQEVGTiECh0ND9ffyRtugBSH2QVECgCrzjHfly3mzNet4Tq76vHP8nIqKFIoBaY0IV/+Tchz51Uzs0A6Y/SA4PG4igWjB/Vshmj6rUGPyJiGhhOdUwk8t5gTOvjz+U+jiT+l8Aw8MQQEOHV8IYiLRHaYaIiFqKCX0fcPISHVnnYXQ09QsCpToBUFWR9evDqfeet8IaebFfqwFAWzRnEBFR6xARU/N9l8t4x1QqpzxTANXh4VTHm1QnAEknZkYyL87lcitqYRhy5T8iIloMCjib8UxgzOsAAMPDzX1AByjdCQDgFBCnMgx1ythPRESLyAa1Gjw1z9H3nN0v69eHaV4TwGv2A9hfqioi4iYuePNgDniq7wcCVQMmAUREtAhERGpB6Lqy2UMqYe8pAK7A+vUGQCr7AdJbAYiedOSRf2o2kxngtr9ERLQEHKyFC/FCAMCaNamNO6mtAGB4GBgbQ+jMX+aMFShCpDmhISKi1qcwzg8Axcv0vPP+CaOjNYgAmr7V51MZMJPu/z+NnN0los8JfB9g9z8RES0yETGVINCcZ4+u9drjBVB95StTGX9SmQAk5f/BauGkbCZzEMv/RES0ZFRDm8mYMLTPBpDaYYB0DgHET7aq90KbyVjn+wFX/yMioqWgIqLOIQReDODjSOneAGkNmg6AqMjTNAwB3v0TEdFSUTV+EMACJ0yMvH1QRkdTuUVw6ioA9el/I28fkipO9oMAnP5HRERLRUTED0PXnc0OSa16EoDL0zgdMHUJQPIk52o4Ke95g8VazYmIQfoaMImIKK0UDtZ6rmbWAbg8jX0A6UsA4ifZqZwFzwpqyul/RES0tASiYQhVfaaOjBiksA8gjYHTAYBzeAo4/k9ERM2gMEEQQKAn7sSunqgPAKmKR6lKAFQhMjrqHjr33B6BHheEIZCyJ5yIiNJPBOI7pznPG+irZo8BAGwYSVU8SlUCkDy5A735Y/LWO7QahiqSst+BiIjagqqGNpv1fLinxR9KVTxK1YNF/Hh94BSb8QxUUzfmQkREbUQVzslpAIDjj09VO3raEgAAgEJXw5jor0RERM0gIghDiOrRIyMjBjfdlKqYlLZZANEdv8paBCEAEaYARETUFArjhyFE5OjzsKtHRj89pQpJS2RKTQIQPamj7qGRc3ukrMf7YQCoClsAiYioGUQgtTDUvLVDKNlVAK6JetVGmQAshq4Z1yVW+kNVKBj+iYioeVRVrbWehv4KAMC2bamJS+npAVg/bADASu6oLs/2hGHohPf/RETUXA7WwqlZCyBVOwOmJwGIObHHwVqjbAAkIqKmE4FzAHQNAGDbttTEpvQkAMkWwNAjYDkDgIiIWoAAUAWAIwAAa9akJjalJwGoZ1V6BEIHcPs/IiJqNqcSOAcDWalvf3sBGzZoWpYETk8TYJJVqXkiXJILNPHxEBERQSQMHFRx2ESfyw2KlJkALAJdt86bcX7BIQNGfyIiagVqoDZ0Yrc/2AtgotmPZ2+lYghAEW0CNLlyZR92PLy6NjUJiKTisRMRUfsSa8QvlzU/Nd4bTupqAPVZa60uVRUAB4TiNNSJcWi1AukfiFoBlNWAjseWkPbB9zOlhQh0Zho6OQn1PKiHWrMf0r5IRwIwMiIYHVWTlVV5z/ZVw1BRLIrzfZiBQSCbRTQNgzqCyNyA7xwQhs17PLSwRABrZ/9blUkBtRYRwDnoxDi0VAKMUfE8aDU4FcAvsWZ7Ku5I0pEAxCsrWYP+rBivooETYwS+D7fjYUj/AKS7m0lAuzMmav0IfKhfA5wC1kAyWaC7u9mPjhZKpQItl5A0+4rnRUl+Uu1jMkDNZAy0WoVOjAO+n1yXNIr4sqzJj26fpCMBSAjCULXh/S+AAjo+DqlUIf390Z0DE4H2IRLtrBGG0FIRMAKzYiW8Ix4Pc9jhMIcdBunqhlm+HFwZOu0UgECnp6ATE3APPYTwT3+Eu/ceuAcegNZqkFwOkslAmQjQUourjjo5BZ2Zjs4/iW5KVBGdvg6pKkWmKgFQ7OHJFYGWilC/FlUD8nkmAe3AWCCowVVrkL4+ZE49Hd7ak2CPPiZ6jaktSaEArDwIdtVqZADAOYT33oNg6/XwN2+Ge3g7YC0kl2NFgJaGMYDvR2P9lXL037vpO9pjjGpR6UgA4vEUDXGq8QwAeeQ73hggCKA7dwC9vZCe3rhk6MA7w5SJ31huZhpm2TJkn/cMZJ/8VMjAwOzXNCZ4bABsP41B3RjYI58Ae+QTkH3eCxBcfz1qV/wc7t57okTQeoALwfc5LayoIlW/wZycjM4zs5sGf4GoOkD1FADAtpWpyErTkQDU6TIRxR5T/vj9r1OTQLUCGRgEMhlWA9LEGKjvAy5E9hnPRO5FL4H09UefS15HI7t/E1L7mJ/UxXf6kssj86QnI3Pa6aj94qeo/uJnQKkIKXSxEZQWljFxo98EtDgTXXdEsMc1aFQB0agHICXLAacqAVCRYK++0BhorQZ9+GFIX1/UIAiwVNjqrI2av3p6UVj/V/BOipJpOBe98Rj0O1fjzA/nAGuRfe4L4K05AeVv/ifCu+6E6elhsk8LwxhopQKdnJht9NsrexmjWkSqrqiiuvc1vjhT04lx6Piu6O6AAaR1WQtXnIE58onofvu7o+DvXJS07WG8jTpU8j4OQ5hDD0P3W9+O7DPWwc1MQ/kepwORNPpNTUbDyUGwj3FjH2JUC0hVBWCfxMM3MAZaKkHjRjLp6p7bOJSql6sNKaDWQqdnYI8+Gl1vekvUBBaGc+eCE82XzPjJ5pB/1V8D1qL2i58BfX0Q52avAUSPJjlPxEBrVWByMvozCfxJ4bgNz6X0JQDJdIu9/VogmqoRhtBdu4BKFdLXB3hefIe5SI+T9ooaCy0WYY9qCP5xiZfoMRlTT+jzw68CANR+8XOgtw+iId/f9Nji9SV0ehI6MzNnet8cj3UupfBcS18CsL+koZuzVt19NYCWlBoDrZRhj3g8ut7cEPxZxqV90dAbkB9+FRCGqP1yUzQbiI2B9GhMfNc/0XDX30HDjZ13pTVxNWB8V1QR2OcxHloIKgIEASSXQ+G1r2PwpwOTNAmqIv8Xw7BPeEI09MfziXbHxHf9k5PQHTuilUU78FxJYQVgX8YA9kCi/9PSDLRahvRypsBSUiCqxtSqKLzu72AOPoTBnw5cvD47MlkUXvM6FP/5Y9HaIMZA+L4mAIAARuIO/0kgCfzRSjMH+L0XIDYtsc6+4sbjhzoxDt25cx+ne9D+UKDemOmtPQmZ05/E4E8LJ567bQ4+BNnnvTDaqEVMyi7LtCiMATTewGfnDiDg9T5VFYBkhu+Cv5mNgVYrwI4qpKcX0tPDbYYXQXTnj2hxjVwO+Ze/ks8xLby4EpA761moXf07uAfuh+RyUOfasZGbHksypl8qwk1NLcqw7+xWAOmSrvTHYfaZXuhD4o2FpibhHn4YWqk8cttZOnBi4UolZM54CsyKlbPz/IkWSvKetR5yz3keNPDrn2K62WGSNfx37oTbNT67HsxixZGUZQC88iYapwzGJ4yOj7NJcIHUL7zOARkPuac9vZkPh9pdvBBYZu3JsCsOgtZqTOY7STK8Oznvhi7eQZYijGy7k0wZLBajk2dqavbjtP+MgauU4R11DOxhh/PunxaPCOAUks0ic9rp0RBfsspbkx8aLaL6dO8Sr917gVffR7OnLJIn0z6Zc8ENA2TWnsQeC1oymZNOAbJZKPcJaGMyp9zPKd57J1VNgHObAJaQMYBfizpHu7qirYazGcClb9pHM2kYQLq6kDn+hGY/FOoE8cXfHnoY7CGHwt1/H5DLRUk92nJl185kDBCE0OmZhpX8kld3qa7PjY0A6cH0aK/ovGGB7dEcUuUGQ4+l/nYQAH4NsvIgmKHl0cf43NFii5eVtkc+Ac73wbDfRkw8pJNck1nu32cpqwC0gDho6dQUtFSKFhHqKsRrR7PEuGcCDUJ4hzwuWudfXfScES2qKAW1hx0e/ZfOpgCsAqSQYjbwl6vA9BS0WuV24fspfQlAq1RZJC477doFFHPRDmS5XPQ5jm0DmPsyKQQaumjqHzD3Sky0aKKTzK48iEl66kWr+KFWg87MRIs8AbM3Es2+7LZKbNoH6UsAWkkyLFCrATt2APl8tNNgNstNhhqoKiBRx3+9/M/oT0shPs2kvx8oFKJzEYCwTJwuyR4uE9PQYpGrhy4QJgALIZleVKlAq1VIVwHS3RMnAtxyGEDUeGUM7IoVzX4k1FGi96YZGIDkC0BxGrC87KWGMdF+DjPT0GJptrOfwX9B8J2wkESiKtBMEVIqR0sKd3dDPA9wCm3IBNr9/kPn/RnN31BoEDTpEVFHcy66+49PSIk7xR3YCd0q6muxAdHy7M4BxWLUbxUHfmHgX1CpTABa94Y6bisyJgp2U1NAqQjp6o52G4wTAcxJBdpT/ffTeb8rS6/UJI0BxmFuMyC1iDjwazGe0lfz5zT46dw0oWWk9aqewgSg1TstGh6bEcCF0KlJaKkI6e6GdMWJQIf0CMxpBGz/X5daGk/AlhXv4jgb+OOlm82e0rRWey1bPS7tXroSgCatA3Rg4pM4DKETk9HwQHdcEbAdkAhowx9t/GtSCujs2014LraGJPDPxIHfr6G+ql/arvVpe7xIWwKQVgrMSQQmJ6HF3Q8NtKP2/K0obTT5/3kJN9cDaII93fG3ypS+DsEEYKklewl04NBAe/5WlFpzloylJbHHUj+b+5qBCUDTyGyPQFIRaJNEYLePOqW/C7WR9i2ytT4G/pbEBKDp9jA00FUAMilfUCitj5s6Akv/iyypdgYBtFSCFhn4Ww0TgFYxf2hgZhrS1dWwoFCKEwE0jL8SNVFjEYDBf5HMCfzFaOW+IGDgb0EpSwBSOQ1g3xkBoNHqV6UiJJePFhTK5wHI7OqCLX8Fa/WpO9RZ0rlla8tLrkUi0V/8WlTqL1eAMIga+/Y4na9dJOdVuvaaSEcCcEXD3+cvMdfOJJoKo6USUC4DuTzQ1QUpFOpjai2N8Z9aSUP8b/ncOU2MiRb8qlSAUglaLs+u1d9JXf0p/B3TkQB0umQVrGoFqJSh2Ww0PFDoaumGwUfE/9Z8mNQBGlYBpoVQH7J0UYm/VIquT6pcqz9FUpUAJPe7HftGTt50vg+dmABmZiD5PEx3D5DJ1N+QRESLYv74fqkM9WuzH+/QaZVpHVxKVQJAscbse2YGYakEyebiqkChXpLj7TYRLYikzF+tRB39lQoQhmzsSzkmAGnXMDyglTIkk4UUCtE0Qi8bfY2yKkBE+2j+NL5SEVqrsczfRpgAtIv4zaqBD52qAcVpSC4fVQVyeVYFiOixJUFfFVqrRUG/UpmdxtfBZf52lL4EQNM40rIEGic3iwGcxll7CZLJRFWBQlfUKwA8MhlYlPf07qYB8LWjZknrSO0iaHwKkmsGAIQBtBKX+Wu1qHoojXf7mpIpyEstnedWuhKADlkG4IA0brsXZ+rq+9GbeTquChQK0ZoC1s4mAm4R1kXnNEBqJem8Ri+exl6iShlaLked/HPu9pNpfPOeND6Hj5S+ZQBSlgDQ/mko22mlBK2UAOtB8vEQQSY7NxkgovbUUOKH788Gft/n2H4HYgLQaeqlvjDag7tYnG0czOdnpxMyGSBqH2IAaPS+r1ai6Xu1ajRtmGP7HYsJQKdqrAr4tehiMG2iZKCra3aIgMkAUTqJicbqwxBaLUGLpeh9nkzf4xS+jscEgOYmA7VqNA5obbS2QCEfzSJgMkDU+kxDha8azdevz9mHzmvoo07HBIDmapwGVC5Dy6U9JwOOHVVETdd4p18uQcuVKIkPwyhZryf4LPHTXOlLABhzFlnDHJ/kouFcdGEpJclA1DOAXA5ivejLd1cZ0Hnfk68bNVsqrx/zHnDjeH0YQmvRImBaqUa77yni3fcavq4+O4hJwKJJ4bmVsgQgmgeoaXuWU2c3z69IHOijZACNlYFcFsjlIXEDocbJQPI6Re8LvmrUXNpwJqbuXGzs3k8a+apVaLX6yDv9eozf3W+Zut88FbThf2mSsgSAWoKZnRuslVKUEBgTVQZyOWg2B8lm53wd+waI9tH8KXtxwK838jV+DTv4aT8wAaADk4w/AtHFqVKBikTTCTMZSC4PzWSibYvZfES0Z/WAD8CFcUNuFahWo3n6zs2u2sf3Ei0AJgC0cBrvRJI7luIM1FhoNgt1yo2JiBKN75fkLt+vRUl0zY/H8xtK+wz6tMCYANDiaLxgqUKrVbhiEfD95j4uomaR+P/qY/kBtOZHJf1abd5dPkv7tPiYANDiaWw65h0MtbPdtbjUG/Iamvd8Pwr2tRrUrwFhssEJ7/Jp6aUrAeBmQOmj8/7O146aZcE3A5q3pd4j7vDnBfzAb+jYx+7n5/P9kU4p3WgqXQkAgFQ+yx2L2wFSK1ngq3Rjid45IAjjnTer0Xh+EMyboofdlPX5nmgP6YxLKUwAiIiW2PyGPedm7+6D+M8wBFwYV/SF4/jU8pgAEBE12k2wRxBAAx9aq83e3TsXHY3/pmFaLFGrYwJARJ1p/h1645194Ed/+gE0jEv5jcE++ZNNe5RiTACIqDOYeAEdEahzUVAPA6gfQIIgHrMPos/tJtgLgz21mVQlAA5cVTYNkpcneZ3q7TGaxjYZag8KnZqGm5qEqkLiEr7EF5Sogb+xk9/M/+c8d2mPNKVrnKUqASAi2i+qcFNT0KkpaDYbBX426VGHS1kCwIUA0oXTAKmFNAwB8DpCCys5n9JVBuCgFhF1iJSu1kK0SJgAEBERdSAmAERERB2ICQAREVEHSlcTIHsA04U9gNRKFGwDoMWRzh5AVgCIiIg6ERMAIiKiDpSuIQAArN+lCccAqJVwDIAWSzrPq9QlAOl7ijuP7uZPvm7UbAz/tFhS2gLAIQAiIqJOlLoKANP3FOEIALUSlgBosaT0vGIFgIiIqAMxASAiIupATACIiIg6UMp6ALgUYLo0vk4Cvm7UXPPnpRAtlHSeU6wAEBERdSAmAERERB0oXUMAHAFIl91NA+RrR80wfwogz0NaSCk9r1gBICIi6kBMAIiIiDpQqoYAOAKQDtwLgFoVz0VaDGk9r1KVAETS+DR3Kp33d7521ExsAqDFks7zikMAREREHSh9FYD0JVmdi5sBUatJ540atbqUnlOsABAREXUgJgBEREQdiAkAERFRB2ICQERE1IGYABAREXWglM0C4FJA6bK7dQCImoXrANBiSc4p1+wHsk/SlQAw/qcLpwFSK2H8p8WSzvifsgQAfO+mwe6WAm78k6gZ5i9NTbRQ0ppXsgeAiIioAzEBICIi6kBMAIiIiDpQChOAtI2yEBERtZ7UNQGms9WiU3EaILUSTgOgxZLO8yp9CUD6nuPOxWmA1EoY/2mxpPS8SuEQABERER0oJgBEREQdiAkAERFRB2ICQERE1IGYABAREXWgVM0CcM7BqUI1Za2WHaa+5nr8OikAleh14ytHzRKdfwrwGkILTFN6TrECQERE1IGYABAREXUgJgBEREQdiAkAERFRB2ICQERE1IGYABAREXWgVE0DBABoNI2HUqDxdUpeN7521CyN5yDPQ1pIKT2vWAEgIiLqQEwAiIiIOhATACIiog7EBICIiOgApWv0P5K6JkBFOp/oTqK7+ZOvGzVb4znIc5EWUnJuuWY/kH2UrgTAgZEkTXTe3/m6UTMpmI3S4khpBsAhACIiog6UrgoASwApwxIAtRKWAGixpLMEwAoAERFRB2ICQERE1IGYABAREXWg9CUAHLojIiI6YClrAgT7d9KEPYDUStgDSIslpedV+ioAREREdMDSVwFIY5rVsVgCoFbCEgAtlnSeV6lKALgKQDpwKWBqRVwKmBZLWq9xHAIgIiLqQEwAiIiIOlCqhgA4BpAybAGgVsIWAFosKT2nWAEgIiLqQEwAiIiIOlC6hgA4BpAyHAOgVsIxAFos6TynWAEgIiLqQCmrAFDqGeac1AQi0dGqJP6/5DHOf6y6F3eXjf8m+fr5fxI1YAJAi0YgUGhUGBOB+j5qd9yO/Ilroapo4csxtQtVQATBn/4ENzEO8bItEAwlCvhJUqIKhCHgQqjvA85BnQOci79cIF5mD99Lo+/nQmgYzn69tdFfs9ko6fY8oP6OU8Cls2RNCyt9CQDP23RpXHrNKcKdO5v5aKhDhZOT0GoN4uWWPgFIAn1DsFffB3wf6hzEWkhPD6SrB5nDD4NksvAOOQT2oIOhYQDT14/ME59Yj/VzxAlO+NBDCO6/H5Lx4KZn4N9xOwAguOduaKUCNzlZTxDE8yCZTJQUGBN9j+Sg/ZPS1pL0JQCUTqoQz0PtzjsAANLK5VhqG0mlqXbH7dAggBgBwiX4wSKzw12+D63VoqBvLUx/PzKHHQ7v8Y9H5phjkDn6GNiDD4YZGITp7V3Qh6HFIlyxiOBP9yG4+274t9+G4O67ETxwP9z4OLRahXgekMtFSYFIVHlgMtARUpcApDDJ6jjze/+B6EKMTAa1e+6JLjq5XP3uhWixJIlm5bZbALHReYhFuoYkQV81CviVCiCAHRxCZvVqZNccj9yJa5E5ZhXs8uVAXKZ/hKT03xiEH+t9Mj9gxxUH6e6G7e6GXbkSuVNOnf0Rk5Pw77oTta1bUbtxK/w77kD48PYoScrlovenMUwG9lJKCwDpSwAopVQh2Sz8++5D9c47kT/uOCYAtLji88uVSqjedCMkP3f8/8CrUHFN3sTlfT+Am56GGAN76KHInXIaciedhNwpp8CuPOiR/zwJriJzmwAXslG2sQkw+VnGwPT3I3fyKcidfEr0UKanULvxRlQ3X4fqddfCv/NOaLUCKRQg2dzs493tOASlVQoTgDTmWZ1F0PgKNVxwrYVWyihd+UvkjzuOjYC0uFQBY1C5cSv8P/4RXm8foG7hzjlro4a9UhEahrCDQ+h+9rNReMY65E4+GdLVPffrw3BuP8BSzIh5tFkFyWEEprcP+aeeifxTzwTCELWb/4DKr69E+fJfILj/PqhTmK6uqG+AVYHdSGcNIIUJAKWWczD5PIq/vhKDr31d1KFMtEiSe9WZX/wcohrFwAO9PieBOwjgJichuRyya09G1/NfiPyTnwy7fMXs1yaB0pjo3+2p5N8M86dFNiYE1iJ7/AnIHn8Cev/mtahu2YzS//w3KtdcAzcxAenqit67qrPDFZRK6UoAuBBg+sxpCFCYfAHVW29BecsWdD35ydEFhGsD0EJThYggHB9H8Ve/hHR1AeHug9VeVQTiwK+1GrRcguntQ8/LXoGuF70Y2TXHz35dw9S9VJ3X8xOCOHmRri7kz3wa8mc+DcEf70X5Fz9H8Yf/F8ED90OyOUihwEQAmI1LKXsa0pUAUOpIPCBQzwNUIcZi4ttjUQJAtBicA6zF5I9+iHDnTmQGBvY/SFkbBf5SCd4hj0P337wWhWc/G97hR0SfTwKgMekK+o8m+T0apgd6hx+B3r99Pbr/z8tQ/vWVKH7/u6j94Q+QTCZKsDg0kDpMAGhxxWXXevXVOdjubpR+82uUrr0GXaedzioALaxkbvz4Lkx+eywau24I/skaPI/J2qjUPzEB75BD0P2a16L7/7wMZnAw+nzyPY1prfL+QmqsDMSJjhkcRPdLXoquF7wQ5Z/9FDNj/4XazTdD8vlo9kC4FPMsaSHwqkuLYk/X1+TjYgwe/vS/7H7KE9EB0Dih3PHFLyB48AGY7Gz3/+x5+SgZQHwn76amABH0/f3ZWPml/0Dv374+Cv5hODu230mJa9LHEC9mJJ6Hrhe8ECsu+yKGLhqBXbYMbnw8+tp2TYjaTAedvdRM9cutCMQ5mK4u1G6+GTsu+/dobJV3DbQANAwh1mLmyl9i6gffhzfQHwWrPdzyP+Kj1kLLZWhxBt0veCFWXvZF9L3+72AGGgK/tZ09fbWxobEhEVj5hS+h7+/PAQDo9PRs8yO1rJQNAbALMI2iFVC1YXqgAmEA29eLXV/9MvInnoiepz8zWoTES9kpSa0jXlbXf/BBPHjJxTAZL+o5aZyKuqd/Gy964ybHkT32OPSdcy7yT4p7VMKwvcv8B6IhETD9A+h7w9+h68+ejcnLPovKlb8CstkOGRZIZxcgKwC05ESi1kABYPJ5PPjhD6Fyyy0Qz2MlgPZPXPYPZ2Zw/z9dCJ2YiFa0a1hrov7n/LtSa6HFIuAc+s85Fysu+1IU/JOmtk6/498bDUMD3pFHYtklH8XQBy6GHRyCm5xgNaBFpS8BUB5pOST+U+f9d/3vTmEyWbjpGdz7tvNQufWWaLGgINjNC0+0B/Edejgzgz++420oX389TE8vEIRxyUnq5+CcPyVKQ934BLLHn4jln/4sel/7uqgKlTSmMmjtvcYeAedQeNafYcXnv4TuF7wYbnoGGoSAsbMTC9r1SJFUJQCNAwA80nMAiLYDjv+q8X8DgDoHUyjAzczgnn88D5VbbmYlgPaahiFgLVxxBn98xz+ivGUzvIGBaGw6+RrMbf5TILrr9wO4UhE9r3ktVvzbvyN77HGzpepOau5baMkaCGEIOzSEwYtGMPi+9wMZD644E29N3Pzr0qJd61KEZzktqvn3TzLv7waAuBBeoQCdmcE9b3srpq64vL6feccvMEK751x9zL9y2224+y3nonT9DcgMDkKCoD7ElJT7Z8v/iIL/9DRMdzeWfegSDJz7ltld8DjOv3AahgW6X/RirPz0vyO7+li4XbsAw2GVVsAEgJbMIy/GSS+ARHcL+Ty0VMZ9F7wbD37mX6OhgGR3tfpGJNTRnIO6sD4Fb/xHP8Tdbz4b1VtuQaa/DwiC2fNqN+cbrIWbnET+lFOx8nOfR2HdWbNr9POuf+ElwwJhiMzRR2PFv/4bev7ilXDTU9Hn+Zw3FVuuadHNX4J9bmlWIFAYETjnYDMZiOdh51e/guLvf4+V574FvU95Sv1irsmUrvlLl1L7ci6aRRIHfQFQvesuPPTZz2D6yl/B5nLwenog8bmRVJYS0UZ7UYB3O3ei91V/hcG3vaNepuZd/xKIN06SQgGD578H2ePWYPwjl0SzBLLZDpgl0JpSmACkdbSFgN1MCZToYu1UYQRwGsJAkOnvR/WO23DvO96K7qeciaFX/AV6n/xkSKZhA6E4MNS/MbWHZNGe5K48DvoAULpxK8Z/9ENM/eR/4MoleD29ECgkjO78DTSqKAkAaJQIGAsEPrTiY+g9F6DnL4ZRX76XwX/pxNU8qKL7JS+FPeQQjI+OIBzfBenpBcI0N/+msxMghQkApVE94Gt016/1gI+GJABRJSCZTlTogqqieNWVmL7yV8gfswq9Z56Jvmeehfwxx8Dk89xOuM1pGKJ6772Y/s1VmP7VL1G+4XporQavpxuZ3l5I6KJiEARG5xaGRAFYA1SrkHwOg+++AN3Pf2EU+Fnyb47kBQpD5E87Hcs+/knsGv0nBPfeC+npiWZu8E29ZNKVAHAdoFSbOxQgQFIJiEsB9UpA3Knt4gZAr6cXqoB/1114+OY/YMc3vo7M4w5F7vGPR37VKnhDy5A/6qi57d48R9Kj/ppFEdx/8EHU/nQfqvfei8qdd8K/749w09MwmQxsVxekUIA4FwV/zJb86/0kGv89XtXP9vVhxSc+hezq1dFdpk3XZa8txX0B2VWrsfKyL2LH+e9EdcsWmIEBII3TgFMal/hOoCWVJAEiiIq1cbl37nBA8veoUqDOwQGwhTxsVwHqHIL770ftnrsx9YufR9+sYWoRpVP9xi8M60vMmkwGJpuDHRyMzhXVaClpzFtQSma/Qz34V8qwfb1Y8cl/QXbVqni8n5e8lmEt4EKYnl4s/9gnseP8d6Q7CUghvhuoaQSAyrwkAAIT9wk4RBd5B8CqRslAsjVpPgfN5+tRQ13j93jsNICJwtLZu4quzJ2ql3TwJ6vGODfb3Cd4xJ3/I4J/OQn+/9oQ/Dne33JM1BxoenqYBDQBEwBaco1DAfWKQHwks/5FBEYViugir/HdnsYf03iN9/omgo/Y7e3RgzyHGVvD7OvQODgkc15Pafi6xrv+xql+9a81jXf+DP6pEO/DwCRg6TEBoKaYkwQkqwRq1LWdDKfJ/KDf8LXJ19fj/25mAfAuv/U91kJRaAj4ycfmB34grgwYA9SqsL0M/qmzmySgdsP1kN7+lM8OaG2pSwBS2mtBj0KTGkD9xi+pCSgUEgcBbXjho6leGn+83vunyWcjvMtPD5n3l6SgH6/+UP+7xGP92vD/AoWKAQIfJptl8E+reUnAw//4FtRuuTmaHRCGaOV3dBSXNGV7AaYuAXCY3UmC2stsyVcVDYFdHxHQk2mEjcMHs9/hkZcJni2tZ4+Xcm18nbX+xdLw+SgBxGxyIHFlqFrF4HsvjIM/u/1TKV6cyfT0YOiiEWz/hzfDlUqQTKa1lwVP4lLKLjZ8h1DTPSKAJ+XdhnFg3cPXNM4gi4YPUvYOpDlkTrSf/7m5f0b/IRBr4XbuwLL3XYTu5z4/Gjf2eGlLrWTp4COfgBWf+Gc8dM4bgdDMLiREC4bvEmoZj1gyOFn+d96e7vOTgehrk8+3bpmQ9t1ugz4akkRr4SYn0Pfqv0HPK/4iKhW3c/CfHwDbdQXMZJ2AY4/D0AUXYteHPgDp7mYCsMC4FBa1lMaGr/rHROpH49eYhr/PPyg99vQaNr6+wCPPg2RXv8LpZ2DwHe+KSsTttLpfvAaGhmG0GVaygmHj0fg1YdheATJOArpf+CL0/s1r4CYm2ju5awI+m9SS9rSg35zu70e52DEJaA/JTIBHfkKAWg12cBBDF/7T7LnQDnfEcVAXax8x2yGcmYk+h6gy5vX3P+Jr6htmtUMyFPcEDJzzZtRuugnV666F9PZy86AFwgSAWtqeEoHok/te8Nd2ukNKofnBar++R/SNoNUKhj5wMbxDDmmPjv/GwG8t1DkUt27F9ObNmL76agQTE6jcdRdcvOWxOof8kUfC6+tDz8kno/f009Gzdi1sd3f07cIw2kExzUlRQ7Vj6MKL8NAbXx81BXpee1U7moQJAKXC3C7weQnBPlzfFiIA0RJoeIHnTBFUAJ6FGx9H3+v/DoVnPKM9gn88fCHWwt+5Ew9/97vY8X//L4o33QRXqdS3Qja53Oy/EcH01VdDwxA7f/xjmEwGuSOOwLIXvQgrXvlKdB1zDIA4EUjz8xNXAbxDDsHQBRdix3veBXgZpK7lvgWlKwFwiKdaOLDI29nmvPq6279SyjzmO1oBGAOdnkHu5FMwcM6bouCf8lJ3EqDDmRk88MUv4qFvfhOVe++FKRRg8nnYrq74C/URFSyTycze4aui9sADuO9f/xUPfu1rWP7Sl+LQN78Z+SOPjCoLjVslpk3cD1B4xjPQ+1evxtRXvwIzONg6QwH1JavTdQVK9zuHaJ49NZTxaP3jMYlEewJkMxh69wVR4E9zUMNs8J/evBlb//zPcc+ll8IfH0dm+XKYQiEK+nGDn7qGdVDio7EBUJ2DZLPILF8OqOLBr30NN7z0pdg+NhZVEIB0l83jhYL633g2ssesgpbLqU/+mo3PHhGlgzFw09Po+7s3InP00am/+0/G+7d/61u4aXgY5bvuQmblSojnQYNg/xa+UY3+LYDMsmXQWg23/eM/4q5/+qcogYhnDqRSMguoUMDg+e/monALIL3vHiLqHMZAy2VkjzsOvX/11+me8hcHaTEGd42M4LZ3vAOSycB2dUF9f8GCmgYBYC0yQ0O4/4tfxLZXvxrB5GR9d8VUivsBcqecip7/8+dwU1Pp7/9oolS9gxxm9wLgwYNHZx3O9zHw1rdFHeBAakv/GoYQz8O9H/kI/vTZzyKzbBkgEs3jX/AfFg0hZJYvx8SmTbjlnHOin5Xmu+d4RcC+vz8bZuVKuFoN2rBJWLOPNElVAkBEHchauOlp9Lz4xcifdnqq7/6T4L/jBz/AfZ/5DLIHHbQkC/io7yOzciUmfvlL3D06Wp9mmErxMIYdHMLA35/DXoADkK5ZAEA60ywi2j8CIAhhCl3of8Pfp/euFaiP+ZduvRV3vve9MIXCkt6Jq+8jMzSEP112GbpPOgkrXv7y9E4RjBtCe17yUkx/99vwb78DUig0b2gjpSWAlKVNHATgwaOjDmPgpibR95rXwjv00PTe/cdB3tVquPOCCxDMzERz+pc4YKlz8Pr6cNdFF6Fy770QY9JZCWhYDnrwvLcBLkTTz1UokLINgVP4TiKijhAv9+s97nHofeX6KIimMfgjCrxiDHb9+MeY/M1v4A0M1Lv1l/aBKCSXg79zJ+7/939P96yAeFpg/vTTkT/zTLiZmdSeH83CZ4uIWpMxcMUZ9L5yGKavd3YznLSJExdXqeD+z30uKv03cQEb9X14AwN4+PvfR/mOO6IhgDRWARr0v+Z1XOVzPzABIKLWU7/7PxQ9L3tF+u/+RTD1299iZuvWaGW/Jgdc8TwEExN4+DvfqT/GVIqrALmTT2YVYD/wmSKi1mMMXKmI3r8YhunrS+/dP1B/3A/913+1zO+gYQjb3Y2dP/oRwpmZtthcp/81fzu74iHtFT5bRNR6ghCmtw9dz31equ/+oQoxBsHkJGauvRYmn2+Nu21VmFwOlXvuQfHGG6MPtcLj2h/xugDZE9ciu3o1tFQGpAnnSwrzp3S9qzgJgAeP9j+MhZuZRvcLXgjvcY8DVFvmznlfJUG1tG0batu3w2SzaJk7bWPgfB/T11wT/XerPK79EU+x7HvVX0erKUKac+6mTLoSACJqf85Bsjn0/PnLmv1IDlwcVGduvBGuWm2tSkZcnZi+/vrov1vpse2ruApQWLcOmSOOAGqV1CaNSyl9CwGlNdUiosdmDFyxiPyppyF7zKr0zvtPxEHI37Gj9QKSKsRaBBMT9X0DUksECENIPo+u5zwHE1/8POxgDgiXalgjnWWA1CUA6XuKiWiviUDDAN0vfnF945dUi4N+8Q9/iKbbtVCZXVUh2Syqd9+NsFiE19+f6uGW5HF3v/BFmPqv/1rSqZbpDP8cAiCiViEC9X3YoeUonPm06GNpvvtv0NLd6cakN+g3iqcEZo58AnJr1sBxj4DHxGeHiFqCGAMtFdG1bh3s4NDs/vVEeyuusHS/+MVAGPD8eQypGwKAIpoNwNeVqK2oKkQMup79HAB8i9N+iO/4C2c+DXbZCrhSaWmGXlI6BsAKABE1nwi0WoN32BHInbi2/jGifRLvEmgHh5A/5dRoq2CeR3vEBICImk6MQMtl5M84A6arK2rg4oWb9oPGd/uFZz4TcCH3CHgUKRsCaFwJiIjaiijyp57a7Eexd1SjHoWka34PQaa+ul4Ldf/vlnNzf58Ggjioxp+TFm8aTBoucyeeCNPXBxcGSzCclM64lLIEgIjajgicH8AOLUf+9NOjD7Vi93YS9OMgKHsxbz75PVptCuAcIjDd3Y/6nD8igMbPRUsmA/EWx5lDD0N21WpUrt8M6epu+gZMrYgJABE1lwi0VkHmuONgB4daci66hiHE2nrQDyYmUPzDHzCzZQuC8XGUbr45WkhnD0G+9Ic/REMbrRSE4oWAwmIRN7/hDbtPaOKpmfnHPx7Zgw5C1+rV6D7xROQe97j612sYtlwioPHSwLkT16Jyze8hIim8P198TACIqKlEBKj5UfOfMfVg2xLilQjFWqjvY2LTJmz/9rcxfd118Ldvj5b3Fdnzbnrx3agpFFpzx704wE9s2rTnxyYS9WQ4B/E8ZIaG0LV6NVa84hUYfO5zkVm2DABa6nVLxv1zJ50MMbbeF0BzpSsBYAsAUdtRpxBjkTv5ZABomaatJKBpGOLh730PD3zpSyhu3RqVzAsFmO5u2N7evQrq9fH1ViQCr7d3z3fwjX0OqnCVCqZ+9ztMXnklcocfjoNe/Woc9JrXIDM01DpJQJIAHHcszMAQXKUCsWbxXoMkLrVQgWdvpCoBYPwnajPx3aUZGETu2NX1jzWbBgHE81D6wx9wx/veh6nf/Q4mn4c3MBB93rnZxrk2sE+/h7WwPT2AMfDHx3HPpZfioW9+E0eOjGDZC18Yld8fpTFyScTJih1aBu/II1G5YQtMV/eiJQBpjUst2GlDRJ1E/Rq8gw+G6R9sifF/DUOI5+Hh734XN77ylZi+9lpkli2DKRSgYRiVw1v1bn4pxA2ASZKUWb4c/o4duOWcc3DPhz882w/Q5OdI4+Gb7BOfCPh+y1SWWkmqKgCRpA5ARKknAtSqyDzxCZBMJhpzb9aFOulstxb3XHIJ7v/c5yC5HLz+/mi3PHok1SgRyOXg5XK47zOfQem223DMv/wLvL6+ltjNMXvs6jgZWcz79HQuBcgKABE1jYgATpFbHZX/m9mslQT/u0dH8cdPfhK2txeSyTD47414OCSzfDl2/fjHuPn1r4erVKJw2KTXNLnjzx59DCSXa5vhmoXEBICImkYRTUXLHH0MgOY1ACbNa9vHxvCnyy5D9uCD6+P8tPfU95E96CBM/vrXuHt0NNrgqVlbOsfnknf44TD9A1xdcjeYABBRkwg0CGF6e+Edckj8oaW/QCd3/jM33IA7L7ggKvl3+jj/AXC1GjIrVuCBL30JD37taxDPa04SkEzB7O6Gd9BBUN8Ht5iaK309AOkbZiGi3REAoYP09sEuW96cxxAH+XB6Gre//e1Q52DiqX+0/zQM4S1bhrs/8AH0nnoquo8/fnblwCV9IArJZGGXLQOSoZzFiB/pbAFgBYCImkQE6teQOewwSC7XlAbAJCg9+NWvonjjjbC9vQz+C0EV4nlw5TLu/ehHm/gwooicfeJRQMiNgeZLWwLAV4+onTgHyeWiVfKWmirEGPi7duHBr34Vtq+PDX8LSIMAXn8/JjZtwtRvf9vUfgDT3Q2ES9HPoamKUakaAlA4P5V1FiLaPRfCO+RxTfnRyXz/HT/4ASr33IPMihVMABaaCDQI8MCXv4y+pzylCT8+isf24IMBL1kSePHGABTqL8I3XzTpqACsXKkAYMX8ruYUSMvjJqI9krgHIHPYYQCWfgqgWAtXq2HH974XLfLDjv8Fp2EI29ODySuvROXuu6NlgpvwPGcOOyyuMi3aOaYZIxDB7wEAV1yRihiVigeZcAKf9/5E7cVVq0v+M5Ntfcu33hqN/RcKnPK3SCSTgb9zZ7ThEPZx2eEFotXqkry+TiRVFYBUDQFIzRnNGs7OIWoHCqgYmP7+pf/Z8Qp105s3I6xUojFilv8XR7zt8PQ11+Dgv/3bpkz1ND29QDYHdbooRQDVeBXrUFN1U52qB+uAwLEBgKgtaNwpnj2mCYsAxT9r6ne/i6am8a5i0ahzMLkcZrZuRVgqRcMAS/V8J4sBHXEEzOBg1OOxiOeZAqmqAKQjARgbcwBQy2a31cJgImOMWZw8joiWXDNK7/EiMcH4eNPXqu8I1iKcmWnKcA+A6Bxb3KTDVJ3Civ0tgHrfWqtL1ZlfC8NQIS2w2TQRpVY8/S+YmUHlrrtgslk2AC4mVZhMBsHOnajccUf0oTZ8vg0EaRtESk0CoKoyEwQVVb3Pi7L3VGRYRNSi4p3suD780ki2EG43CqgRkZoLy8aYPwEA1qxJRXxKRROgAKobNpgzf/vb8p1Pf8pDnmANB+2I0q4F1vRg+X9pNfX51nnHwrEi4ruw6vt+lACMjqYiPqXw7JcJ5utEdMBUAS77u3Ta9flWRK3/gqnQ81RTtGJtehKAeGEFUWzNQOJFl/DIpI4HDx4pOxRLSgSqCtvdjdyRR0JrNa4Rv5ji1QC9oSHkjjwy/tASP9+qi3n+alYMnMOdx1111TRGRkSiz7S89CQAdToe55B8xxK1Aclklv6HxlMQvYEB7hO/BDQMYbu64PX1RR9Y6ufb8xZ1+CH6bWR80X7AIklPAlCfVmG3BNEdA9+xRGkmUWDw77tv6X923IXee9JJ9VUBaXGIMXC1GgqrVsF2dTXl+Q4f3g43PQ1Yg0W4OVdPBCK4AUBqlgEG0pQAjI0pADjgzkoYzlgR0ZSUWYjokQQCNCQASzqxJw5AvaefDpPJcBngxSQC9X30nX569Lwv5XMdn1PB9u3Q6WmIsYsRNcRXhVPZCiA1awAAKZkFEFMAqKmOG9GSJ6Yn4FRAolRTACaXW/KfK3E5uPuEE5B//ONRvf9+SDa79P0InSAu//c//enRfzdjKeBsFmoXbQkZCVSdVfvAYv2AxZKaCoAAqiMj5ltXXVVUxa1ZI4hqSU3vYOLBg8f+HgKEkxNYcnFjmu3pwbKXvARhsRgtUUsLSqxFUCyi97TT0BMPtzTjeQ4nJuIZCAt7/ipUrRFTceHMBILbAdRXrk2D1CQAAIArrjCjgFPVzZwJwINHug91ChiL6q23Alj6zvCkCrDiL/4iagZsw0Vqmk4ECAKs/Ku/qi+/vJSSInHt9tuhvh8NOy3keexUcyJwTm8fz2Z3qWpqZgAAaUsAYiJyW7MfAxEtgCToN6P0bgw0DFE46iiseNnLEExMNGdGQpsSYxDOzKD7xBOx7CUviTZ/atJCQIu49LB6EAjkrmdt2hRg/fpUxdRUPdikucKKbq5GF4x0PX4imqUKyWbh3303XLkcTdNqwpoAUMXj3vxmZJYti/aN54yAhWEMXLWKw9/+9tlGy6Wu8sQ/r3rzHwBrF6PRVK0IQtHNAIDt21N18qQrgMZjKw97+ZsrYbiDuwISpZwxcKVSNEWrCcQYqHPIH3EEnvDBDyKYmmraXWo7kUwG/vbtOOQNb8DQ858PDcPm9FjEvR7hxASwOD/fVJy6jOpvAKRqBgCQsgQgaQQ8fdOmHU5xcy66Y0hNwwURNYgX43ETEwiStQCaMBQg1kLDECte/nIces458Hft4lDAARDPQzgxgf6nPQ1HXnhh1PjXjKRKNUoAymUE99234LM8FFDPGFNx4UwlW4jWAEhRAyCQsgQAQH2RBYVuzkTlnVRlXEQ0S+I7NP+euwGgaZt8StwPcOTICAae+Uz427czCdgP4nkIZ2bgLVuGYz79aZhCIf5EEyrjyRoADzwANzUF8byFTTBVNWcEqrjtAWAibQ2AQBoTgKQPAPqLUB0AXeC2Th48eCzZodFR+cM2NJVINF6sitWXXYaBdevg79gRla3ZE7BXxPMQTE4iu3Il1vznfyJ36KFR6b9ZjX/1GQC3wc3MQIxggc9flxWBCq581qZNAc46K3XzSNOXAMQllpqaq4tBWLQQq5wOyINHKg9VBTwPtdtvA5oYLABETYgi8Pr7seYb38Dj3vhG+Lt2RY/LS9OaaUtLrAWMgb9jB/qf+lSs/X//D93HH9+0Of/zVW++GYu0GZCETmHUXQEgdeP/QAoTAAFUVeX6ww9/0Cn+kLcWTasbEtGBUYXkcgju+xPczExT5orPEf98MQZP+MAHcMy//Es0U2HnzujTnseKABBVTKyFGINgagpuZgaHnXce1nzjG8gsX968cf85DzGeAXD7bYDnLWiYUECtiC2GYbGm5moAqRv/B1KYAAAAzjrLrh8bC9XIVbnoRU7dE09EQNIIGO7cidrtt9c/1lRx4FDnsHJ4GGt/+EMc/JrXACLwd+yItg82JgqAcRCEyKMfre6xHn/j72stEIYIxscRFosYPOssrPnWt/D4970v+lwT5/vXqUYzTKam4N91FySXW9jzStXlrUXo9JbrDz/8wTSO/wPp2gtgVlJq0fCnVZXzNK2JDBFBRBBWqyhv2Yz8aadFC8Y0/0FFDYphiPyRR+Koj3wEh7zxjXj429/Gzv/+b1TvvRfO92eD4mN0mLd6L4EGwZ4ff7yZj4YhNAgg1iKzfDmWveQlWPHyl9fX+K9P9WuF3zOeAVC97Tb4Dz4I0929oIsBKaAZEcDIz9ePjYV61lkegNQtJZnOBCAutZhs15XFankiY8ygr6rCLYKJUkfjKkBly+bo7rEVAkgsuaNV59B1zDF4/Hvfi8Pe+lbM3HADpq+5BjNbtiCYmkLl7rt3e9eriC5KYakE9f3WCI7zicAbGNj98x7P0sgefDAyQ0PoWrUKvWecgZ6TTkL24IOjr1GNXsMWGO9PJElkZcvmqGLT07PQt+empg7G4L8BpHL8H0hpApCsB4DR0ck7n/Kk3xSMeZEfBA4irXMGEtHeUYXk86jeFnVrm97e+h1cS4jHu+EcVBW2uxv9T30q+p/61PqXBJOTUcVg/r91DjAGt557LiZ++Ut4fX3QMFzSh79H8Z19ZnAQJ3zve7C7ed6TKojX1xc1STbQMIyeG2NaKmkDZsf/K9dvgSzC+H/WGFMK3YPo7t0MIJXj/0BKEwAAwBVXGAGCO2E2CvCi2fJVa52IRPQYVCFeBsGDD6Jyw/XoetrTWysBSBgTXV3iigCA+lCB19//qP9UMpnm9zbsSVwBsN3dj/51cQIEoN4D0ZLi8f9wxw5UbroJks9HidiCPP0KqIZdmYw3HgT/c8zPfjapw8NWxsZaJKvbN+lNADZtCgGgaqo/lSBbsiJdIaACbbGrBhE9FhFAazWUr74aXU97emv0AexJUhFotIfgXu+Gb9XgH6v3ADxa4pUkQK0u/h0q225CsH07bH9/vBXwghEHRdbh+wv5TZshtc1zyTDA1kM3PxTCbY2nA6ayDEPU6dQ5SD6P0u9+G23b2uwu8n3V7rMA0vA7xJIqRelXv4qqSwv5vQH1jLGl0E2VPD+10/8SKXuXzXPFFWb9GEID+U6OywITpZcqTD6P6q23onrrLVHAWbwtXKldxc2IrlRC6aqrYAqFhd0KWNV1GQNf3a+Pu2rz/ToyYtI4/S+R7gRg0yYHAE7l+9NhUDYiVlP8YhB1MjEGWi6jePnlALi+F+2H+JypbL4O/h/vXfANgICoy8wAXwdQ35smrVL94AVwOjJijv7d726rOf1FD4cBiFJLnYPp7sbM//wYrlRKxdj5XmvlEnorP7b9NPX97y/4uRN3/9upMHygnCv+AEC9Fy2tUp0AAKhnYB7wbSsibXK5IOo8qtGyu/fei8rm65q/LPACUt9v9kPYvXief1s8zw3d/+VrroZ0dQFuQVf/C7uthUJ/dsKmbTM6PGzTXP4H0jwLIBFnYH7G/39TvuzIilnGRYGIUkoBOMX0974fTQdMuziw5h//+JbraRARON9H9uCDYfL51px6uQ+SzYdm/vd/ETz4ELyhoYVdc0FhqqEDnHx54b5pc6W+AiCA6vCwXXXllodDdd/rtkagLlyMrZ948OCxuIc6B+nuQvE3v4b/pz+lvwqQJACHHRY1o7VSgI3v/jMrVsDkcqnvuRBjgDDE1I9+CMnn4tHgBTgnoXBQV7DGlMLgpj8WCr9UQNI6979R6hOABhIa/WI5DB0gpvmXMh48eOzrASjgeQh27cLMj/87/bMB4oCff+ITo50EWynIxqv8dR19dPTfrfTY9lWcXJW3bEblphshcff/wpyTAFRdzhioyH88a9OmAOvWtegqSPumLRIAGRsLdQSy6vnXXlNRd123Z42qpj47I+pIzsH09GBi438hnJiIlqBNaXBKlqTtOeUUZIaGWms/gHjXvr4nP7nZj2RhqGL8P/6/BU8YFdHc/+kgKPpZ9w0AqW/+S7RFAgAA2DYsMgonkH9rn1+KqAOpwmSz8O+7D6Vfbkp3FcAYqHPILF+OrmOPRViptMYiR8k+ACtWoPukk6IPtcLj2h/xfgv+Pfeg9Pvfw/T0LOz5ouq6jRFf9dtrfnXtA+3Q/JdI6Su+G2NjTgGZKVfHpoPgoZyxXBOAKKXUOUguh/Gvf7217pr3R7wc8IpXvrJlfhexFsHMDIae8xxkV6yob+yTZuNf+ypcsfiITYsOlEDEV4VR+cyCfuMW0DYJgACK4WFz8g03FFXlcwUjUKcLMwjEgwePpT2cwhS6ULnhBsz89H+ji3qr7KK3j5IthYee8xzkDz8crlJpfrB1DiaTwYrh4eY+jgMVj/3799yD6R/9CLanNzpPFug81Gjqn5SC8BdHvejq63QEph2a/xJtkwAAqK/JXC6bf58OXNETYzR6KYkobZxGVYAvf7ll7pz3iwjUOXiDgzj4ta9FOD0dNQQ26+FYi2BqCgNnnYW+Jz2pPn0uleKpi+Nf/QrCqak42VrI7y+wgIixn5BROGwbTulJuHttlQAkUwLX3vi7hwJ13+n1jKgm+0Dy4MEjVYeGMF0FVLZuxcz/prwKEDcyHvTXf438E56wKKXqvaYKEcFh//AP9f9OpYax/+kf/RC2rzee978w559CXcGKmQrDW7Iil6tC0rzxz+60VQIAAFizRgEgVHy4HIZVG7XhpvQMJ+pwzsF0FbDzXz8FNzmZ3hkBSRVgYABPGB2Fq9WaslKZeB78nTvxuHPPRe8ZZ0DDML13/wAggh2f/HhDQrVw54aqas6IhOouOeK3vy1j/XCqN/7ZnbZLAGR01OnwsD3ummtuqTj9rz7PM477AxClkypMLofaPfdg4lvfrAfSNBJroWGIoec9D4e95S3wd+2CZDJL9/M9D8HkJAbOOgtHnH9+VPpPeed/+Xe/w8wvfgHT27ugnf8KdV3WmskguEXGJ7+lIzDtdvcPtGECAABYs0YVEFYBiNJPwxC2vx/jX/oi/HvuiYJWWpMAY6BhiCPe8x4se+EL4T/0EEw2u/g/1/MQTk8jd8ghWPXZz0KMiSoQaeyriCtA6vt4+OMfBRahgqGK+O4fl6y6/fYqtg1Lu939A22aAMjoqMPwsGEVgKhNmGiP9x2f/Hi6lwcWiZIA53D0Jz+J/qc/HbWHHoqaAhcpGEsmg3BqCt7QEI790peiBYnijXPSSOO7/8lvfB2VrVthu7oW9u5fO+PuH2jTBADAnCpAKQgDCxHV6LznwYNHyo4whOnpxfTPfo6Zn/88uutLaRUAIhAReAMDOO5rX8PBr3sd/O3bAdUFHY8XY6Ix/+3b0XvaaTjx+99H9wknpLv0r9Hqhf5992HnF74A09MLF7oFPdecQvNi2v7uH2jzHfN0eNjK2Fh4yxmnfWbAev8wEQShEUlxxwtRB4tXr7NDQ3j82Ldh+/uju+Y0lrGB+jg2ADz45S/j7osvhqtU4PX11dfp3x9iTLQtbrEIrVZx8Gtfi8e///2w3d3pb/oLQ8Ba/OkfzkXx8sth+vsXdGaIU3Xd1krFuevc+MTTjrn9dh+AtmsCkNI0cC/FqwPmK7WLZsJwV9YYo1Ge1+xHRkT7Sh1MLgf/T/fh4Y9/rL7MbmrFMxrUORz8utfhhO98BwNnnYWwWEQwMRHd7XpeFLD3lOjEH0/u9iGCYGYGwa5d6Fq1CqsvuwxPvOSSKPineb4/UA/+k9/5NmZ+9rM4+AcL9M2jmGAEagTiFO9cdfvtVQy3790/0OYVAKChCnDaaRcOZb0P7fJ9VgGI0swauMkpHPLRj6P3JS+pB4Y0a7wzn7zySjz41a9i8qqr4O/cCfE8mFwOMAaSySDpaBYALggA5+Cq1ag60tWFnlNPxcq//EuseNnLoqQg2YY4rZUSoF4tqd1xO+79m78GfD96zXXhYrOqhr2eZ6eC8H9XX3Pt8xWwAqRz4Ym9lOIzYu9o9DvKTWvWeLnuwg15Y1aVw1BFpL2rH0TtSqQe9I/4xjeRPeroOeX01JoXqMt33omJK67A9LXXonjjjQiLRfg7d0Z38vF0yMzQEEyhgK7Vq9F76qnof/rT0XvqqfVvmfqSP1CvkqBWwx9f91pUtm2LNvxZ2EWh1ADOEwlLDmuPu+aaW3RkxMjoaIpLTI+t7RMAYLYKcOuTTnter7E/mQ7DUICUvyuIOpi1cDMzyK9Zg8O//DUgm4nGvtN8lxtLhjUaG/VcpYKwVELlzjuhQVDfITF/5JGwPT2wvb0N30BnG/3a4fmIk5jtH/oAxr/2NXjLlkXPwQIKVcPlmYzdEQQfPvbqay9MYsaC/pAWlP6zYy/VhwJOP3VswMu8ciKIhwKSWhoRpYfGC9vs2onBv3kNVl70T20xFDCHc1DV+hj/Y35tXAVJbYf/7sSv6fSPfoj73/VO2IHB6GMLdc1WQKEub6wE6u4KxJ5yzO9/P4M2bvxr1EZnymOIpwUC5j2VMJzOiBHV+AVWHjx4pOoAoEEAOziE8a9/HVPf+y5gLXTBmsJagDEQa+v7CCR39hqG9aM+dy1uAmyr4O8cYC2q27bhoQ9+ELa7Z3bq5wKeR1BoTkQCh/es+v3vp9q98a9RR937JlWAm0899R+GMt5nxjktkCjd4hK3m5nB4V/5KgpnnNF+lYBOFFczwokJ3POKlyPcuROSzy/42g9ONRzwPDsRhGOrr712faeU/hMdlQAAs0nAbaef9ssea58xxSSAKN2MQP0Aprsbh33hC8gdexyTgDSLqxquWMSf3vwmlLdsiZv+AixkyFKoZsSoQidd1T/2qBtueBhxd8WC/ZAW10b1or0U7xYIxdt8F4aeRCdC82uaPHjw2K/DOUg2g3DXTjzwrnfCTU+ne6XATpZ0/BuD7R/8AEq//Q1sb0/DfP8FPG9Uw15rTE31oqNvuGE7hodNJwV/oAMTgGS3wGOuvfa6Uqjv6vU8C9WOKfkQtaUwhOntQ+2uu3Dfm8+JkoAUbxrUkeI7/6jj/4OY/L8/gF2xYsE7/oGo9N+fyXjjQfDtY6+57t8uX7fO66TSf6LjhgAS9amBp5/6sz5rn81lgonST6yHYGIcXaefjsP+/bLZbWLbqTmuHTU0Mz70oQ9i/Ctfhl22bKHn+ic/ymWNiAI7Aj88/pgtW3agw0r/ic59VySzAlTOKYduPCdGnEKbXc3kwYPH/h8aBPAGBlG6+hrc9yZWAlKhIfhv/9AHMf7lL8NbthwIwkU5RwzgcmKk6sJzV23Z8nAnlv4THZsAJFsGr7r22juKGp6dM8bYNl/2kagTaBDAGxxE6Zp5ScAi3E3SAVKtV2i2f+iD2PXlL8NbvnxRyv7Rj9NgwPO8ST/41HHXbvl2p5b+Ex07BJDQdes82bQp+MNpp/zzci/ztl2+H4iI1+zHRUQHRjwPwXg8HHDZ52eXj+XsgNbQMDTz0Aejsv9iBn+nGvZ5ni2Gwe+OfuLRTwMAjI25TpnzvzsdWwGo27Qp1OFhe+wTj37XROD/rtfzPMemQKLUSyoB5WuvxR9f/zpUb701XiyIb++mC0PAGLjpaTxw/vkY/8/FWeI34QDNGmN858ad2FdjbMxhzZqOWO3v0XR8AiCAYs0axdiYc2JfXXPhzqwR4zg1kAeP1B8a+LAD/ajcdCP++IbXoXLD9ZBkxcAF3EmO9kFchQl37sR9bzoHk9/9NrzBgXgVx8U5Dyw0zBmRaQ3PXn3NNXdieLjtN/rZGx0/BJBIZgXcdPLJz+nP2J+WnQtctB0knyOilBNr4Wo1wDkctGEU/S9/BRqbz2gJJOP91qK67Sbc95Z/QPDQQ7C9vYt25w8ACvWXeZnMw7Xa6HGbr9+QDPsu2g9MEQa3BsmJcfOpp75tZcb+88NJP4CCzxRRminiRsAArlrF0OvfgBXveAdgbHtsmdvqGsb7J7/3XWy/5BJouQzTVYAGC7i5TyK+ZjunwfJsxtvp+99Zfd2WVzL4z8WwNk99fYBTTvl8f8b7+3HfDwybAonagwgggnB8HN1nnomDL/4wMocfHiUBbbJ9bqtJEixXKuHhj34E49/4Bmx3N+B5izo906mGPdazNXXXzNT85524desEEA/7EgAmAI+g0XMiAuhtp5xyVV/Ge8q473ORIKI2Ip6HcHISdvlyHDwygp7nPi/6BBcNWjhJcDcG1ZtvxoMXvR/lzZthh4aizy1iD4ZTdQVrDVTHy35w2rE33HCXjoxw3H8eJgC7oXFz5E1r1gx0FfI/yRpz+kwQhFbEMnUkag9iLVy1CvV9DL72tVh+3lthurtZDVgAjcMqE9/8BnZ86lMIp6cXfbwfAFTVZYyBBSanQvf8E7dsubrTdvnbW0x1d0MANzY8LCds27ar5gfrfefG89baQNUBrB8RtQMXhpBMFqa7Gzu/+EXc86q/RPGqq6LAJcLpgvsjvusXa1G7917c96Zz8OA//RNcrQbT0wO3WAv8JD8eUCOiBWPMdOjOPnHLlqu1wxf7eTRMcR9FkjVuPfnkM3qs+QkEg5XQOSNiwM5AojYQvY/Fs3DFIiCC/le8Asvf8lZ4K1ZEX8JhgcfWUO7XIMCu/+9L2PXl/0Cwcye8/gGoC+OS/2JcM6Pvq1C1ENdljZ0Mg7PXXHf9F9j09+gYwR7D3CRAfqLAYNUlSQARtQ1jAFWEk5PIHHIIlr3pXAysXw9pbFZjIjBXMpYfl/uLV16Jhz/5cZS33gDb0wvJZJakkqKAWiAsWOsVw+Ds1Qz+e4UJwF5ITqQ4CbjCKfK+OgiYBBC1G/E8uGoFrlRG/oQTsPKd70T3058RfZJrB0TmBf7a7bdj+yc/gZnLLweMwHZ3Q8PFbfRLKKACDfu9jDce+G86bvP1l11z2mmZ06+91l/0H55yTAD2UnJCbTv55L8d8OyXZ8JQnaoKKwFE7UcEYgzCYhEA0P30p2Po9a9H91PPrH9JRzYLOlefSgkA1dtvx/hXvoKp//cjuGIx2n45+boloABENViWyXg7/Nplx2654U288997HXTmHrjkxNp20kl/3+OZz9YUns/hAKL2Fd/pJzsK9jzjGRh83evR/ZSn1D+nYQgRad+qgCrUuTmLJVVvvRXj//k1TP3oRwinpmD7+uIllpeu104BNYDrs9ZOufCyVddtedPl69Z5Z23aFHKu/95hArCPLl+3znvWpk3BzSed9LSsNT80IoPlMGQSQNTOrAVU4aanIdYid+yxGHzt36L3uc+F6e6OviYJlO1QFUiW7W1MbJxD8be/xfiX/wPF3/8erliE7emBeN6Sz5hwgHqAK1hrK6F709GbN1+mw8O203f321cpP0ubY05PgJGfQGSwEoZcLIio3SWJQKkEBAGyRx6Jnuc/H/0v/T/IrVo1+3XOQVXTVRmIExgAc+72g4cewtSPf4ypH/0QlW3bgDCE6e5e8jv+hofpjEC7rbUzfnD26uuv/wLn+e8fJgD7qTEJ6DPyE2tkcDpgEkDUEYyBCOAqVbhSCba/H/nj16D/z1+O7mc8A95BB8358iRQtlR1IG5o3F2i4opFlK7+PSa/912Urr4GwUMPweRzkEIhevxhcxbUc9EiP6bLGEz4wdlrrr/+C2z4238tciamUzIccNPataf0ePZLnpFTpoKAewcQdYq4WVDDEK5UggYhvJUr0XX66eh51rNQWHsSskcd9Yh/Vk8IkoY6ARb1ctwQ7AFAjGD+JKbgoYdQvuEGFH/1SxR/cxX8e+8FVGG6uqLpfE4Bbd5Kuk41LBhjFTJeDd2bjr3++o3JNbhpDyrlmAAcoKT09KsTTxw81DM/6bHeGbt83xeRTLMfGxEtIWMgIlDfj5IB52D7+5E79lgUTjoZhdNOQ/7445E55JDd//t42ACqUWIhUv/7Y1YNGv7dI77HHoYgwslJVG+5GeXrrkP5uutQufFGBA8/DKhC8nlILhf9Pou8bv/ecKpBj7VeoLprRvGC+gp/DP4HhAnAAkiSgD+sXt1bKBQ+1ZOxb9hZ80MnUcGv2Y+PiJZQHHQFgAYBXKUC9X2ItbBDQ8ge+QTkjjkaudXHInfcccg94QmwAwOL2isQTk7Cv+8+VG+7FdWbb0b11ttQu/MO+A8+CK3VIJ4XBf1sNnrcLRD0E6rqL8tkMtNhcPWEyl+fumXLbQz+C4PBaYEoYARwAHDrySeP5I1sqKnCdy403ESIqHPFlQEAUXWgWgV8HwrA5HKwAwPwDjkE3uAgcsceC1MoIHPY4cg87nHQMITt7UXmiCNmqwGN4o+FO3bAf/BBSMaDm5pG5eabAVVUbtyKcGoKtXvvRTg5CS0WozH/TCYK9tlsvdJQrxy0CBdP8xv0PDsThhuLQfimtVu3jrPhb+EwAVhADVsJu5tPOml91prPZQSD00HIvgAiqpfz6wmBc0AQQJMjDAHnouWHrY3+ns/BGxjc7bdLVtcPi8X6WgVwDur70c/xvCgByWYh1ta7++vBvoUCfiNVDTPG2KwIyqEbXX399RsAYCNg1wMM/guECcAiSLpSb1q79pRua7+Ut+aUcd8PIVHrTbMfHxG1kIYx/npTYEPDHlTrAf0RATv+mFhbX5YXiGcbqEYT4ls82M+nqkGP53m+c7tqTt987PXXb1TAAuAc/wXGYLRIkjGqK1ev7j20q+uTOSNvnAlDhKqhcKogEe2Lx5w6qKkPjQo4geqAl7GlMPx1WfH64znev6iYACyijcPDdn08VnXbySe+MSPmk1akdyYIA+GQABERgOiuP2uMlzWCinOfuq9/8PxnbdoUcJrf4mICsMgUEAwPGxkbC7edeOKpXZ75bN6YJ08EoYsX4EjJMmFERAtLAYVq2O95XsW5B2oavu3Y62/cKABcQ2M1LQ4Gn0UmgMrYWKjDw3bN1q3X/cfm658+HQSjeWNMl7VGVYP0F++IiPaNUw09ERnMeF7JhRvHy5XTj73+xo2Xr1vnxfMdGPwXGSsASyjeRdwpgD+sXfv8nMEn8sYePxWGUPYGEFEHUMCpKvo9z/iq2324Dx2z+YZPA7Orqzb7MXYKJgBLTy5ft84+a9OmYOOaNdlTMvZ9RuTCnLHedBAEELGcKUBEbUhVNcxb42XFoOLct2pi3nnc5s33a1SNVnb5Ly0GmiZpbBC8Ze3aJ2eNXJw35tlF51CLFg8y4OtDRG0gqXAOehYl524NoSNHb77hWwDv+puJAaa56tUAALh17do3GMEHu6193CSHBYgo5VSjcfxea01VXc1AP7rTZj5++rXXTm4cHrbDY2Oc299ETABaQGP5a8vatSt7Rd4vwDlZkey0Cx0UKgIbvVzJ2l9ERK0kieMChTpVaJc11gDwnf64Crx7zQ033AjM7p/SvMdKACNJS2kshW1bu/aEjOiFOTGvAoAZF20VxooAEbUqBRxUNW+MLRiDogt/J6IXHbXlxp8CUeAH7/pbBhOAFtO4bgAA3HHyyc9V5873jDzXgIkAEbWeeuC31uZEUHHhjVD5559lMl8759pr/bjKCU7tay1MAFrU/DfM/ERg2jkVVSdsFiSiZlENFUBj4A9V/rkWBP95wrZtNQDYOAy7fowb+LQiBo4Wt3EYdngMOpsInPBcdeZ8K3huxhjMhCGcKjcaIqIlEa/e5yBiuo0RK4LqbgJ/PM7vwHJ/y2LASIn5icBtJx9/JtT8HSB/021MthRPH4QAAlYFiGhhxWV+Z0W8bmvhqyJw7qfW4jOlavg/DPzpwyCRMvOnztx8wgnHZqy8SlX+LmfMYQpFMZo4EABiBDCcPEBEe03n/FUFGjqI7TJGckZQCt10CP121uoXnrD5xt/Uv5aBP3UYElJKAYPhYUmaBW89+ug+6ep6mUD/RhV/1m2trTiHsjo1ilC5wiAR7YV6iR9ANu7m99XBV70BkK+p6rdWbd16X/y1guFhw87+dGJASLn5iQAA3HHKCWsR4DUOeJFnzJqcCErOoabqRNWpxJUBIqKIg6pTQKwR222iy0PZufss5Kdq9JtPPObGX0jczLcxms6H9WBzX5oxAWgTu8vEdd06786dO58lRv4qhD43K+YwTwRVVVSiWQShQgQCNhASdZCotB9N3VMRkxUxBWPgoCiFbsoTXBFAvzNUDb634pZbppN/d/m6dd5ZmzaFvNtvD7zotyEFzBXr1pnG9bVvfdKT+ky5fEYAfYEVebEBjisYg0AVVVX4qi4u+wlnFBC1lzkBHxArYnPGICOCQBU1dfcB8lOB+5FT8/ukxA9EY/tjANZzfL/t8CLf3mTj8LAZBtA4RKDDsHfedvKpzgXPBPDCUHFy3phlORH4swmBimr0b0REwSoBURokwV41KgRCxHjRXT6yIgijRuGSFbkpVN3kQf6nv7f39yuuumq64XsYDA8Lx/bbGy/oHUIBGRseNiu2b5f5O2/duGbNkOd5JwPuGap4JoC1VmR5jzFwAMI4KQhUVRUq0GQ1L1ERASDxicTziWjxaTypR+M7ekgyz0dEbBzsvWgDEVRUUXVu0gC3GsGvBeZXkgmuOerabffO+abDwxYANoyN6ShX7OsIvGB3IAVkDDAr1q2TszZtcvOX57zjtNP6gyBYLc6dqcBaAzyx5tyajDErcvGFRRElBiEAXxUKRRjv/CVRM1EjiVIEzkUk2jtRL/6cD0WrfsIAxsTBPSOC5O+BKgKgHuyd6n0w5jqH4DcD2a7rD7322h3zfohcvm6dPWvlSuWdfmfi1ZhmGwi3bxfsJiEAgGue+MT+nkJhVdbzBstBcIYVOdoCR9SAQzyRgwPncj3WdjnEF6WGfxtC4ZQnG9HeSNJkT+a+Y2qqEAAzYRhaY6ZC1RkPuD1QnciIXK+qWwNjdgxks9t2E+yBhoDPu3wCeE2m3ZhTIXiMi4UOD9vJm2/u+6NzPQWrx5RDUQuclAEGfIlajAFd64kZCFQVojzniPZAIAqoCOCHwNUGxhdVAeCryO97rQ0mguDBPmMefDibrZ5+7bWlPX2rjcPDZnj7dgHv8InoQCggGwGrw8NW163zdHjYKtcSIGoqBcxGoP6e3Bi9L5lk017hiUIHJLnYbABkw/CwAMAV27fLWQ1fM7Zpkw7z7oNor40BMrxu3dzr88qV0XtobEwRv594V09ERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERETUxv5/yXONlXDhSucAAAAASUVORK5CYIJpYzEwAADT94lQTkcNChoKAAAADUlIRFIAAAQAAAAEAAgGAAAAfx0rgwAA07ZJREFUeJzs/XmcbHdV7/+/P5+9a+zhjAlGr15FRHJQpkAGpjAkDEZGaRQUMCCNV4wYImPgnjQJQYw4Xn18Od579crPAVoZDTKJCSgkYARRguLX7xVEAsmZeqpx771+f+za1dXV1ef0Oaera3o9tenTNfVOV+1hrc/6rI8EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJgUbtAbAAA7wUyOIxoAoJ+cZIPeBgA4F1wuAxg67WDelB6l5ua8rtjndVfvx7sjR5q7uHkAgAllhw+Huueera+f3/nOSG7j3SQNAAwTEgAAdpV1HnfMpFe8Iuy8/2yDeXvXb87qm98wVcoc1wAAO+aYpAPpPxO3sLB6ps/fkDS4SNInTiRaXEyytIBzJAgA7B4ulAH0xfoovumuV7wivEiSLrjA3MJCdNrnrgfzgaREYXSpSlOXxbVaoiTx67/DAudcLKfLXC5/WdJsJJL81q8MAMCZ884pMWtI7vecWd3MnHOuHbgH3itOkkYQB78nqdHx1G0lDWx+PrcpOeCoHgCw80gAADgn7RF9M+mGGwLdc4871Si+HT48Lcm3RlTycRC/PPA+nySJNylJg/lcGsybC+TMQh/MqlyWkqT3UasZSc2mussuAQDYUcXiFlfPTrJEUaWyKimROpMG+j1nrp44s1yp5FStflZReIdKNafv+k5zL3rV8la/zg4fDvWd97j1xICpM/EAAGeKq2UA22ZSWqj4/Nac/G9uPaLfMYpfaPpoPhcEuURJPjGb987lEzNJ8mG5PL0hcO8RzMdJIjNrniLA95K8zEgCAAD6Iz3H9K5iM0nOXOiDcNN9WdLAJHkvVSqKknhZ5sznc86azc/K6W+DQiGnWu1vjkXhHQfS81q0VfWAzc/ndMEFphtuiOUclQIAto0rZQBbSgP+U4/sZyP6SkfzXxF4H8aWrI/iS2E7yDdJtdqG50dJHMmcdRyNvLrK+B3HKgDACLDuQLw7aZCO4OcC79fvz+WkMJS8kypVRUm87OVdoqQu6Z1hqdSM1ip3hMXmZ5T/zsBde+3JTb+3s1LgPYsJ0wcAbIWLagBt7YD/Fa8It5qvb7/5m7NavvdSlUqXRdVqTtIrWiP666P5XaP4WZDvnGRmYeehx7F4HwBgwpi1gvO0MiCRU7IpOSBJxYLkg6xq4KQLc4Ga0WcC7z8bJ0kUxME7JdV6VQrYO+dzJAQAdOPCG5hgpwv4W6P7xWxkP0mSy5TLXaYomvVTU1ISS/V6+5IiSuJIcqauUXxG8AEA2J52FYGZ5BTLZO3EQFYxkAslMyXV6mpiVpPpneFUqalq9bOaPf8O96rNfQVICACQuCgHJsqGOfyHDrlTBPwvD5ybaVrycu9cMSiVNozsR2aSWdOcnEyBW59377JpjgAA4Nxl51UzWet0m8iUmDOXy3oOtCoFkrU1WRguJ43mZ3JTxTuiavXOcPb8z/RMCMzP5/TOd0b0EAAmCwkAYAKYmbvrFa8IH9k1h78z4HfOzcSdAb+cVKvJtGGefntkn1F9AAAGyyTrrhQInUurBPJ5xWtr0jYSAnb4cKi77zYtLiYkA4DxxgU8MIY6m/f5hYWo80xuv/mbs9HyvZf6QvkJSa3yMudcuWfAL2cyC1sjAxwrAAAYch1NCBOZJVslBFwzusNktwVx8L8kVTp7CLSTAUwVAMYSF/XAmDDJaW6L0v5bbjm/WV16WSD3BMuFlyqKZoOpslSpEvADADCmeiUEAufk8jkpCBRXq6tmVvHF8v/y9cZtR5crnz3vlltWOl/j7+bncxe9852Rc45EADAGuMgHRpzNzQXdQX+rtL8cB/HLnPOXWxg8OgiDGSWJrNFUbCYza0oubEX7HAsAABhz6w0GlciZhT4InSSVS1K1pmYc3Zsrlv9XVK/cFnY1E3SSPj8/n7voyJGIqgBgdHHRD4wgM3O64YZACwtxdhK+7zWvmTk4W74sKeQ3lvbHsazRVGRJJHOuNY+foB8AgAmX9hCQTEnsnA9z3kvlkuK1SnuqQCy7LVfa87/ca15zb/t59AwARhYBADAiTHJ3zc+HjzpypLlhTv/NNz4lCf0T4lrlZbkgPF+l4sbS/lbQT8APAABOxdJ0QLRhqoD3iqN4xUXxZ8yS2yvV+H/Ovu1t97Wf00oGuMXFeJDbDmB7CAiAIdezxP+WW86Pq0svc85f7vPhUxWGaeleksgsiZxcwFx+AABwNjZNFXA+dPmcFIaK1ir3+WLpf3b3DDDJ6fDhDdWJAIYPwQEwhHqdRJff8IbzyqXgZ7rn9DdrdZMUSy5IY34AAICd05oqkJgzy/sg7OwZEBTL/8tHyW3ujW/+WPvxVAUAQ4tgARgivUb7mze9+am+UHh8Uq29PJwqn6co6pjTL+ecgnRXJtkOAAD6JQ0bLJ0oEMkpl/OBVCpKUaSk0fioJfapSi35vWyKAFUBwPAhAQAMmElucW7Oz3U00ll+wxvOKxf9y513j/f5XLvEv5HEkTM5OcecfgAAMFBmZpLFkgtyxYJrTxEolX4vqdc/lXvTjR9tP/bw4VA33BCznCAwWAQQwIBknfw3jPb/8puf6oPC45Nq9eVhuXye4ogSfwAAMPTMFLenCLSrApppVUASHpldWDgqtaoC5uY80wOAwSCYAHZZd+Bvh6+ZlZ+5LMnnr3XSU10utz7aL+ecFAx6mwEAALYj7RdgsaR2VUBcqRxPEvut3AX7f8e94pfSRICZW3z+8zdUQALoPxIAwC6xubmgc73ck4cP75/x0S+Y0ysD7w8ql1OzWmO0HwAAjIUNVQH5vOI4XnbefSaJot9gegAwGAQYQJ+9Z24umHvPe5LspGbv/NWDzXuOv9J79wtBqbRf9YaacWwyS5xzjPYDAICxYmYmpzhwPvT5nMxMJn3UNxq/rmTls27ht5clEgHAbiABAPRJd+DfvOnNT/Vh+IuW2KODIJhVo6FmEkcyBc459kUAADDWWtMDEkk+Vyo6NZuKk+SoM/3OShL+1t6FheMSiQCgnwg6gB22acT/poWnJqF+0Zk9zTmnpNFUnC7hR+APAAAmkpnFcs7ngsCpkFdcrR6X3G+txsFvkwgA+ofgA9ghpw78vZq1mklKWMIPAAAglU0PyPkgVLGouFohEQD0EUEIcI62G/gzvx8AAKA3EgHA7iABAJwlO3zY64YbjMAfAABgZ2w7EbCwELN8IHDmSAAAZ8gkp/n50B050pQI/AEAAHbaVomAIA5+22WJgLm5wC0uxoPeVmCUkAAAtsnMnG64IXALC5EkNRfecKXPF65z0lOdc2rW6gT+AAAAO6g7EZBUq8cS5/7H+770zzc+f3ExtsOH/eLdd7vnkwgAtoUEALANnRnmpde//sBUOfx5mb05KBWDZrWayGQE/gAAAP2RJQJC70M3NaWk0fhYEkW/lnvTjR+VWhWakpgWAJwaCQDgFGxuLtDiYuIkO3nttfun9pZ/QU7XhKXy/qhaUZJYTOAPAADQf05pIsCkKF8s5MxM5txHkij6jXYiYH4+pyNHIhIBQG8kAIAeuuf5N2968zNc4H4/CHIHrFFXI44jJxewnB8AAMDuSyxJnJzLF4tOTmpWax+q1uzqPb/8y8ck+gMAWyF4Abp0njCaC2+4MswVrktkT1WcKIrjpmShcy7dd8gtAwAA7D4nySSTxZJ8vlBwUaN5zDn32+/9x3+56fmLizHTAoDNSAAALZ3l/kuvf+WBqeKenzenN4eFYlCvVs1Jagf+AAAAGBomxaFzgZ9O+wN4s3e4Ny58TGJaANCJYAZQemLYUO4v9/tBLncgqtWUJAnz/AEAAIZcWhBgUb5QyMk5NetMCwC6kQDARLO5uUCHDplbWEja5f5mT1WSlfsrZJ4/AADA6DDrmBbQbB6T9D/e909fTZcN7Bj0ASYRgQ0mUmeTv/fMzQXP+aEHvtnJrg8KxZByfwAAgNFnUhx6F/ipKSX1xscb1fotpRvf9nE7fNjr7rsd1QCYRAQ4mDgbmvwdvv4KX8i91hfyVzZXVxNLzCj3BwAAGA+WrhwYFUqlXFSrxc77G4N//JebHE0CMaFIAGCimOS2aPLX9M7lBr19AAAA2HlmFjvvXG562m9qEkhvAEwQEgCYCPae9wT68pfTuf40+QMAAJhIZtbMmgTG9dqH1mrLV+/55d85Rm8ATAoSABh72QH9PXNzwXN/+AffF4ThM+I4VkyTPwAAgInTbhKYz7tYdjyqRS8u3njzrfQGwCQg8MHY2tDhP5vrHwRXNqqVRCZHkz8AAIDJZbIoH+bCKI4iyb2VlQIwCQiAMJbs8OWhW7g9ao36v8mS5M1hsRg0atXIyYWD3j4AAAAMXmJm3jvLTU/7TSsF3HCDOedoEIix4ge9AcBOs8OHvVu4Paq++bVX/tjDH/yXwVT5BnNyjWo1JvgHAABAxjvnZPL15ZWm9/7KMHB/2XjLmw637jKbm6NPFMYKFQAYGxsa/d18+EeV2PvDIAjqtRod/gEAAHBKZhbLO5efnfXNpaVbK0u1F+/99V8/zpQAjBMSABgLdvnlobu9VfL/4Ae+L8jnntFoNhOLE/PeBazuCgAAgFNykpnkpGYun8vFZsejekeDQKYEYAyQAMDIS0v+F5Lm9a+/IiwVXqswuLJRqSSS87T5AwAAwJlKTHEhFwZRHEXmg5ty8aff6hZuj2xuLmCVAIwywiOMrA0l/29504/KufeHQRA0arXIOeb6AwAA4OwlZua8s/zMrI+Xl29dXWZKAEYfCQCMpCz7+p45Bc998PXvC3LhMxpRq+TfOZq1AAAA4JyZWlMCcrlcLDse1RsvLt749nRKwMKCOTHRFKOFVQAwcuzw4bxbXIyb17/+irmHHv7LoFh4RqNeTxQnnuAfAAAAO6U1WpqrNxpxYNofBP79zYXrb7hNt3knmR0+TNUpRgoVABgZJjkdPuzcwkJSe/PrrsrlCx/wgafkHwAAAH23YUrAyuqtwQ1vfaaTEvoCYJRQAYCRYIcPh06y23Sbb7zlTYeDwL/fLCb4BwAAwK7wzjmZfGNpqREU81fppsMfaV7/+ivc4mJshw/nB719wHZQAYChl2VVTfLxDdd/MJiZvqq5spxYYs45+vwDAABgdyVmcaFYDJI4iZuN+rPoC4BRQQUAhprNz+fc4mJcvf71V+imwx8JivmrGktLDTN5gn8AAAAMgncuaNRqkVkcBIF/f+Mtbzqs9b4AxFgYWgRQGFrZyP/qG6+7qlAufzD0ga/VajGN/gAAADAMrKMvQGNl9db8oa8+yz1/MaYvAIYV2SkMHTNzdviwd4uLcW3hjc8olMrvV5KoXqtFBP8AAAAYFs45ZyZfX16u50vFq5pffsAHvn7ty/a7xTQJMOjtA7pRAYChsl4ydZtvuse+N5cLn9GImkkSJ85T8g8AAIAhZWZxIZ8PYul4VKu+qHjTLR+2+fmcO3KkOehtAzJUAGBoZOuoLt59t2u4x74/Vyo+o95oxBYnnuAfAAAAw8w5F9QajdhZsj8oFD+4+sbrrnJHjjTtmmsKg942IENQhaGQzZM6LPnrb7j+g7lS8ap6pdJ0Um7Q2wYAAABsV2KWhGEg531SqzeePc0KARgiJAAwcFlpVPX611+RK+VfF4TBFY1qrSmCfwAAAIwgM0vCMPRJEkfywU25+NNvdQu3R3b4sHcLC8mgtw+TiwQABioL/mtves2PBMXih+j0DwAAgHGwaYWAL3/1WTp0yCSJJAAGhQQABmZD8F8oflCWuDiKE+dcOOhtAwAAAM5Vq96/XiiXC81q7dYcSQAMGAkADMQWwb+cczSmBAAAwFgxqVkol3MkATBoBFvYdQT/AAAAmCROytUrlWauVLyq+eAHfkB33+2kziWwgd3BBw67yq65puCOHGmuvvG6qwj+AQAAMCm6kwCL60kApr9i1zAFALvCJKfDh51bWEhW3/y6q4qF/PstSTzBPwAAACZJ53SAt97w1mcuSEm2JPagtw3jjwQA+i5b7sQOXx42g8ddryR+k/dBGEVRQvAPAACACdTMl4q5OIo/0aw23l566y9/IpsmO+gNw3gjAYC+as9ruvtu13jwAz+Qn5m+qrGynFhizjnH5w8AAAATKTGLi8ViECVxEtdqzyjedMuHSQKg3wjA0DcmOSeZzc0FjQc/8AP5UvGqeqVSl1TggwcAAIBJZ2ZREAZezlu9WnnW9M3vuJXpAOgn4jD0hUlO8/OhfmAm31jNvztfLl9Vr1SaTsoNetsAAACAYWFmSRAGkvMWNxrPKvjiX+ruux1JAPQD86/RH9dck3dHjjTrS8Ev5Wdnr6pXKnWCfwAAAGAj55yPoljeLPBB8J5v6p6iW1yMWSIQ/UAFAHZcNndp9Y3XXVUsTb3b4jgfJ0no+LwBAAAAmznJTHEun3NxFH049+V/fbYOHTJJcgsLyaA3D+ODrBJ2VGfwXyiWP6AknorimOAfAAAA2IpJTgqajabliqUfbR564Ad0991O6miqDewAgjLsmCz4r73pNT8S5IsflCUujmKx1B8AAACwPSY1C+Vyrlmt3Zq7+6vPohIAO4nADDuC4B8AAAA4d07K1SuVZq5UvIpKAOy0cNAbgNG3MfgvfFAWdwT/NujNAwAAAEZKmgRYaxbK5auahx7wgdzddz9Lhw5Ztsz2oLcPo4spADgn2Tql7Tn/G4J/AAAAAGcrmw7QqFZv/Yzyz36CJC0sxCQBcLZIAOCs2eHLQ7dwe1Q5/LrH5sL8bUkcuSROCP4BAACAHWJSszg1lautrHyodNOvPDOrvh30dmE0kQDAWWnPQbr7btc49AN/ncvnHlev1SLnHNNKAAAAgB3kpGa+UMhV1lafOXXzOz5EEgBni5FanDHLEkd33+0ahx7wgXwh/7h6rRYT/AMAAAA7L5HCZtSM8qXSe1ffeN1V7siRps3P5wa9XRg9VADgjJjkdPhwcJukR6vx/nypdFW9UmlK4gAEAAAA9EliZmEYmHOB1WuVZ03f/I5bs35cg942jA4qAHBm5udDt7AQXRpX35svl6+qEfwDAAAAfeedc3EUy5LIFUrlD1QOv+6xbnExtsOXU4WLbSMBgG3L5hqtvfG6ZxRLpWc01taajuAfAAAA2BXOOR/FSRJ4HwQKbra5uUB6QmJUdmOb+KBgWzqX+yuWSu9PkkRxnASOzxAAAACwq8wsLpZKQaNevzX/4Ic/S1/+smN5QGwHFQA4Lbv88tAtLsaV61/32EKp/IEkjn0UxQT/AAAAwAA454JardbMl8tX1b70d+9zCwuR5ueZCoDTIoDDKZnknGT2nrmg8U/pcn+1Wi3ydPwHAAAABso5NfP5Qq5SaS0PSFNAnAYJAGzJJKf5+VA/MJNvrOTfnS8UrqpVq7FzLhj0tgEAAACTziQLAh8771Vv1J8zFZQ/rLvvdiQBsBWmAGBL/3rNNXl35EizeiL4pfzMzFX1Wq1O8A8AAAAMBye5OIq9TyzMufDd39Q9Rbe4GBtxHrZABQB66mz6VyiU321JnI+TJGTePwAAADBcTIpz+ZyLm/GH8y73HEmiKSB6IZjDJnb55aG7/faocv2rH5srTN1mcRxEcWzeOY4hAAAAwNBxMllcnJoKaiurHyq99VeeaYcPh25hIRr0lmG4kADABiY5HT4cSFLD6p/M5fM0/QMAAABGgJOa+UIhV6ksP3Pq5t+gKSA2YW4INjp8OHALC1Etqrw3Xyw+rlarxQT/AAAAwPBLpLDRaET50vR7K9e/+rFucTG2yy/nWh5tVACgLcsQrr3xF59RLs9+sFGvRyZxwAAAAABGhJlFhWIxbDYan867wpMk0Q8AbVQAQFJr3v/iYly5/tWPzZem39toNKJEouM/AAAAMEKcc2GtVovzxeLjalHlvW5hIcqm+AJUAKDnvP96rRY5Sv8BAACAkeSkKF8ohPQDQCcqANBz3j/BPwAAADC6EimgHwC6UQEw4Zj3DwAAAIwn+gGgGxUAEywL/ivXv455/wAAAMCY6dkPYG6OGHCCUQEwoUxymp8P9QMz+cZS+Je5QoF5/wAAAMAYavcDqFefVb7plg9pbs7TD2Aykf2ZVPPzoTtypFk94X4pPz39uHqt1vQE/wAAAMDYSSQfN5tJoOBPdHi+pEOHzIgFJxIVABPILr88dLffHlWuf/Vjc/mpjyRRM5+YheLzAAAAAIwdJymR4nwu5xv1xofKN//Ks+zw4dAtLESD3jbsLgK+CdO55F/d6p8s5AuPq1SrsXeOuf8AAADAGHNOcSFfCJZXl5+55+0sDTiJKPuYNHNz3i0sRNWo8t5CoUjwDwAAAEyIxOQbjUZUnupYGnBujlhggpAAmCDtJf/e9JpnlgqlZ9Sr1YjgHwAAAJgMTnJxkihwPvQud7Pdct2U1KoSxkTgjZ4QrdJ/t6TlvYUo/x9h4IvNJJYjCQQAAABMECcza5ZmZnK1leWF4ltvWcgahA96y9B/BH+TYn4+dAsLSRiFP18sF0vNJI4J/gEAAIBJY5JTGFXWYuf8NTo8X9IFF8SsCjAZeJMngM3NBe7IkWbl+tc9tpAvvLZeqyWSWPIPAAAAmEBOcs0kUT6f219t7v0Tt7CQaG6O6vAJQAJgzJnktG+ft1uum/JON4eBn4qTRI7pHwAAAMDEclLQaDbjUrHwzLU3vfqZWlxMaAg4/kgAjLvWfJ61E+6XCtNTj6tUq00a/wEAAABIzFwUNROv3J/o8OGSDh0ypgKMN0aBx5jNzQU6dMiqSeUxuVz+w0kUF+IkCRn9BwAAACBJJsX5XM436vUPlW/+1WdlK4cNervQH2R3xpxbWEhc4m4MfTAdx7Ej+AcAAACQcVIQNZtJqVR+ZuX66x7vFhdju/xy+oWNKYLBMZVl7tZe/5pn5ov5D8TNZmwSpf8AAAAANkikuFjIu0a9+bfFvdHT9bmv17S4mDjJBr1t2FlUAIwhk5wOHbKTh6/d7737E0sSS0j2AAAAAOjBS0G9Vo+L01OPqx33r9HiYqL5eaoAxhAJgHE0Px+6hYUkbIQ/XyyXSlEcR473GgAAAMBWnAujSiV23l+jw4dLeuc7IxoCjh/e0DFjc3OBLrggrrzhNY8rFAuvqddqiSSydwAAAAC25CTXTBLl87n91cbanzjnTHNzVBGPGRIAY8gtLCTOuRtD76eTJDEa/wEAAAA4HScFjUYjLpVpCDiuSACMkc7Gf2E+d3m9Voudc+ywAAAAALYllpRYkjiFN9kt103p/PPNGFAcGyQAxoRJTouLCY3/AAAAAJyt7oaAbnExpiHg+CABMC7m50MnWb6ZuyZP4z8AAAAAZ8u5sLm2ljjvrzl5+Nr9OnIkogpgPJDJGQMmOV1wQXzy8LX7faRfSOo1ScZ7CwAAAOCMOcnFZlGxVNqfVOJrZHqLXjEf6siR5qC3DeeGEeJx0F72z/98oVza30ySiMZ/AAAAAM6WSWGzXjfv/C/ohnmWBRwTvIEjzubmAr3znVG67F/xNfVqNRaVHQAAAADOgZNclCRJuizgDMsCjgkSAGPAOWfOJemyf8ayfwAAAADOXXtZwFL5mctvuPZyLS4mNjcXDHq7cPYYKR5hNjcX+MXFePkN116eyxcvr9VqsZMLbdAbBgAAAGDkOUmJZIklFphfcNITiDVGGwmAEWeSAvMLzjmLmZQDAAAAYIe0gv2wXm/E+WLx8uU3XHu5f9uv325zc4FbXIwHu3U4G8SLI6pz9D9fKF5er9cTL1GOAwAAAGBHJZK8cxaYX6ACYLSRABhh2ei/986SQW8MAAAAgLHkpaBeryf5QqsKYHExphfAaCIBMIIY/QcAAACwmxJJ3lMFMOpIAIwoRv8BAAAA7BaqAMYDCYARw+g/AAAAgEGgCmD0kQAYQYz+AwAAANhtVAGMPhIAI4TRfwAAAACDRBXAaCMBMGIY/QcAAAAwKBurAF5DFcCICQe9Adgem5sL3OJiXLn+usfncoXL6/Va7OWCNCUAAAAAALsjrQKQBZYsmPSEQW8Pto8KgBHyT4fn8pa4G53UGv0n+AcAAACwu7wUNOr1JF/IX756/S89xVEFMDJIAIwAk5xbXIz36btnnXRp3GzK894BAAAAGJBESsJcaN70NEnSvn3EJyOAN2kUzM+HkrSn6V9ZKheDWBZJcgPeKgAAAACTK2zU6pL0UycPX7vfHTnSNGKUoccbNORMck6yk9deu79QCv818G5/M07M8d4BAAAAGJQ0GmmWSqVcda16Q/mXf3XB5udz7siR5oC3DKdAEDnkbH4+pxMnktr9v+fNxanS4Wq11pSUG/R2AQAAAJhsJlnOexcndryp2oNm3vbbRyXJ0axsaDEFYIiZ5HTkSPRlKTDnXhk1mjJWbgAAAAAwBJzkmknSLJaL+/NW+ElJ7enLGE4kAIbZ3JyXpPvf/3suzeVzs1GSxJT+AwAAABgiPolixZY83UmmEyeSQW8QtkYCYMg5yczpLaH3+diopAEAAAAwPJwUNBqNuFgqPqXyuusez5KAw40EwJCyubnALS7Gq6//pafkC/nLa/V67CV2JAAAAABDJZZkJjPvbvynubn8oLcHWyMBMKxa62h66WlhGFoiUUoDAAAAYOh4ycfNppx06Xd///kzbnExZknA4cSbMoSypf+W33DNeaErfDlw/rwoYek/AAAAAMPJzKJiueTqldqNpX/72k06dMi5hYVo0NuFjagAGEbz86FJLm+FnyyVS+dFSdIk+AcAAAAwtJwLkkYzkPTzX5YCLSxQBTCESAAMoxMnEidZbPb0pBlLvE8AAAAAhpiTXJQkcS6fm73/A773EidZtqoZhgdvyJDpbP5XLBae0mg0YkfzPwAAAABDLjZT4H3eyW6iGeBwCge9AeiSNv+LvZKn+dBb0rCEBAAAAACAYecl32zUzWRpM8Bf/p1jWX+zQW8bUszJGCIbm//laf4HAAAAYKSsNwOs3lj6t/+gGeCQYQrAMJmfDyUpsPAnS+Uyzf8AAAAAjJasGaBzP6970+CfZoDDgwTAMDlxIrH5+Zxz/ulJM5J4fwAAAACMkKwZYJgLZ2uXrDxRkmgGODx4I4aESc4tLsarxeJ+SU+Kmk2J9wcAAADAiEnMklw+n7dAP2Jzc0GrzxmGAG/EsJifD83M+XLwglK55CIzyv8BAAAAjKIwqtZkphd8WQrckSNNpgEMBxIAw+LEicQ5ZzL3dIvjQLw3AAAAAEaQk1xkFufy+f33f8B3XSKJaQBDgjdhCNjcXOAWF+PV1//iU4rFwlPq9UbM0n8AAAAARlVsptD7nJO/yebnc4PeHqRIAAyDffu8zc0FgfdP82FgiZQMepMAAAAA4Gx5yTcbDZncpavF4n63uBgzDWDwSAAMmEnOHTnS1L2HXJLohVGt7iSFg94uAAAAADgHLjJrlsqlIDcV/oSk9rLnGBwSAIPWmgtTu2Tlibl8bn9kFtP8DwAAAMAY8EkUB7G5q2x+PqcTJ6h0HjASAIO2b583Myevp+fy+Vxsxk4BAAAAYBz4qNmUc3rit2b8PqYBDB4JgAHKyv/vfeUrp8zpJ5vVmhzl/wAAAADGgJNcbNYslYpuT650tSSmAQwYf/whUC6Vys6pPOjtAAAAAICdZJLkXODk99rcHCudDRgVAIPUyn75XPLCYqk01UySJvP/AQAAAIyRMKo3ZM5eqnsPOXfkSJNpAINDBcAgnTiR2Px8riL/I0kUOxkJGQAAAADjwzm5KE7iMMztq12y8kTdro9rbs5rcTEe9LZNIgLOATHJucXFeLVY3O+kJ0aNpsT7AQAAAGCcmJSYJbl8PmeBfsTm5gLt20fcMyD84QelVf6fmwp/olQuuciM8n8AAAAA4yiMqjVZohfcxjSAgSIBMAAmOZ04kdi115YSc1clURyI9wIAAADAGHKSayZJksvn9j/qktUrJUlzc8Q/A8AffUDc4mL85W/MxmZ2eRxFEu8FAAAAgDFlUpQrFHLe28Wtm1gRYAAIOgehle36/u9fe3wun48TMxpgAAAAABhnQdxoSNIlNj+f06FD0aA3aBKRABiEffu8mTkp+ZFcPleKzBLm/wMAAAAYYz5uRpLcld+a8fvcwkJCH4DdxzKAu8wk544caX47DKenZ4s/2ajWJCm0QW8YAAAAAPSPi8ya5VLRJ0qulvR2zc+HOnKkOegNmyRUAAxIHAQl53yZwB8AAADAJDBJci5w8nvTimjsNhIAu621/N/sVPjSQrEwFSUJy/8BAAAAmARho1aXpJfd+8pXTrEc4O4jATAAZuac/F7vHB92AAAAABPDJDnnSnEQlAa9LZOIBMAuyub/3/vKV05Jelkr+0UfBgAAAABjz0kuSpJmoViYmp0KXyqpXSGN3UECYADS+f+uxPx/AAAAAJPGO+foAzAY/MF3kc3P59yRI83V11/7ulKp/LZqtRY5U27Q2wUAAAAAu8EkywXeRXFy3+pK9f73+93fXTXJuVaPQPQX5Ra7zMxc5fW/tNdLLv2I8zkHAAAAMCmczEzOKesDsDroLZokTAHYJRvn/1tr/r+RgAEAAAAwMZxsvQ9AkT4Au40EwC4rFYtF5v8DAAAAmGTeOee838sygLuLBMBuaWW1fKhXFIqFqThJmo4POwAAAIDJE6YV0cnPnHjd62bdkSNNEgG7gwTALvPmIu+9owIAAAAAwKRykkwq/H8nTlQGvS2ThATALjDJ6YILYrv22pJ5PTFuNiX+9gAAAAAmVJQkSS6Xyz9opnSFJGlujvhoF/BH3iVuYSH58je+EZslT4yjWOJvDwAAAGACOcklUpQvFAoKgotbNwcD3agJQRC6G1rZrO/9vu9+Yi6fj+MkSQa9SQAAAAAwQEHcaMg5XWLXXFPQoUMRfQD6jwTAbti3z0uSOXtCPp8rxVJMA0AAAAAAE8zHzUiSrjhaLObdwgKDpLuABMAuMcl5c5ElCZE/AAAAADgnOVUKcVwY9KZMChIAfWaSc0eONI9dc82MnP1ss96QpHDQ2wUAAAAAg+Ik10ySZrlYnA1De7mk9tLp6B8SALvkQBwnJlcc9HYAAAAAwNBwziVy+UFvxqQgAbBLVorFoneOeS0AAAAAkDHJ5PI0ANwd/JH7zObnc+7Ikebqa199/VSpeGOlWosk5Qa9XQAAAAAwSCZZznsXJ3a05sIH7H/725cs7Qxgg962ccUci13izUXy3pnIugAAAACAlMZGSRIX/r/llcqgt2USkADotwsuiL96zTUFU/zEuNmQZEy7AAAAADDxnKTYkjhXyOUfNFt+oqSPaW7Oa3ExHvS2jSsSAH1kknMLC8n/fdWrSnLuSVG6zqWnngUAAADApHOSi8yS6Xy+0IgaT5b0Me3b5yWRAOgTRqN3QbnZjBJpTc4xmQUAAAAA1DHR30zOtDzIbZkUJAB2QalYLDqnYNDbAQAAAADDyMmXWQmg/0gA9NP8fChJYWgvnyoWp5tJ0nR8qAEAAAAgE9ZrdZls/tg118y4I0eaJAL6hwTALkhkeTnHhxgAAAAAejC54oE4Tga9HeOOBECfmeRMLj/o7QAAAACAYeWdS1aKxeKgt2PckQDoE5OcO3KkefQ1r5l2svl6rS6x6gIAAAAAtDnJNZOkWS4WZnwYv1xSeyo1dh4JgD4Llpa85MhkAQAAAMBWnHOOuKnvSAD0WTMMYznWsQQAAACAUzEpGvQ2jDsSAH1WSuex8HcGAAAAgFNwckVWAOgv/rh9YvPzOXfkSHP1ule9YWqq/NbVai1yUm7Q2wUAAAAAw8Qky3nvoiQ+WlXu/ufdcsuKSc5JNuhtGzeMTPeZc67IEoAAAAAAcDqu6Go1Yqc+IgHQbwlLWQIAAADANiSB98SofcTyCn1mhfxaOtHClM64oIoFAAAAAFJpjORkMsn+7dChtUFv0Tgju9IvF1wQf/VpTyskR489KW42Jec8wT8AAAAAdEpjpNj7OJ80iw/61CefKEmamyNW7QP+qH1gknMLC8nBmZmiKqtPanzrW1Kj7kU1CwAAAACsc05OctHJE0l+ZaVg3p4kSdq3j+CpD/ij9lGSz5u8X1OjoeToUVm1kvayBAAAAIBJZq0+/0kiO3FcdvKkZCZLHFMA+ogeAH0UhKFX0vRyaZ7Fjh+XikW5/QfSBxhTAgAAAABMoDCUVSqykyfSxulhGpo6Z8SofUQFQB/9W6GwZiZrj/k7J6tWZUePyhp1MSUAAAAAwERpVUTb0knZieNp8O9cuyLAJCoA+ogItB9aDSsetLb0xEIYFiMpbt/nvaxRT5MATAkAAAAAMAm6S/6XltLbs3jIOd9sRpLsSV992tMKuuCCeMvXwlmjvKIf0oYVscmeVMjnCrVKtemdC9r3Z1kvpgQA6OTc+oqhAIYD52YA2Bm9Sv43HmN9M4oluScdnJkpuoWFuq1fHWGHkADoI5OtyWzra/nWlAAdPSrNzsgViunOAGD8ObdxGlAcp18tnOmAwdl03g7D9REqs43lqgCAU2sdL23ppGx1db0SoMcx1DlJprUkn+cA2yckAPrJudNPsWhNCdDRutz+/VKxlN7ORQUwXrKAP47T4MFMVqtJkixJ5Kam5EplZSUAFAEAQ8JMdvK4lFiaGQhzcvn8+uhVq5yV8zYA9JCV/J88IatUpCA4/RRoJ89ISP+QAOijRJLs9NcE2aV+fOy4XLEot3efnPcyS0QtMDB62ntta4Tf4ljWrEv1hjQ9LVcsyQWhclc8VS6Xk9XrCh/wA/Lf+71pkOHZ74GBy6bjRLGad35WajSkIFD87/9X8b/9q5TLy44fk0xypaLkA7kg2JAM4PoVwCRzWQP0kyfTwY4gLfnf6tho2RcHz74iATAE2p9x52S1muzeb6dJgHJ5Q0kwgBHgnMw5WRxL1WprdL+s4MKHKfiOCxR8/wMUfO/3pQ8tFge8sQBOqyDln3TFhpusWpWSRM07Pyur1dT83J2y5SUlq6ty5bKc92kCkGl9ACaNWXsAJD5+TGpVO8o5GZH9UCAB0EfubFZZ6OiMqWZDbnqGeYbAKPA+zWpHkazRkJuaUvBDD1H4gAco96iL5WZmNz+ns2zYOVYFAYaVJevZ+iCQK6XT9bLEQP7JV6aVAf/yFTW/8IV0nmutJlcopFUBto1yQAAYB2GYJklXVqR67ayWPXeSgjBktbo+IQHQR4m0dlYV/O21MZfSksMZGgQCQ6sV+CeVilw+Lzczq/xjHqv8ox+TJvA6xXGrvN+tPxfA8OtYyEfSejDfagboCgWFP/gghT/4IOWf8nTFX/t3NT75ccVf+1paFZDPr/cNIBEAYBz1avR3lsF/YrJ/KxTWdn4jIZEA6I8LLoi/+rSnFby5JzWb8faaAfYShrJ6XarXpf375WgQCAwP59J5atWq5JzCQ4eUf9IVCv7r920s7c+6hTuXNr4BMPqyap3OfbqVpHfFYjsZYKsranz2M2p++nYlx46m/T/CkIQ+gPFyNo3+thCZ4kIYFh+wtvRESR/T3JzX4iJzoncQCYAdZpJzCwvJ8bm5omRPakSRJPmzagWULZEhSxsNFUtye/etzyt0Uvo/JASA/sv2NScLvNRoypJY4YUXKv+EJyu88ND6QzuDfkb5gcnQua9nlQHTMypc+VTlH/M4Nf/mU2r8zaeULJ2UKxTT03vS2eyXczmAUbF+TZT2MKvKTp5orY4StA5nZ35Mc5KLLUlm8vlCI4qeJOlj2rfPSyIBsINIAPRJks9boMaac27vuY3Yr88PtlpVdm9dbu9eufJUq0EgFwzA7jBZVt62siK/Z49KP/lihQ/+4dbdHXP5CfqByZYdA1pz/125rPxTnqbcYx+n2p/+sZpfuEvmXVoRQDUAgFFjyfpKR8ePtpc13om+ZU6SmclkTAHoExIA/eTOogngKV8vaxB4QmpGctPTkvNSEtM8DOiT9mnMe6lRl3J5FZ/1XOUe93i5Unm9uRdBP4BuWSWQmZQkcuUplV76cuX++bFqfPLjiu7+J2lqej1RMOjtBYDt6Gj0Z2fZ6O9U0iLns5xCjdMiATBq2g0CT6bByPRM2o2Y5QKBHdcO/oNAqtXkSiUVX/zS9XL/pJUBJwEH4FQ6e4CYKXzQhQp/8EGq/u/fU/MfviBXKEg+kCXpuZwjCoChtEON/jBYJABGVdYgsNGQpqdZLhDYQe29KEu4HTum3KWPVvGFL1pPuGXrfAPAmWhV80lS6WXzyn35H1X9n++URTW5qXR6X2tmLQAMD+/T0f6VlXT0/xwa/WGwuHodVe0GgelygXbi+HrjMQBnbUPJfxxLcio878dVuvpn0uA/STjpATg3WQIxSRQ++IdV+rlfUPigC2WrK+1KARNdfgAMgdZUJqtWZEePpgOQIWPIo4wEwDgIQ1mtpuTeb8tq1fU5hwDOyKbgP0lUuvpnVHjq09crbBj1B7BTsiTADzxQ5Ve+SrmHPUK2vLzh4pokAICByfqPHT8mO358Y18TjCyuZMdBVg2QJLLjx9MlA6kGALZtw0hbFvzHsUqveGU63z+KSKwB6I9saV8zlV72CuUe8ci0z09AEgDAgGSj/rVqa4CxxjXQGKF+o58SpSmWXTtzt6YEVGuy+rfT5QKLpfQuMnVATxv2DO+lKJaSVvD/oAvTZAClbgD6yfv2ebr00nlJUvOuz8vt2ZsmICX6AgDYHc5JcSI7eaJreb9d+v2mNIZihdS+4ap2HHVUA6hYlNu7b8PFBYDUpuA/7hH8Z527AaCfsrJad+okgEQiAEAfZL3FalXZyZNUE48xpgCMq3bpDr0BgF4I/gEMnewc3UoC5C56VGs6wMZjEel8ADuqe64/wf9YowJg3FENAGyy4dOfLclF8A9gGHRWArysVQnwhb+Xm55urUySYkoAgHPGqP9EogJgElANALRtSn05J9VrKr38vxH8AxgOHefn0ktfrvDCQ7LKGpUAAHYOo/4TiwTAJOm1UgBLmmGCbLpYDgLZ6qrCRzxS4aEHE/wDGB5ZdZL3Klz1DLkgSI9RXRfoJAEAbFu2clivDv8E/xOD6G/SdFcDLC+t3860AIyxnsF/ZU3BoUMqveSlJMQADJ8gkJJEwffdX6VXvHLLpbg4ewPYljCU1euyY0cZ9Z9g9ADoK+v4GjJOkiVpc6FGXZqekSuVNswvBMZFz7L/OJK8V/GqZ66vw81JEMCwaTUpDS88pPCiixR9/nNyMzOcrwFsj5nkg/Z1v62uSIlJPrvmGbY4JYudWAewXxjumnRZJvD4sTQZIFENgLHS85PsnKxRV/lnX6ng++7P6D+A4dZKUpZf/FIFhx4sq1Q2HbM4awPoKQxl9drGa33PgMck44p30mVzgSTZ0lJ6cKjXpZDiEIypbN7/gx6s8MLWvH+CfwDDLKtOCgIVfuQZsjjumagnCQCgrXVtw/U9unHVi3UbqgGWJKMkGqOtV+m/xbFUKqnwtB/ZkAADgKHWqgII7//9yj3qElm12jN5SRIAmHCdTf6o8EUPpIH6aIg7APTWWQ2wvCStrcrt3StXLK3fD4yIrUr/k5VllX7sxxXc//vp+g9gtLQu4Es/+WKt/L//qqSyJheGnJ8BpLIVv06eSJuGSumo/wgfI+4a9AaMISoA0FtrpIElAzGKtpz332zKHzxP+cc8rtUUh880gBHSurh3uZwKlz8hrQJgVQBgsp1uab8RDv7RH1z99pON8Je0fjCp1pTce286LUAiaMJock5Wrarw+CfIlct0/QcwmryXnFP+sZfLHzwoazR6PoxLfmBCdC7td6xrab9BxxPnGougL4jk0FvnDpiVEy0tyY4dWx9xIHjCENrqnGHNpvz55yv/2MvTG0hkARhFzklxLFcuq/D4J8gaDdkW52OuoYExtun6vDXqL0cQjVPiChjb184wHpMdY1oAhk+vc52ZybyXVSrKX3RxOvofxySwAIyu1rk3/5jHy09PS3HMtT4wCTrL/atVKnRxVvikYPs2zDFiWgBGSGvObPCgC9OfCf4BjLKsF0CxKP9fvy9d3ss5GUsDAuMtG4w7elR2/DiDcTgrfGJwdpgWgCGz1ei/vJdVqwof+jDlfvBBnCwBjI8gUPFpV7ESADDuuq+7O5v8AWeIZQBxblqZSNXrUrEot29fuqxakgx6y4BU66QZPvDC9AKZi2QA46B14R/+1++V239AduK4FAQyM7muoMAkESYAI6ZjtSKrVmUnT6ZTGL1nIAPnhE8Pzs2maQHfZloAdt2Wo/+SFEXS9LRyj7go/azyuQQwDlrNAOWdcg99uKxSSRPwUs+pAABGDOX+6BM+Rdg5zkmJbe5GSnkSdln72td7WaOh8AEPlGfpPwDjppXUzF14SMqOcVuM9ZMSAEZE9/V0rc71NHYUUwD6atIWs2wdmMJAVq9J9ZpULLWmBXgp6fxbOE3O3wX9tPlT5CS1LoKdZFFTuQddmI6MxfGubx8A9E02DeABD5Tfu1fJyZOtfgBqTQUY8PYB2D7v0323WpWdPCHFrRF/n+3Ik3LdPEmx02BQAYAd1NphN0wLqCq591vptICkc+k1dmz0h1mr/4ST1GzK79un3CMemd5G6RyAcZJNA3BS7pEXy6qVVrDQ+wKaMy8wbDYu62dH75Mdz5ba7tyX2Xuxc6gAQH9lZUzLy7K1Nbm9e+VKpXZjNuBcnO50aGZy+bxcPr8r2wMAA+G9XKm8qUQ4y8cDGFI+rU60EyfSzv4djf+AfuETht3hfbp8yfHjaTMTlg1EH2xofOW9rFZT4dLHpAmAOObzBmD8tIKFwqWXyR84IGs2T1ltxzgiMAQ6lvVLvn3v+rJ+BP/YBVQAYPe0LkjS/gAsG4hzc9rRfydZHMto/AdgEgShkkZj0xKAAIaI95LZ5mX92G+xi0gA9BPTdjZzkly2pmlN1rhXbqosNzXVSgTYxsfyt8OZyha8jmK5qSmF3/8D6e2cXAGMqySRwlC5BzxQzS/9QzrVrlURZTK5LVYGALBLXKsxcbUqra62Ovtr44g/17ypLHZibLBvqDPB7upMirTLn5bT8qdKdWP5EwdCnAEz6/jMOClO5KamlfuBB7Zu4gIYwBhyTjKTC0OFP/CDskZD1nm863Eu5fQK7IKOJYmVJLKjx2T3dSyTLcdgIQaCCgAMXkd/ABUK0vS0XLGYZkZjyrex2WnL/7N/xLGs0UhHwwBgzFmt1vt2qgCA3Rd4KYpkqyuytUqr3L8V+AMDRAIAwyHrD1Br9QcoFKSZmTRwY+12nAVLErkwRwIJwOTI5Xsf87KpUQD6LxvYWlqSVSpSFDHPH0OFKQAYLq0DpNVqsmPHZEtLrbVQ+ahia53d/01aXwHgsken1SSsAABgnLXOkcVHP1p+//72NIBTVUtRcQzssOwatlrlGhZDjQoADKfWwdKWlmRra3LlVqPAMGTFAGyLmUlhbtCbAQC75xRVT2bGCgFAP3R09tfqqqxeT28Pw3YzTmCYkADAcMvKqJaXZZXKeiIgCDioTqhtjWi1Pxt8RgBMELMex0EAfZFNX+0M/M06mlmzD2I4kQDAaOhMBKytye3dm/YHaK0kgMnVWf6frRzJKRcATo/WAMBZ8l6KYyUnTki12nrgT5UNRgAJgD5iZY8+6FgxwG1YMYBEwKTo3p+s69/WXvua5DuAycNhD+gj3+rsv7Iqq6yt9xgi8N9xXNX3DwkAjJ4NKwbUpEKRRAC46AWAlux42B2S0AcAOEvtwH+Fzv4YeSQA+uaYpClRA9BHnkTApNnOnpRNAwCASWdmknOU+QNna0Pgv7Ye+HuuNvoni524ju8XEgAYfe1EQJVEwIQ51fx/TssAJlJ2XNzmHCj6AAA9bBn4s6QfRh8JAIyPbOnAekciYGZarkAiYBJYx/8CABihBM5YFvivrsjWOgL/wLM7YWyQAOgnugDuPifJtRIBtWrambXYURGgrkQA10ejr+P927j6n9EFEMDEsS1/ANBTdu0Yt0b819akOEpvay/pJ/an3cLfuu9IAGC8dB4wskRAtSpVuxIBWUUAB5iR0fOtOtX7x3sLYBKd5uKZRoCA1ue+ZCP+a12l/q4j8AfGDAkAjD/fURFAj4CJwBKAACaZmXXM6zeZaAQIbBBsUerPHH9MABIAmBwkAiYCcT8ArA9wthYCACDR3A8QCQBMIhIBY8EY4gcAANtB4A+0kQDA5CIRMDbSkn8SAgBwNlgKEGOLwB/YhAQAQCJg/LSSAUbdK4AJ006FmhHYY3IR+ANbIgEAZLaTCGAyJQAAwHAi8AdOiwQA0O1UiQDvqQgAAIw0lgLEWHEu/SLwB7aFBACwle5EQLEoFQpypbIUhiQCAAAjg+kAGDvep1NdajWpXpdVKwT+wDaQAABOp50IqEnVqmx1Va48JTc1RSJgyFjHd1oCAphU3cE+I/4YC9k0zCzwr1al1VVZvZbeR+APbAsJAGC7shKzJJEtL8kqaxsTAWbt5nMAAADYQUFwisDfkfkHtokEQF9Z13eMjcBJSSxbPimrrKbTAgoFVg7ok957UPet1vVv6gAATCKOfxgzWWO/tRWp3kinZsok51uNmY2P+1jh+NVvJAD6iXPw+PNeihPZ8nJ6Eip2NAyUkyzh/e+H1vl+A+J/AOD4h9HUfV7Pqi7jVmO/tVZjP+fS0f5skguf8/GTHb8YS+sbEgDA2eg+4fhAUqssrdpqGDgzI5fPr68cQAemncMJHwCA8ZGd172XEpPiWLa21rujP9cAwDkhAQDsiNbZqGvlAAsCuakpuTJ9AnaS8TcEAGB8bGjstyJrNNLBExr7ATuOBADQD9nJKo5lS0uytY6GgT5Iy9eSZL2jLQAAO4H8KEZJq0rSajVpZSVt7JfN7yfwB/qCBADQT90rB6yuyOXzctMz6TSBbHoAAADAJMiujaLW/P7KmhTH6x39mS8J9BUJgD6iDw8yTpK8Tz8P9ZpUr6eNAgsF+VKZ6QEAAGC8ZWX+tZqsXpeqFVmrsZ/LkgLiuhnoNxIAwC7YcDJzWZ+AmlStKl5dlStPyXdPDwAAABhlnZWQtVo64l+vrY/2Z72TBryZwCQhAQAMStf0gDibHjAzu3H1AAAAgFGQ9Tbq6OafZN38O8v8W9UAAHYfCQBgGGQZ8HqrLC4I1qsCOqcH0DQQAAAMqyBod/O3zm7+2aBHdg1D8A8MDAkAYJi4jtUDlpcUV9bkSmW5QiHtGUBVAAAAGAbZoERHU79kbVWq19NpjnTzB4YSCQBgGHVOD1hZlq26rZsGUhUAAAB2Wzba32rqZ9WK1Grql16XcG0CDCMSAMCw6zjBtpsG9qwKMHGyBQAAO+50o/1dTf0ADC8SAMCwy+bJOZeW0m2oCihJhXyPqgCRCwAAADvASYE/9Wg/Tf2AkUECoK+s6zuwQ7KmgbWKVF1LVxBoVwWU1pcSNBvTRECvfcq6/s1+B2ASmTgG4sw5tT8z2SCC8x2j/ZXWaH+192i/0Z8IOyU7fvGZ6hcSAP3EORg7rvvD5NJgP45ly8syd4peAeNUFkD8DwBb4xiIM5ZVG6o9mm/Viqze6DHa71oP50OGPuD41XckAIBRZ1J3ed6mXgGFguQDGgcCAIDNvJcSk+JYSbXX3P5AGyoEAIwsEgDAuNjQK6BjBYG1tEzPTU3Jl6fSE3kQsJwgAACTqLuhX5Kkc/tXlmWNRnp9sGluP1E/MC5IAADjrLWCgOJYtrSkeGUlrQboOUUAAACMtY6gfkNDvziWZOm8/w1z+7k+AMYNCQBgnHVXBUinmCLgmSIAAMA42lDiX9lY4t++RuC8D0wCEgDApNlqikB5Sn6qY4oAyQAAAEbXGZX4A5gUJACASdY5RWB5KV1OsHOKAP0CAAAYflvN66fEH0AXEgDAJDvVFIHlZfoFAAAwrDqD/l7z+pNk42g/Jf4ARAIAQLcz7RcAAAB2R3fQnySnntefVfoBQAsJAABb26pfAMkAAAB2x+mC/np963n9nJsBdCEBAGB7OvsFkAwAAKB/zibo73wuAGyBBACA7ensF5AF+iQDAADYGecS9APANpEAAHDmNjQP9JLOIBlgog8RAABSx1K7TgoI+gH0HwmAfrKOL2BsZR9wJ3mX/hjHsuVlmU+TAb5UlnpWBpxlNqDXPmVd/2bfAzCJOP6NgNa5z0nyraV2k1i2Wkk7+Pec0y/eU0yG7LPOCtR9QwKgj0zW+gxzxMaEsI5wPmgtSRTHileWpDUv16oMyJIBrmuagG2RD+jeg7r3qWw/s66fuVoCMGms/X/pTxgeLvtf72VJIsWJrLqSBvz1enpbK+h3vlVdJ2MmHSaQdcT/dw1wO8YTCQAAO6p9ndKeJqB0hKOVDLCVZal7mkA+31quqHOqQFYWCQDACGsF9RbHkiVK1k5f3s/gEYB+IQEAoP9O10DQObl8Pk0GlMrpY4JWWSQAAKOgM3HduYxurSbV6+m8/tb5jzn9AAaFBACA3dUrGWAmq9Vk1aq0vJz2CigU0t4Bzq0vQUgdJABgmPTq3G/Wnstv1Uprjn+yHuwT9AMYIBIAAAanM6DPLqCkdLSkWlW8spJWB2zVRJCpAgCAQXGu1cQv3ti5v9FIz02d5f1ZIhsABowEAIDhk10wtQL8pLNvQHkqjffbUwVCyRIurAAA/dE5yp8lnFul/dZoSM3G5vn80sagn3MUgCFBAgDA8MsuouJYtryUdoZdXpYrFKVcLv3KqgMkKgIAADuje5S/siaZZJW19vJ9cr73fH6CfgBDiAQAgOHX2TcgqwyQZLWqVF2T+UDmvVQqpVMGpmc2jsIAAHAqZzLKL3WU9ocE+gBGCgkAAKPLOcmHHdUBy5KkpFJRUq3IGvUBbyAAYCh1d+xnlB/AhCABAGC0da8qkN1crabNBAEA6NQZ8Gcd+xnlBzAhSAAAGE9MAQAAZLIEcVbW32xIjUZHx35G+QFMBhIAAAAAGG0mqTPnmwXxcTrKn6yubCzrj+P0Me2O/YzyA5gMJAD6yTq+AOycrfYp6/jOvgdgEk3i8c9pc8C/0hHwt/rESJK8S5+QBfzt88Yk/cGAITZpx68BIAEAAACA4bZhhN+1AnmlgX1iSiqr6Xz+TQF/KzHgg44XEgE/gIlFAqCvrOs7gJ2x3RIAAJg0prEoA2gH/K1+Lt6lN8axZFKyutYR8KsV8FtHwO97vOAI/z2AiWKSkkFvxNgiAQAAAIABygLzzmX5XDpX3xJZvdFe1tUqld4l/dn3Ta8JYPSw//YTCQAAAADsHrONq7Rk5flxLDmXdunPluVrd+lvjQZuOcIPANgOEgAAAADok672/M6lAX8St4P6DR36pfT2zmX5JCkImLcPADuABAAAAAB2RufovnNpEC+1Rvclq9XXR/frjTQ30N2wT9q8LB/BPwDsCBIAAAAAOEOtJfQ2lPK3AvgkSRv01eutuftu69F9U+9yfgJ+AOgLEgAAAAA4hR5l/K4j2O8s5ZeTGvWt5+5Lm0f3AQC7hgQAAAAAetuyjL+e3t6oby7ld+7Uc/cJ/gFgYEgAAAAATJruTvzSxlH6jmBfrTL+ZEMZf2tkPwv226X8ThuW8CLYB4ChQgIAAABgnLWD/VZw7tx6sJ+N2pu1SvjVoyN/rzL+YP21N/6yPvwHAAB2CgmAPkqUngY5FQLn5nSXlyb2NQCQuo6HnaX4Zq3me05Wr8s1G2qP6pulM/yzZIC0XvbvlC7b132EZWQfAEYSCYB+OSZpSkQlQD9stU9Zx3f2OwCTyExKTAosnatfr8sFgazeKuV3XkoSuSyA7xzVd36911/n8ZQDKoDdkl3DJYPekPFFAgAAAGAcWKLk3vtkqyuyXE6KYzmz1mp9Ts45yVpX1b2a80nE+gAw5kgAAAAAjAuzjcvvbRnoE+kDwCTyp38IAAAARhKBPgCgAxUAfWVd3wHsjO02AWDfAzBpTBwDAYw2jl39RAUAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATIBz0Bow16/oOYGdstU917nN2iscBwDiyHl8AMEo4dvUdFQAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAVgHoK5YBAPpju8sAAMCkYRkAAKPOJCWD3oixRQUAAAAAAAATgAQAAAAAAAATgCkAfUQBHrAzuvehXj9372vd/3Z92C4AGCZcdwAYB0wA6C8qAAAAAAAAmAAkAAAAAAAAmAAkAAAAAAAAmAD0AOgnVgEE+oNVAAGgN1YBBDDKsmMXTQD6hgoAAOOJC18AAABgAxIAAAAAAABMABIAAAAAAABMABIAAAAAAABMABIAAAAAAABMABIAAAAAAABMAJYB7CvWAQT643T7FOtfAZhU3WsAciwEMGo4bvUTFQAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAVgHoJxrwAv2x1T7Vuc+xEACASWTiGAhgtHUeu+4a2FaMLSoAAAAAAACYACQAAAAAAACYACQAAAAAAACYACQAAAAAAACYACQAAAAAAACYAKwC0Ec04QV2Rvc+1Ovn7n2NfQ/AJOLYB2DUcQzrLyoAAAAAAACYACQAAAAAAACYAEwB6Cvr+g5gZ5xun2ICDoBJxfEPwKgzScmgN2JsUQEAAAAAAMAEIAEAAAAAAMAEIAEAAAAAAMAEoAdAP9ECAOiPrfapzn2O/Q7ApKINAIBRRguAvqICAAAAAAAwHEhe9hUJAAAAAAAAJgAJAAAAAAAAJgAJAAAAAAAAJgAJAAAAAAAAJgAJAAAAAAAAJgAJAAAAAAAAJgAJAAAAAAAAJgAJAAAAAAAAJgAJAAAAAAAAJkA46A0Yb9b1HcDOON0+Zdt4DACMIxPHQACjjeNXP1EBAAAAAADABCABAAAAAADABGAKQD8xAwDoj632qc59jgpYAJPIxDEQwGjj2NVXVAAAAAAAADABqADok+OS9ogEPLATuvehXj937muux2MAYBJw3QFg1JmkZNAbMcaoAAAAAAAAYAKQAAAAAAAAYAKQAAAAAAAAYAKQAAAAAAAAYAKQAAAAAAAAYAKQAAAAAAAAYAKQAAAAAAAAYAKQAAAAAAAAYAKEg96A8WZd3wHsjO3sU7bNxwHAODFx/AMw2kxSMuiNGFtUAAAAAAAAMAGoAOgnCgCA/thqn+rc59jvAEwiE0UAAEYbBQB9RQUAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATgAQAAAAAAAATIBz0Bowzs0QmLzMb9KYAI617D+rep6zjq/UAmdmm5wHAuLPW8U/ZcZIDIYARQ+zUX1QAAAAAAAAwAUgAAAAAAAAwAUgAAAAAAAAwAUgAAAAAAAAwAUgAAAAAAAAwAUgAAAAAAAAwAUgAAAAAAAAwAUgAAAAAAAAwAUgAAAAAAAAwAUgAAAAAAAAwAUgAAAAAAAAwAUgAAAAAAAAwAcJBb8BYs67vAHbG6fYp6/gCgEnC8Q/AqDNJyaA3YnyRAOgrzsJAf5ABAIDeOP4BGHVkAPqJKQAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEyAcNAbMM6s4wvA2eveh3r93L2vsd8BmERcdwAYdSYpGfRGjDEqAACMJS6AAQAAgI1IAAAAAAAAMAGYAtBP1vUdwM443T5FDSyAScX8QwCjjuNXX1EBAAAAAADABCABAAAAAADABGAKQF9Rhwf0x5nOAWAfBDApuPYAMOo4fvUTFQAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEwAEgAAAAAAAEyAcNAbMNas6zuAnbGdfcq2+TgAGCcmjn8ARptJSga9EeOLCgAAAAAAACYACQAAAAAAACYACQAAAAAAACYACQAAAAAAACYATQD7ik48QH+cbp9i3wMwqTj+ARh1dAHsJyoAAAAAAACYAFQA9BE5eGBndO9DvX7u3tfY9wBMIo59AEYdx7D+ogIAAAAAAIAJQAIAAAAAAIAJQAIAAAAAAIAJQAIAAAAAAIAJQAIAAAAAAIAJwCoA/ZQoTbHQyhLYWafbp2iDDWBSsQQRgFHH8auvqAAAAAAAAGACkAAAAAAAAGACkAAAAAAAAGACkAAAAAAAAGACkAAAAAAAAGACsApAX9GKF+gPlgEAgN649gAw6jh+9RMVAAAAAAAATAASAAAAAAAATAASAAAAAAAATAASAADGV5IMegsAYPdwzAMAnAYJAADjyUyuVBr0VgDArnGlkuQ9/bMAAFsiAQBg9LhT322WyBcKqn3x72XNpuS8ZFwRAxhPZunIf+0Lf69keUkKA5EF6APnenwpTbqEoRQE6fcz+grWn9vz9U9zwgOAM8QygP3ESjxAXzjnZKcK6GOTKxRU+8IXZI2G/NQUCQAA46t1fKt98QtKTi4rPO+gFMWnTZZC6d/IWt/bfzBLg3rnO+40qdHY+FyT5J2sXpXVG+uvdZbb4aemegf8QSAXhLLObYk7p3vYhs0ERp5JYkZT35AAADB6tnOBk5hcsVUOCwATwJXLTAHYrizQ9l6bAnznZJWqLPvZ0oRAcP79JN8RoDsvq1VVfOTFyl14Yfq4Mx2xzwL3ZqTKX94qazTXf0fr9WxlRfHxE+vnMyf5ckeyIAjkwjBNjJulvSCcI/ENoCcSAACG3lkPasSxrNmQ6AUAYNyZyeo1SsZ76Qj2nXOyKJKiSJKUrK22Am2v4H73k3yQBvWP6gjqJblcXuUfuUouDDe8rsWx/PT0jmzm9AteICUdZztLJOfV+Mrdanzxi1KxmN4WRap8+NY0QeF9miA4kSYIXD4vVyik253Pp//tSUJSAEAbCQAA48dMLl9QdO+9Wv2LD2nPC39KlsRyAYc8AGPGTC4IlaytafXWW+XLZVYDkNJg2PuuYH9NimP5PXvkpqflcjlN/+RPpSPoWYCfy8niSH56Zlu/pp1uiSOdXbp6fQ6CK/ZOVhcueqQKFz1yw23TP/4CKY4l30oQfOHvpVJZzbv/SfUvflGuUFD8rW9JlsjlCxuTAtL6Z4SEADBxuBoGMNI6L102XnpZenEUBLu+TQCw21yxKItjuWy0e9IqAToD/iSR1WpKqtWNwf5PvViKIuUf9jDlLzwkqTVtokvvoN5tPaXMOWknEsxbBeOdZf1ZsqCjsq07QZCsrkpJosqtH5JFkZr//M+qf/ELcoWi4m/dkyaNpqfTz0ou13oSCQFgUpAA6KOsfwWHUuDcde9H1vXvTfebSYWCql/8omaf/Vy5fO7s5mcCwDBrHdeqf3+X4pUVuVbSs6Od3YZ/j4XWcdwFwYaA36pV+b175XI5FS6+RLnvu78KD32I8od+KH18j2BfcayeAf5OBfVnYqvzk+uRfOgM1DsTBEHQnpIw/YKfbD8kSwqsffhWqVLR2kf/UlarKT56n5RY+hzn0gqI7PWAAaEHYH+RAAAwnszk8nnVvvQPreWVWAoQwPgxi+XkVf/nryg6eVL58+8nRc3TJDtHNBHqffrf1WxKZopPHJffs1fK5VRsB/wPVe5BF/aelx/H7YZ+nQ30RlLn+9udIMjOdUlrGCoI23+PmZ94gSRp+gUvlDUaWvvIh6W1LCFQV3z0Xrkwl04Z8D5tLpj93QCMBRIAAMaUpaNDjYZqX/oHlR5xkSxJ2qNjADAOnE9Hwev//M8KSiUpiU//nFGK/7NgPWrK1iqyKFJw8Hy5UlHTz5tT4ZEXK/eDD+w5Z9+iSG4cgv0z1eu/d0NSQHKlklyppJkf70gI1Gta++hH1PjiF9X4xy/Jmk3FR++Tn5mVwtZShCQDgJFHAqCvTL2LkwGcu9PsV2ZyYajo6H2q3HmHSg97OBctAMZLq3t9srKk6l2flyvk0y7xo37dkY1oR1Ea9Mex/OweFR/zWOUf8jBNPe1pcoXihnnwUlfA79zGjv2TrjspcKqEwI+/QMnqipr/8lXVP3+nKrd9UsnRo4pPnJCfmZHCMH1/4tMnm4Czk4hJAP3DkRHAWNjQALD1Q7o804xWb/tr7Z//2fRikD4AAMaExbFcGGr1rz+p+ORJhfv3y6JIW7Sq29JQHBGdS6u24lhqNpXU6vKzM2nQ/9CHaerKp8rv37/xOXHcDvYJ+M/QqRICQSA/PaPCRRepcNFFmnnJ1Wrc/WXV/+5zqvz1Xys5ep+Sej1dcSI7r9IzABgZHCkBjKj1kH/LhZfM5HI5xffeq9oXv6jSRUwDADBGWl3vK5+7cz3BOWqyEftGozXCPC2/b59mnvUcTf3oM+T37tv4+NbSd5Imp6R/N/RKCLS+XKnUXmlg5kUvUeMrd2vlT/5Yja98RcnSSbnAy5Wn1hM4o/g5BCYICQAAI8m5019jOEkKAsWrx1X53J0qXXQRFyYAxoOZnPeKV1dV+8Lfp2vIJ8lwjOafTsdov62tyRoNhd/zPZp+3vNVuOiRyj/4h9bL+7PR5SxRQNC/O7LKCmljMqA8pcJFj1LhokcpOX5Max/7qBpf+gfV/vZvlDQaabPBfJ6qAGCIkQAAMLZMkuJYfnZWK3/1ce19wQsV7N3LNAAAI8/iWM57Lb//fYpXlhXO7llvANjZIH4wm9dbNre/0VB88qRcPt+a1/9QTT39Kvk9e9Yfm430E/QPXq9kgHPy+w9o5ideKP3EC1X//OdU//u7VPnkJxR9/ety+bzcVFmSIxEADBkSAP1ED0Bgx2xd5r/F4y27y+TzBTW/9u9a/atPaM9zf6w9bxYARlKryalFkZY++AH5QiFt/pcdD53bcGzckATY8mC6w7Lf49QK5L1UrytZW1X43a3R/kdcpMKjLl5/TuecfoL+4dSdDGhVZxQedbEKj7pY0z/xQq395a1q/MM/qPaZv0lXXZyakvN+fXpA9oHk+hhb4bPRV1wBAxhd25gCkA5WmFy+oMpdf6c9P/a8jeslA8CIsSSR8171u+9WfOw++VxeSjoOiKc4NrrdqgkwpcdaM9lqq8z/u75LMy+5WlPPfna6tFz2wLhV4k/QP1o6EzVJIpnJ79mzXhXwuTu18p53q/75z6VNA7PpAa3HAhgMEgAAxsKmAYXOJgFxrGB6Wqu3/7WqX/oHlR7y0LQKgItNAKOoNQp7/P/8vqxelwrF9pJsQ1Hy30qyJqtrck6tMv+HaOqqH5WfbZX5x1FaFUDgPx6yxHpnVcDFl6hw8SWqf+5zqn/hLlU+8QlF3/i6/BSJAGCQSAAAGFnOOdl2Lx6ckzPp+B/+gb7rV3+9vxsGAH2Szf2vfukftHbHZxXMzJ5T8L+jCYPOwN97FS+5RDPP/3EVLr5k/THZ3P6AS9Cx1F0V4JwKF1+swsUXa/qFP6m1979fa+9/r6JvflN+aopEADAAHH0BjIX21Nce/3ZKL5r9zIwqn/2Mql/6kkoPeQhVAABGT3v0/w8kmVx3Q9OOn3etGuB0gX9nJ3+OuZMjqwpIEskS+ZlZzbzoxZp69nO09v73kQgABoSJsABGxqkuZrfqKeQ2/NtJcjr2v39PSa22vbUEAWBYtOb+r332M6p87g4FUzNSHG/r2Chpc7LgXLW6+iera7JKVcVLLtHBW35VB3/119LgPwv8s1FhVl+ZTFnFh1m6Ms/MjGZe9GKd/wfv0p6f+3n5PXuUnDghRRE9eoBdQAUAgLFxyj4AkiyJFczOavVTt+vke96t/S96MSsCABgNrWNZvLKib924IBeE6k557lp43QrorVaX4qj3iL/Z+jJ+gLSeCGolhrJEQGdFQHzffXLlsuRd2hwSwI4jzQZgbHSW/nfa8HMcK9y7Tyf/fFHWaKTBP1UAAIactebOL33g/YqOHZUvFjccu3Zt/r/3UhQpOXFCfqqsAzf/cu8Rf0ZysZXORMCGioA/VOkJT5StrSlZXSOBBPQJR2cAI+10Ja3Zkleu9SUz+TBUdOyo7nnLDUqq1fW1iQFgCGX9StbuvEPH/s/vb2j8l3FSf+f/+7SE39bW5Pfs0Z7/9krd74/freKjH0Pgj7OzIREQyc/Mav9bbtLBd/yGihdfIqtWZc1ICkMSAcAOou61r6zjC8BO6Gzyt862vs+51o3Wvt+SRMH0jJY+9AEVHvQgHXjRS2RRxFQAAMPHTC4IZPW67rnhzbJ6rT367+TkerRA3RwquVb8tN3rkY4JVc7JBaGSlRUpSVR60pO19zWvlZ+ZTR+SNfcjQMPZcm69R4DUXjWg9pm/1Ylfvlnx0fvkZ2bSZEEca+uuPxgfvLf9RJoWwJizjgvkViWAc1IcKXe/++n4H/6B1u64I73A7hpRA4CBMpPFsZJqVd98y2Elq6sKSqU06E4fICkb/d/89PWbzvRiujV44b0Ux4q+/S0VHvlIHfz139T+t9yUBv9xtD7PH9gJrRUustUAio9+jO73R3+qPf/tlZJzSpaWWskmiQAROHsctQGMPHfasle3+XZLl8+yel3fvOHNsmYzXRIwoekQgOFgUVMuDHXiz96jpQ9+QMH0dNr1v+uY1+u4d7rx+FPe3wrErLImP7tHe695lQ6+4zdUeNTF6w3+Asqy0SdZRUm7UeBLdODmt6t46WXr0wI8y0kCZ4sEAICx5Lp+cF33udbFRVAqKVlb1TcPv3l9Div9AAAMmEWRXC6vtTvv1LH/8wfKf8d3yKKoff+GwP80cfgZLf/nA1kUydbWVLr8iTr/D/5QMy+5en1kNhulBfrN+3Z/gMIjLtLBd/yGDtz8dvmpsqxS4bMInCUSAABGzulGu7a7JraUNtcKymUtf/yj+sYbX78e/JMEADAgWU+Stc/dof94zavT9dHl5FqVS53Bv+v43+xfZzX63x71r8iXyzrw9l/V/re8db3cX6LcH7sv6w/QOS3gj9+t0uWXy9bW0qQY1QDAGaHjVT/RAxDYRacbuXfyZkrWH91+jkWxcgfO0/LHP6ZvyPRfbn77ej8tRhcA7KL14P9O/cd1r5YLQvlcuPX0pN6dUbd/vyR5L2s2pXpdpSc+SXtf93r56Zn1Y2rA5SIGLEs+JYn89Iz2v+WtaZPAt71VydKyXKmY3k/yfjyYJGZk9g1H9D4i/gf6q3vf6rWvbfUY6/pS1FTu4Hla+tjHZZK+++a3S85IAgDYNZ3B/9ev+0X5ICeXC2VJsmmZP1Naxmldo//dx7zOdQI2cUo7/K+tyc/Oav+Nb02X9ZPWu/sDwySbFiC1qwFO/Movq/rXn5QrleVCGvqOA2Kn/uLIDmBs9JrnurEXgJPXxhLZrJxWShtu5c47qOWPfUz/8cbXr5+BaAwIoM+6g3/nQ7kwlGsdf7qPblt1/t82nx4No3vuUelxj9d3/Ml70uA/a/JH8I9h1bFagJ+Z0YEb36qDv/KrsqipZHmFJX2B0+DoDmBknVOX66772/9uRgoPnqflj320lQRIL4QZUQDQN0mSBv933qmvX3etXBDK5XKSdQT/25j7v/GWUyRFg0BWq0mS9v7iq3Vg4Ub51goDNFbDyMiqAZJExUc/Ruf92m+ocPGjFJ84IecDPsfAFkgAABgr26kC6LxQdh3PSf8tKepIAlz/BsWrq3JBsKEDNwCcK4vjdqn96t/+jb7+mldLQSAX5uQs2XSsUsfPZ8VJLgzTRn/T0zpw41s1+5Kflnyrh0pAMzWMGOfSREAcq/DwR+i8X/tNlZ78ZCWrK1LCZxrohQQAgImwnSRAdptvJQGCAwe08qnb9a/Pe45W77wjLStsdSIGgHNhcSwXpKOUX3/Da/W1666VC0P5Vtl/+3gktUcyN4zydyQ7tzX6771cZ8n/ny6qePElaYd/5xktxWgLAimJJTMdvOlt7SkBxpQAYBMSAABGWs8lAXtcGPd6Xq/RtfXeAJKLE/lyWcnqqr5x/et13+//b5lZulQW1QAAzkaSpE39gkBrf3+X/v1VP6+VT3xC4cxMmohMrB2LZ8F/53GsMyGwbUEgbVXyT4d/jAsfpNUATAkATokEAICx12t0rHs+rST57soAJymO5YtFyaR73nGLvvGmNype6RhRoEEggO0wa61Z7uW818rf/o3+/VXXaO3OOxXu25dWBNh6jNI5yu+kTcerzGlH/4OAkn9MllNNCaC5JcAygABGX8+lr5xLR+tP+US3uZzfOTmzdPU/pUkBSxKZpMJ3fqeWb/9rVb78Ze1/9nN03tUvbY82SOLCAsBmZu0RfxeGWvu7z+u+P/xDrd31efl8Xr5YTFcAkNsY/LdkR5V2AuA0FU6u40VcmFd89D6Vr7xSB15/vdz0dFryz6g/xl02JUBOB296m2qf+VsdfdMb5cxL+bxEFR8mGFerAMbYqefIpj+no/6dB0O3qRIgfZRFkcLylJLlJd3zG7+uf3/VNVq984408G91I7Y4pkcAgDRxGEVpUjEIFC8v674/+H197bWv0eodn1FQKsm1VhhxcmnvEWWBvttwHMpu3yr435QIcOmrRN/8T5WvuEIH3vLWVvBPyT8mSNeUgINvv0UWRbKlZfoCYKLx6e+b45KmlI5LEgwA/bZ1FYA23bPhsc7JmWSyVjLAlGQjce3bs2dJlsRygVf+gvtp9XN3avXzn9P0JZfowAteqJlLLkubekmyOJLLGmsx7xCYDNlof6vMX94rXl7Wsff+uY7/+aKa//lNhXtnlduzRxZHUpaAbAf/6XEo/f/1Y49Xx9yAHsez7Kjmso7ozYZcmNO+X3y1Zl70onRbkoSSf0wm72VxpOKjLtZ5v/6bWv7DP1DtjjsU7Nsni5paT6FxvT48TBJTLPuFBACAsbE5CWAbqvw771//t3X8YK37WlMA2kkAybnWo631P82mwukpmUmrn/2sVu74rGYe93hNPfRh2v+MZyrYs3d9K+I4vTAnGQCMl9bBJSvxz0b7JWnlzju0dtfndfJjH1Xj6/+hcHpauQP7pCROE4Stl0iDf1vvO6LO4D/99/oQf3aM0obv7dvDUNZoSEmiAzfepOLFl0rWWrmEKUqYYC4I1/sCPPwROvrG16n6Vx9XcPB8WdQg9sdEIQEAYOx19gPoVSmQPcaZKdHGsQDXyiBkzwmcU9KqDFBrqa5wZjpNBHz6U1r6xMd17M8WtefKp2jmURer/EM/LF8ub/hd7bLgzgtyEgPA8Oqc1tMa5e8M9rPv0bFjOvGRD2vtC1/Qyt98SlZvKJiZUe7AfrkkSUvw02e0Svqzn9q39FihZOOxYasjhc/llCwty+VCHbzl11R81MWyZlMulzu3/3ZgXARBug/6tC/AUedU+fBfKDj/fq2LA7IAmAwkAPrJOr4A7IqtAnxp/Y7sMZsf6+R7JQGUJgE6n9euEzBJcZoICKamFUzPKD52XPceeaeO/skfK3feedrz5Cs0c8mlKj3oQgUzM1vOPUwTA6f6DwCw6zoC/fbPreRdUq0qqdV04ta/0NoX/15rX/iC4qWTcj5QMD0tNz0rl8RSFHc8vWMFEutYcURKVwHIHtdxe+exS9r8b5/LKT5xQqVLLtXsS65W4eGPSKsMCP6BjYKgVRHjdPAtN2v5gT+olT/6IylqSLk8K/sMC66D+ooEAICx07MfQLuw/zSPdVskAToqAVz7eU7mtF5d0FotwIeh8uedL4siRUeP6t7fO6Jji++RC0NNPeIilQ4dkgtDHXjms+VyOVkcnzIxAGCwkmo1Dah9oMo//aNWv/D3cmFOxz/4flm9rua998qHoXyxpHDPvrRsP0nk4o2dxp1zGxuOar1r/+aRf6kzzN8q+He5vOJjR1V+8hU6+La3pzfGcVryDGCzbG6gk2ZfcrXyD7pQR1/3GrkoksKQJADGHmcHABNjq6kA20kCSJK5tBmX2cbnyq1XA7RaBbaaAEpBmFPQSgZYs6nlT92upY9/TPJeR//4j6QgUFKtauoRF6n84B9KLzx852/NfvnO/R0AdNlyBo6ToqaOfeiDsnpDLkib+sVLS3JhoKA8JXmv3L79cmbpfPsk3rzaSK+O/j1uz+5znfMDdKrgP6fk2H0qX/EUHbzp5vT4YUazP+B0Wj15rNlU8ZJLdfBX3qGjr70u3b9IAmDMkQAAMJZONdd/u0kA17NvgGvPFdw4laCrGqB9X5YMcFIQKJyalmZmJDMlq6vt37WSJQY6Gg/uNKY3Yhz1o33Ghpd0TsHUVHrskOSDQMH557eaVKdL+KXrjffOI/iOEf7se5Y47P59Zzbyn1Ny7Nh68J+9Hs3+gG1zuZwsilS8+GKSAJgYJAAAjK1zTQJ0NwDc8NiO5QXW+wKoHSSY2YaL+vYzLZG1qoJ9mFMW7fupKWlm5pSBP/E7sPNOlz9w1lr+M7vBlM7pd1nAbhuOAdlrnmrUv/2Yjvt9eueW29Y7+L9yY/BPM1HgjLkwJAmAiUICAMBYO5skgDqf49YbAHa/pmUX+D2G1rNEQHcCof2Snb/FSZZYazSxV6eCjc/PnGlCgNAA46hf+0HnSPz68nxaLwLqeK1eJf09v3dVA2z4N8E/MDAkATBJqBMDMLFcjxLcXj875zaM2nU+xikt8e3s7L3hy7kN93c/d/1x2Vf6eN/5POfU6/+8dEZfwDg60/2g597U2s8273vpfrn+3N6BfXs/77xNG48Dat2fvY7vvr8DwT+w+7qTABbHUhQxrQZjhwoAAGNvqyqA0z1uqykBnfd1NwOUtKkiwJRe7GcVA92VAe3nb7FNkmQ9H3BmF/2ECEBvZ7JvnGokv7MyoPtxvX7HqQL/Ta9P8A/0HZUAmASktABMhC0D7I7R/exxW42+tZ6woRrAdzwm+95dEeC771dXZUDX47fafr744qs/X1tx0oZ99JTVPp1fPUb8O18zOwZ0/66tfib4B3YPlQAYd3ySAUyMU17ob7MEt9fjOy/yXcdtvYL7zmSA635uVxmy6/WlzcEGgNPbKlDv9eVPE+z7LV5LHc85ZeB/msCd4B8YLJIAGGdMAQAwUbJL5q0aA6ZN+W3TY3s9r50EaD0nCwS2WjWg/e9sQQDZKQP47t/plE4j2OpxAM5M5z6a/bzV4zb+3Jrv7zbf3+vfTq7ni58u0ehzOcUE/8BAMB0A44oEQB+ZNs4RBjAcegbW2e1ZTG8bH9v5+M6f15/TepXtNhto/SN91noioMeCAqcN8AkFgNPb7uoaG+7bcKfrmTA45S7feVDRxmNO9vNWxxifyyk+eUIlgn9gYDYmAX5VR1/7S3LeSc5v6uWDnWOSSLH0DwmAvrKu7wCGQa9Avtft67UA23+tjRGBbX2Xtppa0PX6Xb+g96U/xxjgdFzH/275mFPevbEyaOPrdv/bdbzW9oKE7uA/WT6pwsWXpMH/9jYQQB+sJwEu0YG336Kjr/4F+ZlZWUyI2j9c1/QTCYB+ogQAGGqnnA7Q/l/bVA3QaxSv1+umI4bpvVu9RnuFgNNsYy+2rUcB6HTKfcpOHeB33945gu+6Rvu7d+qeCb/un52TvJfVG1IQau/LXyHnvSyO5Zh7DAxMlgQoXXKpyk++UmsfvlXBeefLms1Bb9p4SkQJQB+RAAAw8U5dxrs5zO8u2XVd33s933Xc2Wvuf68kwNaJic2lwwDOTK/9dTshdud+57eY23+q5/T6uV0x4L3UbEpJrPN+9ddV+KEfToP/INjGlgHoJxcEsjjW/sNvkTUjVT7xMQX7D6QNAoERQgIAAHTqJEA2smc95vj3urDfMpnQbhi2HsZ3zv3vlVjY6rUJ/oFzt1X1zeaR+VPd2/v5W+3D3Te0jwfOyZlJYagDb71FpYsvkUWRXMilGjAUnGtX4hx469skJ1U//Wn5cpkkAEYKZxUAaDnVlID0/nS0z3p06tsqOD/1DKCOyQJdkYHr8TsY9Qd23paj/mc4337TlACdfn91nceAXE7RN/5D+17zujT4bzblcrkz2gYAfeaclCRy3uvADTfqm8/6UVmlIhWLEkkAjAgSAADQ5XSdvbPl/7oTAd0X+706fJ+2a/j6L+m5XQCGj+v63v3vTY/v2r9dECi+715N/egzNTP344z8A8Ms68uRy+nADW/R0df+ktRoSLkcywNiJNBRBgB62NbonXObLuR7vUZ3cND92gT2wHDr3l97fXXft+k1WseLXsF/UqmofOVTdPCmm+WLxXTOPx3/gaHlgkAyU/GSS3XwlnfIhWFaucd+ixFAAgAATmE7p/KtLuy7X6dXkHCq2850OwCcuVPtc7320e77eo3+b3idUx0bvJdVq/LT0zp4w43p/OIkIYgARoH3smZTxYsv0cyLX6Lo29+SC6jcwfDjUwoAp3G63gAbHrvF9IDu1+p+3dM1AOx+LoCddap97kz7b5wqGdjxIDkzuUJB+294i1wuR8f/cbLFOaCNJM9YyJYHnHne89X456+o+qlP0RQQQ48EAABs09kkAjJbJQQ6X3ern7PfyeUisPO2s7LGdiuBzoQPQkXf/Eba9O+SS5n3P8rM0mN8x/zv7byXFkXrj88SPyQGRotz6XsXhjrw3xf0zWc/Q7a2ljYFpB8AhhRTAADgDG2nP8Cm53RMEzjTQCH7nQB23tnsz9LZ7dPZ7/JBoGRtVVPPeKZmnvf8NPhn5H90mMmSZD2Aby0P58Kw/RVXKopXVxWvraXfs6+1NUXLy+nTOh4v5yTnZFGUvu7pKggwPJxLq3fyeR244S1yhQL9ADDUSDUDwFna/nJ/PZ67xYXBqSoFAOyus0nWbfla2T865v0f+O8LcoVCGuwRLAy/VuDvgiD9bLTWhI+Wl7X2j/+opc9+VkG5rKRe172Li7J6vf2YNueUVCqavfRSTT/84VIUyZdKOn9uTq5QUFAub/x9Zunv4vMx1FwQyKJIxUsu1cyLX6ITt7xd4Xf+F1nUHPSmAZuQAACAHXAuyYANr7NDF3l2TlsBjD43BHUzm7agNe9fhUI6UpjPM+9/BFiStIPwbNWG5b/7Oy1//vOq/Mu/aPkzn5FFkZrHjrXfy2BmpnfQbiZ5r+Mf/7iO/sVfSGZy3us//5//R75Y1PnPe56C6Wmd99znKnfw4HpfmThOm0SSCBhaWRKAfgAYdiQAAGCH7VQy4Ny2gYtEYLeddunQjnn/Reb9D70s8HetUfzm0aP69p/+qb79R3+k5tGjik6eVFAuyxWLct4rf8EF7dL90wV94fS0NDvb/jleXVW8sqKv/8qvSEGgb/z2b2v6oQ/Vd/7sz2rmYQ9TMD2dvm42XYREwPChHwBGBGedfjJLr/4p6QUmVvclGkcDYHxsf+a/pSPHqyua+lHm/Q+77sD/5O2365v/839q9YtfVHTihHypJJfLpQF/HKdTt8xkze2Xe2/VNDB33nnt1zp5++1avvNO5Q4e1P1e+EJ9x4tfrHDPnvT5JAKGU2c/gMNv0bE3vVFKkvTcv/4/OB0zSSRN+oUmgACwi7rXDz/bBmQAds+57bcmeSdrNOSnp7X/8IJcqUTwNqQsitql9idvv113v+hFuvslL9HJ22+XNZsK9+6Vy+XaQbolyc4M9GRJhChKqwecU7hnj1wup+bRo/razTfri095ir7xP/6HoqWlduNAysuHjwsCWRyreGnaDyA+el8rwUPwj+FAAgAAhsBWAQbJAqB/dmufcyZZvab9hxfkW/P+Cf6HTCsAd2Gopb/9W939Uz/VDvzDqSmFs7PrAfcuVXZmv8vlcsodPKjo+HF97a1v1T885Sn6xm/9VnpfK9jEcMn6AUzPPV+lxz9ByYkTVPxgaDAFAABGDGEDMDpcEChZW1P5iqeodNmjpVYXeQyPrBGjRZH+83d/V//5zncqOnlSuX372vcPdgPTyoAsEdA8eVL/9y1v0dIdd+i/XHON9lx2WTqdoHvFAQxOq2mkL5U0+/JXqP7lf0zfI+eYGoyB40gBAADQD96npf+zM9p3/ZvXAwAMjSz4j5eX9dVXvlL/3+HDkply+/bJ4njwwX+nLBEQBCp813dp6dOf1t0vepFO/NVfpcH/Tk1HwI7IkkqFH/5hzf70yxS1pwIAg0UCAAAAoA+cWVr6/98X5AuFNDgjATA8WtUYJz/1Kd31+Mfr+Mc+puJ3f7ekIRj1PxUzWaOhcO9e+TDUV66+Wv/ysz+bNhakL8BQaU8FeN6cykwFwJAgAQAAALDTfKCk0lH6byZx4T8csg783uvEX/2V/vmlL1W8sqJgairt5D8io+gWRZL3Cmdndd/73qev/tzPKV5eToNOlp0bDl1TAdz0FD1AMHAkAAAAAHaSc1LUVHDwvLT0n5H/4dEKjM1M//KKV+grV18tF4YKisXRHDk3k8Wx8uedp+Mf+5juetzjdPJTn5LzPk0QYOC6pwIkK8tUAWCgmIjSR9bxBQAAJoMPQ0XH7tPMT79UvlhM520z93fwzNK+DHGsf/lv/01HP/AB5c87T5YkIz9ibnGsYGpK8eqqvnL11brw939fex//eJoDDgkXBFKSaPrZz9HKH///lFQq68tJDnrjhhB/k/7iiAAAALBTWg3lSo9/omZ+/CdkdP0fDq2R8rhS0Vd/7ufS4P9+99vVZf36zeJYQakkFwT6yktfqpO33da+HQPWqgDyMzPa/99vkMVR2q9hwJuFyUQCAAAAYIc4MymONfuyl8sXi5T/D4msCuOe3/99ffvd71bhO74jne8/ZiyO5fN5SdJXX/UqJY1Ge/QZA+a9LElUuuzRKl58qeKlJZKDGAgSAAAAADvBB0rWVlV+6tNUfMhDGP0fEhbHcrmcTn7qU/rP3/kdFb7zO5WMYfCfsThWUCwqXl7Wv77qVbIoSlcIGJNKh5HWeh/2/PRL5WemaQiIgSABAAAAcK6ck5oNBQfP0/43vkkyk+PCfuAsjuWCQCt33aWv/PRPp6P+zo19MJz1BLjvfe/Tv77qVWkjOqYCDFz2PhQe8pC0IeDSSZKE2HV0pOmX45KmRBdAAADGmZNkkgsDxUtLmn3py+QLhTTwpPHfYLWCfIsiff0d75A1m+lSfxPSHd/iWPnzz9fRD35Q5z//+dp7+eXthAgGp7Mh4OqfvUfJ0nJriVAjZsiYJGat9A0VAAAAAGfLlDbzqtYUHDiomef8mCQRZA0DM7kg0L++6lU6edttCvfunZjgP2NJomB6Wl+5+mqt3HUXlQDDwLn0fZmZ0fRzn6fkxIk0WUjwj11CarqvrOs7AAAYN845JVFTBw/fID8zw9Jrw6D1Hpz45Cd19EMfUm7//okL/iWlSZAwlK2u6uu/9mu68Pd+T47mlAPngkCWJJr58Z9Q/a6/U+1zd8rPzJCcaSN26ifOTgAAAGfJBYGSlRUVL71Upcsena4nT/A/WK3gNlpa0v973XXplIwxn/N/KhZFCvfv1/GPfETf/N//W857As1Ba/Wh8MWiZn/m5eltE/wZxe7iDAUAAHC2zCTvNfuSq9sdvjFYWWf1b73rXWp8+9vpcowTvgyeNZvKHTyob73rXYqWllol53xWBymbjlF8yENVfPSjlaysMHUIu4IEAAAAwFloj/5fdpmKD32YrDXnHAPUKnmPlpb0rXe9S8H0NKPdUjranM+r9rWv6Vvveld6E3+XoTH7kqvTyiGSMtgFJAAAAADORufof/YzBioLar/1rnep9rWvyRcKvC8tFscKZ2epAhgiWS+A4kMfpuJll1EFgF1BAgAAAOAMbRr9TxIu3AetNfrfPH5c337XuxTSVG0jM/lCIa0C+MM/lCUJf59h0ErCUAWA3UICAAAA4Ewx+j90LI4lMx394AdV/b//N537z/uygcWxwulp3funfyrFMVUAQ4AqAOw2EgAAAABngNH/IeW95JyWPvMZgv+tmMnl86p/+9ta+eIX05smvEHiUKAKALuIBAAAAMCZ6LxY7/gZg2NxLOe9lv7mb3T8Ix9RQPn/lpz3Smo1feO3fkvWbKZL0mGgNlUBLC+TVETfkAAAAADYJhcESlZXVXriExn9HyatJRhPfvrTSup1Oc8l7lYsSRROT2v1i19UtLKS/q1IYg1e6zM8+9MvlSsUJn7pSvQPR0cAAIDtck7WqKv4yEelF+xcpA9eq/lfUq3q2K23Ktyzh9H/U8maJR47pvv+/M/Tm/h7DZxrTWEpHHqwgvPOozoDfRMOegPGmnV9BwAAo8s7Wa2u8L98t8pXPEVyjtH/IZLUaoorFYKm7XBOFseKlpcZ/R8WzsmiSM57TT3zWTr527+lYP8BWRRJTpMVT0zSf+sAUAEAAACwDc6n5f/Tz32egr17WxfmBJuDlo1e3/vnf676PffI5/MEtadhcaxwdlZH3/teJdUqqwEMCRcEkvea+bE5hd/5XbJaLT3G8NZgB5EAAAAAOB3nZPW6ct/zPZr5seelNzH6PzzM0tFspmRsn/eKq1Ul9fqgtwSZVhWAn5nR9PPmZLUa/Syw4/hEAQAAnEa29F/pyqfIz8ww+j8sWvPZ40pF9/35nyucnWU++3aYyefzatxzj779nvekN/F3GwpZYnH6Oc+V37OHYw12HD0A+oomAAAAjIUklsvnVLr4kvRnLsiHisVxOpLN+3JGLEmU1GqD3gx0ck6WJPLlsvIPfrBqn/2M/OysLJ6k6haTNEn/vbuLCgAAAIBTyZb+u/wJKj7qUSz9N4SCclk+l2Me+5kyUzA1NeitQLdWZcvsy35GLp9nagt2FBUAfWQdXwAAYDQ555TU6yo+6uL1pf+YlzsUsmTM0h13qHn8OM3szoAliXyxqOU77tB3vPjF6387qigGLpv3Xzj0YPnzzlN8333SBDW3TMT4fz9x9gIAANhK1vzve79X5StZ+m/otAKi5TvuUPPECblcbsAbNELM5EslLd95p6xep9ncMOlYEnD6Wc/h/cGO4pMEAACwBRcESpaXVb7yqSz9N8R8uZwmZiZkhHTHmMmXy3ymh1C2JOD0c38s7QHAsQc7hAQAAADAVuJYfmZGpUsuTX/mAnw4JQnB/9lifvlw6mgGWHjERbJqlSoA7Ag+RQAAAL04J2s0FBw4qMLDH57exAU4gN2SJHJhqNLFl8pY5QI7hLMYAABAD857Wb2u6Wc/R641J5cLcAC7Jes3Ur7ySuW+93tJAmBHkAAAAADo1gr4/eyspp/7Y5L3NP8DsLtax6Fg716Vr3yqkuVljkM4ZywD2E/W9R0AAIwE572SypqKl18uXy6ny81R/g9gt7VG/EuXXKqVP/ljKYrT28c5vjCxDmAfcSYDAADo1hp5K11yabo+Oo3SAAxAlngsPPzhCs4/X9ZsSmIaAM4eCQAAAIBOWfO/vXtVfvIV6U2U3QIYhFYy0jmn8pOerGRlheMRzgkJAAAAgA7Oe1mtpsIjLpKfmZElCY23AAyOc5L3Kl16mfz0tBTHg94ijDASAAAAAJ2ckzWbKl1K+T+Awes5DYCkJM4STQD7ii6AAACMFOdkjbrC+52v8hVXpjdRbgtgkLJpAN5r6ulP18nf/V0FBw+kS5OOJWKnfqICAAAAoJOZXKkkVywOeksAYJ336RSAwEtGkIyzQwIAAACgxQWBkuVllZ98hXyhkI6wUWoLYMCySqSpH/lRBXv2MA0AZ40pAAAAAFK7zNbv2aPSpY9OL665wO6PjtFLMzvrPgtZCbTRp+GcWBSlf0uzs/7Mb5gqw36z85yTkkR+elrFR12sym1/LTc1RSUAzhgJAAAAgEwcyxWLKjzsYZLWm2/hHLWCFGt1L3fh+iWoa3U4PxvZ6wQEQmfPOYV79+74y1oUSd6n7y8JgR1hcSyXyyl/4YVa+/Ct8rOzJL9wxkgAAAAASK0GgA2VLnt0usyW9wQu58iSREqSdqCefY8rlbSpWRBo9Qtf0NIddygol888mEkSyXstf+5z8mfz/EnWGu1P6nX9x6/9mlw+f+avkY1KFwo6f25OLp+XxbHC2dkNSR5J7febfersZVUW+UMPlt+/f30aAMkvnAESAAAAAGrN/69UlD90SK5QkDWbcrncoDdr9JilI5VBkFZQeJ8G/LWa7v2zP1O8uqp7/+zPlNTrct4rWlpSdOKEXBCk0wHOgHNOZqagVFJQLrNk4xly3svqdX39V37ljP/26QukwafzXt985zul1j40++hHq/zAB2r2kks0/dCHbkgItCsDqK45c63kSfERF6XJllpNCgnncGb4xAAAADgnazbl9+9X/tCD05tY/u/MmMmSJA38W0HJyU99Skuf+YyO/cVfKK5U1LjnHslMwcxMO5hxQaD8BRec2yhmkjD6f7acU+688875ZaKVlfQ99F7HP/pRHX3f+5Q7cEAul9PMxRdrz8UX6/znP1/hvn3pE8xkreQBzkCSSHGs4sMfocrtt6VJSioAcAZIAPSTdX0HAADDqzX/v/iIi9KfKVXenmzEPwzlgkDRiRO69z3v0fLnPqfjH/+4kkZDYSvgzx08mD6l1Qug/fxmc0AbD0k7sp58Z8l/OD0ttTrVJ42GTnziEzp266265//8Hx185v+/vXuPs6wu7z3/fX5r7brfuhtaAWMmRFEaBWQjAiqNk3OMJwoYTaEeR18h8RaNaHKcMzO5gTNzzpwz0TkRb4hGc7xLJSaCDWpUaK4NdnHpox2jhCQi9+7quteuvdf6PfPH2ru6ummkga7at8/79dov+rWruli9a+211/P8nuf5na/Rs87S2NatxXwAEgGHrz6o1Hp71XPiFi1cc43C8Ig877DkF7HTmiIBAAAAYCZfrhbT/+n/P2weoywEWZoqm5nRQ1/4gh7+whe09K//qtDbq2R4WGkIKwH/kQg00aIeZ2cHC6FICIyMqLZnj+77i7/Q/ZdfrrGXv1zHvu1tByQCir/A++4XOeQcAJmImnG4SAAAAICuZ0minP7/J6e+apvNzuqhz39eD33hC1r+2c+UDA2p5+ijV8ryKc3H6mGQjXNjevt2Td944wGJAEkr8yPwOBpzAMr1OQDLFSlJif9x2EgArCFf9QAAAC3KTKrVFDZsUM+WLcVTBCCPy/N8Zeu+fd/7nu75wAdUffhhJYODKh11lDzPWenHobmvnBvpyIjkXiQCrr9em17zGv3qf/2vSkdGijJ3hts9vvocgN5TT9XiDTcoDJae2hDHFtU5/5LWRLMNAADoep7nCsPD6jv9xcUTlCEf0srqrJn+8Z3v1D9cdJHy+fmVYW+eZQwkw2HxPJfHqHRkRMnIiKa+9S3dec45mt6+vQj+Y+RcOhSzovWmt1e9LzpNsVIpWpaAw8TZAgAA4F5sQ1epNPtIWpbXarIk0cytt+pHb36z9lx9dbG9G4E/ngbPcylGJYODymZn9Y/vfrd+ftllxYq22YEDI3GgPJeoVsKTRAIAAAB0NUsS5QsLGrrgtQoDA0UwSwXAfvWBblYqaXr7du3+X/4Xzdx4o0qbNhXBGYE/jgDPc4X+fsld/3zJJfrHd71rf2KOJMABGi1KQ699rUrPfKZ8eZlrFg4bzTVrin0AAQBoeSYpz4ogg5voA8UohSCPUfdfdpnu/9SnZCEoGRujzx9HXoySmfqe/Wzt3bZNP3rzm/Wsiy/W6JlnMhfgEKyU1oN/qbMmj7kkhoeuFSoAAABA97KitD0ZHVPfi15UPEU/bWFVCfY//t7v6Z8vuaRYke3pIfjH2nFXrFZV2rRJMzfeqN3//t9r+oYbZGnKebdajLK0pL7TylQA4EnhEw4AAHQxk/JcYWREfeVy/SlupOVebOFXD/73XHWV+p797OJrbOuHdeBZpnRsTFYq6R8uumh/EoB2gP2DAEs96n3RixQrFRKXOGycKQAAoLsxAPAxGtP+f/q+92nPN76hns2bFatV+v2xrjzLFNJUlqb6h9/+bc1NTjIT4GAMAsSTRAIAAAB0rcYAwMHzL1AYGGQAoCTluSxNNX399dpz1VXqOfpoea3W7KNCl/IYFXp65LWafvahD+3firLLk1ErgwAvuEClZzAIEIePBAAAAOhuMRbDxbh5XhmEOH399fqHt71NyeCgnJJ/NFmjHWD6hhv0k3e/W/niIjtQ1FlPT7MPAW2GBAAAAOhuITBdXFpphYjVqn7yvvcVz7HSihbhWabSUUfp4a99TQ9+7nPMA2ioD+bkfYrDxafdWmIXQAAAWpeZvLKs0jOO0dD55xdPdWsvbX3oX1xe1j1/+IfKZ2eL1X8CLLQQr9XUe+yxuv/jH9fQSSdpbOvWYhheNw7AMytmJPQPaPA152nfxz+mdNOmztgpgV0A11QXvlsAAABWSRJZb2+zj6KpGn3VD/3VX+nhr35VyfAwwT9aT31rylip6Cfve18x/d6su1e/zWR9fd39GuBJIQEAAAC6l5l8aamYpN2lGsH/7M6d+vlHP6re447rjFVEdKYYlQwMKJuZ0T3/6/9avIe7PPj1xcVie07mmOAwkAAAAADdqb6S2HvaabKenu4ddmcmmen+j35U2cwMK6poeZ7nSgYH9ejf/Z1mb79dZtadFSv1gL/vtNMURkfZrQOHhQQAAADoShaCfHlZfeWyrNTTlStonueyEDR7++3ad/31Km3c2J2BFNqOmclC0P2f+MRKEqvbNGYf9JXLSkbHJLYxxWEgAQAAALqXmbxSafZRNE89WLj/E58oEiBAm/A8Vzoyon3XXVdUAYTQtckrX1rqygQmnhoSAAAAAF1oZfX/Bz/QvuuuUzo62rUBFNpYjLr/4x8v/tytAXAItO3gsLEN4FpyD1q5DvGmBACgdZikYqK49ZSafTDNYSav1fTzyy4jeEBb8jxXMjKifdu3a+ammzT6spetDLXsKo3rmHfOHuTmzkL1GuGFXSN5mrqkShH/t/+bEACAjmKSLy+r9MxnaOi884unuilocJeFoHx+XvN33aVkYKB7hyCirVkIiktLmr7ppuKJbkpmmcmzTKGvX4Pnnad8YV6WtH94FxVdIXRxb9baav8zpMWY5DvL5dLzb7llXuZXDKepTGIvHQAAWpEFWU9Ps49i3Xmey/NcD33pS6pNTcnStLsCJ3QMz3Olo6Pac/XV3XsumxXXsTb/d7vkiVlpplabX1qsfFqSypOTxFFHGAmANWKSS6HSpZ1IAAC0jza/aX7S3IsgSdIjX/mKQn8/q/9oX+4Kvb1a+ulPtefqq4ununGWRQddx1zm2dAQFQBrhATAWqJ3BQAAtJp6oDBz882qPvKIQgesHKLLuSv092v6hhsUKxWG4nWAnqUl4qg1whDANRRVdP9z+QEAoLXURwAWgUKXaUz/n9+1S7V9+9R77LHyWq3ZhwU8ZR6jQl+f5icnZUki68YEQAiSrK1jDxex03ogAbDWOIsBAGg5xUezKS4udVeg4C5LEsVKRfO7dikZHOzOcml0HAtBsVLRzK23auycc4r3dRdtC+iLS/X3srV/7NHux9/iui/tDQAAup6ZySsV9Z12mqynp7t64EOQJYnmbr9doa+vuxIg6EzuslJJ1Ucf1fyuXcVT3ZLYqic5+splJaOjEtU8eAIkANYQ+1cCANCiQlBcXlZfuSwr9UgxdsVqodeD/dnbblNeqRSl0kAH8DxXMjSk+V27FKvVYlvPLkhuNd7DfeWywuiYPMva/1pGDLWmeHHXUgiVSBELAACtyUy+tNTso1hf9UqHmR07VNu7V1YqdUWQhC7grtDXp9lbb5UvL3fdfA9fWpJi3vbBv0mSWSVPUy5Ma6S73hnrpLFf5fJi5dMztep8YlZyEgEAALSeLgsSGpLBwe4clIbO5q5kYEBKkmYfyfqrDwFsZyZlw2kqd7/i+bfcMr+zXC51wESDltOdn3rrJBsaqriMkxYAALQO92KrtDZfKQQOxbOsqABAWzJJCqFC4L92SACsIfavBAAALcNdlqbKFxf1yMSE0uHh7hmUhs7nrtDbq8oDD+jhK68snuL8bk/MAFhTvLhrjRMYAAC0End5tUoFADpTjMX5jbbFIPW1xYu7hvI0dZlV+HgFAAAtheAfnYzzu21FyRVCpdnH0cnSZh9AJzLJd5bLpeffcsv8P7/0rCuGS+kf7atlmeSlZh8bAACQivZSWkwBdBI/6NE+XPLUrDRTq84tL1U/Le0frI4jiwqANWSSK6heAdBeb0IAAAAAWE8ueTY0RAXAGiIBsMaCCP0BAAAA4Im4FBmkvrZ4cdeYuw8mZiQBAABA6wjcAqJDmXF+tymXZNJgkucMcVhDzABYI/dOTkZJ8hi/v1DL3h9caZTc6ttbAgCAJmq/Ftkjx11xcZFBaeg8ZvI8L87vbuOr/tuW1zePfSFJFmP2/XxmpuJSMCk2+6g6EemxNTJeP2GnlvPrFvO8kpglzT4mAADQ3TxGWW+vRl7yEsWlJZIA6Cheq6m0YYNGzjyzeILzu22YLPaHIHd9/4R77lmeLJeJndYICYA1tinLBoOZt10SDgAAdBYzKUaFnh6NnHmmYqUio1QancJMnmUqbdyo0XoCgPO7vdSX+/ubexSdj3fFGotp6i4NkgAAAACtIl9YYHUUncdMsVZT3o0tAG3OJSVmMhIAa44EwBoxyV0K+cxMRe7f7wtBcqePBQCAVtKlQXDo62N1FJ3HXaG3V5Z0YfV4G1/LXPIghYUsW3bF70v756nhyOPKv4Ymy+XkhHvuWXaP3+0PQWbGiQwAQKswk1erRcq+SzQCo2dceKF6jjlGsVpt68ABaLAkUTY7q6Nf/3olAwPyLOuqc7vdr2WJWbKQ54u/Uur/vrR/nhqOPBIA68BCstnYChAAgJbhea5kcFDzV1+luLQkS9O2vnl+skJvr5L+filyj40OEoLSkZHuCvzzXJI0f/VVqj34oKy3ty2vZVFSkIZ/lufDzT6WTkcCYA2tbAXo+XcXsmw5SMHbcFMOAAA6UhdWADQGpYX+fh31utcpm53tznJpdBYzxWpVvccco82vf33xVJed1219LXOPfUVL0veWH3posb4FYJv+Y1ofCYA1tHorwIU8X2IrQAAAWkwXrRQewEzpyEgRJLVr0ACs5q5kYEChr6/ZR9IcbXwtM6tvASh9jy0A117a7APoBpuGhgaVVdNGkR0fswAAtIZu/ExurIwe/frX6+eXXSav1aRiWHGTjwx4aixJVNu7V8dcdJFCf788y4q2ni7iBz3ahemA4x5p8uF0BSoA1kGlVstdqjROcAAA0HwuFUFvt/XBm8ljVDo8rKFTT1U2P8+OAGhrHqNCb6/GXv7yYiW8jVfDn7I2vY41YqNc8mBi/8Z10F2psXVmku8sl0vPv+WW+XvPPvPy4VL6J/tqtUxSqdnHBgBA1/MoJUHW34XbTrvLSiU96+KLNXPrrfI2DR6AxvT/ja96lUZf9jJ5jF3X/y9J1t9XXNParAbAJU/NSjO16sxypfZpSSpPTmbNPq5ORrp3HZjkJqUpOwEAANAa3GVpqnx6WkuTO4unuigIbqz4D596qnqf8YxigFg3rpqi/ZkpVioaPfvs7qvocZdCkFerqkxOynp72/I6Vk9ZDHhv73Kzj6UbkABYY42dAOR2/XwtWw6uxF3+mEYdHjx48ODBg8e6PiwtKU7PqDI5KUnqqh74+m4AShJtfuMbizaALlw1RZurB//9v/IrOur88yWzrjuP7YAEQJ8UvenX1id1HXbFPgsy1/eTkZGqE5+uOV7gNdbYCeBXenq+t5Dni4kZrzkAAK3AXUoSWZdODbckkYWgZ771rer75V9WXF6mCgBtxZJE2dycnvGWt6i0cWOR1OrGc9isaGVqzyRmsQOAx++e8K1vLU+WywlbAK4tgtF18rM8Hw7ScPsV5QAA0MHa84b5yKhXAaSjo3rmW96ibHa261ZP0cbMFJeX1ffLv6xnvuUtxVPdev6atW3rg0syM1lINjf7WLoFCYA1ZsWtRVh+6KFFN32vLwRZvSoAAAA0mVnR/96liYBGwPTMt7ylqAJgFgDahCWJ8vl5PfMtb1E6Otq9q/9S217DXPJECgtZtuyef1da1T6NNUMCYB1MlsvJCffcs2yu6waKoTuc2AAANJnnucLgoOavvkpxaanYN7wNb6KfloOqAGp79shKbFaEFheCYqWinmc8o1j9d+/K1X/Pc0nS3FXfUO3BBxV6e9vuGmZmyUKeV6eW8+uk/e3TWDskANaRmdLM2+xdCQBAJzOTLy9L9RvpbmRJIo9Rx/7O72jjq16lbGqqSIYALcrq5f/P+fCHlY6OFkFvl67+S5JXKm0X+DeYpGC2vEEaaPaxdAsSAOugsZfl8nL2qZksWwhmJWe4BQAAzeculUrFAK1uZUXDYhgY0LP/8A9lpVJXl1OjtVmaqjY1paPOO08b/uf/ueh9D90d0tjAYFsmAEzKRopk42eOn5yc3VkulxgAuPa6+92yzrKlpUp0VXjRAQBoAe6yNFW+b5+WJncWT7XpIK2ny5JEnucaLpd14uc+p3x+XtblQRVaj6WpsulpjZ17rp77kY8UJfDdmqhyl1a2ANwp6+1ty+uXSy73aQL/9cOVfR2Y5DvL5dJJu3cvBNPlw2kqk7JmHxcAAN3OSiXFmRlVfvCD4ok2XEU7UixJ5Fmmsa1bddT556v6yCNd2VeNFlXv+7dSSc/+D/9hf5tKtyYAJFkI8kqlSAD09bXV9cslT8xK07XabLWa/aW0v2oaa4sEwDqq7wiQpmakuAAAaAX13uGwcWOzj6QlNCoBnvuRj+jo3/xN5QsLJAHQfPU2FSuVdOJf/ZWGy2V5nnNuSrKBAYWhobbcBtCLx4D39i43+1i6CQmAdbKypYXb9fNZthSkhDkAAAA0l8co6+tT5Qc/KLbSCqGtVtGOOLNiT+401XM/8hElIyPKKxUCLTRVKJW0/MADOu4979HYOefIazXOyfp1amlyp/J9+9puFxOTYl/RZvTdZGSk6sSl64YXep00trRYnJm5bjHPEzPjtQcAoNncZb29qtwxWQQV9L0XfcV5rtDToxM+8hFJUqxWCbjQFFYqafmhh/SMN7xBx1x0kTzL2KVC++eVVO64Q/n0dDtu35kPFdeU20741reWf7RlS8ocgPXBu2cduRTuGxlJMtP3+oL9u8U8Rkl8mgIA0DS2kgTwWq3ZB9MyLEmkGDV27rk68bOf1T9cdJHypSUl/f0re48Da8pMFoKqDz+soy64QCd84hPFednlW/4dwL14TZJE8kYLQOvH0C55kKVzebZkUbdJ0u7du7mwrBPS3OvEJP/Rli3ps3fsWFKMtw2FRHLljeYXHjx48ODBg0czHlGhp6TaAw9o7u/+VpIIcBtCKIYCnnOOTvzc55QMDTETAOvCQpBiVDY7q6Nf+1o975OfXHmO4F9q7GASFxY093dfVxgcKK5b7i1wTT2MhySTwmKWJQuzs9+X9ldLY+2RAFhHjcyWyW+by7Ilk1JfeRsAAIB151KxG3VerKLhAJam8hg1ds45Kt94oza+8pWqPvpokQQgEMMasCRRXqnIs0wnfu5zet6nPiVrnGu06BzA+vrkWa5iqbHZR3P4LBb9/yZ9b2RkJHFi0nXFi72OGpmthdmF7zMHAACA1uAxyvr7VLnjDnm1Wqw0ttEwrbVm9ZkAyciITvjEJ3T0b/6mstlZKUZ6sXHkmMlKJeULC0qGh/X8z35WG37t14pV/xBIOK22agBgnJ1tv6ocq/f/u2579o4dS/T/ry8C0HXmUhgZGUnM9L165otyFwAAmqkxCHByZzEHgFXGx2j0XpuZnnf55Trxc59TzDJl09Oynh6CMzwtjQC2ct992vjKV6p8ww3FtP885/14CIccANgmSUuX3KS0qIZ2+v+bgHfUOjpgDoDrtvrkS054AACajUGAT8ysCMZi1IZf+zVt+cIXNPryl2v5/vuLPdnTlEQAnhRLElmSqLZvn2Sm4z/4QZ3w8Y8rGRkpzql2W9leTwcMAGyP4L/BzMJinicLswv0/zcBCYB1xhwAAABajLtCb28xCPDqq4qnGAT4+OotAaNnnaWTvvQl/cqf/ZlKY2Oq7dlTbKVIIgBPwJJEFoKy2Vll8/Pa8IpX6PlXXKFnXXzx/moTgv9DawwArFQ093d/qzA42FbXK1O9/9/o/28WXvB1tnoOwAJzAAAAaB3uivPzbbea1gyWJEXQYaZnXXyxTvnOd/TLf/zHSjduXEkEyIwgDvs1zgf3IvBfWNDY1q3a8t//u7Z88YsafelL5VlWJI9IID0hX15WrFTasUUiH6T/v6l4d60zl2xifDyced99PZnFbwwk6b+dz7LczPiEBACgWczktZrSo47WL/3N1xX6+8V+44fBfX/5v6RsZkYPff7zevjLX1Ztzx7FSkXJ4OBKVcDKSiVJls5nVkzvTxJ5lslrNcWlJaUbNmjo1FN17NveprGtW4vvdZe7FwM48Qt5lsnSVNNf+Lwe/a//RenGjUXipH3EvhDypSxe8Jzbbrv2Sim5kJbodcXo1nVmku+8997w7MnJpXvOPOOanhD+jZlFSSQAAABophDklSX58rLU39/so2kPZkVwX08EpKOjetZ736tjLrpIc3fdpQcuv1zzd9+t2tSUlOdKhoclM4Xe3v0/I0b5000IkFB4eo5Aomul2qOeTPM8V6xUlC8uKh0bU+moo/SMN79Zz3jjG1U66qjie1cF/kay7fA1qpVie7XOu+Slov9/z8/7+v9eov+/GXinNUF9PcHvOeuszUHxn8xsKHd34/cBAEDTWJoqm5rS0f/b/66xt7x1ZaUNT4J7sa3iqtL/2p49evTrX1c+P69H/vqvFSsVVR98sJhkXk8GhL6+Iph5ikGgNQYU4il52j3k7srn5lZ+VmnTJlmaauTsszXwvOdp5MUv1sjppysMDKx8Pyv+T0G9KikuLem+179O2Z5H22oHAEm1jaVSaapa/S+Tv/TLf3L8vfeG0ycnmby6zvhUa6LKzMxi78jQYslsqNnHAgAAJMXIHICnY1Wft9e3DSwddZSOfcc7JEnHvutd8uVlPTIxobi0JKWp5u+8U7M7dhTB4ZN93RsBUbVaVG6wivzkmSkdGakvTz2FtpcYZb29Ou7d71bo7VW+uKjRs87S4AtfWPzcVTzPi6C/0R6Ap8SXl+WVpbZLepkkd8/dffrCiYl8Z7ncXv+ADsE7r0l2lsul8uRk9k8vefGHj+rt/YO9tVpNUqnZxwUAQNdiDsDaqLcHSHrciopsdnYlcfCkfnR9q7gHrrhC//r//r/qOfroduuHbh4zeZYpHRnRydu2KRkcfEo/Q+5SCEoaq/sH8SyTGiX+vJeelnbu/3fJg5l5jJlbctxzbr31kUZVdLOPrdtQAdAk5eOPjzY56f+kcO1izH/fpMDZDwBAk4UgX14qVteYA3BkNOYESCsB/uqSc0vTx6wUH7Z6gsb6+qjaeKrqFQDhaZ7vBwSiqwJ+2miOsBgV5+farv9f8jgQkmQ+xut+tVrdd+X4eGITEwz/awLekc0yMREl6fi+vut+urw01RvCM2qROQAAADSPK5R6VHvwYc1/+zsafeMbD5hwjyOgvgL8mNf0KQbvK3Ma2i4Yai2eZcXv4GlUvPA+WWPusjSV57nmtm1TGBxatatGcw/tcJhZ7DXTotk2m5ys7Swqn0kANAHv1CYxyXeWy6WJzZtj+Wf/8pWxJLx/T8wy0QYAAEBzuCSPslKqxVtu1shv/qbUGLBF6fLaeqqvL2XlR8bq15HXszXVr0NLt9+m7OGHi+F/0dUO0b9LHmSlqWo1k8JXJak8OdkevQsdiMELTVQ+/vh44cRELku2LcR8KRRtAK3/LgYAoEN5jLK+PlXuvqsoY26zIVsAOlNjtX/5Rz9SPjNTr7hoj7DBpNgfTNH098dn2ZRLgd7/5uFTrZnqbQBLs7M3LGQxkVnyRH8FAACsLQtBvrysyp13SiqSAgDQTJYk8izT8u7dCgMDT3/rxvWVDyaJTHabTU7WfrRlC1XoTUQCoMmuHB9PRkZGksS0vT8EyZ27DAAAmqXeZ5tPT2vx5puK3nKGywFopvpOC3F2Vku33ybr7W2361I6l+U1ebxdknbv3t1W2YtOQwKgiUzy4++9Nzx7x46laGFbryk3MxIAAAA0kee5wvCwFr7/vWIv+zRtt5ttAB2ksdo//51vK9u3T6Gnp22uSS55ahYWYj51X9/g30vSuES800QkAJqsMQDDor46VcvczErMAQAAoIncZaWSag89pMrkzuIp2gAANEsI8izT4q23tl1C0qRsNE2UmL7y6ObNvrNcLtH/31wkAJrMJL9yfDw5Psum3PT9AdoAAABoOksSxbk5Ld5yM20AAJrHXVYv/69M7pT19bVVQtKksJjHqmK45sKJibx8/PHtc/AdigRACzj+3nuDTU7WJLu2L5hoAwAAoLlW2gC+9z15nrfdqhuAzuB5Lrm3b/l/sGQxz2eP7+u7TtLKEHQ0DwmAFtBoA4hpz5f21rJHE9oAAABorkYbwIMPavmHPyyeaqNVNwAdIgTJTEu37Wi7RKS554Mh5DL7mDZvdt+6NaX8v/lIALQAk3xnuVw64aabHnX3L46liUzKmn1cAAB0MwtBXq1q6opPybNMMmv2IQHoIp7nshC0dNsOzX//+wpDQ22z/Z9LbiGkM7XM+3L/mE1M5Nq+vT0OvsORAGgRjX4YU7h2MY8143cDAEBTeYyygQEt//B/KM7Oyoo5Pc0+LADdwl2KUYu33iqvVotrULtwjwMhKDddN72wMHfl+HjC6n9raKOzqMPV+2GO7+u7bj7mU4lZQhsAAABN5K5QKimbmtL8d74tubfN6huANlffgtTzXAvf+25brf5LkpnF3qA8sbDtBbt3V4+/917izhaRNvsAUGi0AWjz5pj+7F++PJIm75+qZZmkUrOPDQCArhVdlqRa2rFDo298U9GPi9ZDZcZTx2vXkjxGWZJo+Uc/VO3BB2Wl+vC/Nvh1ucmDrLSvmldd9lVp/8wzNB+fYi2kfPzx0SYm8sztW8sxmvj9AADQVJ7nCkNDmv/+94shXCG01Spct7CeHpIzT4V78dox36L1mMmzTFOf+pS8Ui//b4PgX5IUPQ4lQdG14/gsm6L8v7VwpWwhNjGRXzk+npxw++3fmanl3xlMksTl3GUAANBEjWGAiztuLZ5gxbRlWJJIkp5x4YXqO/ZYxeVlgtnDZEmibG5Om8fHlQwMMOiylbjLQlBcWNDy//gfssGBttqFJJgpd6+a9Cc2OVkbb/YB4QC0ALSY4++9N7gU/8n82r6gVy7kipInzT4uAAC6leeZwvCQ5q+9VmNv/W0lGzYUSQCCpZZhvb3FFml4ctwV+vo4l1tMY/r/7MSVyqenlIyOtU3lkUteCiGZz7J9y/OLt0myxqwztAaulC2mPDmZmeQ/6en70p7a8h8lZkdn7m4SV2YAAJrBXdbbq+V/vldz3/qWxt74xuIGnYCzdeS58sVFAtknw0weo/KFhWYfCVZrDP+r1TTzN38t9fYpttHqv9zzgWBWzfWxk046Kfejj05s+3b6/1sILQAtpjEM8ISbbnpU0b84miZuEm8aAACaqZ4EWLp9RxFk0m/eOmKU9fZq5KyzFCsVkgCHw0xeq6m0aZNGzzyzeI5zuiV4jJK7Kj/8obJHHylmNLRJ25FLbhaSmSzP+9w+ZhMTubZvb4/ShS7CO70FlY8/PkpSMGcYIAAALaAYBjis+e99V0t33MEwwFZhVvxueno0dPLJyufnV+YC4BfzGJX09WnkJS+RJBmJk9ZgJplp32euUKxUiuF/7cI9DqXBovuO6YWFOYb/taY2OqO6R2MY4PG3T35ntjEM0BkGCABAM5kVt7L7/vLTjSeae0CQtH8Q4NDJJ6vn6KPltRq/mydiplipaPiMM4pEVjuVmHewRu//0p13aOGmG5WMjLZVorEx/C8o/MkLdu+uMvyvNZEAaFH1YYCWmK7tCyYz48oMAEATeZ4rDA9r8eabtMiWgK2jHuyPnnWWQl9fW01LbxZLEuULCxo6+eTiNctzkiatoN6aMXXFp4q2ozb6nbjkqVkyn+WzS/PzDP9rYSQAWlR9GKBiT9+Xpqq1qdSs5JTQAADQVBaCYqXCloAtxmOU57mGyuX2K5tuAs8ylTZs0NDJJ0sSbROtoLH13+JisfVff3tt/Sf3fChNlLh/fPdJJ+U7y+WU8v/WxNWxRZnkvnVrcsJNNz2aS5cNJSEPDAMEAKCpiiqAEc1fe63y2dliJwCSAM1lJsWo0NensXPOUVxaYjX7FzFTrFbVs3mzRl/60pXn0FyNaqKZv55QPr1PoY2uLS55GkIyXcseXUpKl104MZGXJyeJW1oUCYBWVp+aGXP/+EyW55KlVAEAANBE7gq9var+679o5sqvFU/RBtB0jRXso847T/3Pfa7i8jJB7eOwEBSXlrT5TW+SVFQD8Fo1WX3rv3x2VjNf/Yqsr7+tVv9NykbTRB79iy/YsWNqZ7lcYvW/dZEAaGEm+ZXj40m2tDQb3XcMJEFyb5+rAQAAHaixI8DM175KFUCrMCvK2jdu1FHnnadsZoay9kNZ9To9881vliUJr1MLWFn9v/Jrqv38PoW+vna7poSlGC2Yf0vav6MZWhMJgBY3LukFu3dXE7c/dXeT6hla58GDBw8ePHis+0OSoiv09Kp2331UAbSS+ir22MteptDfXiuo68VCUL64qKFTT1UyNFS8Rqz+N9cBq/9fVRgcLq4nzb7WHebD3fOhkIT5LNt+/O2T37lyfDyxiQkuiC2MBECLW9kS8Ac/uGEuy7aPJEnikS0BAQBoinoSYKUK4KtUAbQKSxJ5jBp92cu0YevW4vfC6vZjmelZF18sK5U4Z1vAyur/1+qr/729Umyf34sVi5NWinaJS8bWf62PBEAbGJfkkpUU/ix3rwYytQAANFd9FkDt5/dp5mtUAbSMekB73HveI7ETwAEsSZTNzGjDK16hkRe/WB4jCZJmW736/7WvKgwNt9V1xN3zwSRJZrLsO8fv3Ll9Ynw8sPrf+rgytoOJiWiSFhcWdszn+Wxqlvj+QkQAANAEzAJoPY0qgJEzztCGV7xCGVUABwpBx7373cWfOVeb7pCr/230ezGz2GemxHStS3b8vfcSW7YBfkltwCTfWS6nu086KU/kHx9KgmxlS8AWaP7hwYMHDx48uu4hyaNCb09RBXDl1yT3tlq961jukruOe/e75THK2yigWiuWJKpNTWnDuedq5IwzWP1vBe7FTIbZWc187SsKQ0P160ezr22H93C5p2alqVptKvb0fckksfVfeyAB0CbKk5PZhRMT+VJSumy6VptKTKm3U4oQAICOUnwEF1UAQ5r5ypcVl5eLoIqP56ayJJG7a+SMM3T0a1+rfGGhu4NdM7m70tFRHffe964kSNBcnudSCJqZuFK1+35WX/1vn8GVJmXDSZCbLjvhppse3Vkup2z91x5IALSJehVA6QU7dky52WUjSWL7qwAAAEBTuMt6epQ98oge+bM/KSaqE1w1ndV/D8/58z9XOjqqfHGxa2cCWJpq+f779az3vlcjp58uz/PuToi0gMbvYOnOO7XvisuVjG1oq+ohlzwxS6dr2VQlpB+VZKz+t4/uvBK2qfobyyoh/eh0LZtKzFIn0wYAQHPVqwDmtn1TS3dMFiuubXQz35Hqq96hr08nfOQj+/dV77JBypYkyufm9Iw3vlHP/O3fJvhvJWbad8WnlM/NtV3lkEnZSJKYmy57wY4dU6z+txcSAG2kMQugqAIQVQAAALQIM5NC0L5Pf7oIMrss0GxFFoI8zzV27rk67j3v0fIDDxRb33WLEJRXKkpGRvTcv/gLJQMDshA4N5ts/+r/HVq4+UZW/7HuSAC0GaoAAABoPY0dARZvuVkLN95QBFqxffp5O5UliTzLdMxFF+kZb3iDanv2FLs1dDozqR5UnvCRjyj09BRBJsF/c9WrUOLSkqY++QnJpXb7jbD63/5IALQZqgAAAGhR7lKa6uE//iPlszP7n0PzmMmSRMnAgE74xCc0ds45yqanOz4JYCEoX1jQiZ/5jMbOPbeYVUHpf9N5nsvMNP3FL2j+e99VMjrK6j/WHQmANkQVAAAALajec549+ohmJiakegk6mqw+k8GSRM/+wAdkpZJitVpUaXQgK5VUffRRHXX++Ro791x5lkkE/81XT8LESkUzX/2Kko2bit9NG2H1vzN05pWvw1EFAABAa/I8VzIyqn1XXK6lO+8sStBJAjRd4/cwXC7rxL/6K3mWKWZZZ1UCmCn09Kj6yCM66oIL9NyPfIShfy3E6+X/j1zyp8oeeaSYR9FGFUKs/ncOEgBt6uAqgJQqAAAAmq++ypfPzWnfFZczELCFNOYBjJ1zjk783OfktVrntAPUqxkqP/uZjjr/fD3vk5+UJQlD/1qE57ksBC3deYfmtn1TYWhoZUZDu2D1v3NwRWhjO8vl0umTk7WfnH76JRtL6aXTWVaTVOKdCABAc5iKO2ILQXFxUcd+/OMafNnLi4GArMS2BK+v/M/s2KGfX3aZpq+/Xj1HH61Yq7XVimyDpalipSLr6dFx73ynjnvPe4pV/xhXEgNoInd5nsurVT3wvou1dOutCsPDUp63RfRskqLkJTPl7vsqSfrcF+zYsc+Lr7XDPwEH4arQxhpVANU0/eh0rTYVzJLIGxEAgKZpfAh7fSDgQ//H/6G4vFyswrZhcNmJLE3lea7RM8/USV/6kja9+tWq/OxnxRfbLGC2NFU2PS2PUc/7xCf0rIsvLrakdG+7f0un8jyXpammv/JlzX/3uwr1wX/tcjWoB/rZYAiKzup/J+DK0MYOmAXg+uimNA1iFgAAAM3nrtDbq3xmRg//6Z8UwRgJgJaxMpvBTM+7/HL9ygc/uLI9W1v0zNd3N6jt3avRl79cW774RY1t3Sqv1YpzjbL/ltAI/pfuuktTl1+udPPmthv8JymmZulMni9V0/SjTu9/2yMB0ObKk5PZlePjyVCt9uePVms3DiVJ6u7t1VQEAEAH8jxXGBjQ3DXXaOHGGw7Ymx3NZ0lSzGww07MuvljP+8QnlI6MKF9YkEJozUSAWVHBUKspm53VUeedp5O+9CWNnnVWEWyWSs0+QjS4S+6KS0va+/GPKc7PFzMZ2i8R6CUzy1xvesGOHVMTUmD1v72RAGhzJvnRjzxix+zatZCb/YncjckOAAC0CJOsr49WgFZlVmzXmGUa27pVL7rhBm181auUz84qm52VtUoiYFXgX9u7V8nQkE783Of0vE99aqXHvCWOEytWSv+//CXNf/e7SjZtbLsdQdw9H0qSMJ/l20/cufOqK8fHkwul9vpH4DEIFTuEj48nNjGR/7h82vUjpfSchSzLZdYBY20BAGhvliTK5+c1/KpX6Zg//zDBWota/XuZ3r5dD3zmM5q+8UYpRqXDw0WiIM/XNYFjIUghKFYqyufn1fvsZ+uZb3mLnvnWtyodGSmOhXL/ltM4lyp336Wfv+13989jaLPkn7vywSQkC7mf+9ydO2+4fuvW5BXbt1P+3+aoAOggLlmweEkiWTEBBgAANNtKK8C2bVq4+ab9/edoKY2WALlrbOtWbfnCF7Tlv/93jW3dqmxhQdVHH13ZQcDWasBefdtIS1MpBGXz86o++qhKGzfql//4j3Xqd76jZ/3+7ysdGZHHSPDfiupBvue59nz0svYt/XfPxkppMpfl20/YuXP7xPh4IPjvDFw1OsiV4+PJhUUVwDdGSun583mem8QSAwAAzVYv/fflZf3S57+gvlNOpRKghXmMxVpKPcCe3r5dM7feqj1XXaWle+9V6O1V6OsrWgRKpWJLt9UB3uEEe6uC98Z5EJeXJXdlc3MKPT3a+G//rUbOOEObL7xQ6YYNxY/OsuL7Cf5bUuN9/eAH/oNmr75K6aZNbTf4zyVPpNgXwtK8579xwu133KTx8WATE2QuOwBXjg5yiRQulfyBcrm/EnRfMButuQfj9wwAQNNZmiqfmdHAWWfpuE99uniOie0t7eBEQLZvnx658krN3H675m6/faUnPwwMKPT1SfVV+dDb+/g/1Exeq+2vAnFXPjcnmannmGOUDAxo02teo9Gzz9bYOefsP5Y853xpcY3gf+Hmm3T/O96mMDLaroM/a2Npmj66vHzpljvu+j93lsul0ycna80+KBwZXEE6zM5yuVSenMx+Un7RJc/s7b3k4VqtZhIjYQEAaAGWpsr27tXIeefrmA8xD6BdeIxSjEVpfl02O6v5u+/W7G23afEnP9HsLbcoDAxIea7lBx7YX6K/qhrAzOR5rnTDBqWjo/IYFXp7tfm3fkvJ0JA2/9Zvyfr6lAwM1P/Hqwb8Efi3tNV9//e99S2y3t52HfoZUzPL3Jd6k9Iv/dKv//q0PvhBZ/J/5+BK0mFcsonx8fDyf/zHvoWe0rUDSXjpfJ67mXF3AQBAK0gSxdkZHXfFZzT40peRBGgnjYA8feyc5Wx2tpjvUK3qkYmJopz/oN5vC0H54qJGzzxTQy960crPWgn4G/+bLCu2IlyrWQM4styLhI+k+9/5di3eequS0dG2K/2XJJfy/hCS+Ty74MSdd151pcTk/w5DAqADXbd1a/qK7duzf3zxi84ZS0rbZ/M8F7MAAABoDcwD6AzuRd//QZUBT+lH1QPFlXOA1f620gl9/5Ik92y0lKb7qtn2503ecW5jvlizDwtHFmnFDvSK7duzK8fHk+f94M4b9tWyqwaTJHEncwcAQEtwL/Z0zzLt+ehlB/SCo42YFUMAG8F/fQcBucuz7Bc/Yjzg+y1Ni5+zat4A2sPqvv+5a7cp2bixLYN/lzyYWS36vFx/eokUxpt9UFgTXGE61AEDAY2BgAAAtJoD5gF8+MMrW8wBaA8rff93tX3fv9QY/Fdl8F+nowKgQ31QipPlcnrs5ORS5vGjG9M0can90pEAAHQozzIlGzdq7tprtHDTTStVAQDagHuxQ0SMRSVPI4HXhsG/S7Fklkxn2dJQT9/H/JJLQnlykotRh2I1uIMdPBBwOElePpNlOQMBAQBoEfUAwrNMx33ikxo4+2zmAQCtbtXQvwf/4A809+1vKW3T0n9JMikfTJJkOq8x+K8LUAHQwUzycUnH7Nq1kLn+KHOfT0OIYhsPAABag7uUJLIk0f3veqcqd91VTJJvz73Dga7QSNI99B//o+a2fbN9h/5Jcve8L4Qwm2VXEfx3BxIAHc4mJvKd5XLp+ZOTN83E/EOb0rREKwAAAC0kRllPz8pQQMW4UloMoLU0Sv0XbrpJc9deo+Too+W1tm2Vjz0hWCXGpSHZm1wKP2KhsOPRAtAFXLLJcjntG1rq7V3ov2YwJC+dzzOnFQAAgNZhaaps3z4Nv/LXdexf/MX+PeSZCg+0hhilELR48826/z3vlqUlKbTt0D+5lA+EkMzF7ILn77zzao2PB2Pbv47HqNkuYJJfNzTkp2+fnP/HF7/oTxIL280apT3tecECAKCzmDyrKd2wQXPXbNMDJj3zv/xXWalUzAMgCQA0lee5LAQt3HSTHvj9d0tJIiWNSh1Te91Tm+SejaVpui/Ltp84eedVV46PJxcS/HcFWgC6xCu2b8+uHB9PnveDO2/Yl9Wu6g8huEfe5AAAtIQiePCspvQZmzX79b/R9Be/UOwM0L7lxUBniLGYzVGt6qH/+AFJkpVKq9p02in4l1zuIZjXPM4r0Z9eIoXxZh8U1g0JgC7yo4kJv0QKw0retBzzpb4kSVyiwRAAgBbitZrSY47R1Kev0OLNN6/MBwDQBDGu7Nbx4H/8gOL8vEJfn9TWgzo9e2apVJqJ8UPPu/2OG88rlxNK/7sHCYAu8kEpnjQ+bsdOTi4tR3uD3BeSIgHQXmlLAAA6Wb3v32s13f/ud2nxlpuLSgCSAMD6agT/7nrg/e/T3LZtCgMDbb1Lh7vn/SFJH6wuf3NDNfvQdVu3puXJSS4uXYSGsi60s1wunT45Wfvx6addckypdOlDtWotyEpkAQAAaL5GN7GFIM8yeZbpuE9ersGzX7oygRzAGjso+J+9dpvSozfLa7W26/iXVq4rsWSm3GNl2sPRp09OLl4ihQ9SEdxVSAB0ocauAMfVaj3zPcm1w0n68pksy9kVAACAFlNPAogkALB+VgX/97//fZpbFfy3uXwoSZKZnKn/3YwWgC5kkpePPz4es2vXQu7hjzL3+SSE6O2XzAQAoLPFKEtTWZrq/t97lxZoBwDWVocG/0XpfwizWe2qE3feedWERPDfpagA6GKNVoDdp512ybN7ey69v7pcM1mp2ccFAAAOEoLUaAe4nEoAYE0cHPxf0yHBvxT7Qgi1mC/2Kxx97ORk5VIV88GafWxYf1QAdLHy5GR23dat6YYs+9CD1eVv9ockdXcygQAAtJoYpUYlwLuoBACOuM4N/j01y+W+UHV7w7GTk0sT4+NG8N+9SAB0MZP8+u3b4zG7di3MKLyhytaAAAC0LpIAwNro0OC/4NnmUqm0FP3Pt9xxxzcny+X0Qkr/uxoJgC73QSn6+Hhy9eRkperF1oCpWc48AAAAWhBJAODI6uDgv7Hl30PV5W+OZtmHdpbLJbb8AwkAyCYm8vPK5WTLHXd8cyn6n28ulUqSc3EAAKAVkQQAjoxODv6l2JckSTXmSzMKbzhm166Fqycnc2ORr+uRAICkYh7AznK5NJplH3qIeQAAALS2g5MANxdJAEW6+IDDkufFcM3ODP4P6Pu/enKy4uPjCX3/kEgAoM4kv3pyMmceAAAAbWJ1EuA979b89uuLgCZGyVnkAx5XjFKSKM7N6f4/eL/mtnVO8F84sO//vHI5Ycs/NLANIA7g4+PJpRMT/obTTvuNwRC+msl7MvfUOFcAAGhNIUh5rri4qOFXvlLH/H//TVZf2VRgrQdYrbF95sItN+vBD3xAcW5ONjBQVAR0AHfP+5MkLMd821Atf+P9pVK1PDmZUfqPBoI6PMbOcrl0+uRk7cennXrJcb29lz5QrS6brJfrBgAArcYkuWQmC4myPXs0/Orf0HF/cdlKYkBJ0uyDBFpDjFIIWrj5Zt3/e++STAp9/fI80/6wqF3vd00ujz0WQu5xcVrh6NMnJxcvkQKl/1iNBAAewyWbLJfT42q1nvlS+NpIkr56X5blwYw7CAAAWpiVSsoeeUTDrzlPx/zf/0lheHgl6AG6lvtKRcz89uv1wPsuLqpkSqXOWfmXvCTlqZnmY/abJ96x6xqNjxul/zgYCQAckjdmoo6PJ/9870+v60vSl89lWWZmabOPDQAA/AJJIl9cUBge0TEf+rAGz36pvFqV9fQ0+8iAded5LjOTu+vBP/wDzX3n2woDA0VlTAcNzTR5bTBJS3tr1fNfeOeuq11KTCL4x2OQDsYhmeTXbd2a2sREXlX8ozzGvBRCGtu3LgoAgO6Q5woDg4oLC7r/996lhZtuKoJ/hgOiy3iey5JECkEPvP99mv3m1UpGRvYPy+wQ7p5vTEul2Sy7+oV37rp6Z7lcIvjH46ECAL+Qj48nNjGR7zrllFeP9aRfq3nsyVwMBQQAoNUliXx5WdbTo42/87va+PZ3FMEQcwHQDeqtL4u33669n/qkFm+8UcnGjfIsa/aRHVHung8kiS3HeM2vDo385vWSzt2+PWfoHx4PQRye0DXPeU7vb9xzz/KPTzv1kuN6GkMB1dvs4wIAAE8gFGFA9tBDGnnd63XMfyrmAjQmoQOdplHyrxA0f/31euDi98qrVSWjox0X/Ecp9gYLeR4Xp0Ny9OmTk4tevOs7p7wBRxwJADyhA4YCJsnXNpTSV++t1XJjKCAAAG3AZGmiuDBfzAX48w9p8GUvK1ZIzYoH0AFWSv7ddf/7Ltb8d76jMDgoS9NODP69p7gZzxc8ey1D/3C4uOLjsKweCvhP997zd70WfmMxz50kAAAA7cGSRHFxUdbfX7QEvIOWAHSQ1SX/l9dL/jdskHfg7AuXPDVlJQvVec/esGXy7m1XSsmF9P3jMJAAwGFrlBTtLJcHxmL+aBLCwLJ7DAyTBACgPYQgudMSgI5x6JL/ZSWjYx236t/g0vKxPT2991eXL33+HXd98CfPeU7vCffcs9zs40J7IAGAJ8XHxxNNTPhPyqf8uz4l38glq7nLSAIAANAezIpqgEO1BEhFkgBoAyuJqy4o+W9w99qmUqm0r5ZtG8rzN9xfKlXLk5MZQ/9wuEgA4ElrlBjtPuWUVw+lyTcyKam6e+B8AgCgbRzYEvA72vSu35PMqAZA61uVrFq87Tbt/dSntHjjDR1b8t/g7vmmUimZybNtk8c/54ILJybyRptus48N7YOADU/JznK5dPrkZG33Kae8eqjE9oAAALSlRkvAo49q6Nf+jTa9850aeMlLqAZAy1q96r/38ss19ZefUT47q3TDho5d9Zf2b/dX83jNzuOf89ofTUz4pZKY+I8ni2ANT1mj36ixPeD91epyYHtAAADajpVKyqamlIyMaOPvvk2b3vWu/dUAScJOAWi+PC/Ow1Wr/vPf+67So4+WhSDPO3f+XZRir1nII9v94enjao6nbPX2gHP7twesmVmp2ccGAACeHEsSeYzKD64GkFYmrAPrrlHObybFqL2f+pT2/uVnFGdnlWzcKK/Vmnt8a8ylWDJTIvmy8gtOmLz7Wrb7w9NBAgBPS6Pv6Mrx8eRF997zjdEkffUUSQAAANrW6mqATW9/h8be9CYlIyNFIOZOIgDrZvU8ioWbb9bUZz+rue9+R+nRmzt+1V+SXB5TCypJPpPlF5x8N9v94ekjAYCnzaVwqaSTxsftRff+lCQAAABtzpJEnudFb/XmzTrmP/1nDZ37CkmiLQBrL8+lJCn+ODOjhy75M81de40UgpLR0Y5f9ZeKlf/UTCXJ53M//6S77rqmMYOr2ceG9saVG0cESQAAADpMY7vASkXKMg2ceZY2vf0dGjjzTElitwAceauHT7pr7+Wf1L4rv6bs4YcVBgeLpFOHr/pLBP9YWyQAcMSQBAAAoAOZSWbKZ2b2twW88U1KRkeLr69arQWeEnd5nq8q979pf7n/xk1Smu5PDnS4KHmPmacE/1gjJABwRB2QBLjnp98YSpNXT2dZHswSdigFAKDNmFZ2GLc0kWe58plplX7p2dpw4Ru06fd+b2U4myTmA+DJcZfHWLSUSFrcsUN7P32FFm+9RR69KPfPsmL2RCNq6eD7SZe8ZMpTmWby+NqT7757G8E/jjQSADjiXAqSNDE+bqf99KfX9afJy+eyLDMz6gQBAGhrViQCqlVlU3s1/G9fqY0X/Y4GX/ay4ssMCsThOCjwz2dmNP3Vr2jvFVcon52tV5eYFDu/3H81c68NJklpqpad/8Jdu64m+MdaIAGANXHd1q3pK7Zvz3588skvG0iT66uSZe6yenIAAAC0MTNZmiqfmZGZaeClL9XG3/5tDb7s5cXXSQTgUA4O/GdnNf2VL2vfl7+s2n33KRkbWxlA2W3cvXZUqVR6pFa7estdd59P8I+1QgIAa8bHxxObmMh3nXLKq0eT8I2aZLUYFcy4GwAAoBMkieSuODcnC+HxEwH1OQLoUk8Q+IfhYYXe3iLw9w6u8X8c7l7bWCqVZrJs289HRl8rSedu355bRzc8oFm4EmNNNbKXjSRAlJLlGHMzY1oQAACd4okSAVIx5C0EEgHdJMYDkj8E/gdySXLPN5VKyXSWbbvzOc+94EcTE36p5AT/WCtcgbHmGkmAH5166m8MBfuCzDYu5TlJAAAAOs2hEgG/8zvqP+XUYhs3kQjoeIeo+sj37tX03/y19n3pSwT+dVHyVPL+JAmVLL/6vtHR112/fXu8VMX0g2YfHzoXV16siyul5EIpv2XLlo1H9fR8fkMpffVetggEAKAzNRIBs7Oyvj6lmzZp7A1v0Ni/f7OSkZHie2gP6CwHlflL0sJNN2nqrz6nyq5dyvftk/X3K/T1dXXgL0kuxZKZEinmrtf96p13Xl0fos3KP9YcV1usm8ZMAB8fT+6556ffGE3TV0+RBAAAoGNZkshjlNdqigsLKj3rWdrw5jdr7PW/pWTTppXvoyqgTR0iiRMXFrR0912a+uxntXjzzfIYFQYGZGkqj7GrA3+pCP5TM5Ukn8njBSffffc2H1diE+q+yYdoCq6yWFcuhUslnTQ+bi8iCQAAQHcwkyWJYqUiX1pSsmGD+k4+WRt/53fVf8opK+0Bci+SAUlCMqCVxSh3P2C1P9+7V9N/PaHpr35V2d698kpFYWSk+D124VT/Q1kd/M9HP/+ku+66hmn/WG9cWbHuSAIAANClzGQhyLNMcWFhf3vAG9+osfELlWzcuPKtnmX7qwJIBjRfo8R/VaVGnJ/X0q5dmvrsXx5Q5m+lUvF7JvBfQfCPVsHVFE1BEgAAgO62uj3Al5YURsc0cMaLNVA+XaOve72SDWMr3+t5JjOSAeuuUZGRpgc8vXDzTVrcsUOz116r7JFHitX+wUHK/B9HdMVSIPhHa+AKiqY5OAkwlqav3lur5TIlJhMzUAAA6FSNz3nbXxVQqxUtAsvL6vmVX9HIq1+tgbPOVv+ppyoMDKz8zcYAOdoE1kC9p99jfEzQn+3Zo9mrvqHFnT/Q/Pe/L1+uKowMy9K0vtrfGFxf/71yHyfJ5O55bwhJkPJGzz/BP5qJqyaaqpEEOHfr1vBLM9Nf70vDeUt5jJncAp/qAAB0D5NkQRaC4vKy4syMwsiI0s2bNfKqf6eBl7602E5wVTJAolXgaamv1Huer8xpWG110L/4gx8oTu+TkkRhaHh/iT+r/Y/L5Xl/SBK5T83H7C0n3fVDVv7RdFwl0XRe/8g3Kf7Ti150XiL/ei6FmrvMFEggAwDQBRp3pa4iGE0TeZYX8wJmZxSGR5QefbRGX/tahaEhjV7w2gN2EmggIfALHBDwS5YcuMofFxe1dMcdWprcqeWf/lQLO25VnJ4ugv56b7+7SzGy0P+LmOTRa5t6SqV9tdq2PdXsrWfv3j3V2Ba72YeH7sZVES2jsU3grlNe8OrRkH6jJlkWYzSz9In/NgAA6Ej1lekiGVBTnJ+ThURhbEyDZ52l3uc+V/2nv1j9J5+sMDz8mL/uWVb8mMbqdrckBRor8/WS/kOt8MfFRfnysmb+9uuK8/Oa+du/U7bnUeUzMwr9/Qp9fQcG/XhCXjyWN6Vp70xW2/ac5z7vgsY22DYxQfCPpuuSKyDaRaMs6kenvuA3Bi29uhRCmM2yPJglT/y3AQBAR2sEse7FzIDliuLiktKNG2WlkgbOeIl6T/jFCQHpEEmB+s9uW4cR7EsHB/wLmvnbv1WsLCl7+GHJY1HaXyqtDGgk6H9youRB8meWSuGRWnXbnc993gU/mpjwSyWZxIuJltDGVzp0qpUkwAtf+G9GSun/VjL7N9NZxg4BAADgQCGsbCuoGIvZAYuLKwmB/he/WP0vPFkqpRobHy8qB54gKSDpgK3u9j/ZxNvmg/rsV2+vd/Cwvoa4sCC5a2nXLi394HZZWtL0X08oVipFwB+jwvCwzEzW0yOZ0dP/NET32BNCyGPMUgv/97+Ojv6nV2zfnrkUCP7RSkgAoCU1yqQukcJbTz35qpG0VN8hwBJOWgAA8Bi2akeBRkKgvquAQlDp2GPly8vqf/EZ6nvhC2WlVGO/NV4E0CE8ZrjgwVYnCA743x4qWfAUrA7qD/j5jxPgr5bPzMjSVEt3362lH9wupSXNTEzIa1Xl8/PK9+2TJYnC0NBjA36JoP9pcve8pz7pfzH6BVvuvnubS0GSG1MS0GKIpdCyrtu6NT13+/Z4/dat4Vkz01/vS4odAnJ3mVlo9vEBAIAWtiohIHfFalVmdmBS4Jhjim/t6dHY618v6+lVXFzUwBlnqP+UU4rt8MwOK0GwluLcnBSKWx+v1TT9N38jr1SkNFHl7l1avP02hYEB5dPTyhtD++rBvpJkJYlAwH/kuXvenySJuabmvfaWk+764TU/ec5zek+4557lZh8bcCgkANDSDrVDQJTS5RhzYy4AAAA4XI1V+oOSApKKP8/PF3/McyVjY0pGRla+1kgQKN3fjWghKC4tauDFq5IF4UmuT7gXK/GNoL5aLQrGXZJHyYIqu3Zp8Qe3K/T3F3357qo9+IAUiyDeensV+vrk7jKC/XXjkuSebyqVkqmstm2KSf9oEyQA0Bau1HhyoYodAkZC6fMybVzKc5IAAADgqVtVur96aJ5n2YEl+Y0Ewepgul5Cf0Cy4Kk6KKg/4BBXBfgNobd3/19tDOszI9hfJ+4eEzP1JyFU8nj1z0fHXveK7dszJv2jHZAAQNtwKTEpv2XLlo0be9LPb2QuAAAAWCsH9fUfaqq+dIhkwVO0Oqg/4OfXV/0PfJJAv1ncPe8t+v2zXPa6X73zzqtdCpdK+iDD/tAGiJvQVhqZ1eu2bk2LuQDJeUt5HjN3Z6tAAADQFEdihwCC+pZWL/mv9SdJSa6p2Vh768l3/3Bbo0q12ccHHC4SAGg7l9SzrCbFfznttNe4x78rhZDMZVlmZk88KhcAAAA4TFHyIPkxPaXwYLW60u/fqE5t9vEBTwaT1NF2PihFk6LrkvA/3XHHNxc9f5W7//1YmqbR/RDdcwAAAMCT5+55fwhm7vHRanbpg6MbXnv27t1TPj5O8I+2RAUA2tp1W7emr9i+PRuXkv986il/S0sAAAAAnq4DS/59ajH6W7fcffc2LxZQvb5XA9B2SACg7fn4eKKJCS9aAk5+jUcrWgLyeksAl2cAAAA8kXpkFL1R8t8THqztL/nfWS6XTp+crDX3IIGnhxYAtD2bmMj3twTs+uZiHl/lHv9+LEnTGD06GVoAAAA8EZcUPStK/hUfrVUvfXB010rJP8E/OgEVAOgoq1sC/p9TTvnb3iSctxyjajHmRksAAAAADqGxYNQfgsk1tejZW7fc/UNK/tFxqABAR3nF9u2Zj48nV0r+nLvvPj9Xfl4q29ufJImzwQ4AAAAO4u55ycyGk8SWo1/900rlhC13/3DbznK5ZMXwaW4h0TGoAEDH8mJXXr/t+c/fNNrb+7mhJJy3yIBAAAAA6OBBf9qrEH/7f7pj1zelYsaUTUww5R8dhwQAOtrqi/fqAYGzWVYzs9R4DwAAAHQdd8/NzI4p9YQHq9VtU1kx6M/r94as+qNT0QKAjmYTE7lL5pcUAwLnsvzfyfX3z+jpKSUmk5zMLgAAQJdwyaPko2maSPJHs+qlD24oBv1dt3VravT7o8Ox+omusXpA4H8+5ZQ/jfLf7w9h00KMLklUAwAAAHQud89LISSpmVLp24s1ffiEH97195dI4VICf3QJAh50ldUtAbtf/PxNoVrMBqiwUwAAAEBHOmjC/16zeNEv37nraknaWS6X2N4P3YQEALqOSzZZLqeNi/2/nHbyaxTDX8m0aTFGN/dIIgAAAKC9ueTmnqUhlPpC0Hwer55ZXr7oJT/+8V6XbEIKF0q0g6KrkABA11o95GX1TgHRXQt5XhNDAgEAANpSfchfMpokWo6+N7d40a/WV/2Z8I9uRnCDrrf6Q+BfTznllSHYfxhMklfuyWqK7rlENQAAAEA7cMld0liS2Fye5276v2Yq1Y81Vv0lJvyju5EAAHRgNcC4lPw/p576J7nH9/aHsGk+Rjd5NBIBAAAALWl1uX9jyN9sTR/e8sO7/l6SrpQSyv0BEgDAAR4zJLBS+txQmp4X5VrI6m0BVn/fkDsGAABoLntsub/FeNEv79o/5K88OZmx6g8USAAABzl4SOC/nnLKK4PV2wJqNeXumcwS5gMAAAA0j7vnkmw0TcNcnucu/V8z1f3l/gz5Ax6LAAZ4HAe3BfyXU174p5nr90fTdNNcnisrPnQSEyllAACA9WCSYv3WazgEyyUl0reXlH/4hLt+SLk/8ARIAABPYHVbwA+3bNmYpul7Jb+4P4SN82wbCAAAsC4O0ef/rVr0vzh+165vS5T7A4eDBABwGFwybd2a2PbtmSTtfv7zN6lU+txwmpzn7pojEQAAALAmXHK556UQ0sEQtOy+N0a/6Ffrff71qk0zKTb5UIGWRwIAeBIOng9w78kn/3op2Ptz6VVBIhEAAABwhKwO/IeSRDNZNuWuj+7L88vO3r17ij5/4MkjAQA8BQfvI/uzk0/+dQ/2ficRAAAA8LQcKvCX7LIsyz76gt27pyT6/IGnigQA8DRcKSXjUiQRAAAA8PQcTuDvW7em2r49p88feGpIAABHAIkAAACAp4bAH1g/JACAI+gwEwG5zBLj/QcAALqZe+6SE/gD64cABFgDh0oEWH1YYF8Ims1zZTFmJAIAAEC3cffczcJQCNYbgqbrw/3yPL+MwB9YWwQewBo6OBFw78kn/3pfYudMZ/EdG0vpUXN5rlqMmUkm2gMAAECHapT5u1kyHIK5pCWP3/aoG2x5+Yrn/+QneyQCf2CtkQAA1sFjKgK2bNm4mKbvlfzisTTduByj5vfPCQjivQkAADpAI/BPQ0hHkkSVGJVI36pF/4vjd+36duP7rtu6NT2XwB9YcwQZwDq6cnw8GX/kEbPt2zNJ+vEJJxzlvb3vsKBzBiz8uiQtxih3z5z2AAAA0J7c3aPMQsnMhpJE+2rZnrE0XFHJ/YZG4O+SaevWhBV/YP0QXABN4JJdv3Vr8op6IkAq2gNKZu/P3M8uhTBSiVFVdxdVAQAAoA245Oaem1k6WF/tz9z3SPr4YJ5f9uxGf79kE1K4UMqbfMhA1yGgAJroUJlvL5eP+ofl5feY2e+nZkf1haCFPKcqAAAAtKKV1f4eM+sLQbUYZ4PZrYtZ9t+SwcFbT7j99lmp6O+f2LzZL5yYIPAHmoRAAmgRV46PJ+MTEytzAnacccbI6MLCWQNp+gfR/axSsFVVAcplqicDTFTNAQCAtbdyz+HuxWyjYrU/qBJdmfseN//YiaXej9vk5J7G36K/H2gdJACAFnOo9oD9VQH6/dTsqNEk0Uyeq+YuFaV2tAgAAIA11SjxD2ZpfwhKzFSNcTZYuHUxy/7bzODyrWfefs9s/XttYnw8rF7cANB8BAxAizrUB+cPt2wZ6jE7eyhNz53Os98thbD5gBYByUgGAACAI6UxxV9myUqJv/t8Ncabc9f2XwrhL4d37Xqk8f2s9gOtjSABaAOHqgr4yRlnjGhh4czeNP3D6PGsnhBGcnctxajonklyN0uZGQAAAJ4ElxS9GEJcSs3UqDzM3Pe462PP6u39+MiqEn+T9LVxJeMTYrUfaHEEBkAbKaoCFMYf2bqylaAkzZ188ub7YvzdxLS1J4SX9pgNJWaa298mkIkBggAA4NDc3aNJHszSvhA0EIKm81y1GB8ZS9K/nM+y66vut7xg9+55iS38gHZFMAC0qUYy4A0Tyld/6tbnBbw9NR/OZG8vrZoZkLnL3Wv1NgFaBQAA6FL1fv5Mkh3Q0+8+v5TnN25MS7ftzfPbPc9vbAT9EiX+QLvj5h/oAI0s/OqqAOnQMwPGkkSLMapyUKuAtLKlAAAA6Czukuyg0v7hJFHuruov6OmXGtv3bXdK/IH2x80+0GFcsslyOZ0bGvLVMwN+uGXLkCXJyzclyRlTWe0l/Uny8tWtAi4pizEzEgIAALS7xwT8QdIBpf3ue1L5pzO3uRN7ez+9ets+SdpZLpfunZyM4yLoBzoJN/dAB3u8mQHS/laBYD4cZW8PUt9okgzZqoRAHiMVAgAAtDiXvP4BfciAf2+Wqc9sdjH6LWNpumPfIUr7pWKln55+oLNxMw90CZdsQgrHl8vh9MnJ2uqv/XDLlqENWdY309fz9uD7EwIjSTIUzDSb55KkrBgoWNP+GQKSZCbuFAAAWGurPm9dkqy+BXAaQuru6j0o4F+KfsvGNN0xHau3Pa9v6Ba7/fbZ1T/vuq1b0+H5eStPTmYE/UB3IAEAdKlGq0B5aMgPNTsgzbK+2NfzdnMfdtnbTeoxs5GNq2YImNlK24AkUSkAAMCR4yuBvqLk0SWZWSkxk0kaThK5u/Zl2Wx/CKrEePNYWrptKlZvO+kQAb9EaT/Q7bhJB1AMEZT0eAmBn5xxxog0pVgZOHskhJdM12ov6Q/hpYsetSFJR4KZXK65PBatA43dBho/v54YkEgOAABwsNUl/HKP9edWVvb7QlBvMCUy7ctzRfdZl6rm/mk3m1usVj9dHhurHkbAX//RALoVN+IAHuOJEgKS5GecMfIPs7MlS5J3mlkpk3pMemeQSsFsZEN9srAkzcW4crexumJAOjA5IJEgAAB0Fj8o4G6s5te/psZE/rgS6AeZpFhf2R8IQUvut0q6eTRJSjNZdlO6vLxDGzfqBAJ+AE8SN9oAnlAjIfB4MwQafnLGGSOamlLW23vmaJqePZPnubv3mxUtBC6FsfpcgaJnwA9IDkiPrR6QJJkF3z9z4DFIGgAA1sPBwfzBrNhed/X3WxrCSqK7sZrfF4LcXYkVK/p5jNN9SZJUYrxF0q1mlrj7krLsihNHRmqHWtmXiqF9k/UefkmipB/AE+GmGcBTsrpKQJIer1JAKmYK9FSrYTaEnoGenrcn7r25mbt7byM5EIthgp6YRjYkaVE9UI/sK9FViVEriYODHDJpAADAEXRwMH8wkzQcQvFhJslUrOpP5/m86qX9/SGE+mr+rZI0lqaartVutSy79fl9fYndfff04/38neVySZIaq/v1/ycBP4AnhftlAEfMwZUC0i9ODEj7kwMLg4NheWEhjvT2njlWSs6azrLobiUzy6V4Vr8lZy3FPNZ3IFj5/xVJg/0tB2Zc1gAAR04RzOvAYP6gr4fiv1X3+GmzZFn156JUXaxWP53FWB1NEn/+6Kg93mp+QyPQlyRW9gEcadwpA1hzvupa06gYkJ44OXDAzzjjjJEfz8z4TJ6v/KzeQyQN9AtaBQAAeCqCwgHB/EZJU6u+vlFStacnvmD37vnD+Xmrg3xW9AGsJxIAAJrKD7oOra4eaHi8mQMAALSSRk/+6ucaq/gNBPkAmokEAIC2cHCiYLVDJQ0AADjSDg7mD0ZwDwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgFbx/wMiz0iwcGg6PgAAAABJRU5ErkJggg==
__ICNS_STOP_DATA__

# Forcer le Finder a reconnaitre les nouvelles apps (sinon elles peuvent
# apparaitre comme de simples dossiers ou tarder a s'afficher).
touch "$START_APP" "$STOP_APP" 2>/dev/null
LSREG="$(find /System/Library/Frameworks/CoreServices.framework -name lsregister 2>/dev/null | head -1)"
[ -n "$LSREG" ] && "$LSREG" -f "$START_APP" "$STOP_APP" 2>/dev/null
echo "  Icones creees sur le Bureau : « Cabinet Kine » et « Arreter Cabinet Kine »."

# 7) Message final + ouverture du dossier
echo ""
echo "  ============================================================"
echo "  Installation terminee."
echo ""
echo "  Le BILAN ORAL est installe : micro -> transcription locale -> resume."
echo ""
echo "  Sur le BUREAU, deux icones ont ete creees :"
echo "    - « Cabinet Kine »          -> demarre l'application"
echo "    - « Arreter Cabinet Kine »  -> arrete le serveur"
echo "  Double-cliquez « Cabinet Kine » : le navigateur s'ouvre tout seul."
echo ""
echo "  Au 1er acces, acceptez l'avertissement de certificat"
echo "  (Avance > Continuer). Connectez-vous avec  admin / admin"
echo "  puis changez le mot de passe (menu « Securite »)."
echo "  ============================================================"
echo ""
open "$HOME/Desktop" 2>/dev/null
echo "  (Appuyez sur Entree pour fermer cette fenetre.)"
read -r _
