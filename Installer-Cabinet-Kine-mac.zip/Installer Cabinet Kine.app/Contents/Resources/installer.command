#!/bin/bash
# ============================================================================
#  Cabinet kine — installateur macOS (double-cliquable)
#  Cree ~/cabinet-kine et un lanceur « demarrer.command » double-cliquable.
#  Sans Homebrew : utilise Python 3 des outils Apple.
# ============================================================================
cd "$HOME" || exit 1
info(){ echo "  $1"; }

echo ""
echo "  Installation du Cabinet kine (macOS)..."
echo ""

# 1) Python 3 (outils de developpement Apple)
if ! command -v python3 >/dev/null 2>&1; then
  echo "  Python 3 n'est pas encore installe."
  echo "  Une fenetre Apple va proposer d'installer les outils de developpement."
  echo "  -> Cliquez sur « Installer », attendez la fin, puis RELANCEZ ce fichier."
  xcode-select --install 2>/dev/null
  echo ""
  echo "  (Appuyez sur Entree pour fermer cette fenetre.)"
  read -r _
  exit 0
fi

APP="$HOME/cabinet-kine"
mkdir -p "$APP/templates" "$APP/static"

# 2) Environnement Python isole + dependances
info "Preparation de l'environnement Python..."
python3 -m venv "$APP/venv" || { echo "  Echec de creation de l'environnement."; read -r _; exit 1; }
source "$APP/venv/bin/activate"
pip install --upgrade pip >/dev/null 2>&1
info "Installation des dependances (cela peut prendre quelques minutes)..."
pip install flask reportlab cryptography faster-whisper || { echo "  Echec d'installation des dependances."; read -r _; exit 1; }

# 3) Fichiers de l'application
info "Ecriture des fichiers de l'application..."
info "  · app.py"
cat > "$APP/app.py" << '__FIN_APP_PY__'
#!/usr/bin/env python3
"""Cabinet kiné — socle de gestion (espace kiné uniquement).

Application web LOCALE pour un cabinet de kinésithérapie :
  - dossiers patients (pathologie, objectifs court/long terme, note libre),
  - calendrier par patient avec annotation des séances,
  - niveau de douleur (EVA 1-10) par séance + graphique d'évolution.

Tout reste sur la machine : base SQLite locale, aucun envoi en ligne.
Sert une interface sur http://127.0.0.1:5001
"""
import os
import io
import sqlite3
import secrets
import tempfile
import random
import calendar
import re
import socket
from datetime import datetime, date, timedelta, timezone
from functools import wraps

from flask import (
    Flask, request, session, redirect, url_for,
    render_template, jsonify, abort, flash, g, send_file,
)
from werkzeug.security import generate_password_hash as _gen_hash, check_password_hash


def generate_password_hash(secret):
    """Hachage portable. pbkdf2 plutôt que scrypt : certains Python de macOS
    n'ont pas hashlib.scrypt (compilés sans le scrypt d'OpenSSL)."""
    return _gen_hash(secret, method="pbkdf2:sha256")

ICI = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ICI, "cabinet.db")
SECRET_FILE = os.path.join(ICI, ".secret")

# Le module de transcription vocale est optionnel (installé séparément).
try:
    import transcription
    import resume
    AUDIO_DISPO = True
except Exception:
    AUDIO_DISPO = False


def cle_secrete():
    """Clé de session persistante (pour rester connecté entre redémarrages)."""
    if os.path.exists(SECRET_FILE):
        with open(SECRET_FILE) as f:
            return f.read().strip()
    cle = secrets.token_hex(32)
    with open(SECRET_FILE, "w") as f:
        f.write(cle)
    os.chmod(SECRET_FILE, 0o600)
    return cle


app = Flask(__name__)
app.secret_key = cle_secrete()


# --------------------------------------------------------------------------
#  Base de données
# --------------------------------------------------------------------------
def co():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def fermer_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


ADMIN_DEFAUT_ID = "admin"
ADMIN_DEFAUT_MDP = "admin"
QUESTION_DEFAUT = "Quelle est la marque de ma première voiture ?"
REPONSE_DEFAUT = "citroen"


def init_db():
    db = sqlite3.connect(DB)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS kine (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            identifiant TEXT UNIQUE NOT NULL,
            mdp_hash    TEXT NOT NULL,
            cree_le     TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS patients (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            prenom          TEXT NOT NULL,
            nom             TEXT NOT NULL,
            naissance       TEXT,
            pathologie      TEXT,
            objectif_court  TEXT,
            objectif_long   TEXT,
            note_libre      TEXT,
            archive         INTEGER NOT NULL DEFAULT 0,
            cree_le         TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS seances (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id  INTEGER NOT NULL,
            date_seance TEXT NOT NULL,
            heure       TEXT,
            fait        TEXT,
            douleur     INTEGER,
            cree_le     TEXT NOT NULL,
            UNIQUE(patient_id, date_seance),
            FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS praticiens (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            nom     TEXT UNIQUE NOT NULL,
            cree_le TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS config (
            cle    TEXT PRIMARY KEY,
            valeur TEXT
        );
        """
    )
    db.commit()
    # Migration : marqueur des patients de démonstration
    cols = [r[1] for r in db.execute("PRAGMA table_info(patients)").fetchall()]
    if "demo" not in cols:
        db.execute("ALTER TABLE patients ADD COLUMN demo INTEGER NOT NULL DEFAULT 0")
        db.commit()
    # Migration : heure des séances (créneaux)
    cols_s = [r[1] for r in db.execute("PRAGMA table_info(seances)").fetchall()]
    if "heure" not in cols_s:
        db.execute("ALTER TABLE seances ADD COLUMN heure TEXT")
        db.commit()
    if "praticien" not in cols_s:
        db.execute("ALTER TABLE seances ADD COLUMN praticien TEXT")
        db.commit()
    # Migration : rôle des comptes
    cols_k = [r[1] for r in db.execute("PRAGMA table_info(kine)").fetchall()]
    if "role" not in cols_k:
        db.execute("ALTER TABLE kine ADD COLUMN role TEXT NOT NULL DEFAULT 'praticien'")
        db.commit()
    if "question" not in cols_k:
        db.execute("ALTER TABLE kine ADD COLUMN question TEXT")
        db.commit()
    if "reponse_hash" not in cols_k:
        db.execute("ALTER TABLE kine ADD COLUMN reponse_hash TEXT")
        db.commit()
    # Compte administrateur par défaut : garanti tant que son mot de passe
    # est encore celui par défaut (sinon on respecte le mot de passe choisi).
    rep_def = generate_password_hash(REPONSE_DEFAUT.strip().upper())
    admin = db.execute(
        "SELECT mdp_hash FROM kine WHERE identifiant = ?", (ADMIN_DEFAUT_ID,)
    ).fetchone()
    if admin is None:
        db.execute(
            "INSERT INTO kine (identifiant, mdp_hash, role, question, reponse_hash, cree_le) "
            "VALUES (?,?,?,?,?,?)",
            (ADMIN_DEFAUT_ID, generate_password_hash(ADMIN_DEFAUT_MDP), "admin",
             QUESTION_DEFAUT, rep_def, datetime.now().isoformat(timespec="seconds")),
        )
        db.commit()
    elif check_password_hash(admin[0], ADMIN_DEFAUT_MDP):
        db.execute(
            "UPDATE kine SET role = 'admin', question = ?, reponse_hash = ? "
            "WHERE identifiant = ?",
            (QUESTION_DEFAUT, rep_def, ADMIN_DEFAUT_ID),
        )
        db.commit()
    # Un seul administrateur : tout autre compte est un praticien
    db.execute(
        "UPDATE kine SET role = 'praticien' WHERE identifiant <> ? AND role = 'admin'",
        (ADMIN_DEFAUT_ID,),
    )
    db.commit()
    db.close()


def normaliser_heure(v):
    """Renvoie 'HH:00' ou 'HH:30' (créneaux de 30 min), ou None."""
    v = (v or "").strip()
    if not v:
        return None
    try:
        parts = v.split(":")
        h, m = int(parts[0]), int(parts[1])
        if 0 <= h <= 23:
            return "%02d:%02d" % (h, 0 if m < 30 else 30)
    except (ValueError, IndexError):
        pass
    return None


PALETTE_PRAT = ["#5A4FE3", "#1F9D6B", "#E0A100", "#2563EB", "#D6409F",
                "#0E8FA8", "#C2410C", "#7C3AED"]


def liste_praticiens():
    return [r["identifiant"] for r in co().execute(
        "SELECT identifiant FROM kine WHERE role = 'praticien' ORDER BY id"
    ).fetchall()]


def praticiens_couleurs():
    rows = co().execute(
        "SELECT id, identifiant FROM kine WHERE role = 'praticien' ORDER BY id"
    ).fetchall()
    return {r["identifiant"]: PALETTE_PRAT[(r["id"] - 1) % len(PALETTE_PRAT)] for r in rows}


def praticien_valide(v):
    v = (v or "").strip()
    return v if v in liste_praticiens() else None


# -- Administration (réservée au compte de rôle « admin ») --
def est_admin():
    return bool(session.get("est_admin"))


def _norm_reponse(v):
    return (v or "").strip().upper()


def admin_requise(vue):
    @wraps(vue)
    def wrap(*a, **kw):
        if not session.get("kine_id"):
            return redirect(url_for("connexion"))
        if not est_admin():
            flash("Cette section est réservée à l'administrateur.")
            return redirect(url_for("dashboard"))
        return vue(*a, **kw)
    return wrap


def maintenant():
    return datetime.now().isoformat(timespec="seconds")


# --------------------------------------------------------------------------
#  Authentification
# --------------------------------------------------------------------------
def compte_existe():
    return co().execute("SELECT 1 FROM kine LIMIT 1").fetchone() is not None


def connexion_requise(vue):
    @wraps(vue)
    def wrap(*a, **kw):
        if not session.get("kine_id"):
            return redirect(url_for("connexion"))
        return vue(*a, **kw)
    return wrap


@app.route("/")
def accueil():
    if not compte_existe():
        return redirect(url_for("setup"))
    if not session.get("kine_id"):
        return redirect(url_for("connexion"))
    return redirect(url_for("dashboard"))


@app.route("/bienvenue", methods=["GET", "POST"])
def setup():
    """Création du premier (et unique) compte kiné. Pas de mot de passe par défaut."""
    if compte_existe():
        return redirect(url_for("connexion"))
    if request.method == "POST":
        ident = (request.form.get("identifiant") or "").strip()
        mdp = request.form.get("mdp") or ""
        mdp2 = request.form.get("mdp2") or ""
        question = (request.form.get("question") or "").strip()
        reponse = (request.form.get("reponse") or "").strip()
        if len(ident) < 3:
            flash("L'identifiant doit faire au moins 3 caractères.")
        elif len(mdp) < 6:
            flash("Le mot de passe doit faire au moins 6 caractères.")
        elif mdp != mdp2:
            flash("Les deux mots de passe ne correspondent pas.")
        elif not question or not reponse:
            flash("Veuillez renseigner la question de sécurité et sa réponse.")
        else:
            co().execute(
                "INSERT INTO kine (identifiant, mdp_hash, role, question, reponse_hash, cree_le) "
                "VALUES (?,?,?,?,?,?)",
                (ident, generate_password_hash(mdp), "admin", question,
                 generate_password_hash(_norm_reponse(reponse)), maintenant()),
            )
            co().commit()
            ligne = co().execute(
                "SELECT id FROM kine WHERE identifiant = ?", (ident,)
            ).fetchone()
            session["kine_id"] = ligne["id"]
            session["est_admin"] = True
            return redirect(url_for("dashboard"))
    return render_template("setup.html")


@app.route("/connexion", methods=["GET", "POST"])
def connexion():
    if not compte_existe():
        return redirect(url_for("setup"))
    if request.method == "POST":
        ident = (request.form.get("identifiant") or "").strip()
        mdp = request.form.get("mdp") or ""
        ligne = co().execute(
            "SELECT * FROM kine WHERE identifiant = ?", (ident,)
        ).fetchone()
        if ligne and check_password_hash(ligne["mdp_hash"], mdp):
            session["kine_id"] = ligne["id"]
            session["est_admin"] = (ligne["role"] == "admin")
            return redirect(url_for("dashboard"))
        flash("Identifiant ou mot de passe incorrect.")
    return render_template("connexion.html")


@app.route("/deconnexion")
def deconnexion():
    session.clear()
    return redirect(url_for("connexion"))


@app.route("/mot-de-passe-oublie", methods=["GET", "POST"])
def mdp_oublie():
    if not compte_existe():
        return redirect(url_for("setup"))
    if request.method == "POST":
        ident = (request.form.get("identifiant") or "").strip()
        compte = co().execute(
            "SELECT * FROM kine WHERE identifiant = ?", (ident,)
        ).fetchone()
        if not compte or not compte["question"] or not compte["reponse_hash"]:
            flash("Aucune question de sécurité n'est configurée pour cet identifiant.")
            return render_template("mdp_oublie.html", etape=1)
        # Étape 2 : la réponse et le nouveau mot de passe sont fournis
        if "reponse" in request.form:
            if not check_password_hash(compte["reponse_hash"],
                                       _norm_reponse(request.form.get("reponse"))):
                flash("Réponse incorrecte.")
            else:
                mdp = request.form.get("mdp") or ""
                mdp2 = request.form.get("mdp2") or ""
                if len(mdp) < 6:
                    flash("Le mot de passe doit faire au moins 6 caractères.")
                elif mdp != mdp2:
                    flash("Les deux mots de passe ne correspondent pas.")
                else:
                    co().execute("UPDATE kine SET mdp_hash = ? WHERE id = ?",
                                 (generate_password_hash(mdp), compte["id"]))
                    co().commit()
                    flash("Mot de passe réinitialisé. Vous pouvez vous connecter.")
                    return redirect(url_for("connexion"))
            return render_template("mdp_oublie.html", etape=2, identifiant=ident,
                                   question=compte["question"])
        # Étape 1 -> 2 : afficher la question de ce compte
        return render_template("mdp_oublie.html", etape=2, identifiant=ident,
                               question=compte["question"])
    return render_template("mdp_oublie.html", etape=1)


@app.route("/securite", methods=["GET", "POST"])
@connexion_requise
def securite():
    compte = co().execute(
        "SELECT * FROM kine WHERE id = ?", (session["kine_id"],)
    ).fetchone()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "mdp":
            ancien = request.form.get("ancien") or ""
            mdp = request.form.get("mdp") or ""
            mdp2 = request.form.get("mdp2") or ""
            if not check_password_hash(compte["mdp_hash"], ancien):
                flash("Mot de passe actuel incorrect.")
            elif len(mdp) < 6:
                flash("Le nouveau mot de passe doit faire au moins 6 caractères.")
            elif mdp != mdp2:
                flash("Les deux mots de passe ne correspondent pas.")
            else:
                co().execute("UPDATE kine SET mdp_hash = ? WHERE id = ?",
                             (generate_password_hash(mdp), compte["id"]))
                co().commit()
                flash("Mot de passe modifié.")
        elif action == "question":
            question = (request.form.get("question") or "").strip()
            reponse = (request.form.get("reponse") or "").strip()
            if not question or not reponse:
                flash("Question et réponse sont requises.")
            else:
                co().execute("UPDATE kine SET question = ?, reponse_hash = ? WHERE id = ?",
                             (question, generate_password_hash(_norm_reponse(reponse)),
                              compte["id"]))
                co().commit()
                flash("Question de sécurité enregistrée.")
        return redirect(url_for("securite"))
    return render_template("securite.html", compte=compte)


# --------------------------------------------------------------------------
#  Tableau de bord
# --------------------------------------------------------------------------
@app.route("/dashboard")
@connexion_requise
def dashboard():
    patients = co().execute(
        """
        SELECT p.*,
               (SELECT COUNT(*) FROM seances s WHERE s.patient_id = p.id) AS nb_seances,
               (SELECT MAX(date_seance) FROM seances s WHERE s.patient_id = p.id) AS derniere,
               (SELECT douleur FROM seances s WHERE s.patient_id = p.id
                  AND douleur IS NOT NULL ORDER BY date_seance DESC LIMIT 1) AS douleur_recente
        FROM patients p
        WHERE p.archive = 0
        ORDER BY p.nom COLLATE NOCASE, p.prenom COLLATE NOCASE
        """
    ).fetchall()
    nb_archives = co().execute(
        "SELECT COUNT(*) AS n FROM patients WHERE archive = 1"
    ).fetchone()["n"]
    return render_template("dashboard.html", patients=patients, nb_archives=nb_archives)


@app.route("/archives")
@connexion_requise
def archives():
    patients = co().execute(
        "SELECT * FROM patients WHERE archive = 1 ORDER BY nom COLLATE NOCASE"
    ).fetchall()
    return render_template("archives.html", patients=patients)


@app.route("/calendrier")
@connexion_requise
def calendrier():
    return render_template("calendrier.html")


@app.route("/agenda.json")
@connexion_requise
def agenda_json():
    lignes = co().execute(
        """SELECT s.date_seance, s.heure, s.douleur, s.fait, s.praticien,
                  p.id AS patient_id, p.prenom, p.nom, p.archive
           FROM seances s JOIN patients p ON p.id = s.patient_id
           ORDER BY s.date_seance, s.heure IS NULL, s.heure,
                    p.nom COLLATE NOCASE, p.prenom COLLATE NOCASE"""
    ).fetchall()
    return jsonify([dict(x) for x in lignes])


@app.route("/patients.json")
@connexion_requise
def patients_json():
    rows = co().execute(
        "SELECT id, prenom, nom FROM patients WHERE archive = 0 "
        "ORDER BY nom COLLATE NOCASE, prenom COLLATE NOCASE"
    ).fetchall()
    return jsonify([dict(r) for r in rows])


# --------------------------------------------------------------------------
#  Dossiers patients
# --------------------------------------------------------------------------
def get_patient(pid):
    p = co().execute("SELECT * FROM patients WHERE id = ?", (pid,)).fetchone()
    if p is None:
        abort(404)
    return p


@app.route("/patient/nouveau", methods=["GET", "POST"])
@connexion_requise
def patient_nouveau():
    if request.method == "POST":
        prenom = (request.form.get("prenom") or "").strip()
        nom = (request.form.get("nom") or "").strip()
        if not prenom or not nom:
            flash("Le prénom et le nom sont obligatoires.")
            return render_template("patient_form.html", patient=request.form, mode="nouveau")
        cur = co().execute(
            """INSERT INTO patients
               (prenom, nom, naissance, pathologie, objectif_court, objectif_long,
                note_libre, cree_le)
               VALUES (?,?,?,?,?,?,?,?)""",
            (
                prenom, nom,
                request.form.get("naissance") or None,
                request.form.get("pathologie") or None,
                request.form.get("objectif_court") or None,
                request.form.get("objectif_long") or None,
                request.form.get("note_libre") or None,
                maintenant(),
            ),
        )
        co().commit()
        return redirect(url_for("patient", pid=cur.lastrowid))
    return render_template("patient_form.html", patient={}, mode="nouveau")


@app.route("/patient/<int:pid>")
@connexion_requise
def patient(pid):
    p = get_patient(pid)
    seances = co().execute(
        "SELECT * FROM seances WHERE patient_id = ? ORDER BY date_seance DESC", (pid,)
    ).fetchall()
    return render_template("patient.html", p=p, seances=seances)


@app.route("/patient/<int:pid>/modifier", methods=["GET", "POST"])
@connexion_requise
def patient_modifier(pid):
    p = get_patient(pid)
    if request.method == "POST":
        prenom = (request.form.get("prenom") or "").strip()
        nom = (request.form.get("nom") or "").strip()
        if not prenom or not nom:
            flash("Le prénom et le nom sont obligatoires.")
            return render_template("patient_form.html", patient=request.form, mode="modifier")
        co().execute(
            """UPDATE patients SET prenom=?, nom=?, naissance=?, pathologie=?,
               objectif_court=?, objectif_long=?, note_libre=? WHERE id=?""",
            (
                prenom, nom,
                request.form.get("naissance") or None,
                request.form.get("pathologie") or None,
                request.form.get("objectif_court") or None,
                request.form.get("objectif_long") or None,
                request.form.get("note_libre") or None,
                pid,
            ),
        )
        co().commit()
        return redirect(url_for("patient", pid=pid))
    return render_template("patient_form.html", patient=p, mode="modifier")


@app.route("/patient/<int:pid>/note", methods=["POST"])
@connexion_requise
def patient_note(pid):
    get_patient(pid)
    co().execute(
        "UPDATE patients SET note_libre = ? WHERE id = ?",
        (request.form.get("note_libre") or None, pid),
    )
    co().commit()
    return redirect(url_for("patient", pid=pid))


@app.route("/patient/<int:pid>/archiver", methods=["POST"])
@connexion_requise
def patient_archiver(pid):
    get_patient(pid)
    co().execute("UPDATE patients SET archive = 1 WHERE id = ?", (pid,))
    co().commit()
    flash("Patient archivé.")
    return redirect(url_for("dashboard"))


@app.route("/patient/<int:pid>/restaurer", methods=["POST"])
@connexion_requise
def patient_restaurer(pid):
    get_patient(pid)
    co().execute("UPDATE patients SET archive = 0 WHERE id = ?", (pid,))
    co().commit()
    return redirect(url_for("patient", pid=pid))


# --------------------------------------------------------------------------
#  Séances (annotation depuis le calendrier + douleur)
# --------------------------------------------------------------------------
@app.route("/patient/<int:pid>/seance", methods=["POST"])
@connexion_requise
def seance_enregistrer(pid):
    get_patient(pid)
    date_seance = (request.form.get("date_seance") or "").strip()
    if not date_seance:
        abort(400)
    fait = request.form.get("fait") or None
    douleur_brut = request.form.get("douleur")
    douleur = None
    if douleur_brut not in (None, "", "0"):
        try:
            d = int(douleur_brut)
            if 1 <= d <= 10:
                douleur = d
        except ValueError:
            douleur = None
    # heure et praticien : modifiés uniquement s'ils sont explicitement envoyés
    # (permet de les changer/vider depuis la modale sans casser le bilan oral)
    maj_heure = "heure" in request.form
    maj_prat = "praticien" in request.form
    heure = normaliser_heure(request.form.get("heure")) if maj_heure else None
    prat = praticien_valide(request.form.get("praticien")) if maj_prat else None
    db = co()
    db.execute(
        """INSERT INTO seances (patient_id, date_seance, heure, praticien, fait, douleur, cree_le)
           VALUES (?,?,?,?,?,?,?)
           ON CONFLICT(patient_id, date_seance)
           DO UPDATE SET fait=excluded.fait, douleur=excluded.douleur""",
        (pid, date_seance, heure, prat, fait, douleur, maintenant()),
    )
    if maj_heure:
        db.execute("UPDATE seances SET heure=? WHERE patient_id=? AND date_seance=?",
                   (heure, pid, date_seance))
    if maj_prat:
        db.execute("UPDATE seances SET praticien=? WHERE patient_id=? AND date_seance=?",
                   (prat, pid, date_seance))
    db.commit()
    if request.form.get("ajax"):
        return jsonify({"ok": True})
    return redirect(url_for("patient", pid=pid) + "#seances")


@app.route("/patient/<int:pid>/creneau", methods=["POST"])
@connexion_requise
def creneau_enregistrer(pid):
    """Assigne un patient à un créneau (date + heure) sans toucher au compte-rendu."""
    get_patient(pid)
    date_seance = (request.form.get("date") or "").strip()
    heure = normaliser_heure(request.form.get("heure"))
    prat = praticien_valide(request.form.get("praticien"))
    if not date_seance or not heure:
        abort(400)
    co().execute(
        """INSERT INTO seances (patient_id, date_seance, heure, praticien, cree_le)
           VALUES (?,?,?,?,?)
           ON CONFLICT(patient_id, date_seance)
           DO UPDATE SET heure=excluded.heure, praticien=excluded.praticien""",
        (pid, date_seance, heure, prat, maintenant()),
    )
    co().commit()
    return jsonify({"ok": True})


@app.route("/patient/<int:pid>/seance/<int:sid>/supprimer", methods=["POST"])
@connexion_requise
def seance_supprimer(pid, sid):
    get_patient(pid)
    co().execute("DELETE FROM seances WHERE id = ? AND patient_id = ?", (sid, pid))
    co().commit()
    return redirect(url_for("patient", pid=pid) + "#seances")


@app.route("/patient/<int:pid>/seances.json")
@connexion_requise
def seances_json(pid):
    get_patient(pid)
    lignes = co().execute(
        "SELECT id, date_seance, heure, praticien, fait, douleur FROM seances WHERE patient_id = ? ORDER BY date_seance",
        (pid,),
    ).fetchall()
    return jsonify([dict(x) for x in lignes])


@app.route("/patient/<int:pid>/pdf")
@connexion_requise
def patient_pdf(pid):
    p = get_patient(pid)
    seances = co().execute(
        "SELECT * FROM seances WHERE patient_id = ? ORDER BY date_seance", (pid,)
    ).fetchall()
    try:
        import pdf_export
    except Exception:
        abort(500, "Export PDF indisponible (reportlab non installé).")
    data = pdf_export.generer_fiche(dict(p), [dict(s) for s in seances])
    base = "bilan_%s_%s" % (p["nom"], p["prenom"])
    nom = "".join(c if (c.isalnum() or c in "-_") else "_" for c in base) + ".pdf"
    return send_file(io.BytesIO(data), mimetype="application/pdf",
                     as_attachment=True, download_name=nom)


@app.route("/reformuler", methods=["POST"])
@connexion_requise
def reformuler():
    """Réécrit un texte de séance via le modèle local (clarté/orthographe)."""
    if not AUDIO_DISPO:
        return jsonify({"erreur": "Module IA non installé."}), 400
    res = resume.reformuler(request.form.get("texte", ""))
    return jsonify(res)


@app.route("/patient/<int:pid>/bilan", methods=["POST"])
@connexion_requise
def bilan_oral(pid):
    """Reçoit la dictée, transcrit en local puis résume. Rien n'est envoyé en ligne."""
    if not AUDIO_DISPO:
        return jsonify({"erreur": "Module audio non installé."}), 400
    get_patient(pid)
    if "audio" not in request.files:
        return jsonify({"erreur": "Aucun audio reçu."}), 400
    fichier = request.files["audio"]
    suffixe = os.path.splitext(fichier.filename or "")[1] or ".webm"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffixe) as tmp:
        fichier.save(tmp.name)
        chemin = tmp.name
    try:
        tr = transcription.transcrire(chemin)
        texte = tr.get("texte", "")
        res = resume.resumer(texte)
        return jsonify({
            "transcription": texte,
            "resume": res.get("resume", ""),
            "moteur": res.get("moteur", ""),
            "douleur": resume.detecter_douleur(texte),
            "duree": tr.get("duree"),
        })
    except Exception as e:  # noqa: BLE001
        return jsonify({"erreur": str(e)}), 500
    finally:
        try:
            os.remove(chemin)
        except OSError:
            pass


# --------------------------------------------------------------------------
#  Données de test (patients fictifs, marqués demo=1, supprimables)
# --------------------------------------------------------------------------
_PRENOMS = ["Marie", "Jean", "Sophie", "Luc", "Alice", "Paul", "Emma", "Thomas",
            "Julie", "Pierre", "Camille", "Nicolas", "Léa", "Hugo", "Chloé",
            "Antoine", "Manon", "Louis", "Sarah", "Maxime", "Inès", "Théo",
            "Clara", "Lucas", "Eva", "Nathan", "Jade", "Gabriel", "Lola", "Adam"]
_NOMS = ["Durand", "Petit", "Martin", "Bernard", "Dubois", "Moreau", "Laurent",
         "Simon", "Michel", "Lefebvre", "Garcia", "Roux", "Fontaine", "Girard",
         "Bonnet", "Dupont", "Lambert", "Rousseau", "Vincent", "Muller", "Faure",
         "André", "Mercier", "Blanc", "Guérin", "Boyer", "Garnier", "Chevalier"]
_PATHOS = ["Lombalgie chronique", "Tendinopathie de l'épaule", "Entorse de la cheville",
           "Rééducation post-prothèse de genou", "Cervicalgie", "Syndrome rotulien",
           "Capsulite rétractile", "Lombosciatique", "Rupture du LCA (post-op)",
           "Périarthrite scapulo-humérale"]
_ACTES = ["Mobilisations passives et actives.", "Renforcement musculaire progressif.",
          "Étirements et travail proprioceptif.", "Massage décontracturant et physiothérapie.",
          "Travail de l'équilibre et de la marche.", "Exercices de gainage.",
          "Rééducation fonctionnelle.", "Travail excentrique progressif."]
_OBJ_C = ["Réduire la douleur sous 3 semaines.", "Récupérer l'amplitude articulaire.",
          "Diminuer l'inflammation.", "Reprendre la marche sans canne."]
_OBJ_L = ["Reprise du sport sans appréhension.", "Retour au travail.",
          "Autonomie complète au quotidien.", "Prévention des récidives."]


def _creer_patient_demo(db):
    cur = db.execute(
        """INSERT INTO patients
           (prenom, nom, naissance, pathologie, objectif_court, objectif_long,
            note_libre, demo, cree_le)
           VALUES (?,?,?,?,?,?,?,1,?)""",
        (random.choice(_PRENOMS), random.choice(_NOMS), None,
         random.choice(_PATHOS), random.choice(_OBJ_C), random.choice(_OBJ_L),
         "[Données de démonstration]", maintenant()),
    )
    return cur.lastrowid


def _heure_creneau_demo():
    """Heure de créneau aléatoire alignée sur :00/:30, entre 07:00 et 19:30."""
    m = random.randrange(7 * 60, 20 * 60, 30)
    return "%02d:%02d" % (m // 60, m % 60)


def _ajouter_seance_demo(db, pid, jour_iso, prats):
    db.execute(
        "INSERT INTO seances (patient_id, date_seance, heure, praticien, fait, douleur, cree_le) "
        "VALUES (?,?,?,?,?,?,?)",
        (pid, jour_iso, _heure_creneau_demo(), (random.choice(prats) if prats else None),
         random.choice(_ACTES), random.randint(1, 10), maintenant()),
    )


# --------------------------------------------------------------------------
#  Administration (réservée au compte admin) : comptes, praticiens, démo
# --------------------------------------------------------------------------
@app.route("/admin")
@admin_requise
def admin_panel():
    comptes = co().execute(
        "SELECT id, identifiant, role FROM kine ORDER BY role DESC, identifiant COLLATE NOCASE"
    ).fetchall()
    nb_demo = co().execute(
        "SELECT COUNT(*) AS n FROM patients WHERE demo = 1"
    ).fetchone()["n"]
    return render_template("admin_panel.html", comptes=comptes,
                           couleurs=praticiens_couleurs(),
                           nb_demo=nb_demo, aujourdhui=date.today().isoformat(),
                           moi=session.get("kine_id"))


@app.route("/admin/comptes/ajouter", methods=["POST"])
@admin_requise
def admin_compte_ajouter():
    ident = (request.form.get("identifiant") or "").strip()
    mdp = request.form.get("mdp") or ""
    if len(ident) < 3 or len(ident) > 40:
        flash("Le nom/identifiant doit faire entre 3 et 40 caractères.")
    elif len(mdp) < 6:
        flash("Le mot de passe doit faire au moins 6 caractères.")
    else:
        try:
            co().execute(
                "INSERT INTO kine (identifiant, mdp_hash, role, cree_le) VALUES (?,?,?,?)",
                (ident, generate_password_hash(mdp), "praticien", maintenant()),
            )
            co().commit()
            flash("Praticien « %s » ajouté (il peut se connecter avec ce nom)." % ident)
        except sqlite3.IntegrityError:
            flash("Ce nom/identifiant existe déjà.")
    return redirect(url_for("admin_panel") + "#praticiens")


@app.route("/admin/comptes/<int:compte_id>/supprimer", methods=["POST"])
@admin_requise
def admin_compte_supprimer(compte_id):
    if compte_id == session.get("kine_id"):
        flash("Vous ne pouvez pas supprimer votre propre compte.")
        return redirect(url_for("admin_panel") + "#praticiens")
    row = co().execute("SELECT role FROM kine WHERE id = ?", (compte_id,)).fetchone()
    if row and row["role"] == "admin":
        flash("Le compte administrateur ne peut pas être supprimé.")
        return redirect(url_for("admin_panel") + "#praticiens")
    co().execute("DELETE FROM kine WHERE id = ?", (compte_id,))
    co().commit()
    flash("Praticien retiré. Il ne sera plus proposé ; les séances passées "
          "conservent son nom.")
    return redirect(url_for("admin_panel") + "#praticiens")


# -- Données de test (réservées à l'admin) --
@app.route("/test/jour", methods=["POST"])
@admin_requise
def test_jour():
    jour = (request.form.get("date") or date.today().isoformat()).strip()
    try:
        nombre = max(1, min(150, int(request.form.get("nombre") or 25)))
    except ValueError:
        nombre = 25
    db = co()
    prats = liste_praticiens()
    for _ in range(nombre):
        _ajouter_seance_demo(db, _creer_patient_demo(db), jour, prats)
    db.commit()
    flash("%d patient(s) de démo ajouté(s) le %s." % (nombre, jour))
    return redirect(url_for("admin_panel") + "#donnees")


@app.route("/test/mois", methods=["POST"])
@admin_requise
def test_mois():
    val = (request.form.get("aaaamm") or "").strip()
    try:
        annee, mois = int(val[:4]), int(val[5:7])
    except (ValueError, IndexError):
        t = date.today()
        annee, mois = t.year, t.month
    try:
        nombre = max(1, min(400, int(request.form.get("nombre") or 60)))
    except ValueError:
        nombre = 60
    njours = calendar.monthrange(annee, mois)[1]
    db = co()
    prats = liste_praticiens()
    for _ in range(nombre):
        jour = "%04d-%02d-%02d" % (annee, mois, random.randint(1, njours))
        _ajouter_seance_demo(db, _creer_patient_demo(db), jour, prats)
    db.commit()
    flash("%d séance(s) de démo réparties sur %02d/%04d." % (nombre, mois, annee))
    return redirect(url_for("admin_panel") + "#donnees")


@app.route("/test/purge", methods=["POST"])
@admin_requise
def test_purge():
    db = co()
    db.execute("DELETE FROM seances WHERE patient_id IN (SELECT id FROM patients WHERE demo = 1)")
    db.execute("DELETE FROM patients WHERE demo = 1")
    db.commit()
    flash("Données de démonstration supprimées.")
    return redirect(url_for("admin_panel") + "#donnees")


@app.context_processor
def injecter():
    return {
        "AUDIO_DISPO": AUDIO_DISPO,
        "LLM_DISPO": AUDIO_DISPO,
        "praticiens": liste_praticiens(),
        "praticiens_couleurs": praticiens_couleurs(),
        "est_admin": est_admin(),
        "annee": datetime.now().year,
        "aujourdhui": date.today().isoformat(),
    }


def ip_locale():
    """Adresse IP du PC sur le réseau local (sans rien émettre), sinon None."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except OSError:
        ip = None
    finally:
        s.close()
    return ip


def generer_certificat(cert_path, key_path, ip):
    """Crée un certificat auto-signé (localhost + IP locale) pour servir en HTTPS.

    Le micro des navigateurs n'est autorisé qu'en contexte sécurisé (HTTPS ou
    localhost) : le HTTPS débloque donc le bilan oral depuis les autres postes.
    """
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    import ipaddress as _ipaddr

    cle = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    nom = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Cabinet kine")])
    noms_alt = [x509.DNSName("localhost"),
                x509.IPAddress(_ipaddr.ip_address("127.0.0.1"))]
    if ip:
        try:
            noms_alt.append(x509.IPAddress(_ipaddr.ip_address(ip)))
        except ValueError:
            pass
    t0 = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(nom).issuer_name(nom)
        .public_key(cle.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(t0 - timedelta(days=1))
        .not_valid_after(t0 + timedelta(days=3650))
        .add_extension(x509.SubjectAlternativeName(noms_alt), critical=False)
        .sign(cle, hashes.SHA256())
    )
    with open(key_path, "wb") as f:
        f.write(cle.private_bytes(serialization.Encoding.PEM,
                                  serialization.PrivateFormat.TraditionalOpenSSL,
                                  serialization.NoEncryption()))
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))


if __name__ == "__main__":
    init_db()
    port = 5001
    ip = ip_locale()
    ici = os.path.dirname(os.path.abspath(__file__))
    cert_path = os.path.join(ici, "cert.pem")
    key_path = os.path.join(ici, "key.pem")
    contexte_ssl = None
    try:
        if not (os.path.exists(cert_path) and os.path.exists(key_path)):
            generer_certificat(cert_path, key_path, ip)
        contexte_ssl = (cert_path, key_path)
    except Exception as err:
        print("\n  (HTTPS indisponible : %s — démarrage en HTTP)" % err)
    schema = "https" if contexte_ssl else "http"
    print("\n  Cabinet kiné — prêt.\n")
    print("  Sur CET ordinateur :")
    print("      %s://localhost:%d" % (schema, port))
    print("      %s://127.0.0.1:%d   (si « localhost » ne répond pas)" % (schema, port))
    if ip:
        print("\n  Depuis un autre PC / smartphone sur le MÊME réseau :")
        print("      %s://%s:%d" % (schema, ip, port))
        if contexte_ssl:
            print("\n  (1re visite sur chaque appareil : le navigateur affiche un")
            print("   avertissement de sécurité — normal avec un certificat local.")
            print("   Cliquez sur « Avancé » puis « Continuer ». Le HTTPS est requis")
            print("   pour autoriser le micro — donc le bilan oral — à distance.)")
        else:
            print("\n  (connexion non chiffrée : le micro ne sera pas disponible")
            print("   depuis les autres postes)")
    print("\n  Pour arrêter : Ctrl+C\n")
    app.run(host="0.0.0.0", port=port, threaded=True, ssl_context=contexte_ssl)
__FIN_APP_PY__

info "  · resume.py"
cat > "$APP/resume.py" << '__FIN_RESUME_PY__'
#!/usr/bin/env python3
"""Résumé LOCAL du bilan oral via Ollama (avec repli par règles si Ollama est absent).

Aucune donnée ne quitte la machine : Ollama tourne en local sur le port 11434.
Utilise uniquement la bibliothèque standard (pas de dépendance pip).
"""
import json
import re
import urllib.request

OLLAMA_URL = "http://127.0.0.1:11434/api/generate"
MODELE = "llama3.2:3b"

SYSTEME = (
    "Tu es l'assistant d'un kinésithérapeute. À partir de la dictée brute d'un "
    "bilan de séance, rédige en français un résumé clair et concis des éléments "
    "cliniquement pertinents, en quelques phrases courtes : ce qui a été fait, "
    "l'évolution, la douleur, les objectifs. N'invente rien ; garde uniquement ce "
    "qui est dit. Pas de préambule, donne directement le résumé."
)

SYSTEME_REFORM = (
    "Tu es l'assistant d'un kinésithérapeute. Reformule le texte suivant, qui décrit "
    "ce qui a été fait lors d'une séance, pour qu'il soit clair, concis et "
    "professionnel, en français. Corrige l'orthographe et la grammaire. N'ajoute "
    "aucune information et ne retire aucun fait : garde strictement le même sens. "
    "Réponds uniquement par le texte reformulé, sans préambule ni commentaire."
)


def resumer(texte):
    """Retourne {'resume': ..., 'moteur': 'ollama'|'règles'|'vide'}."""
    texte = (texte or "").strip()
    if not texte:
        return {"resume": "", "moteur": "vide"}
    try:
        return {"resume": _ollama(SYSTEME, texte), "moteur": "ollama"}
    except Exception:
        return {"resume": _regles(texte), "moteur": "règles"}


def reformuler(texte):
    """Réécrit un texte de séance (clarté/orthographe) sans changer le sens.

    Retourne {'texte': ..., 'moteur': 'ollama'|'indisponible'|'vide'}.
    En cas d'absence d'Ollama, renvoie le texte d'origine inchangé.
    """
    texte = (texte or "").strip()
    if not texte:
        return {"texte": "", "moteur": "vide"}
    try:
        return {"texte": _ollama(SYSTEME_REFORM, texte), "moteur": "ollama"}
    except Exception:
        return {"texte": texte, "moteur": "indisponible"}


def _ollama(systeme, texte):
    corps = json.dumps({
        "model": MODELE,
        "prompt": systeme + "\n\nTexte :\n" + texte + "\n\nRésultat :",
        "stream": False,
        "options": {"temperature": 0.2},
    }).encode("utf-8")
    req = urllib.request.Request(
        OLLAMA_URL, data=corps, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=240) as r:
        data = json.loads(r.read().decode("utf-8"))
    sortie = (data.get("response") or "").strip()
    if not sortie:
        raise ValueError("réponse vide d'Ollama")
    return sortie


def _regles(texte):
    """Repli sans IA : garde les phrases porteuses de sens clinique, en puces."""
    phrases = re.split(r"(?<=[.!?])\s+", texte)
    cles = (
        "douleur", "amplitude", "exercice", "renforc", "étire", "etire", "mobilis",
        "objectif", "progrès", "progres", "séance", "seance", "marche", "gainage",
        "raide", "souple", "force", "reprise", "mieux", "moins", "plus", "degré", "degre",
    )
    gardees = [p.strip() for p in phrases if any(k in p.lower() for k in cles)]
    if not gardees:
        gardees = [p.strip() for p in phrases if p.strip()]
    return "\n".join("- " + p for p in gardees if p)


def detecter_douleur(texte):
    """Repère un niveau de douleur cité (ex. « 3 sur 10 », « EVA 4 »). 0 si rien."""
    t = (texte or "").lower()
    for motif in (
        r"(\d{1,2})\s*(?:/|sur)\s*10",
        r"eva\D{0,6}(\d{1,2})",
        r"douleur\D{0,15}(\d{1,2})",
    ):
        m = re.search(motif, t)
        if m:
            v = int(m.group(1))
            if 0 <= v <= 10:
                return v
    return 0
__FIN_RESUME_PY__

info "  · pdf_export.py"
cat > "$APP/pdf_export.py" << '__FIN_PDF_EXPORT_PY__'
#!/usr/bin/env python3
"""Génère un compte-rendu PDF du dossier patient (reportlab).

Contenu : identité, pathologie, objectifs, note, courbe d'évolution de la
douleur (EVA) et historique des séances. Renvoie les octets du PDF.
"""
import io
from datetime import date, datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor, white
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether,
)
from reportlab.graphics.shapes import Drawing, Line, Circle, PolyLine, String

# Charte (cohérente avec l'application)
ACCENT = HexColor("#5A4FE3")
INK = HexColor("#161A23")
MUTED = HexColor("#5A6473")
LIGNE = HexColor("#DCE0E8")
SOFT = HexColor("#F0EFFC")
PATHO_BG = HexColor("#FBF1EE")
VERT = HexColor("#1F9D6B")
ORANGE = HexColor("#E0A100")
ROUGE = HexColor("#D2493B")


def _coul(n):
    if not n:
        return MUTED
    if n <= 3:
        return VERT
    if n <= 6:
        return ORANGE
    return ROUGE


def _jolie_date(iso):
    try:
        d = datetime.strptime(iso[:10], "%Y-%m-%d")
        return d.strftime("%d/%m/%Y")
    except Exception:
        return iso or ""


def _styles():
    s = getSampleStyleSheet()
    base = ParagraphStyle("base", parent=s["Normal"], fontName="Helvetica",
                          fontSize=10, leading=14, textColor=INK)
    return {
        "titre": ParagraphStyle("titre", parent=base, fontName="Helvetica-Bold",
                                fontSize=20, leading=24, textColor=INK),
        "sous": ParagraphStyle("sous", parent=base, fontSize=10, textColor=MUTED),
        "eyebrow": ParagraphStyle("eyebrow", parent=base, fontName="Helvetica-Bold",
                                  fontSize=8, textColor=MUTED, spaceAfter=2),
        "h2": ParagraphStyle("h2", parent=base, fontName="Helvetica-Bold",
                             fontSize=11, leading=14, textColor=INK, spaceBefore=4, spaceAfter=6),
        "val": ParagraphStyle("val", parent=base, fontSize=11, leading=15),
        "valbold": ParagraphStyle("valbold", parent=base, fontName="Helvetica-Bold",
                                  fontSize=12, leading=16),
        "base": base,
        "cell": ParagraphStyle("cell", parent=base, fontSize=9.5, leading=13),
        "cellmuted": ParagraphStyle("cellmuted", parent=base, fontSize=9.5,
                                    leading=13, textColor=MUTED),
        "pied": ParagraphStyle("pied", parent=base, fontSize=8, textColor=MUTED),
    }


def _graphe_douleur(points, largeur, hauteur=165):
    d = Drawing(largeur, hauteur)
    padL, padR, padT, padB = 26, 10, 12, 32
    plotW = largeur - padL - padR
    plotH = hauteur - padT - padB
    n = len(points)

    for lvl in range(0, 11, 2):
        y = padB + (lvl / 10.0) * plotH
        d.add(Line(padL, y, largeur - padR, y, strokeColor=LIGNE, strokeWidth=0.5))
        d.add(String(padL - 5, y - 3, str(lvl), fontSize=7,
                     fillColor=MUTED, textAnchor="end"))

    def X(i):
        return padL + (plotW / 2.0 if n == 1 else (i / (n - 1.0)) * plotW)

    def Y(v):
        return padB + (v / 10.0) * plotH

    if n >= 2:
        flat = []
        for i, p in enumerate(points):
            flat += [X(i), Y(p["d"])]
        d.add(PolyLine(flat, strokeColor=ACCENT, strokeWidth=1.5))

    step = 1 if n <= 12 else (n // 12 + 1)
    for i, p in enumerate(points):
        d.add(Circle(X(i), Y(p["d"]), 3, fillColor=_coul(p["d"]),
                     strokeColor=white, strokeWidth=1))
        if i % step == 0:
            d.add(String(X(i), padB - 12, p["date"][5:], fontSize=6.5,
                         fillColor=MUTED, textAnchor="middle"))
    d.add(Line(padL, padB, largeur - padR, padB, strokeColor=MUTED, strokeWidth=0.8))
    return d


def _bloc_clef(titre, valeur, st, accent=False):
    eyebrow = ParagraphStyle("eb", parent=st["eyebrow"],
                             textColor=(ROUGE if accent else MUTED))
    contenu = [
        Paragraph(titre.upper(), eyebrow),
        Paragraph(valeur or "Non renseigné",
                  st["valbold"] if accent else st["val"]),
    ]
    t = Table([[contenu]], colWidths=["100%"])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), PATHO_BG if accent else white),
        ("BOX", (0, 0), (-1, -1), 0.7, (HexColor("#F1D9D1") if accent else LIGNE)),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("ROUNDEDCORNERS", [6, 6, 6, 6]),
    ]))
    return t


def generer_fiche(patient, seances):
    st = _styles()
    buf = io.BytesIO()
    marge = 18 * mm
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=marge, rightMargin=marge, topMargin=16 * mm, bottomMargin=16 * mm,
        title="Bilan kinésithérapie", author="Cabinet kiné",
    )
    util = A4[0] - 2 * marge
    story = []

    nom = f"{patient.get('nom','')} {patient.get('prenom','')}".strip()

    # En-tête
    gauche = [
        Paragraph("BILAN KINÉSITHÉRAPIE", st["eyebrow"]),
        Paragraph(nom or "Patient", st["titre"]),
    ]
    sous = []
    if patient.get("naissance"):
        sous.append("Né(e) le " + _jolie_date(patient["naissance"]))
    sous.append("Édité le " + date.today().strftime("%d/%m/%Y"))
    gauche.append(Paragraph(" · ".join(sous), st["sous"]))
    story.append(Table([[gauche]], colWidths=[util], style=TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LINEBELOW", (0, 0), (-1, -1), 1, LIGNE),
    ])))
    story.append(Spacer(1, 14))

    # Pathologie + objectifs
    col = (util - 12) / 2.0
    story.append(_bloc_clef("Pathologie", patient.get("pathologie"), st, accent=True))
    story.append(Spacer(1, 8))
    obj = Table(
        [[_bloc_clef("Objectif court terme", patient.get("objectif_court"), st),
          _bloc_clef("Objectif long terme", patient.get("objectif_long"), st)]],
        colWidths=[col, col],
    )
    obj.setStyle(TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (0, 0), 12),
        ("RIGHTPADDING", (1, 0), (1, 0), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(obj)
    story.append(Spacer(1, 14))

    # Note libre
    if patient.get("note_libre"):
        story.append(Paragraph("Note", st["h2"]))
        note = Table([[Paragraph(patient["note_libre"].replace("\n", "<br/>"), st["base"])]],
                     colWidths=[util])
        note.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), HexColor("#FFFDF6")),
            ("BOX", (0, 0), (-1, -1), 0.7, HexColor("#F0E4BE")),
            ("LEFTPADDING", (0, 0), (-1, -1), 10), ("RIGHTPADDING", (0, 0), (-1, -1), 10),
            ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(note)
        story.append(Spacer(1, 14))

    seances = sorted(seances, key=lambda s: s.get("date_seance", ""))
    points = [{"date": s["date_seance"], "d": s["douleur"]}
              for s in seances if s.get("douleur")]

    # Graphe douleur
    if points:
        bloc = [Paragraph("Évolution de la douleur (EVA)", st["h2"]),
                _graphe_douleur(points, util)]
        story.append(KeepTogether(bloc))
        story.append(Spacer(1, 14))

    # Historique des séances
    story.append(Paragraph("Historique des séances", st["h2"]))
    if seances:
        entete = [Paragraph("<b>Date</b>", st["cell"]),
                  Paragraph("<b>EVA</b>", st["cell"]),
                  Paragraph("<b>Séance</b>", st["cell"])]
        lignes = [entete]
        for s in reversed(seances):  # plus récentes d'abord
            eva = str(s["douleur"]) if s.get("douleur") else "—"
            fait = (s.get("fait") or "").replace("\n", "<br/>") or "<i>—</i>"
            lignes.append([
                Paragraph(_jolie_date(s["date_seance"]), st["cellmuted"]),
                Paragraph(eva, st["cell"]),
                Paragraph(fait, st["cell"]),
            ])
        tbl = Table(lignes, colWidths=[24 * mm, 14 * mm, util - 38 * mm], repeatRows=1)
        style = [
            ("LINEBELOW", (0, 0), (-1, 0), 0.8, ACCENT),
            ("LINEBELOW", (0, 1), (-1, -1), 0.4, LIGNE),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ]
        for i, s in enumerate(reversed(seances), start=1):
            if s.get("douleur"):
                style.append(("TEXTCOLOR", (1, i), (1, i), _coul(s["douleur"])))
                style.append(("FONTNAME", (1, i), (1, i), "Helvetica-Bold"))
        tbl.setStyle(TableStyle(style))
        story.append(tbl)
    else:
        story.append(Paragraph("Aucune séance enregistrée.", st["cellmuted"]))

    def pied(canvas, doc_):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(MUTED)
        canvas.drawString(marge, 10 * mm, "Document confidentiel — secret médical")
        canvas.drawRightString(A4[0] - marge, 10 * mm, "Page %d" % doc_.page)
        canvas.restoreState()

    doc.build(story, onFirstPage=pied, onLaterPages=pied)
    return buf.getvalue()
__FIN_PDF_EXPORT_PY__

info "  · templates/base.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/base.html" << '__FIN_TEMPLATES_BASE_HTML__'
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{% block titre %}Cabinet kiné{% endblock %}</title>
<link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
</head>
<body class="{% block body_classe %}app{% endblock %}">
{% block chrome %}
  <aside class="rail">
    <div class="rail-mark">
      <span class="rail-dot"></span>
      Cabinet kiné
    </div>
    <nav class="rail-nav">
      <a href="{{ url_for('dashboard') }}" class="{% block nav_dash %}{% endblock %}">Patients</a>
      <a href="{{ url_for('calendrier') }}" class="{% block nav_cal %}{% endblock %}">Calendrier</a>
      <a href="{{ url_for('patient_nouveau') }}" class="{% block nav_new %}{% endblock %}">Nouveau patient</a>
      <a href="{{ url_for('archives') }}" class="{% block nav_arch %}{% endblock %}">Archives</a>
    </nav>
    <div class="rail-foot">
      {% if est_admin %}<a href="{{ url_for('admin_panel') }}" class="rail-test">Administration</a>{% endif %}
      <a href="{{ url_for('securite') }}" class="rail-test">Sécurité</a>
      <span class="local-tag">Tout en local</span>
      <a href="{{ url_for('deconnexion') }}" class="rail-out">Déconnexion</a>
    </div>
  </aside>
  <main class="stage {% block stage_classe %}{% endblock %}">
    {% with messages = get_flashed_messages() %}
      {% if messages %}
        <div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>
      {% endif %}
    {% endwith %}
    {% block contenu %}{% endblock %}
  </main>
{% endblock %}
{% block scripts %}{% endblock %}
</body>
</html>
__FIN_TEMPLATES_BASE_HTML__

info "  · templates/setup.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/setup.html" << '__FIN_TEMPLATES_SETUP_HTML__'
{% extends "base.html" %}
{% block titre %}Bienvenue — Cabinet kiné{% endblock %}
{% block body_classe %}center{% endblock %}
{% block chrome %}
<div class="auth-card">
  <div class="eyebrow">Première utilisation · tout reste en local</div>
  <h1>Créer votre compte</h1>
  <p class="lede">Ce compte protège l'accès aux dossiers. Choisissez vos identifiants ; ils restent sur cette machine.</p>
  {% with messages = get_flashed_messages() %}
    {% if messages %}<div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>{% endif %}
  {% endwith %}
  <form method="post">
    <label class="champ"><span>Identifiant</span>
      <input type="text" name="identifiant" autocomplete="username" required autofocus></label>
    <label class="champ"><span>Mot de passe (6 caractères minimum)</span>
      <input type="password" name="mdp" autocomplete="new-password" required></label>
    <label class="champ"><span>Confirmer le mot de passe</span>
      <input type="password" name="mdp2" autocomplete="new-password" required></label>
    <label class="champ"><span>Question de sécurité (pour récupérer le mot de passe)</span>
      <input type="text" name="question" maxlength="120" required
             value="Quelle est la marque de ma première voiture ?"></label>
    <label class="champ"><span>Réponse</span>
      <input type="text" name="reponse" maxlength="80" autocomplete="off" required></label>
    <button class="btn" type="submit" style="width:100%; justify-content:center;">Créer le compte</button>
  </form>
</div>
{% endblock %}
__FIN_TEMPLATES_SETUP_HTML__

info "  · templates/connexion.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/connexion.html" << '__FIN_TEMPLATES_CONNEXION_HTML__'
{% extends "base.html" %}
{% block titre %}Connexion — Cabinet kiné{% endblock %}
{% block body_classe %}center{% endblock %}
{% block chrome %}
<div class="auth-card">
  <div class="eyebrow">Cabinet kiné · accès privé</div>
  <h1>Connexion</h1>
  <p class="lede">Accédez à vos dossiers patients.</p>
  {% with messages = get_flashed_messages() %}
    {% if messages %}<div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>{% endif %}
  {% endwith %}
  <form method="post">
    <label class="champ"><span>Identifiant</span>
      <input type="text" name="identifiant" autocomplete="username" required autofocus></label>
    <label class="champ"><span>Mot de passe</span>
      <input type="password" name="mdp" autocomplete="current-password" required></label>
    <button class="btn" type="submit" style="width:100%; justify-content:center;">Se connecter</button>
  </form>
  <a class="lien-discret" href="{{ url_for('mdp_oublie') }}">Mot de passe oublié ?</a>
</div>
{% endblock %}
__FIN_TEMPLATES_CONNEXION_HTML__

info "  · templates/dashboard.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/dashboard.html" << '__FIN_TEMPLATES_DASHBOARD_HTML__'
{% extends "base.html" %}
{% block titre %}Patients — Cabinet kiné{% endblock %}
{% block nav_dash %}actif{% endblock %}
{% block contenu %}
<div class="row-between">
  <div>
    <h1 class="page">Patients</h1>
    <p class="page-lede">{{ patients|length }} dossier{{ 's' if patients|length != 1 else '' }} actif{{ 's' if patients|length != 1 else '' }}.</p>
  </div>
  <a class="btn" href="{{ url_for('patient_nouveau') }}">+ Nouveau patient</a>
</div>

{% if patients %}
<div class="patients">
  {% for p in patients %}
  <a class="pcard" href="{{ url_for('patient', pid=p.id) }}">
    <div class="nom">{{ p.nom }} {{ p.prenom }}{% if p.demo %} <span class="demo-tag">démo</span>{% endif %}</div>
    <div class="patho">{{ p.pathologie or "Pathologie non renseignée" }}</div>
    <div class="meta">
      <span>{{ p.nb_seances }} séance{{ 's' if p.nb_seances != 1 else '' }}</span>
      {% if p.douleur_recente %}
        <span class="pastille douleur-{{ p.douleur_recente }}">
          <span class="pip pip-{{ p.douleur_recente }}"></span>EVA {{ p.douleur_recente }}
        </span>
      {% endif %}
    </div>
  </a>
  {% endfor %}
</div>
{% else %}
<div class="vide">Aucun patient pour l'instant.<br>Cliquez sur « Nouveau patient » pour créer le premier dossier.</div>
{% endif %}

{% if nb_archives %}
<p class="page-lede" style="margin-top:28px;"><a href="{{ url_for('archives') }}">Voir les {{ nb_archives }} dossier{{ 's' if nb_archives != 1 else '' }} archivé{{ 's' if nb_archives != 1 else '' }}</a></p>
{% endif %}
{% endblock %}
__FIN_TEMPLATES_DASHBOARD_HTML__

info "  · templates/archives.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/archives.html" << '__FIN_TEMPLATES_ARCHIVES_HTML__'
{% extends "base.html" %}
{% block titre %}Archives — Cabinet kiné{% endblock %}
{% block nav_arch %}actif{% endblock %}
{% block contenu %}
<h1 class="page">Archives</h1>
<p class="page-lede">Dossiers archivés. L'historique est conservé ; vous pouvez les réactiver à tout moment.</p>

{% if patients %}
<div class="patients">
  {% for p in patients %}
  <div class="pcard" style="cursor:default;">
    <div class="nom">{{ p.nom }} {{ p.prenom }}</div>
    <div class="patho">{{ p.pathologie or "—" }}</div>
    <div class="meta" style="justify-content:space-between;">
      <a href="{{ url_for('patient', pid=p.id) }}">Ouvrir</a>
      <form method="post" action="{{ url_for('patient_restaurer', pid=p.id) }}">
        <button class="btn ghost sm" type="submit">Réactiver</button>
      </form>
    </div>
  </div>
  {% endfor %}
</div>
{% else %}
<div class="vide">Aucun dossier archivé.</div>
{% endif %}
{% endblock %}
__FIN_TEMPLATES_ARCHIVES_HTML__

info "  · templates/calendrier.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/calendrier.html" << '__FIN_TEMPLATES_CALENDRIER_HTML__'
{% extends "base.html" %}
{% block titre %}Calendrier — Cabinet kiné{% endblock %}
{% block nav_cal %}actif{% endblock %}
{% block stage_classe %}stage-large{% endblock %}
{% block contenu %}
<h1 class="page">Calendrier</h1>
<p class="page-lede">Toutes les séances du cabinet. Cliquez sur un jour pour voir les patients concernés.</p>

<div class="card">
  <div class="cal-tete">
    <div class="vue-toggle">
      <button id="vueJour" type="button">Jour</button>
      <button id="vueSemaine" type="button">Semaine</button>
      <button id="vueMois" type="button" class="actif">Mois</button>
    </div>
    <div class="mois" id="calMois"></div>
    <div class="cal-nav">
      <button id="calPrev" type="button" aria-label="Précédent">‹</button>
      <button id="calNext" type="button" aria-label="Suivant">›</button>
    </div>
  </div>
  <div class="cal-grille agenda-grille" id="calGrille"></div>
  <div class="cal-legende" id="calLegende"></div>
</div>

<!-- Fenêtre du jour -->
<div class="overlay" id="jourOverlay">
  <div class="modale" role="dialog" aria-modal="true" aria-labelledby="jourTitre">
    <h3 id="jourTitre">Séances du jour</h3>
    <div class="when" id="jourSous"></div>
    <div id="jourListe" class="jour-liste"></div>
    <div class="modale-actions" style="justify-content:flex-end;">
      <button class="btn ghost" id="jourFermer" type="button">Fermer</button>
    </div>
  </div>
</div>

<!-- Fenêtre d'ajout de créneau -->
<div class="overlay" id="creneauOverlay">
  <div class="modale" role="dialog" aria-modal="true" aria-labelledby="creneauTitre">
    <h3 id="creneauTitre">Nouveau créneau</h3>
    <div class="when" id="creneauQuand"></div>
    <label class="champ"><span>Patient</span>
      <select id="creneauPatient"></select></label>
    <label class="champ"><span>Praticien</span>
      <select id="creneauPraticien"></select></label>
    <div class="modale-actions" style="justify-content:flex-end;">
      <button class="btn ghost" id="creneauAnnuler" type="button">Annuler</button>
      <button class="btn" id="creneauOk" type="button">Ajouter au créneau</button>
    </div>
  </div>
</div>

<script>
  window.AGENDA_URL = "{{ url_for('agenda_json') }}";
  window.PATIENTS_URL = "{{ url_for('patients_json') }}";
  window.PATIENT_BASE = "{{ url_for('patient', pid=0) }}";
  window.CRENEAU_BASE = "{{ url_for('creneau_enregistrer', pid=0) }}";
  window.PRATICIENS = {{ praticiens|tojson }};
  window.PRAT_COULEURS = {{ praticiens_couleurs|tojson }};
</script>
{% endblock %}
{% block scripts %}
<script src="{{ url_for('static', filename='agenda.js') }}"></script>
{% endblock %}
__FIN_TEMPLATES_CALENDRIER_HTML__

info "  · templates/patient_form.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/patient_form.html" << '__FIN_TEMPLATES_PATIENT_FORM_HTML__'
{% extends "base.html" %}
{% block titre %}{{ "Nouveau patient" if mode == "nouveau" else "Modifier" }} — Cabinet kiné{% endblock %}
{% block nav_new %}{{ 'actif' if mode == 'nouveau' else '' }}{% endblock %}
{% block contenu %}
<h1 class="page">{{ "Nouveau patient" if mode == "nouveau" else "Modifier le dossier" }}</h1>
<p class="page-lede">La pathologie et les objectifs apparaîtront en évidence sur la fiche.</p>

<form method="post" class="card" style="max-width:720px;">
  <div class="grille2">
    <label class="champ"><span>Nom *</span>
      <input type="text" name="nom" value="{{ patient.nom or '' }}" required autofocus></label>
    <label class="champ"><span>Prénom *</span>
      <input type="text" name="prenom" value="{{ patient.prenom or '' }}" required></label>
  </div>
  <label class="champ"><span>Date de naissance</span>
    <input type="date" name="naissance" value="{{ patient.naissance or '' }}"></label>
  <label class="champ"><span>Pathologie</span>
    <input type="text" name="pathologie" value="{{ patient.pathologie or '' }}" placeholder="ex. Tendinopathie de la coiffe des rotateurs"></label>
  <div class="grille2">
    <label class="champ"><span>Objectif court terme</span>
      <textarea name="objectif_court" placeholder="ex. Retrouver l'amplitude sans douleur sous 3 semaines">{{ patient.objectif_court or '' }}</textarea></label>
    <label class="champ"><span>Objectif long terme</span>
      <textarea name="objectif_long" placeholder="ex. Reprise du sport sans appréhension">{{ patient.objectif_long or '' }}</textarea></label>
  </div>
  <label class="champ"><span>Note libre (particularités du patient)</span>
    <textarea name="note_libre" placeholder="ex. dépendant·e, déteste les courbatures, à rassurer…">{{ patient.note_libre or '' }}</textarea></label>

  <div style="display:flex; gap:10px; margin-top:8px;">
    <button class="btn" type="submit">{{ "Créer le dossier" if mode == "nouveau" else "Enregistrer" }}</button>
    <a class="btn ghost" href="{{ url_for('patient', pid=patient.id) if patient.id else url_for('dashboard') }}">Annuler</a>
  </div>
</form>
{% endblock %}
__FIN_TEMPLATES_PATIENT_FORM_HTML__

info "  · templates/patient.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/patient.html" << '__FIN_TEMPLATES_PATIENT_HTML__'
{% extends "base.html" %}
{% block titre %}{{ p.nom }} {{ p.prenom }} — Cabinet kiné{% endblock %}
{% block contenu %}
<div class="fiche-tete">
  <div class="row-between">
    <div>
      <a href="{{ url_for('dashboard') }}" style="font-size:13px;">← Patients</a>
      <h1>{{ p.nom }} {{ p.prenom }}</h1>
      <div class="sous">
        {% if p.naissance %}Né(e) le {{ p.naissance }} · {% endif %}
        Dossier créé le {{ p.cree_le[:10] }}
        {% if p.archive %} · <strong style="color:var(--danger)">archivé</strong>{% endif %}
      </div>
    </div>
    <div style="display:flex; gap:8px;">
      <a class="btn ghost sm" href="{{ url_for('patient_pdf', pid=p.id) }}">Exporter en PDF</a>
      <a class="btn ghost sm" href="{{ url_for('patient_modifier', pid=p.id) }}">Modifier</a>
      {% if p.archive %}
        <form method="post" action="{{ url_for('patient_restaurer', pid=p.id) }}"><button class="btn ghost sm">Réactiver</button></form>
      {% else %}
        <form method="post" action="{{ url_for('patient_archiver', pid=p.id) }}" onsubmit="return confirm('Archiver ce dossier ? L\'historique est conservé.')"><button class="btn danger sm">Archiver</button></form>
      {% endif %}
    </div>
  </div>
</div>

<!-- Infos clés en évidence -->
<div class="bandeau">
  <div class="bloc-clef patho">
    <div class="k">Pathologie</div>
    <div class="v {{ '' if p.pathologie else 'vide-v' }}">{{ p.pathologie or "Non renseignée" }}</div>
  </div>
  <div class="bloc-clef">
    <div class="k">Objectif court terme</div>
    <div class="v {{ '' if p.objectif_court else 'vide-v' }}" style="font-size:14px; font-weight:500;">{{ p.objectif_court or "Non renseigné" }}</div>
  </div>
  <div class="bloc-clef">
    <div class="k">Objectif long terme</div>
    <div class="v {{ '' if p.objectif_long else 'vide-v' }}" style="font-size:14px; font-weight:500;">{{ p.objectif_long or "Non renseigné" }}</div>
  </div>
</div>

<!-- Note libre -->
<div class="card note-zone">
  <h2>Note du patient</h2>
  <form method="post" action="{{ url_for('patient_note', pid=p.id) }}">
    <textarea name="note_libre" placeholder="Particularités à garder en tête…">{{ p.note_libre or '' }}</textarea>
    <div class="note-row"><button class="btn ghost sm" type="submit">Enregistrer la note</button></div>
  </form>
</div>

<!-- Bilan oral -->
{% if AUDIO_DISPO %}
<div class="card" id="bilan">
  <h2>Bilan oral</h2>
  <p class="aide">Dictez votre bilan : transcription et résumé sont calculés en local, rien n'est envoyé en ligne. Relisez le résumé avant de l'insérer.</p>
  <div class="rec-row">
    <button id="recBtn" class="rec-btn" type="button" aria-label="Démarrer la dictée"><span class="dot"></span></button>
    <div id="meter" class="meter" aria-hidden="true">
      <span class="bar"></span><span class="bar"></span><span class="bar"></span><span class="bar"></span>
      <span class="bar"></span><span class="bar"></span><span class="bar"></span><span class="bar"></span>
      <span class="bar"></span><span class="bar"></span><span class="bar"></span><span class="bar"></span>
    </div>
    <div id="timer" class="timer">0:00</div>
  </div>
  <p class="hint" id="recHint">Cliquez pour dicter. Re-cliquez pour arrêter et lancer la transcription.</p>
  <div class="status" id="bilanStatus" role="status" aria-live="polite"></div>

  <div class="bilan-res" id="bilanRes" style="display:none;">
    <label class="champ"><span>Résumé du bilan (modifiable)</span>
      <textarea id="bilanResume" style="min-height:120px;"></textarea></label>
    <details><summary>Voir la transcription brute</summary>
      <div class="brut" id="bilanBrut"></div></details>
    <label class="champ" style="max-width:240px; margin-top:14px;"><span>Date de la séance</span>
      <input type="date" id="bilanDate"></label>
    <div class="hint" id="dateInfo" style="margin-top:0;"></div>
    <div class="bilan-actions">
      <span class="moteur-tag" id="moteurTag"></span>
      <div style="display:flex; gap:8px;">
        <button class="btn ghost" id="bilanNote" type="button">Ajouter à la note</button>
        <button class="btn" id="bilanSeance" type="button">Insérer dans la séance</button>
      </div>
    </div>
  </div>
</div>
{% else %}
<div class="card" id="bilan">
  <h2>Bilan oral</h2>
  <p class="aide">Le module audio n'est pas installé. Pour l'activer : <code>bash installer.sh --avec-audio</code>, puis relancez l'application.</p>
</div>
{% endif %}

<!-- Calendrier -->
<div class="card">
  <h2>Calendrier des séances</h2>
  <div class="cal-tete">
    <div class="cal-nav"><button id="calPrev" type="button" aria-label="Mois précédent">‹</button></div>
    <div class="mois" id="calMois"></div>
    <div class="cal-nav"><button id="calNext" type="button" aria-label="Mois suivant">›</button></div>
  </div>
  <div class="cal-grille" id="calGrille"></div>
  <div class="cal-legende">
    <span><span class="lg" style="background:var(--accent)"></span> séance notée</span>
    <span><span class="lg" style="background:var(--ok)"></span> douleur faible (1-3)</span>
    <span><span class="lg" style="background:var(--warn)"></span> modérée (4-6)</span>
    <span><span class="lg" style="background:var(--danger)"></span> forte (7-10)</span>
  </div>
</div>

<!-- Graphique douleur -->
<div class="card">
  <h2>Évolution de la douleur (EVA)</h2>
  <div class="graph-wrap" id="graphWrap">
    <div class="graph-vide" id="graphVide">Pas encore de douleur enregistrée. Notez une séance pour voir la courbe.</div>
  </div>
</div>

<!-- Séances -->
<div class="card" id="seances">
  <h2>Séances <span class="compteur">· {{ seances|length }}</span></h2>
  {% if seances %}
    {% for s in seances %}
    <div class="seance-item">
      <div class="tete">
        <span class="date">{{ s.date_seance }}</span>
        <div style="display:flex; align-items:center; gap:10px;">
          {% if s.douleur %}<span class="pastille douleur-{{ s.douleur }}"><span class="pip pip-{{ s.douleur }}"></span>EVA {{ s.douleur }}</span>{% endif %}
          <button class="btn ghost sm js-edit"
                  data-date="{{ s.date_seance }}"
                  data-fait="{{ s.fait or '' }}"
                  data-douleur="{{ s.douleur or 0 }}">Modifier</button>
        </div>
      </div>
      {% if s.fait %}<div class="fait">{{ s.fait }}</div>{% endif %}
    </div>
    {% endfor %}
  {% else %}
    <div class="vide" style="padding:30px;">Aucune séance enregistrée.<br>Cliquez sur un jour du calendrier pour en ajouter une.</div>
  {% endif %}
</div>

<!-- Modale séance -->
<div class="overlay" id="overlay">
  <div class="modale" role="dialog" aria-modal="true" aria-labelledby="modTitre">
    <h3 id="modTitre">Séance</h3>
    <div class="when" id="modDate"></div>
    <form method="post" action="{{ url_for('seance_enregistrer', pid=p.id) }}" id="seanceForm">
      <input type="hidden" name="date_seance" id="fDate">
      <div class="grille2">
        <label class="champ"><span>Heure du créneau</span>
          <select name="heure" id="fHeure">
            <option value="">— sans horaire —</option>
            {% for h in range(7, 20) %}
            <option value="{{ '%02d:00'|format(h) }}">{{ '%02d:00'|format(h) }}</option>
            <option value="{{ '%02d:30'|format(h) }}">{{ '%02d:30'|format(h) }}</option>
            {% endfor %}
          </select></label>
        <label class="champ"><span>Praticien</span>
          <select name="praticien" id="fPraticien">
            <option value="">—</option>
            {% for pr in praticiens %}<option value="{{ pr }}">{{ pr }}</option>{% endfor %}
          </select></label>
      </div>
      <label class="champ"><span>Ce qui a été fait</span>
        <textarea name="fait" id="fFait" placeholder="Exercices, manipulations, ressenti…"></textarea></label>
      <div class="reform-row">
        <button type="button" class="btn ghost sm" id="reformBtn">Reformuler</button>
        <button type="button" class="btn ghost sm" id="reformUndo" style="display:none;">Rétablir</button>
        <span class="reform-status" id="reformStatus"></span>
      </div>
      <div class="eva">
        <div class="eva-haut">
          <span style="font-size:13px;color:var(--muted);">Niveau de douleur</span>
          <span class="eva-val" id="evaVal">—</span>
        </div>
        <input type="range" name="douleur" id="fDouleur" min="0" max="10" value="0" step="1">
        <div class="eva-echelle"><span>aucune</span><span>5</span><span>10 max</span></div>
      </div>
      <div class="modale-actions">
        <button type="button" class="btn ghost sm" id="modSupprimer" style="visibility:hidden;">Supprimer</button>
        <div style="display:flex; gap:8px;">
          <button type="button" class="btn ghost" id="modFermer">Annuler</button>
          <button type="submit" class="btn">Enregistrer</button>
        </div>
      </div>
    </form>
    <form method="post" id="supprimerForm" style="display:none;"></form>
  </div>
</div>

<script>
  window.PATIENT_ID = {{ p.id }};
  window.SEANCES_URL = "{{ url_for('seances_json', pid=p.id) }}";
  window.SUPPR_BASE = "{{ url_for('seance_supprimer', pid=p.id, sid=0) }}";
  window.SEANCE_URL = "{{ url_for('seance_enregistrer', pid=p.id) }}";
  window.NOTE_URL = "{{ url_for('patient_note', pid=p.id) }}";
  window.BILAN_URL = "{{ url_for('bilan_oral', pid=p.id) }}" ;
  window.REFORM_URL = "{{ url_for('reformuler') }}";
  window.AUDIO_DISPO = {{ 'true' if AUDIO_DISPO else 'false' }};
  window.AUJOURDHUI = "{{ aujourdhui }}";
</script>
{% endblock %}
{% block scripts %}
<script src="{{ url_for('static', filename='app.js') }}"></script>
{% endblock %}
__FIN_TEMPLATES_PATIENT_HTML__

info "  · templates/admin_panel.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/admin_panel.html" << '__FIN_TEMPLATES_ADMIN_PANEL_HTML__'
{% extends "base.html" %}
{% block titre %}Administration — Cabinet kiné{% endblock %}
{% block contenu %}
<h1 class="page">Administration</h1>
<p class="page-lede">Réservé au compte administrateur : gestion des praticiens et données de test.</p>

{% with messages = get_flashed_messages() %}
  {% if messages %}<div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>{% endif %}
{% endwith %}

<div class="card" id="praticiens">
  <h2>Praticiens</h2>
  <p class="aide">Chaque praticien a son propre compte : il se connecte avec son nom et son mot de passe, et il est proposé lors de la planification des séances. Seul l'administrateur peut gérer cette liste et générer des données de test.</p>
  <ul class="prat-liste">
    {% for c in comptes %}
    <li>
      {% if c.role == 'admin' %}
        <span class="role-tag role-admin">admin</span>
        <span class="prat-nom">{{ c.identifiant }}{% if c.id == moi %} <span class="aide">(vous)</span>{% endif %}</span>
      {% else %}
        <span class="prat-pastille" style="background:{{ couleurs[c.identifiant] }}"></span>
        <span class="prat-nom">{{ c.identifiant }}</span>
        <form method="post" action="{{ url_for('admin_compte_supprimer', compte_id=c.id) }}"
              onsubmit="return confirm('Retirer le praticien {{ c.identifiant }} ? Son compte sera supprimé (les séances passées gardent son nom).')">
          <button class="btn ghost sm" type="submit">Retirer</button>
        </form>
      {% endif %}
    </li>
    {% endfor %}
  </ul>
  <h3 style="margin:16px 0 6px; font-size:14px;">Ajouter un praticien</h3>
  <form method="post" action="{{ url_for('admin_compte_ajouter') }}" class="grille2">
    <label class="champ"><span>Nom (sert d'identifiant de connexion)</span>
      <input type="text" name="identifiant" minlength="3" maxlength="40" required></label>
    <label class="champ"><span>Mot de passe (6 caractères min)</span>
      <input type="password" name="mdp" minlength="6" autocomplete="new-password" required></label>
    <div style="grid-column:1/-1;"><button class="btn" type="submit">Créer le compte praticien</button></div>
  </form>
  <p class="aide">Le praticien pourra ensuite définir sa propre question de sécurité et changer son mot de passe via « Sécurité ».</p>
</div>

<div class="card" id="donnees">
  <h2>Données de test</h2>
  <p class="aide">Génère des patients fictifs (marqués « démo ») pour tester l'affichage. Réservé à l'administrateur ; tout est supprimable ci-dessous.</p>

  <h3 style="margin:14px 0 6px; font-size:14px;">Beaucoup de patients un même jour</h3>
  <form method="post" action="{{ url_for('test_jour') }}">
    <div class="grille2">
      <label class="champ"><span>Date</span>
        <input type="date" name="date" value="{{ aujourdhui }}"></label>
      <label class="champ"><span>Nombre de patients (max 150)</span>
        <input type="number" name="nombre" value="25" min="1" max="150"></label>
    </div>
    <button class="btn" type="submit">Générer ce jour-là</button>
  </form>

  <h3 style="margin:18px 0 6px; font-size:14px;">Remplir un mois</h3>
  <form method="post" action="{{ url_for('test_mois') }}">
    <div class="grille2">
      <label class="champ"><span>Mois</span>
        <input type="month" name="aaaamm" value="{{ aujourdhui[:7] }}"></label>
      <label class="champ"><span>Nombre de séances (max 400)</span>
        <input type="number" name="nombre" value="60" min="1" max="400"></label>
    </div>
    <button class="btn" type="submit">Remplir le mois</button>
  </form>

  <h3 style="margin:18px 0 6px; font-size:14px;">Nettoyage</h3>
  <p class="aide">Patients de démo actuellement en base : <strong>{{ nb_demo }}</strong>.</p>
  <form method="post" action="{{ url_for('test_purge') }}"
        onsubmit="return confirm('Supprimer tous les patients de démo et leurs séances ?')">
    <button class="btn danger" type="submit">Supprimer toutes les données de démo</button>
  </form>
</div>
{% endblock %}
__FIN_TEMPLATES_ADMIN_PANEL_HTML__

info "  · templates/mdp_oublie.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/mdp_oublie.html" << '__FIN_TEMPLATES_MDP_OUBLIE_HTML__'
{% extends "base.html" %}
{% block titre %}Mot de passe oublié — Cabinet kiné{% endblock %}
{% block body_classe %}center{% endblock %}
{% block chrome %}
<div class="auth-card">
  <div class="eyebrow">Cabinet kiné · récupération</div>
  <h1>Mot de passe oublié</h1>
  {% with messages = get_flashed_messages() %}
    {% if messages %}<div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>{% endif %}
  {% endwith %}
  {% if etape == 2 %}
    <p class="lede">Répondez à votre question de sécurité pour définir un nouveau mot de passe.</p>
    <form method="post">
      <input type="hidden" name="identifiant" value="{{ identifiant }}">
      <label class="champ"><span>{{ question }}</span>
        <input type="text" name="reponse" autocomplete="off" required autofocus></label>
      <label class="champ"><span>Nouveau mot de passe</span>
        <input type="password" name="mdp" autocomplete="new-password" required></label>
      <label class="champ"><span>Confirmer le mot de passe</span>
        <input type="password" name="mdp2" autocomplete="new-password" required></label>
      <button class="btn" type="submit" style="width:100%; justify-content:center;">Réinitialiser</button>
    </form>
  {% else %}
    <p class="lede">Saisissez votre identifiant pour afficher votre question de sécurité.</p>
    <form method="post">
      <label class="champ"><span>Identifiant</span>
        <input type="text" name="identifiant" autocomplete="username" required autofocus></label>
      <button class="btn" type="submit" style="width:100%; justify-content:center;">Continuer</button>
    </form>
  {% endif %}
  <a class="lien-discret" href="{{ url_for('connexion') }}">Retour à la connexion</a>
</div>
{% endblock %}
__FIN_TEMPLATES_MDP_OUBLIE_HTML__

info "  · templates/securite.html"
mkdir -p "$APP/templates"
cat > "$APP/templates/securite.html" << '__FIN_TEMPLATES_SECURITE_HTML__'
{% extends "base.html" %}
{% block titre %}Sécurité — Cabinet kiné{% endblock %}
{% block contenu %}
<h1 class="page">Sécurité du compte</h1>
<p class="page-lede">Compte : <strong>{{ compte.identifiant }}</strong></p>

{% with messages = get_flashed_messages() %}
  {% if messages %}<div class="flash">{% for m in messages %}<div>{{ m }}</div>{% endfor %}</div>{% endif %}
{% endwith %}

<div class="card">
  <h2>Changer le mot de passe</h2>
  <form method="post">
    <input type="hidden" name="action" value="mdp">
    <label class="champ"><span>Mot de passe actuel</span>
      <input type="password" name="ancien" autocomplete="current-password" required></label>
    <div class="grille2">
      <label class="champ"><span>Nouveau mot de passe</span>
        <input type="password" name="mdp" autocomplete="new-password" required></label>
      <label class="champ"><span>Confirmer</span>
        <input type="password" name="mdp2" autocomplete="new-password" required></label>
    </div>
    <button class="btn" type="submit">Modifier le mot de passe</button>
  </form>
</div>

<div class="card">
  <h2>Question de sécurité</h2>
  <p class="aide">Elle permet de réinitialiser votre mot de passe en cas d'oubli.
    {% if compte.question %}Question actuelle : « {{ compte.question }} ».{% else %}<strong>Aucune question n'est encore définie.</strong>{% endif %}</p>
  <form method="post">
    <input type="hidden" name="action" value="question">
    <label class="champ"><span>Question</span>
      <input type="text" name="question" maxlength="120" required
             value="{{ compte.question or 'Quelle est la marque de ma première voiture ?' }}"></label>
    <label class="champ"><span>Réponse</span>
      <input type="text" name="reponse" maxlength="80" autocomplete="off" required></label>
    <button class="btn" type="submit">Enregistrer la question</button>
  </form>
</div>
{% endblock %}
__FIN_TEMPLATES_SECURITE_HTML__

info "  · static/style.css"
mkdir -p "$APP/static"
cat > "$APP/static/style.css" << '__FIN_STATIC_STYLE_CSS__'
:root {
  --bg: #EAEDF2;
  --surface: #FFFFFF;
  --ink: #161A23;
  --muted: #5A6473;
  --line: #DCE0E8;
  --accent: #5A4FE3;
  --accent-deep: #463CC4;
  --accent-soft: #F0EFFC;
  --live: #E2683A;
  --ok: #1F9D6B;
  --warn: #E0A100;
  --danger: #D2493B;
  --cal-h: clamp(340px, calc(100vh - 300px), 1000px);
  --mono: ui-monospace, "SF Mono", "JetBrains Mono", Menlo, Consolas, monospace;
  --sans: system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}

* { box-sizing: border-box; }

body {
  margin: 0;
  min-height: 100vh;
  background: radial-gradient(120% 80% at 50% -10%, #F4F5F9 0%, var(--bg) 55%);
  color: var(--ink);
  font-family: var(--sans);
  line-height: 1.5;
}

a { color: var(--accent); text-decoration: none; }
a:hover { color: var(--accent-deep); }

/* ---------- Pages plein écran (connexion / setup) ---------- */
body.center {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
}
.auth-card {
  width: 100%;
  max-width: 400px;
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 16px;
  padding: 32px;
  box-shadow: 0 1px 0 rgba(22,26,35,0.02), 0 12px 30px -18px rgba(22,26,35,0.22);
}
.eyebrow {
  font-family: var(--mono);
  font-size: 12px;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: var(--muted);
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 14px;
}
.eyebrow::before {
  content: "";
  width: 7px; height: 7px; border-radius: 50%;
  background: var(--ok);
  box-shadow: 0 0 0 3px rgba(31,157,107,0.18);
}
.auth-card h1 { font-size: 24px; font-weight: 660; letter-spacing: -0.02em; margin: 0 0 6px; }
.auth-card .lede { color: var(--muted); margin: 0 0 24px; font-size: 14px; }

/* ---------- Application (rail + scène) ---------- */
body.app { display: flex; }

.rail {
  width: clamp(190px, 16vw, 232px);
  flex: none;
  min-height: 100vh;
  background: var(--surface);
  border-right: 1px solid var(--line);
  padding: 26px 18px;
  display: flex;
  flex-direction: column;
  position: sticky;
  top: 0;
  height: 100vh;
}
.rail-mark {
  font-weight: 680;
  letter-spacing: -0.01em;
  display: flex; align-items: center; gap: 9px;
  margin-bottom: 28px;
}
.rail-dot {
  width: 10px; height: 10px; border-radius: 3px;
  background: var(--accent);
}
.rail-nav { display: flex; flex-direction: column; gap: 2px; }
.rail-nav a {
  color: var(--ink);
  padding: 9px 12px;
  border-radius: 9px;
  font-size: 14px;
  transition: background .12s ease, color .12s ease;
}
.rail-nav a:hover { background: var(--accent-soft); color: var(--accent-deep); }
.rail-nav a.actif { background: var(--accent); color: #fff; }
.rail-foot { margin-top: auto; display: flex; flex-direction: column; gap: 12px; }
.local-tag {
  font-family: var(--mono);
  font-size: 11px;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--muted);
  display: flex; align-items: center; gap: 7px;
}
.local-tag::before {
  content: ""; width: 6px; height: 6px; border-radius: 50%;
  background: var(--ok); box-shadow: 0 0 0 3px rgba(31,157,107,0.16);
}
.rail-out { font-size: 13px; color: var(--muted); }
.rail-out:hover { color: var(--danger); }
.rail-test { font-size: 13px; color: var(--muted); }
.rail-test:hover { color: var(--accent); }
.demo-tag {
  font-family: var(--mono); font-size: 10px; color: var(--muted);
  border: 1px solid var(--line); border-radius: 6px; padding: 1px 5px;
  vertical-align: 1px; font-weight: 400;
}

.stage { flex: 1; min-width: 0; padding: clamp(24px, 3vw, 40px) clamp(18px, 3.4vw, 44px) 64px; max-width: 1120px; margin: 0 auto; }
.stage-large { max-width: 1560px; }

/* ---------- Éléments communs ---------- */
.flash {
  background: #FFF7E8;
  border: 1px solid #F0DDA8;
  color: #8A6400;
  border-radius: 10px;
  padding: 12px 14px;
  font-size: 14px;
  margin-bottom: 22px;
}
.flash div + div { margin-top: 4px; }

h1.page { font-size: 28px; font-weight: 660; letter-spacing: -0.02em; margin: 0 0 4px; }
.page-lede { color: var(--muted); margin: 0 0 28px; font-size: 15px; }

.row-between { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; flex-wrap: wrap; }

.btn {
  font: inherit; font-size: 14px; font-weight: 560;
  padding: 10px 16px; border-radius: 10px;
  border: none; background: var(--accent); color: #fff;
  cursor: pointer; transition: background .14s ease, transform .06s ease;
  display: inline-flex; align-items: center; gap: 8px;
}
.btn:hover { background: var(--accent-deep); }
.btn:active { transform: translateY(1px); }
.btn.ghost { background: #fff; color: var(--ink); border: 1px solid var(--line); }
.btn.ghost:hover { border-color: var(--accent); color: var(--accent); }
.btn.danger { background: #fff; color: var(--danger); border: 1px solid #E6C7C2; }
.btn.danger:hover { background: var(--danger); color: #fff; border-color: var(--danger); }
.btn.sm { padding: 7px 12px; font-size: 13px; }
.btn:focus-visible, a:focus-visible { outline: 3px solid var(--accent); outline-offset: 2px; border-radius: 8px; }

.card {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 1px 0 rgba(22,26,35,0.02), 0 12px 30px -20px rgba(22,26,35,0.18);
}
.card + .card { margin-top: 20px; }
.card h2 { font-size: 15px; font-weight: 620; margin: 0 0 16px; letter-spacing: -0.01em; }
.card h2 .compteur { color: var(--muted); font-weight: 400; }

/* Champs de formulaire */
label.champ { display: block; margin-bottom: 16px; }
label.champ > span {
  display: block; font-size: 13px; color: var(--muted);
  margin-bottom: 6px; font-weight: 540;
}
input[type=text], input[type=password], input[type=date], textarea, select {
  width: 100%; font: inherit; font-size: 15px;
  padding: 10px 12px; border-radius: 10px;
  border: 1px solid var(--line); background: #FBFBFD; color: var(--ink);
}
textarea { resize: vertical; min-height: 80px; line-height: 1.55; }
input:focus-visible, textarea:focus-visible, select:focus-visible {
  outline: 3px solid var(--accent); outline-offset: 1px;
}
.grille2 { display: grid; grid-template-columns: 1fr 1fr; gap: 0 18px; }

/* ---------- Liste patients (dashboard) ---------- */
.patients { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 16px; }
.pcard {
  background: var(--surface); border: 1px solid var(--line); border-radius: 14px;
  padding: 18px; transition: border-color .14s ease, transform .08s ease, box-shadow .14s ease;
  display: block;
}
.pcard:hover { border-color: var(--accent); transform: translateY(-2px); box-shadow: 0 14px 26px -18px rgba(90,79,227,0.4); }
.pcard .nom { font-weight: 620; color: var(--ink); font-size: 16px; letter-spacing: -0.01em; }
.pcard .patho { color: var(--muted); font-size: 13px; margin-top: 4px; min-height: 18px; }
.pcard .meta { display: flex; align-items: center; gap: 10px; margin-top: 14px; font-size: 12.5px; color: var(--muted); }

.pastille {
  display: inline-flex; align-items: center; gap: 6px; white-space: nowrap; flex: none;
  font-family: var(--mono); font-size: 12px; padding: 3px 9px; border-radius: 999px;
  border: 1px solid var(--line);
}
.pastille .pip { width: 8px; height: 8px; border-radius: 50%; }
.douleur-1, .douleur-2, .douleur-3 { color: var(--ok); }
.douleur-4, .douleur-5, .douleur-6 { color: var(--warn); }
.douleur-7, .douleur-8, .douleur-9, .douleur-10 { color: var(--danger); }
.pip-1,.pip-2,.pip-3 { background: var(--ok); }
.pip-4,.pip-5,.pip-6 { background: var(--warn); }
.pip-7,.pip-8,.pip-9,.pip-10 { background: var(--danger); }

.vide {
  text-align: center; color: var(--muted); padding: 50px 20px;
  border: 1.5px dashed var(--line); border-radius: 14px; font-size: 15px;
}

/* ---------- Fiche patient ---------- */
.fiche-tete { margin-bottom: 24px; }
.fiche-tete h1 { font-size: 30px; font-weight: 680; letter-spacing: -0.025em; margin: 6px 0 0; }
.fiche-tete .sous { color: var(--muted); font-size: 14px; margin-top: 4px; }

.bandeau { display: grid; grid-template-columns: 1.1fr 1fr 1fr; gap: 16px; margin-bottom: 20px; }
.bloc-clef {
  border-radius: 14px; padding: 18px; border: 1px solid var(--line); background: var(--surface);
}
.bloc-clef.patho { background: linear-gradient(180deg, #FBF1EE 0%, #fff 70%); border-color: #F1D9D1; }
.bloc-clef .k {
  font-family: var(--mono); font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase;
  color: var(--muted); margin-bottom: 8px;
}
.bloc-clef.patho .k { color: var(--live); }
.bloc-clef .v { font-size: 16px; font-weight: 560; letter-spacing: -0.01em; }
.bloc-clef .v.vide-v { color: var(--muted); font-weight: 400; font-style: italic; }

.note-zone textarea { background: #FFFDF6; border-color: #F0E4BE; }
.note-row { display: flex; justify-content: flex-end; margin-top: 10px; }

/* Calendrier */
.cal-tete { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
.cal-tete .mois { font-weight: 620; font-size: 15px; min-width: 150px; text-align: center; text-transform: capitalize; }
.cal-nav { display: flex; gap: 6px; }
.cal-nav button {
  width: 34px; height: 34px; border-radius: 9px; border: 1px solid var(--line);
  background: #fff; cursor: pointer; font-size: 16px; color: var(--ink);
}
.cal-nav button:hover { border-color: var(--accent); color: var(--accent); }
.cal-grille { display: grid; grid-template-columns: repeat(7, 1fr); gap: 6px; }
.cal-jour-nom { font-size: 11px; color: var(--muted); text-align: center; font-family: var(--mono); text-transform: uppercase; letter-spacing: 0.06em; padding-bottom: 4px; }
.cal-case {
  aspect-ratio: 1 / 1; border: 1px solid var(--line); border-radius: 10px;
  background: #fff; cursor: pointer; padding: 6px; position: relative;
  font-size: 13px; color: var(--ink); text-align: left;
  transition: border-color .12s ease, background .12s ease;
}
.cal-case:hover { border-color: var(--accent); background: var(--accent-soft); }
.cal-case.vide-case { background: transparent; border-color: transparent; cursor: default; }
.cal-case.ajd { box-shadow: inset 0 0 0 2px var(--accent); }
.cal-case .pt {
  position: absolute; bottom: 6px; right: 6px;
  width: 18px; height: 18px; border-radius: 50%;
  font-size: 10px; color: #fff; display: grid; place-items: center; font-weight: 600;
}
.cal-case .fait-dot { position: absolute; bottom: 8px; left: 6px; width: 7px; height: 7px; border-radius: 50%; background: var(--accent); }
.cal-legende { display: flex; gap: 16px; margin-top: 14px; font-size: 12px; color: var(--muted); flex-wrap: wrap; }
.cal-legende span { display: inline-flex; align-items: center; gap: 6px; }
.lg { width: 12px; height: 12px; border-radius: 50%; }

/* Graphique douleur */
.graph-wrap { width: 100%; overflow-x: auto; }
.graph-vide { color: var(--muted); font-style: italic; font-size: 14px; padding: 30px 0; text-align: center; }
svg.graph text { font-family: var(--mono); font-size: 11px; fill: var(--muted); }

/* Calendrier général (agenda) */
.vue-toggle { display: inline-flex; border: 1px solid var(--line); border-radius: 9px; overflow: hidden; }
.vue-toggle button {
  border: none; background: #fff; padding: 7px 14px; font: inherit; font-size: 13px;
  cursor: pointer; color: var(--muted); transition: background .12s ease, color .12s ease;
}
.vue-toggle button + button { border-left: 1px solid var(--line); }
.vue-toggle button:hover { color: var(--accent); }
.vue-toggle button.actif { background: var(--accent); color: #fff; }

.cal-case.sel { box-shadow: inset 0 0 0 2px var(--accent); background: var(--accent-soft); }
.agenda-grille { height: var(--cal-h); grid-template-rows: auto; grid-auto-rows: 1fr; }
.agenda-grille .cal-case {
  aspect-ratio: auto; min-height: 0; padding: 5px 6px;
  display: flex; flex-direction: column; align-items: stretch; gap: 2px; overflow: hidden;
}
.agenda-grille .cal-case .cal-jour-num { font-size: 12px; font-weight: 600; color: var(--muted); }
.agenda-grille .cal-case.ajd .cal-jour-num { color: var(--accent); }
.cal-noms { display: flex; flex-direction: column; gap: 1px; overflow: hidden; min-width: 0; }
.nom-mini {
  font-size: 10.5px; line-height: 1.35; color: var(--ink);
  display: flex; align-items: center; gap: 4px; min-width: 0; overflow: hidden;
}
.nom-mini .nm-dot { width: 6px; height: 6px; border-radius: 50%; flex: none; }
.nm-dot { width: 6px; height: 6px; border-radius: 50%; flex: none; }
.nom-txt { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0; }
.nom-plus { font-size: 10px; color: var(--muted); font-family: var(--mono); }
@media (max-width: 760px) {
  .agenda-grille { height: auto; grid-auto-rows: minmax(58px, auto); }
  .agenda-grille .cal-case { min-height: 58px; }
  .nom-mini { font-size: 9.5px; }
}

.agenda-jour h2 { font-size: 15px; }
.jour-liste { max-height: 56vh; overflow-y: auto; overflow-x: hidden; scrollbar-gutter: stable; margin: 4px 0 4px; }
.jour-liste .agenda-item:first-child { margin-top: 0; }

/* Vue semaine */
.semaine-grille { gap: 8px; align-items: stretch; height: var(--cal-h); grid-auto-rows: 1fr; }
.sem-col {
  border: 1px solid var(--line); border-radius: 12px; background: #fff;
  overflow: hidden; display: flex; flex-direction: column; min-width: 0;
  height: 100%;
}
.sem-col.ajd { border-color: var(--accent); box-shadow: inset 0 0 0 1px var(--accent); }
.sem-tete {
  flex: none;
  border: none; background: var(--accent-soft); color: var(--ink);
  padding: 8px 6px; cursor: pointer; border-bottom: 1px solid var(--line);
  display: flex; flex-direction: column; align-items: center; gap: 1px;
  transition: background .12s ease;
}
.sem-tete:hover { background: #E6E3FB; }
.sem-col.ajd .sem-tete { background: var(--accent); color: #fff; }
.sem-jour { font-family: var(--mono); font-size: 10px; letter-spacing: 0.06em; text-transform: uppercase; opacity: .85; }
.sem-num { font-size: 16px; font-weight: 600; line-height: 1.1; }
.sem-liste {
  flex: 1; min-height: 0; display: flex; flex-direction: column; gap: 2px; padding: 6px;
  min-width: 0; overflow-y: auto; overflow-x: hidden; scrollbar-gutter: stable;
}
.sem-item {
  display: flex; align-items: center; gap: 5px; padding: 4px 5px; border-radius: 7px;
  text-decoration: none; color: var(--ink); font-size: 12px; min-width: 0; flex: none;
}
.sem-item:hover { background: var(--accent-soft); }
.sem-item .nom-txt { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0; }
.sem-vide { color: var(--muted); text-align: center; padding: 10px 0; font-size: 13px; }
@media (max-width: 760px) {
  .semaine-grille { grid-template-columns: 1fr; height: auto; grid-auto-rows: auto; }
  .sem-col { height: auto; }
  .sem-liste { max-height: 280px; }
  .sem-tete { flex-direction: row; gap: 8px; justify-content: flex-start; padding-left: 12px; }
}
.sem-h { font-family: var(--mono); font-size: 10px; color: var(--muted); flex: none; }

/* Vue jour (créneaux) */
.jour-vue {
  height: var(--cal-h); overflow-y: auto; overflow-x: hidden; scrollbar-gutter: stable;
  border: 1px solid var(--line); border-radius: 12px; background: #fff; padding: 2px 4px;
}
.jour-sans { border-bottom: 2px solid var(--line); margin-bottom: 2px; }
.jour-sans-tete {
  font-family: var(--mono); font-size: 11px; text-transform: uppercase; letter-spacing: .06em;
  color: var(--muted); padding: 8px 6px 2px;
}
.creneau { display: flex; gap: 10px; align-items: flex-start; padding: 3px 6px; border-bottom: 1px solid var(--line); }
.creneau:last-child { border-bottom: none; }
.creneau-h { font-family: var(--mono); font-size: 12px; color: var(--muted); width: 46px; flex: none; padding-top: 8px; }
.creneau-corps { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; flex: 1; min-width: 0; padding: 4px 0; }
.creneau-pat {
  display: inline-flex; align-items: center; gap: 5px; padding: 4px 9px;
  border: 1px solid var(--line); border-radius: 999px; text-decoration: none;
  color: var(--ink); font-size: 12.5px; background: #fff; max-width: 100%;
}
.creneau-pat:hover { border-color: var(--accent); background: var(--accent-soft); }
.creneau-pat .nom-txt { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.chip-eva {
  color: #fff; font-size: 10px; font-weight: 600; min-width: 16px; height: 16px;
  border-radius: 8px; display: inline-grid; place-items: center; padding: 0 3px;
}
.chip-prat {
  color: #fff; font-size: 10px; font-weight: 600; height: 16px; flex: none;
  border-radius: 8px; display: inline-grid; place-items: center; padding: 0 7px;
  white-space: nowrap; letter-spacing: 0.02em;
}
.creneau-add {
  width: 24px; height: 24px; border-radius: 7px; border: 1px dashed var(--line);
  background: #fff; color: var(--muted); cursor: pointer; font-size: 15px; line-height: 1;
  display: grid; place-items: center; flex: none;
}
.creneau-add:hover { border-color: var(--accent); color: var(--accent); border-style: solid; }
.agenda-item {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  padding: 12px 14px; border: 1px solid var(--line); border-radius: 12px;
  text-decoration: none; color: var(--ink);
  transition: border-color .12s ease, background .12s ease;
}
.agenda-item + .agenda-item { margin-top: 8px; }
.agenda-item:hover { border-color: var(--accent); background: var(--accent-soft); }
.agenda-item .who { font-weight: 600; }
.agenda-item .extrait { color: var(--muted); font-size: 13px; margin-top: 3px; }

/* Bilan oral (enregistreur) */
.aide { color: var(--muted); font-size: 13.5px; margin: 0 0 16px; }
.aide code { font-family: var(--mono); font-size: 12.5px; background: var(--accent-soft); padding: 2px 6px; border-radius: 5px; color: var(--accent-deep); }
.rec-row { display: flex; align-items: center; gap: 18px; }
.rec-btn {
  flex: none; width: 56px; height: 56px; border-radius: 50%;
  border: none; background: var(--accent); color: #fff; cursor: pointer;
  display: grid; place-items: center; position: relative;
  transition: background .15s ease, transform .08s ease;
}
.rec-btn:hover { background: var(--accent-deep); }
.rec-btn:active { transform: scale(0.96); }
.rec-btn:focus-visible { outline: 3px solid var(--accent); outline-offset: 3px; }
.rec-btn .dot { width: 18px; height: 18px; border-radius: 5px; background: #fff; transition: all .18s ease; }
.rec-btn.live { background: var(--live); }
.rec-btn.live .dot { width: 16px; height: 16px; border-radius: 3px; }
.rec-btn.live::after {
  content: ""; position: absolute; inset: -6px; border-radius: 50%;
  border: 2px solid var(--live); animation: pulse 1.4s ease-out infinite;
}
@keyframes pulse { 0% { transform: scale(0.9); opacity: .8; } 100% { transform: scale(1.35); opacity: 0; } }
.meter { display: flex; align-items: flex-end; gap: 4px; height: 40px; flex: 1; }
.meter .bar { flex: 1; background: var(--line); border-radius: 3px; height: 6px; transition: height .06s linear, background .12s ease; }
.meter.live .bar { background: var(--accent); }
.timer { font-family: var(--mono); font-size: 15px; color: var(--muted); min-width: 52px; text-align: right; font-variant-numeric: tabular-nums; }
.timer.live { color: var(--live); }
.hint { margin: 14px 2px 0; font-size: 13px; color: var(--muted); }
.status { margin-top: 16px; font-size: 14px; min-height: 22px; display: flex; align-items: center; gap: 10px; }
.status .spin { width: 15px; height: 15px; border-radius: 50%; border: 2px solid var(--line); border-top-color: var(--accent); animation: spin .8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.status.err { color: var(--live); }
.bilan-res { margin-top: 18px; }
.bilan-res details { margin-top: 10px; }
.bilan-res summary { cursor: pointer; font-size: 13px; color: var(--muted); }
.bilan-res .brut { margin-top: 8px; padding: 12px; background: #FBFBFD; border: 1px solid var(--line); border-radius: 10px; font-size: 13.5px; color: var(--muted); white-space: pre-wrap; }
.bilan-actions { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-top: 14px; flex-wrap: wrap; }
.moteur-tag { font-family: var(--mono); font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.08em; }

/* Liste des séances */
.seance-item { border: 1px solid var(--line); border-radius: 12px; padding: 14px 16px; }
.seance-item + .seance-item { margin-top: 10px; }
.seance-item .tete { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
.seance-item .date { font-weight: 600; font-size: 14px; }
.seance-item .fait { color: var(--muted); font-size: 14px; margin-top: 6px; white-space: pre-wrap; }

/* Barre Reformuler (IA) */
.reform-row { display: flex; align-items: center; gap: 10px; margin: -6px 0 8px; }
.reform-status { font-size: 12px; color: var(--muted); }
.reform-status.err { color: var(--live); }
.reform-status .spin { display: inline-block; width: 12px; height: 12px; vertical-align: -2px; border-radius: 50%; border: 2px solid var(--line); border-top-color: var(--accent); animation: spin .8s linear infinite; }

/* Modale séance */
.overlay {
  position: fixed; inset: 0; background: rgba(22,26,35,0.42);
  display: none; align-items: center; justify-content: center; padding: 20px; z-index: 50;
}
.overlay.ouvert { display: flex; }
.modale {
  width: 100%; max-width: 460px; background: var(--surface);
  border-radius: 16px; padding: 24px; box-shadow: 0 30px 60px -20px rgba(22,26,35,0.5);
}
.modale h3 { margin: 0 0 4px; font-size: 18px; letter-spacing: -0.01em; }
.modale .when { color: var(--muted); font-size: 13px; margin-bottom: 18px; }

/* Curseur EVA */
.eva { margin-bottom: 8px; }
.eva-haut { display: flex; align-items: baseline; justify-content: space-between; margin-bottom: 8px; }
.eva-val { font-family: var(--mono); font-size: 22px; font-weight: 600; }
.eva input[type=range] { width: 100%; accent-color: var(--accent); }
.eva-echelle { display: flex; justify-content: space-between; font-size: 11px; color: var(--muted); font-family: var(--mono); margin-top: 4px; }
.modale-actions { display: flex; justify-content: space-between; align-items: center; margin-top: 22px; }

@media (max-width: 760px) {
  .rail { position: static; width: 100%; height: auto; min-height: 0; flex-direction: row; align-items: center; flex-wrap: wrap; }
  .rail-foot { margin-top: 0; flex-direction: row; margin-left: auto; }
  body.app { flex-direction: column; }
  .stage { padding: 24px 18px 48px; }
  .bandeau { grid-template-columns: 1fr; }
  .grille2 { grid-template-columns: 1fr; }
}
@media (prefers-reduced-motion: reduce) {
  * { transition: none !important; }
}

/* Administration des praticiens */
.kbd {
  font-family: var(--mono); font-size: 13px; background: var(--accent-soft);
  border: 1px solid var(--line); border-radius: 7px; padding: 4px 9px; color: var(--ink);
}
.lien-discret { display: inline-block; margin-top: 12px; font-size: 13px; color: var(--muted); }
.lien-discret:hover { color: var(--accent); }
.prat-liste { list-style: none; margin: 10px 0 0; padding: 0; }
.prat-liste li {
  display: flex; align-items: center; gap: 10px; padding: 9px 4px;
  border-bottom: 1px solid var(--line);
}
.prat-liste li:last-child { border-bottom: none; }
.prat-pastille { width: 12px; height: 12px; border-radius: 50%; flex: none; }
.prat-nom { font-weight: 600; flex: 1; min-width: 0; }
.prat-liste form { margin: 0; }
.prat-ajout { display: flex; gap: 8px; margin-top: 6px; }
.prat-ajout input {
  flex: 1; min-width: 0; padding: 9px 11px; border: 1px solid var(--line);
  border-radius: 9px; font: inherit; background: #fff;
}

/* Badges de rôle de compte */
.role-tag {
  font-family: var(--mono); font-size: 10px; color: var(--muted);
  border: 1px solid var(--line); border-radius: 6px; padding: 2px 7px; flex: none;
  text-transform: uppercase; letter-spacing: 0.04em;
}
.role-admin { color: #fff; background: var(--accent); border-color: var(--accent); }
__FIN_STATIC_STYLE_CSS__

info "  · static/app.js"
mkdir -p "$APP/static"
cat > "$APP/static/app.js" << '__FIN_STATIC_APP_JS__'
/* Fiche patient : calendrier mensuel, graphique douleur (SVG), modale séance.
   Aucune dépendance externe : tout est fait main pour rester hors-ligne. */
(function () {
  "use strict";

  var MOIS = ["janvier","février","mars","avril","mai","juin","juillet","août",
              "septembre","octobre","novembre","décembre"];
  var JOURS = ["Lun","Mar","Mer","Jeu","Ven","Sam","Dim"];

  var seances = {};        // "AAAA-MM-JJ" -> {fait, douleur}
  var seancesIds = {};     // "AAAA-MM-JJ" -> id (pour la suppression)
  var vue = new Date();    // mois affiché
  vue.setDate(1);

  var grille = document.getElementById("calGrille");
  var moisLabel = document.getElementById("calMois");
  var overlay = document.getElementById("overlay");

  function iso(d) {
    return d.getFullYear() + "-" +
           String(d.getMonth() + 1).padStart(2, "0") + "-" +
           String(d.getDate()).padStart(2, "0");
  }
  function couleurDouleur(n) {
    if (!n) return null;
    if (n <= 3) return getCss("--ok");
    if (n <= 6) return getCss("--warn");
    return getCss("--danger");
  }
  function getCss(v) {
    return getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  }

  /* ---------------- Calendrier ---------------- */
  function dessinerCalendrier() {
    moisLabel.textContent = MOIS[vue.getMonth()] + " " + vue.getFullYear();
    grille.innerHTML = "";
    JOURS.forEach(function (j) {
      var c = document.createElement("div");
      c.className = "cal-jour-nom";
      c.textContent = j;
      grille.appendChild(c);
    });
    var premier = new Date(vue.getFullYear(), vue.getMonth(), 1);
    var decalage = (premier.getDay() + 6) % 7; // lundi = 0
    var nbJours = new Date(vue.getFullYear(), vue.getMonth() + 1, 0).getDate();
    var ajdIso = iso(new Date());

    for (var i = 0; i < decalage; i++) {
      var v = document.createElement("div");
      v.className = "cal-case vide-case";
      grille.appendChild(v);
    }
    for (var jour = 1; jour <= nbJours; jour++) {
      var d = new Date(vue.getFullYear(), vue.getMonth(), jour);
      var key = iso(d);
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cal-case" + (key === ajdIso ? " ajd" : "");
      btn.textContent = jour;
      var s = seances[key];
      if (s) {
        if (s.fait) {
          var fd = document.createElement("span");
          fd.className = "fait-dot";
          btn.appendChild(fd);
        }
        if (s.douleur) {
          var pt = document.createElement("span");
          pt.className = "pt";
          pt.style.background = couleurDouleur(s.douleur);
          pt.textContent = s.douleur;
          btn.appendChild(pt);
        }
      }
      (function (k) {
        btn.addEventListener("click", function () { ouvrirModale(k); });
      })(key);
      grille.appendChild(btn);
    }
  }

  /* ---------------- Graphique douleur (SVG) ---------------- */
  function dessinerGraphique() {
    var wrap = document.getElementById("graphWrap");
    var vide = document.getElementById("graphVide");
    var points = Object.keys(seances)
      .filter(function (k) { return seances[k].douleur; })
      .sort()
      .map(function (k) { return { date: k, d: seances[k].douleur }; });

    var ancien = wrap.querySelector("svg.graph");
    if (ancien) ancien.remove();

    if (points.length === 0) { vide.style.display = "block"; return; }
    vide.style.display = "none";

    var W = Math.max(560, points.length * 60 + 80);
    var H = 240, padL = 38, padR = 20, padT = 18, padB = 46;
    var plotW = W - padL - padR, plotH = H - padT - padB;
    var svgns = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(svgns, "svg");
    svg.setAttribute("class", "graph");
    svg.setAttribute("viewBox", "0 0 " + W + " " + H);
    svg.setAttribute("width", W);
    svg.setAttribute("height", H);

    function x(i) {
      return padL + (points.length === 1 ? plotW / 2 : (i / (points.length - 1)) * plotW);
    }
    function y(v) { return padT + plotH - (v / 10) * plotH; }

    // Grille horizontale 0,2,4,6,8,10
    [0, 2, 4, 6, 8, 10].forEach(function (lvl) {
      var yy = y(lvl);
      var ligne = document.createElementNS(svgns, "line");
      ligne.setAttribute("x1", padL); ligne.setAttribute("x2", W - padR);
      ligne.setAttribute("y1", yy); ligne.setAttribute("y2", yy);
      ligne.setAttribute("stroke", getCss("--line"));
      ligne.setAttribute("stroke-width", lvl === 0 ? 1.5 : 1);
      svg.appendChild(ligne);
      var t = document.createElementNS(svgns, "text");
      t.setAttribute("x", padL - 8); t.setAttribute("y", yy + 4);
      t.setAttribute("text-anchor", "end");
      t.textContent = lvl;
      svg.appendChild(t);
    });

    // Aire + ligne
    var dPath = "", dArea = "";
    points.forEach(function (p, i) {
      dPath += (i === 0 ? "M" : "L") + x(i) + " " + y(p.d) + " ";
    });
    dArea = dPath + "L" + x(points.length - 1) + " " + y(0) + " L" + x(0) + " " + y(0) + " Z";

    var aire = document.createElementNS(svgns, "path");
    aire.setAttribute("d", dArea);
    aire.setAttribute("fill", getCss("--accent"));
    aire.setAttribute("opacity", "0.08");
    svg.appendChild(aire);

    var ligne2 = document.createElementNS(svgns, "path");
    ligne2.setAttribute("d", dPath);
    ligne2.setAttribute("fill", "none");
    ligne2.setAttribute("stroke", getCss("--accent"));
    ligne2.setAttribute("stroke-width", "2.5");
    ligne2.setAttribute("stroke-linejoin", "round");
    ligne2.setAttribute("stroke-linecap", "round");
    svg.appendChild(ligne2);

    // Points + dates
    points.forEach(function (p, i) {
      var c = document.createElementNS(svgns, "circle");
      c.setAttribute("cx", x(i)); c.setAttribute("cy", y(p.d));
      c.setAttribute("r", "5");
      c.setAttribute("fill", couleurDouleur(p.d));
      c.setAttribute("stroke", "#fff");
      c.setAttribute("stroke-width", "2");
      var titre = document.createElementNS(svgns, "title");
      titre.textContent = p.date + " — EVA " + p.d;
      c.appendChild(titre);
      svg.appendChild(c);

      if (points.length <= 14 || i % 2 === 0) {
        var t = document.createElementNS(svgns, "text");
        t.setAttribute("x", x(i)); t.setAttribute("y", H - 24);
        t.setAttribute("text-anchor", "middle");
        t.setAttribute("font-size", "10");
        t.textContent = p.date.slice(5); // MM-JJ
        svg.appendChild(t);
      }
    });

    wrap.appendChild(svg);
  }

  /* ---------------- Modale ---------------- */
  function ouvrirModale(key) {
    var s = seances[key] || { fait: "", douleur: 0, heure: "", praticien: "" };
    document.getElementById("fDate").value = key;
    document.getElementById("fHeure").value = s.heure || "";
    document.getElementById("fPraticien").value = s.praticien || "";
    document.getElementById("fFait").value = s.fait || "";
    var d = s.douleur || 0;
    document.getElementById("fDouleur").value = d;
    majEva(d);
    document.getElementById("modDate").textContent = formaterDate(key);
    var supBtn = document.getElementById("modSupprimer");
    supBtn.style.visibility = seances[key] ? "visible" : "hidden";
    supBtn.dataset.key = key;
    overlay.classList.add("ouvert");
    if (window.__resetReform) window.__resetReform();
    document.getElementById("fFait").focus();
  }
  function fermerModale() { overlay.classList.remove("ouvert"); }

  function majEva(v) {
    document.getElementById("evaVal").textContent = (v > 0) ? v : "—";
  }
  function formaterDate(key) {
    var p = key.split("-");
    return p[2] + " " + MOIS[parseInt(p[1], 10) - 1] + " " + p[0];
  }

  /* ---------------- Données ---------------- */
  function charger() {
    fetch(window.SEANCES_URL)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        seances = {};
        seancesIds = {};
        data.forEach(function (s) {
          seances[s.date_seance] = { fait: s.fait || "", douleur: s.douleur || 0, heure: s.heure || "", praticien: s.praticien || "" };
          seancesIds[s.date_seance] = s.id;
        });
        dessinerCalendrier();
        dessinerGraphique();
      });
  }

  /* ---------------- Événements ---------------- */
  document.getElementById("calPrev").addEventListener("click", function () {
    vue.setMonth(vue.getMonth() - 1); dessinerCalendrier();
  });
  document.getElementById("calNext").addEventListener("click", function () {
    vue.setMonth(vue.getMonth() + 1); dessinerCalendrier();
  });
  document.getElementById("fDouleur").addEventListener("input", function (e) {
    majEva(parseInt(e.target.value, 10));
  });
  document.getElementById("modFermer").addEventListener("click", fermerModale);
  overlay.addEventListener("click", function (e) { if (e.target === overlay) fermerModale(); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && overlay.classList.contains("ouvert")) fermerModale();
  });

  document.getElementById("modSupprimer").addEventListener("click", function () {
    if (!confirm("Supprimer cette séance ?")) return;
    var key = this.dataset.key;
    var sid = seancesIds[key];
    if (!sid) { fermerModale(); return; }
    var f = document.createElement("form");
    f.method = "post";
    f.action = window.SUPPR_BASE.replace(/\/0\/supprimer$/, "/" + sid + "/supprimer");
    document.body.appendChild(f);
    f.submit();
  });

  // Bouton « Modifier » dans la liste des séances
  Array.prototype.forEach.call(document.querySelectorAll(".js-edit"), function (b) {
    b.addEventListener("click", function () {
      ouvrirModale(b.dataset.date);
    });
  });

  // Reformulation IA du champ « ce qui a été fait »
  var reformBtn = document.getElementById("reformBtn");
  if (reformBtn) {
    var reformUndo = document.getElementById("reformUndo");
    var reformStatus = document.getElementById("reformStatus");
    var avantReform = "";
    window.__resetReform = function () {
      reformUndo.style.display = "none";
      reformStatus.textContent = "";
      reformStatus.className = "reform-status";
      avantReform = "";
    };
    reformBtn.addEventListener("click", function () {
      var f = document.getElementById("fFait");
      var t = f.value.trim();
      if (!window.AUDIO_DISPO) {
        reformStatus.className = "reform-status err";
        reformStatus.textContent = "Module IA non installé. Relancez : bash installer.sh --avec-audio";
        return;
      }
      if (!t) { reformStatus.className = "reform-status"; reformStatus.textContent = "Rien à reformuler."; return; }
      reformBtn.disabled = true;
      reformStatus.className = "reform-status";
      reformStatus.innerHTML = '<span class="spin"></span> Reformulation en local…';
      var fd = new FormData();
      fd.append("texte", t);
      fetch(window.REFORM_URL, { method: "POST", body: fd })
        .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
        .then(function (res) {
          reformBtn.disabled = false;
          if (!res.ok) throw new Error(res.d.erreur || "Erreur.");
          if (res.d.moteur === "indisponible") {
            reformStatus.className = "reform-status err";
            reformStatus.textContent = "Modèle injoignable (Ollama éteint) : texte inchangé.";
            return;
          }
          avantReform = t;
          f.value = res.d.texte || t;
          reformUndo.style.display = "";
          reformStatus.className = "reform-status";
          reformStatus.textContent = "Reformulé. Relisez avant d'enregistrer.";
        })
        .catch(function (e) {
          reformBtn.disabled = false;
          reformStatus.className = "reform-status err";
          reformStatus.textContent = "Échec : " + e.message;
        });
    });
    reformUndo.addEventListener("click", function () {
      if (!avantReform) return;
      document.getElementById("fFait").value = avantReform;
      reformUndo.style.display = "none";
      reformStatus.className = "reform-status";
      reformStatus.textContent = "Texte d'origine rétabli.";
    });
  }

  charger();
})();

/* ===================== Bilan oral ===================== */
(function () {
  "use strict";
  var recBtn = document.getElementById("recBtn");
  if (!recBtn) return; // module audio non installé

  var meter = document.getElementById("meter");
  var bars = Array.prototype.slice.call(meter.querySelectorAll(".bar"));
  var timerEl = document.getElementById("timer");
  var recHint = document.getElementById("recHint");
  var statusEl = document.getElementById("bilanStatus");
  var resEl = document.getElementById("bilanRes");
  var resumeEl = document.getElementById("bilanResume");
  var brutEl = document.getElementById("bilanBrut");
  var moteurTag = document.getElementById("moteurTag");
  var btnSeance = document.getElementById("bilanSeance");
  var btnNote = document.getElementById("bilanNote");
  var dateEl = document.getElementById("bilanDate");
  var dateInfo = document.getElementById("dateInfo");

  var mediaRecorder = null, chunks = [], stream = null;
  var audioCtx = null, analyser = null, rafId = null;
  var startTime = 0, timerInt = null, douleurDetectee = 0;

  function fmt(sec) {
    var m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m + ":" + String(s).padStart(2, "0");
  }
  function setStatus(html, err) {
    statusEl.className = "status" + (err ? " err" : "");
    statusEl.innerHTML = html;
  }
  function startMeter() {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    var src = audioCtx.createMediaStreamSource(stream);
    analyser = audioCtx.createAnalyser();
    analyser.fftSize = 64;
    src.connect(analyser);
    var data = new Uint8Array(analyser.frequencyBinCount);
    meter.classList.add("live");
    (function loop() {
      analyser.getByteFrequencyData(data);
      bars.forEach(function (bar, i) {
        var v = data[i * 2] || 0;
        bar.style.height = (6 + (v / 255) * 34).toFixed(0) + "px";
      });
      rafId = requestAnimationFrame(loop);
    })();
  }
  function stopMeter() {
    if (rafId) cancelAnimationFrame(rafId);
    if (audioCtx) audioCtx.close();
    meter.classList.remove("live");
    bars.forEach(function (b) { b.style.height = "6px"; });
  }

  function start() {
    navigator.mediaDevices.getUserMedia({ audio: true }).then(function (s) {
      stream = s;
      chunks = [];
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.ondataavailable = function (e) { if (e.data.size) chunks.push(e.data); };
      mediaRecorder.onstop = function () {
        var blob = new Blob(chunks, { type: mediaRecorder.mimeType || "audio/webm" });
        envoyer(blob);
      };
      mediaRecorder.start();
      recBtn.classList.add("live");
      timerEl.classList.add("live");
      recHint.textContent = "Dictée en cours… Re-cliquez pour arrêter.";
      startTime = Date.now();
      timerEl.textContent = "0:00";
      timerInt = setInterval(function () {
        timerEl.textContent = fmt((Date.now() - startTime) / 1000);
      }, 250);
      startMeter();
    }).catch(function () {
      setStatus("Accès au micro refusé. Autorisez le micro pour cette page.", true);
    });
  }
  function stop() {
    if (mediaRecorder && mediaRecorder.state !== "inactive") mediaRecorder.stop();
    if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
    clearInterval(timerInt);
    stopMeter();
    recBtn.classList.remove("live");
    timerEl.classList.remove("live");
    recHint.textContent = "Cliquez pour dicter. Re-cliquez pour arrêter et lancer la transcription.";
  }
  recBtn.addEventListener("click", function () {
    if (recBtn.classList.contains("live")) stop(); else start();
  });

  function envoyer(blob) {
    resEl.style.display = "none";
    setStatus('<span class="spin"></span> Transcription puis résumé en local… (calcul CPU, patientez)');
    var fd = new FormData();
    fd.append("audio", blob, "bilan.webm");
    fetch(window.BILAN_URL, { method: "POST", body: fd })
      .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
      .then(function (res) {
        if (!res.ok) throw new Error(res.d.erreur || "Erreur inconnue.");
        resumeEl.value = res.d.resume || "(résumé vide)";
        brutEl.textContent = res.d.transcription || "(rien transcrit)";
        douleurDetectee = res.d.douleur || 0;
        var moteur = res.d.moteur === "ollama" ? "résumé : IA locale (Ollama)" :
                     res.d.moteur === "règles" ? "résumé : mise en forme locale (Ollama injoignable)" : "";
        var dl = douleurDetectee ? " · douleur détectée : EVA " + douleurDetectee : "";
        moteurTag.textContent = moteur + dl;
        dateEl.value = window.AUJOURDHUI;
        dateEl.max = window.AUJOURDHUI;
        verifDate();
        resEl.style.display = "block";
        setStatus("Terminé. Choisissez la date puis insérez.");
      })
      .catch(function (e) { setStatus("Échec : " + e.message, true); });
  }

  function soumettre(action, champs) {
    var f = document.createElement("form");
    f.method = "post";
    f.action = action;
    Object.keys(champs).forEach(function (k) {
      var i = document.createElement("input");
      i.type = "hidden"; i.name = k; i.value = champs[k];
      f.appendChild(i);
    });
    document.body.appendChild(f);
    f.submit();
  }

  function verifDate() {
    dateInfo.textContent = "";
    var d = dateEl.value;
    if (!d) return;
    fetch(window.SEANCES_URL)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var existe = data.filter(function (s) { return s.date_seance === d; })[0];
        if (existe) {
          dateInfo.textContent = "Une séance existe déjà ce jour-là : son contenu sera remplacé.";
        } else if (d !== window.AUJOURDHUI) {
          dateInfo.textContent = "Séance antérieure : le résumé sera enregistré à cette date.";
        }
      })
      .catch(function () {});
  }
  dateEl.addEventListener("change", verifDate);

  btnSeance.addEventListener("click", function () {
    if (!resumeEl.value.trim()) return;
    soumettre(window.SEANCE_URL, {
      date_seance: dateEl.value || window.AUJOURDHUI,
      fait: resumeEl.value.trim(),
      douleur: douleurDetectee || 0,
    });
  });

  btnNote.addEventListener("click", function () {
    if (!resumeEl.value.trim()) return;
    var noteEl = document.querySelector('textarea[name="note_libre"]');
    var ancienne = noteEl ? noteEl.value.trim() : "";
    var ajout = "[" + (dateEl.value || window.AUJOURDHUI) + "] " + resumeEl.value.trim();
    soumettre(window.NOTE_URL, {
      note_libre: ancienne ? (ancienne + "\n" + ajout) : ajout,
    });
  });
})();
__FIN_STATIC_APP_JS__

info "  · static/agenda.js"
mkdir -p "$APP/static"
cat > "$APP/static/agenda.js" << '__FIN_STATIC_AGENDA_JS__'
/* Calendrier général : vues Jour, Semaine et Mois.
   - Jour : grille de créneaux de 30 min ; on assigne un patient à un créneau.
   - Semaine : 7 colonnes listant tous les patients de chaque jour.
   - Mois : grille classique (jusqu'à 3 noms + N…).
   Clic sur un patient -> sa fiche. */
(function () {
  "use strict";

  var MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
              "août", "septembre", "octobre", "novembre", "décembre"];
  var JOURS = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
  var JOURS_LONG = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"];
  var H_DEBUT = 7, H_FIN = 20;   // créneaux de 7:00 à 19:30

  var agenda = {};            // "AAAA-MM-JJ" -> [ {patient_id, prenom, nom, douleur, heure, archive} ]
  var patients = [];          // [{id, prenom, nom}]
  var mode = "mois";          // "jour" | "semaine" | "mois"
  var ancre = new Date();
  var selection = null;

  var grille = document.getElementById("calGrille");
  var moisLabel = document.getElementById("calMois");
  var overlay = document.getElementById("jourOverlay");
  var jourTitre = document.getElementById("jourTitre");
  var jourSous = document.getElementById("jourSous");
  var jourListe = document.getElementById("jourListe");
  var btnJour = document.getElementById("vueJour");
  var btnSemaine = document.getElementById("vueSemaine");
  var btnMois = document.getElementById("vueMois");

  // Fenêtre d'ajout de créneau
  var crOverlay = document.getElementById("creneauOverlay");
  var crQuand = document.getElementById("creneauQuand");
  var crSelect = document.getElementById("creneauPatient");
  var crPrat = document.getElementById("creneauPraticien");
  var crDateHeure = { date: null, heure: null };

  function iso(d) {
    return d.getFullYear() + "-" +
           String(d.getMonth() + 1).padStart(2, "0") + "-" +
           String(d.getDate()).padStart(2, "0");
  }
  function getCss(v) {
    return getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  }
  function couleur(n) {
    if (!n) return getCss("--muted");
    if (n <= 3) return getCss("--ok");
    if (n <= 6) return getCss("--warn");
    return getCss("--danger");
  }
  function couleurPrat(nom) {
    return (window.PRAT_COULEURS || {})[nom] || "#8A93A6";
  }
  function jolie(key) {
    var p = key.split("-");
    return p[2] + " " + MOIS[parseInt(p[1], 10) - 1] + " " + p[0];
  }
  function urlPatient(id) { return window.PATIENT_BASE.replace(/\/0$/, "/" + id); }
  function lundi(d) {
    var x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    x.setDate(x.getDate() - ((x.getDay() + 6) % 7));
    return x;
  }
  function ligneNom(it) {
    var dot = document.createElement("span");
    dot.className = "nm-dot";
    dot.style.background = couleurPrat(it.praticien);
    var txt = document.createElement("span");
    txt.className = "nom-txt";
    txt.textContent = it.nom + " " + it.prenom;
    return [dot, txt];
  }

  /* ---------------- Vue jour ---------------- */
  function dessinerJour() {
    grille.className = "jour-vue";
    grille.innerHTML = "";
    var key = iso(ancre);
    var items = agenda[key] || [];
    var parHeure = {};
    var sansHeure = [];
    items.forEach(function (it) {
      if (it.heure) (parHeure[it.heure] = parHeure[it.heure] || []).push(it);
      else sansHeure.push(it);
    });

    if (sansHeure.length) {
      var bloc = document.createElement("div");
      bloc.className = "jour-sans";
      var t = document.createElement("div");
      t.className = "jour-sans-tete";
      t.textContent = "Sans horaire";
      bloc.appendChild(t);
      var corps = document.createElement("div");
      corps.className = "creneau-corps";
      sansHeure.forEach(function (it) { corps.appendChild(chipPatient(it)); });
      bloc.appendChild(corps);
      grille.appendChild(bloc);
    }

    for (var min = H_DEBUT * 60; min < H_FIN * 60; min += 30) {
      var hh = String(Math.floor(min / 60)).padStart(2, "0");
      var mm = String(min % 60).padStart(2, "0");
      var slot = hh + ":" + mm;
      var rang = document.createElement("div");
      rang.className = "creneau";
      var lab = document.createElement("div");
      lab.className = "creneau-h";
      lab.textContent = slot;
      rang.appendChild(lab);
      var corps2 = document.createElement("div");
      corps2.className = "creneau-corps";
      (parHeure[slot] || []).forEach(function (it) { corps2.appendChild(chipPatient(it)); });
      var add = document.createElement("button");
      add.type = "button";
      add.className = "creneau-add";
      add.textContent = "+";
      add.title = "Ajouter un patient à " + slot;
      (function (s) {
        add.addEventListener("click", function () { ouvrirCreneau(key, s); });
      })(slot);
      corps2.appendChild(add);
      rang.appendChild(corps2);
      grille.appendChild(rang);
    }
  }

  function chipPatient(it) {
    var a = document.createElement("a");
    a.className = "creneau-pat";
    a.href = urlPatient(it.patient_id);
    ligneNom(it).forEach(function (e) { a.appendChild(e); });
    if (it.praticien) {
      var b = document.createElement("span");
      b.className = "chip-prat";
      b.textContent = it.praticien;
      b.style.background = couleurPrat(it.praticien);
      a.appendChild(b);
    }
    return a;
  }

  /* ---------------- Vue mois ---------------- */
  function dessinerMois() {
    grille.className = "cal-grille agenda-grille";
    grille.innerHTML = "";
    JOURS.forEach(function (j) {
      var c = document.createElement("div");
      c.className = "cal-jour-nom";
      c.textContent = j;
      grille.appendChild(c);
    });
    var an = ancre.getFullYear(), mo = ancre.getMonth();
    var premier = new Date(an, mo, 1);
    var decalage = (premier.getDay() + 6) % 7;
    var nbJours = new Date(an, mo + 1, 0).getDate();
    var ajd = iso(new Date());
    for (var i = 0; i < decalage; i++) {
      var v = document.createElement("div");
      v.className = "cal-case vide-case";
      grille.appendChild(v);
    }
    for (var jour = 1; jour <= nbJours; jour++) {
      var key = iso(new Date(an, mo, jour));
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cal-case" + (key === ajd ? " ajd" : "") +
                      (key === selection ? " sel" : "");
      var numero = document.createElement("span");
      numero.className = "cal-jour-num";
      numero.textContent = jour;
      btn.appendChild(numero);
      var items = agenda[key];
      if (items && items.length) {
        var noms = document.createElement("div");
        noms.className = "cal-noms";
        var MAX = 3;
        items.slice(0, MAX).forEach(function (it) {
          var l = document.createElement("span");
          l.className = "nom-mini";
          ligneNom(it).forEach(function (e) { l.appendChild(e); });
          noms.appendChild(l);
        });
        if (items.length > MAX) {
          var plus = document.createElement("span");
          plus.className = "nom-plus";
          plus.textContent = "+" + (items.length - MAX) + "…";
          noms.appendChild(plus);
        }
        btn.appendChild(noms);
      }
      (function (k) {
        btn.addEventListener("click", function () { ouvrirJour(k); });
      })(key);
      grille.appendChild(btn);
    }
  }

  /* ---------------- Vue semaine ---------------- */
  function dessinerSemaine() {
    grille.className = "cal-grille semaine-grille";
    grille.innerHTML = "";
    var debut = lundi(ancre);
    var ajd = iso(new Date());
    for (var i = 0; i < 7; i++) {
      var d = new Date(debut);
      d.setDate(debut.getDate() + i);
      var key = iso(d);
      var col = document.createElement("div");
      col.className = "sem-col" + (key === ajd ? " ajd" : "");
      var tete = document.createElement("button");
      tete.type = "button";
      tete.className = "sem-tete";
      var jn = document.createElement("span"); jn.className = "sem-jour"; jn.textContent = JOURS[i];
      var nm = document.createElement("span"); nm.className = "sem-num"; nm.textContent = d.getDate();
      tete.appendChild(jn); tete.appendChild(nm);
      (function (k) { tete.addEventListener("click", function () { ouvrirJour(k); }); })(key);
      col.appendChild(tete);
      var liste = document.createElement("div");
      liste.className = "sem-liste";
      var items = agenda[key] || [];
      if (!items.length) {
        var vide = document.createElement("div");
        vide.className = "sem-vide"; vide.textContent = "—";
        liste.appendChild(vide);
      } else {
        items.forEach(function (it) {
          var a = document.createElement("a");
          a.className = "sem-item";
          a.href = urlPatient(it.patient_id);
          if (it.heure) {
            var h = document.createElement("span");
            h.className = "sem-h"; h.textContent = it.heure;
            a.appendChild(h);
          }
          ligneNom(it).forEach(function (e) { a.appendChild(e); });
          liste.appendChild(a);
        });
      }
      col.appendChild(liste);
      grille.appendChild(col);
    }
  }

  function majLabel() {
    if (mode === "mois") {
      moisLabel.textContent = MOIS[ancre.getMonth()] + " " + ancre.getFullYear();
    } else if (mode === "semaine") {
      var d = lundi(ancre), f = new Date(d); f.setDate(d.getDate() + 6);
      if (d.getMonth() === f.getMonth()) {
        moisLabel.textContent = d.getDate() + " – " + f.getDate() + " " + MOIS[d.getMonth()] + " " + d.getFullYear();
      } else {
        moisLabel.textContent = d.getDate() + " " + MOIS[d.getMonth()] + " – " + f.getDate() + " " + MOIS[f.getMonth()] + " " + f.getFullYear();
      }
    } else {
      var jl = JOURS_LONG[(ancre.getDay() + 6) % 7];
      moisLabel.textContent = jl.charAt(0).toUpperCase() + jl.slice(1) + " " +
                              ancre.getDate() + " " + MOIS[ancre.getMonth()] + " " + ancre.getFullYear();
    }
  }

  function dessiner() {
    if (mode === "mois") dessinerMois();
    else if (mode === "semaine") dessinerSemaine();
    else dessinerJour();
    majLabel();
    btnJour.classList.toggle("actif", mode === "jour");
    btnSemaine.classList.toggle("actif", mode === "semaine");
    btnMois.classList.toggle("actif", mode === "mois");
  }

  /* ---------------- Fenêtre du jour (liste) ---------------- */
  function ouvrirJour(key) {
    selection = key;
    if (mode === "mois") dessiner();
    var items = agenda[key] || [];
    jourTitre.textContent = "Séances du " + jolie(key);
    jourSous.textContent = items.length ? (items.length + " patient" + (items.length > 1 ? "s" : "")) : "";
    jourListe.innerHTML = "";
    if (!items.length) {
      var vide = document.createElement("div");
      vide.className = "vide"; vide.style.padding = "26px";
      vide.textContent = "Aucune séance ce jour-là.";
      jourListe.appendChild(vide);
    } else {
      items.forEach(function (it) {
        var a = document.createElement("a");
        a.className = "agenda-item";
        a.href = urlPatient(it.patient_id);
        var gauche = document.createElement("div"); gauche.style.minWidth = "0";
        var who = document.createElement("div"); who.className = "who";
        who.textContent = (it.heure ? it.heure + " · " : "") + it.nom + " " + it.prenom + (it.archive ? "  · archivé" : "");
        gauche.appendChild(who);
        if (it.fait) {
          var ex = document.createElement("div"); ex.className = "extrait";
          var t = it.fait.replace(/\s+/g, " ").trim();
          ex.textContent = t.length > 90 ? t.slice(0, 90) + "…" : t;
          gauche.appendChild(ex);
        }
        a.appendChild(gauche);
        if (it.praticien) {
          var past = document.createElement("span"); past.className = "pastille";
          var pip = document.createElement("span"); pip.className = "pip"; pip.style.background = couleurPrat(it.praticien);
          past.appendChild(pip); past.appendChild(document.createTextNode(it.praticien));
          a.appendChild(past);
        }
        jourListe.appendChild(a);
      });
    }
    overlay.classList.add("ouvert");
  }
  function fermerJour() { overlay.classList.remove("ouvert"); }

  /* ---------------- Ajout de créneau ---------------- */
  function ouvrirCreneau(date, heure) {
    crDateHeure = { date: date, heure: heure };
    crQuand.textContent = jolie(date) + " à " + heure;
    crSelect.innerHTML = "";
    if (!patients.length) {
      var o = document.createElement("option");
      o.textContent = "Aucun patient actif"; o.disabled = true;
      crSelect.appendChild(o);
    } else {
      patients.forEach(function (p) {
        var o = document.createElement("option");
        o.value = p.id; o.textContent = p.nom + " " + p.prenom;
        crSelect.appendChild(o);
      });
    }
    crOverlay.classList.add("ouvert");
  }
  function fermerCreneau() { crOverlay.classList.remove("ouvert"); }

  function ajouterCreneau() {
    var pid = crSelect.value;
    if (!pid) { fermerCreneau(); return; }
    var fd = new FormData();
    fd.append("date", crDateHeure.date);
    fd.append("heure", crDateHeure.heure);
    fd.append("praticien", crPrat ? crPrat.value : "");
    fetch(window.CRENEAU_BASE.replace(/\/0\/creneau$/, "/" + pid + "/creneau"),
          { method: "POST", body: fd })
      .then(function () { return charger(); })
      .then(function () { fermerCreneau(); dessiner(); })
      .catch(function () { fermerCreneau(); });
  }

  /* ---------------- Données ---------------- */
  function charger() {
    return fetch(window.AGENDA_URL)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        agenda = {};
        data.forEach(function (s) {
          (agenda[s.date_seance] = agenda[s.date_seance] || []).push(s);
        });
      });
  }

  /* ---------------- Navigation & événements ---------------- */
  document.getElementById("calPrev").addEventListener("click", function () {
    if (mode === "mois") ancre.setMonth(ancre.getMonth() - 1);
    else if (mode === "semaine") ancre.setDate(ancre.getDate() - 7);
    else ancre.setDate(ancre.getDate() - 1);
    dessiner();
  });
  document.getElementById("calNext").addEventListener("click", function () {
    if (mode === "mois") ancre.setMonth(ancre.getMonth() + 1);
    else if (mode === "semaine") ancre.setDate(ancre.getDate() + 7);
    else ancre.setDate(ancre.getDate() + 1);
    dessiner();
  });
  btnJour.addEventListener("click", function () { mode = "jour"; dessiner(); });
  btnSemaine.addEventListener("click", function () { mode = "semaine"; dessiner(); });
  btnMois.addEventListener("click", function () { mode = "mois"; dessiner(); });

  document.getElementById("jourFermer").addEventListener("click", fermerJour);
  overlay.addEventListener("click", function (e) { if (e.target === overlay) fermerJour(); });
  document.getElementById("creneauAnnuler").addEventListener("click", fermerCreneau);
  document.getElementById("creneauOk").addEventListener("click", ajouterCreneau);
  crOverlay.addEventListener("click", function (e) { if (e.target === crOverlay) fermerCreneau(); });
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    if (overlay.classList.contains("ouvert")) fermerJour();
    if (crOverlay.classList.contains("ouvert")) fermerCreneau();
  });

  function construireLegende() {
    var el = document.getElementById("calLegende");
    if (!el) return;
    el.innerHTML = "";
    (window.PRATICIENS || []).forEach(function (nom) {
      var s = document.createElement("span");
      var dot = document.createElement("span");
      dot.className = "lg";
      dot.style.background = couleurPrat(nom);
      s.appendChild(dot);
      s.appendChild(document.createTextNode(" " + nom));
      el.appendChild(s);
    });
  }
  function remplirPraticiens() {
    if (!crPrat) return;
    crPrat.innerHTML = "";
    (window.PRATICIENS || []).forEach(function (nom) {
      var o = document.createElement("option");
      o.value = nom; o.textContent = nom;
      crPrat.appendChild(o);
    });
  }
  construireLegende();
  remplirPraticiens();

  Promise.all([
    charger(),
    fetch(window.PATIENTS_URL).then(function (r) { return r.json(); })
      .then(function (d) { patients = d; }).catch(function () { patients = []; })
  ]).then(function () { dessiner(); })
    .catch(function () {
      grille.innerHTML = '<div class="vide" style="padding:30px;">Impossible de charger l\'agenda.</div>';
    });
})();
__FIN_STATIC_AGENDA_JS__

info "Ecriture du module de transcription locale..."
cat > "$APP/transcription.py" << '__FIN_TRANSCRIPTION__'
#!/usr/bin/env python3
"""Module de transcription vocale LOCALE (optionnel).

Sa simple présence active la fonctionnalité audio dans l'application
(le bilan oral sera branché à l'étape suivante). Moteur : faster-whisper,
CPU, quantification INT8. Aucun audio ne quitte la machine.
"""
from faster_whisper import WhisperModel

_modeles = {}
MODELE_DEFAUT = "medium"          # "large-v3" pour la qualité maximale
MODELES_OK = {"large-v3", "medium", "small"}


def _charger(nom):
    if nom not in MODELES_OK:
        nom = MODELE_DEFAUT
    if nom not in _modeles:
        _modeles[nom] = WhisperModel(nom, device="cpu", compute_type="int8")
    return _modeles[nom]


def transcrire(chemin, modele=MODELE_DEFAUT, langue="fr"):
    """Transcrit un fichier audio en texte (français par défaut)."""
    model = _charger(modele)
    segments, info = model.transcribe(chemin, language=langue)
    texte = "".join(s.text for s in segments).strip()
    return {"texte": texte, "duree": round(info.duration, 1)}
__FIN_TRANSCRIPTION__
# Moteur de resume local (Ollama) — facultatif (repli par regles sinon)
if command -v ollama >/dev/null 2>&1; then
  info "Ollama detecte : telechargement du modele de resume (~2 Go)..."
  (ollama serve >/dev/null 2>&1 &)
  sleep 3
  ollama pull llama3.2:3b || echo "  (Le modele se chargera plus tard ; sinon resume par regles.)"
else
  echo ""
  echo "  --- RESUME automatique (facultatif) : installez Ollama ---"
  echo "   1) La page de telechargement va s'ouvrir."
  echo "   2) Telechargez la version macOS, ouvrez le fichier, glissez"
  echo "      « Ollama » dans Applications, lancez-le une fois (autorisez"
  echo "      l'installation de la commande)."
  echo "   3) Le modele se telechargera ensuite tout seul au demarrage."
  echo "   Sans Ollama : la transcription marche, le resume se fait par"
  echo "   regles (un peu moins fin)."
  open "https://ollama.com/download" 2>/dev/null
fi

# 4) Lanceur double-cliquable
cat > "$APP/demarrer.command" << '__MAC_DEMARRER__'
#!/bin/bash
cd "$HOME/cabinet-kine" || exit 1
# Si le serveur tourne deja, on ouvre juste le navigateur
if curl -sk -o /dev/null --max-time 2 https://127.0.0.1:5001/ 2>/dev/null; then
  echo "Le serveur tourne deja. Ouverture du navigateur..."
  open "https://localhost:5001"
  exit 0
fi
source venv/bin/activate
# Resume local (Ollama) : demarrer l'app si besoin, garantir le modele
if ! curl -s -o /dev/null --max-time 2 http://127.0.0.1:11434/api/tags 2>/dev/null; then
  if [ -d "/Applications/Ollama.app" ]; then
    open -a Ollama 2>/dev/null
    for i in 1 2 3 4 5 6 7 8 9 10; do
      curl -s -o /dev/null --max-time 2 http://127.0.0.1:11434/api/tags 2>/dev/null && break
      sleep 2
    done
  elif command -v ollama >/dev/null 2>&1; then
    (ollama serve >/dev/null 2>&1 &)
    sleep 3
  fi
fi
# Telecharger le modele de resume s'il manque (via l'API, sans dependre du PATH)
if curl -s --max-time 2 http://127.0.0.1:11434/api/tags 2>/dev/null | grep -q '"models"'; then
  if ! curl -s --max-time 2 http://127.0.0.1:11434/api/tags 2>/dev/null | grep -q "llama3.2"; then
    echo "Telechargement du modele de resume (une seule fois, en arriere-plan)..."
    curl -s http://127.0.0.1:11434/api/pull -d '{"name":"llama3.2:3b"}' >/dev/null 2>&1 &
  fi
fi
# Ouvrir le navigateur des que le serveur repond (en tache de fond)
( for i in $(seq 1 30); do
    curl -sk -o /dev/null --max-time 2 https://127.0.0.1:5001/ 2>/dev/null && break
    sleep 1
  done
  open "https://localhost:5001"
  osascript -e 'display notification "Le serveur est demarre." with title "Cabinet Kine"' 2>/dev/null ) &
echo "======================================================================"
echo "  Cabinet Kine — serveur en cours d'execution."
echo "  Laissez CETTE fenetre ouverte. Les journaux (logs) s'affichent ici."
echo "  Pour arreter : icone « Arreter Cabinet Kine », ou fermez la fenetre."
echo "======================================================================"
python app.py
__MAC_DEMARRER__
chmod +x "$APP/demarrer.command"

# 5) Script de secours (reinitialiser un mot de passe)
cat > "$APP/reinitialiser.command" << '__MAC_REINIT__'
#!/bin/bash
cd "$HOME/cabinet-kine" || exit 1
source venv/bin/activate
cat > .reinit_tmp.py << 'PY'
import sqlite3, getpass, sys
from werkzeug.security import generate_password_hash
db = sqlite3.connect("cabinet.db")
rows = db.execute("SELECT identifiant, role FROM kine ORDER BY id").fetchall()
if not rows:
    print("Aucun compte dans la base."); sys.exit(0)
print("Comptes existants :")
for ident, role in rows:
    print("  - %s (%s)" % (ident, role))
cible = input("\nIdentifiant a reinitialiser : ").strip()
if not db.execute("SELECT 1 FROM kine WHERE identifiant = ?", (cible,)).fetchone():
    print("Identifiant introuvable."); sys.exit(1)
mdp = getpass.getpass("Nouveau mot de passe (6 caracteres min) : ")
if len(mdp) < 6:
    print("Mot de passe trop court."); sys.exit(1)
db.execute("UPDATE kine SET mdp_hash = ? WHERE identifiant = ?",
           (generate_password_hash(mdp), cible))
db.commit()
print("Mot de passe de '%s' reinitialise." % cible)
PY
python .reinit_tmp.py
rm -f .reinit_tmp.py
echo ""
echo "(Vous pouvez fermer cette fenetre.)"
read -r _
__MAC_REINIT__
chmod +x "$APP/reinitialiser.command"

# 6) Icone unique (bascule marche/arret) sur le Bureau
BUREAU="$HOME/Desktop"; [ -d "$BUREAU" ] || BUREAU="$APP"
# Nettoyer l'ancienne icone « Arreter » des versions precedentes
rm -rf "$BUREAU/Arreter Cabinet Kine.app"

TOGGLE_APP="$BUREAU/Cabinet Kine.app"
rm -rf "$TOGGLE_APP"; mkdir -p "$TOGGLE_APP/Contents/MacOS"
cat > "$TOGGLE_APP/Contents/Info.plist" << '__ICONE_PLIST__'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Cabinet Kine</string>
<key>CFBundleDisplayName</key><string>Cabinet Kine</string>
<key>CFBundleIdentifier</key><string>fr.cabinetkine.app</string>
<key>CFBundleExecutable</key><string>lanceur</string>
<key>CFBundleIconFile</key><string>icone</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleVersion</key><string>1.0</string>
<key>LSMinimumSystemVersion</key><string>10.13</string>
</dict></plist>
__ICONE_PLIST__
cat > "$TOGGLE_APP/Contents/MacOS/lanceur" << '__ICONE_TOGGLE__'
#!/bin/bash
APP="$HOME/cabinet-kine"
if [ ! -d "$APP" ]; then
  osascript -e 'display alert "Cabinet Kine" message "Dossier introuvable. Relancez l installeur."' 2>/dev/null
  exit 1
fi
if curl -sk -o /dev/null --max-time 2 https://127.0.0.1:5001/ 2>/dev/null; then
  # Le serveur tourne -> on l'arrete
  PID="$(lsof -ti tcp:5001 2>/dev/null)"
  [ -n "$PID" ] && kill $PID 2>/dev/null
  rm -f "$APP/serveur.pid" 2>/dev/null
  osascript -e 'display notification "Le serveur est arrete." with title "Cabinet Kine"' 2>/dev/null
else
  # Le serveur est arrete -> on le demarre (fenetre Terminal = logs visibles)
  osascript -e 'display notification "Demarrage du serveur en cours..." with title "Cabinet Kine"' 2>/dev/null
  open -a Terminal "$APP/demarrer.command"
fi
__ICONE_TOGGLE__
chmod +x "$TOGGLE_APP/Contents/MacOS/lanceur"
mkdir -p "$TOGGLE_APP/Contents/Resources"
python3 -c 'import base64,sys;open(sys.argv[1],"wb").write(base64.b64decode(sys.stdin.read()))' "$TOGGLE_APP/Contents/Resources/icone.icns" << '__ICNS_TOGGLE_DATA__'
aWNucwACfeVpYzExAAAH24lQTkcNChoKAAAADUlIRFIAAAAgAAAAIAgGAAAAc3p69AAAB5pJREFUeJytl3+MXVURxz9z7n337b7t7na3pUD5oaalpd2WFEoUjGYXDIghGhBKlBhNjEAgajDBP9TIssaoBPgDEiPRfzRGI1QQY8CUP+jWEApCAcW2QGmhdvtjS3f3bXffe/fdd86Mf9y327fd7YLGSSb35t47c75n5nvmzgiLismgIXtAZp4cHx6WxSxWDAzYzP16sCHBQGwxmwVli1n0Xxv9D77ieU/MBBHbKhIwky0v1dd5s/Oclzh8yAUjwMWRV6dHnnjmJ3u3ioRW363fzg1nywc3/q12l0TRHRb8hqjY7mTRwM8XMwhZTcXFu9Hwyyc/3f5zwE4HIS0WAnDdX8c62zpKjyWd7df5mifUa5iZno78QyAQEXFR0k5ciqlP155NSu23bN3MyXzl3N8sgEEzt2crkvaefKbY03VtOjGZCcQg7rQ4IYCTfJe6KAgAUwPf1tOdpOOTz03Fr312YGBAh3IA5gD6t2+Ph0S01jv1jUJ317W1sckMk8RMnBmY5qrNqw9GOVWqDZvzfJ4amInDJKmNTWbJ0u6rO8OldwyJaP/27dGpCJhJ/zBRRzbxRlQsrQlpFRFxp28oEvAKSQR3XFxi5/EGz49mLIkFteaGz5gR06itREir+0eX9/Tt2oxHBDdo5hCx7trYGkHW+lrFmZlTM9QMVcPMUFVOZoGqD5zTJlx3fkL/OTFZUCoNperzLasqs7YtambO1yrinLvo/ImJixGxQTNxe7bmUXjvZLhgmqJgqmaGBkVVMVMaQTEzvrKqnc5YyHwgGGRBqWaB6y9I2LwsplwPCE0Qrdq0B9Npiuyf9BcADN837OLju/PKNm3i0oqnIwTrKTqSSPL8Ao1g/ODyLvpXFinXAy8fz4gEgkJ3LNy9YQne4NvPT7BnwtPeTIkAIrlm3pioK5XYo/UwW5jcjpm74EGNyVQ5NOUZrQQawZiqKzd8tI3+lUVePFpl23sVSlGebwecrAd++vI4sRjfv6yLNpfzPsLAjNQrxyuBQ1OeyTSAzmXKnEqoqogpIUDZK5MptEXCllUlKg3lZ7smGc+EVS7fXeygLYKnDqas753mhtWdfHxFzNMHUxInTDWU1Btq+bGdSU8IeWHc0dxELj5gamgwTA2HUWsoy4rCyo6IHSM1dh7LmKoH9o7Vmc4CB8oZo9Oeqcz4/dsVDFjdFfNuucH7VU8lU0wNMZvjG79ABALgmqTJk5ef9844D/fhiqfuDR+UfWXl6j+OMJ5BXYVGZhwuGAJ0JwKqiAmozS1UZhAUT5gPwAeItImwCcCZcaLqEWDt0qRZ+owYOFQxYickzqh6ZWVHghkcmfIEVUwdpja3NjTtW9ZvTYHHVGc1BCVxcKCc8c/3U65c2calywuMVhrEYrQ7KGBkXkkbytfXdyECOw5VKAg0QiCo4ixPgTb9qiqhJQezAAKganMUVereeOClExSc8IvPrGBDb4EjUw1GKw2OTTeoZoEfXdnD5z7WwQsjFf60b7ppm+tYtcFU3eOsxW9LBE6dghDygjHDAfIa0FUQnnqnwoMvHueeK1aw89YLeezNKf51os7SouP6VUtY15vwznjKrX85zBdWd3L7Jd2s7U3IgrFrNOXR18u8MpqyNHHNwrQAByA/v7McmMkMxpLEMfjCGG+NpdzzibP40sWdQCcAmQ/85h8n+N6O97nz8rP44SeXt7rkop6EG1Yv4bZtx3jyrZP0FOcS8xQJvcdFcyPQKp1JxG/3TvPnfVOsW5ZwbkdMzSvvTDTYcyLjpr7e2cVHynX6H3qFVWd3sO2bm2iLHY9eew6vH6sxkgVKCwEIAQiGBVsQgKJ0J45g8PJoA68ZTqBUiCgVY+7ctBQD3j1R44FnD3LgaJUD4ymPPHeIr15xLj2lmC+v6+Tev1fpSRbiAA01DZgFwRbuvxpqiEBHBBLn/PWqdMTCmt4iIRhXPfwq/z5aodSVIAh3/3o3O/aXeeK2jfQtKyI2TWY2S4IYBvKU1P1ICNW8Z8NYMAzkb7TldBvQMCELObg1Z5c4PJ7ONBokSwqsWt4OBqlXp2mVpFgYya0H1DEkiplM1Da9pT68bXHRNJf5v9VZPXWkIqBcbfDKkSqRE56+cxMP3rSGyomUShrY9p3LeODG1YigO4+raT3bf/9Z/k0wYUjyloz7hiOGxKv6Ryxuc6rq8wUWA9EsKkEpCDy0c5SGGkkkfO2Kc/nip87jnms+Qv9FPQAcLNf97/bWXHsSPXzLLRsyBocjaE32oDn6kNLbr21zS5Z9xipjGTNN6QdI5OBkLbClr4dHP38hve1zf7L7xlJ/89Pl5I39h4fvvWrzNUPDKEN5UzqvLe+5f1dXqoWt0tZ5jdWr4OsA4YwNn+REiJwwnXpWLWvj1kt62Xh2O3Wv0c6jnj+8XWd8Yvy5jSvim9+4a2M5p9hpbfksiPyFJD9+9VtCfDvq+6TQdmqlM5Iz/znVGoo2mrWkkQJuj0vcr8K9Tz0iMqRnHkzmg4Atj0eFjWvXO7HzTEMBHxYa5k6JhyiOKCWgEvuSk8Mj3924WxYZzc4sj///htOmrwVD9wETnwmDCH0Iuxcfy+dJ34CxG2No8fH8P2Vx0lhtfhBPAAAAAElFTkSuQmCCaWMxMgAAEXiJUE5HDQoaCgAAAA1JSERSAAAAQAAAAEAIBgAAAKppcd4AABE3SURBVHic7Zt5kGVVfcc/v3Pvfe/1e733DMMyMAMyTLE5CDiAEWZItESiGEyaVKJYFZPg8oeJe+FCM1IYywomJqkkaIwVY1XKaUVUUFHJDIoKRmEEBEaQZfbpZWa6+6333nN++ePc97p75vU2wxCrwq/qVNd7fe8557d/f79zHrxEL9H/a5JjeltVhkC2bsW8QPtZEm3ciNsEioi+qAsPDanZsEXDF3XReWjDFg2HhvSolLA0C1CVwWHM8HViAW74uUbjjvMkjc93zq52ll4jx2hVC5AT1AgTIM8HYfAondGjw+dJDDC4WYPhQdxSLGLRmx1SNZtEHMCbt9bXkJM/x7lrBTkr6MgjL7ITqANbj0F5Sg3foKFfuOPKwpOH73UhWpQABjdrMHyd2GvufKIr6F89JEbeFRbzRVtPsY06ilpR0RctEjjAAEoY5AoEhZC03qir6u1TtdrQD17bP9Hc80JTLSiAQdVgWMS+6Z6DF5hSx5ejYv7ceKKCOpciGBBzfI1+HlIAdShOjAlz3SWSerw9mZi8/q6rl//Phi1bwvuuvDKdb4p5t96U4hu+d2BD1FH6pgRBd1qtJIiEIojqIiY5jtR0dBFQRVFNw45SpGoraXnq2m9dtez7C1nCnHtv+tGbvj91vuSjH4N2pXHdGgmC6aV/20hw6mwQ5QIxpppU61fc/breX8wXE9p7raoADG7Z3+kChgmCrrRRtyImUBSF39KhiEhg44ZFTDGIguHB7x/omcnTogQwOIzZJOIqcXRz1NW5NimXU8QE6nz0PZaBgsl2/ELM13YNMUFSqaRhZ+fpVZVbN4m4weH2vB4hlaEhNZs2iXvjPQdP1zB8QlUjnJN2zy6VRCB20LBKRyCEBppx5DiQYowTMZrEtfPuef3y7e1c4QipbN3ov7Mi7wyLnXnS1KEIqhzLEJRGqqzsEK5emWMgLzRS//2xzt1+IKSphsVSGAbhuwHaQfbDtSqg3PBzwp2jB54M8x1n2LjuOEaYYwRip6woGP7hVV305gx7q473/HSScqIEIscprKozUd64uL6rUuhfc9+VUgcVmEaKsxgbUv/PXeOHzjVhdEbaqKl/ZqmhyP/1iNSPulXW9hh6c4bEwUlFw+pOQ91OPzfz+RdmYGxcU5PLryzFk+sABjcPz+J51oeWiTh7QVAooYpVVZYyXGbuTpVq4qOeqoJTrHMo3iIUcM7BjHerifPPsrQ15x9Yk+/AuPgVACPLB2VOATRpvK6rUwWDwy1xQQPUU8WgrOsPia0XiHq/bPmcwCzmrSqvGIhInWbvcMzMO/X7SB2M1XR1O17bCmCs4bp3TqWUkwzeK5kg5o87Bqgmjt5I+OQru/nMZT2cWBCqScbQYetoJpBKoqztDrjt0m5uurCLvEA9dZkQlj5cJmy/H2XXVMp47LoXLYBQkcTBnoplpGpJnRIsoBFBqaWO5QXhs7/Tw7qBCIB3nVNCMm2gR4gA65SOwD+nCq8+Mcdtl3VTDJhlPUsZAZA6ZbRm2VWxfh6VxQMh5xyiiqhyqOHYVU45WHctLR+euVBIHYQi3Lq+h5WlgMR57V60PMdJRUMjbRPn1bvL6Z0BZ/dFiEDiYG1vxKaLu7FWce7I9dqNpsZV4eCMPUumHKV9dTxHepvp00rqlJGa9ZM2XOZbtHK4oJQbjnecXWRNT0jilMjA7qmYG36wj71lS86QBbgZglalEAhPHox59737OFBLiQwkTrlweY4/XdPBZMNh2khAdXptk83VVFbTas0MPtwc3YH2FqCg6lovN6Ubp46RasrOqZTxekpslUC8qZ7dF/AHZ3RgFQIRDtZT3vfDEZ6aUvKh4LT9DlQdhdDwi3HLh360n1riMCI4hbecVWJlp6FhD0uvQCAZsrTKeN3vaaSaEqduhpU2mVfmMIC5WxizBa4t7RkgscpYzbJzKmVvJWVfJeX3VxUIRLx1CPzjwwd4piz0FCJSqzifCduukTploJjj4QPK5x89SCBgVSmGwlWn5qkmjlCm3S+2jkN1y56yZ3ysZkmyzOHnbaXAaRdZigs4N3/6g+mgeKjhiK1j/Ql5ACIjPDFe59s76vR1RFjnMOLN0aAtITjFNxSyWJNaR39HxF3P1dhXSYiMZ+fVJxUIRZlsOMZqlt0Z0/urlnLsWkFvIewwlwXO2dlVN631tv8ng7ipcvZAxMquEKse1t7xdJmnJhwn2hTB+3klcdQSbx2Jg8h4eNywSmjAOsWIMFpRvvd8hbed04sCq7pDnFOez+IIeNNvai7z0Ln3qfPz0dYC1Ll5pTkdG5TYOk7tNK2cDbBtLCYQQy1xTMVec5Ox8p3nKjx1sEFk4KH9Ne7dUWW0ZtkxmbCrnLKrnLKv5vjJngYA1kEhEE4sGlLrvN8zDXKWBNIy07tv62xe21qAc75cmEdwXlDin+3OVCPii8YDdUdgaEVogHwAY3Xl2m/uZm1vyGPjKWUNyAUzE5QSCozVZ5trdyRYH5mPiCMLUhMczREE5z7caAtcDiMnqCqJnZ5dxOMB53TWFM5BPhAm0oAf7rN0hAE5I1nt0NorLkuhMym1rqX1pZeN8/Mxa6n7Woy5lokvFFgMykjFN15dttDKztALZVYG8ekoEOjMBYh4ZmeugXoMcFqXR5FNwYzWLIEcW21AKwhunVsALf5xLb+ZVwBOiYzwm0MJ9dQRZGjzilM6SG1WCc6cI6sSbaZRnRm53XRG2LCyA4DAwFgtZcdEQpQJ7KgLo0WlwaZwMoEpzNt7cw7yBp6dSHh0tOG1qvDGl5VYWQqoJVlBc/i7euR3RqAcO87uC7ny1CI2s/af762xt2KJjOCOuk+oMMfpwBw4gCM1NMcQoJYqw9snEDyo6S8E3Li+n4M1i0/nC83h40U1sXz80gE6Qh/0BNi8fdIrYoYV0Wy8LEr7TV6WIIDW5IswudQ5uvMBX3lykh2TMVEgJE65/pxu3nthD7unEpzz0V0O69hIFvVTp+wvJ9x8WT9Xn14isUouEB4ZqXHXb8p05wJUszQ4Y20jzEqNC7nr4gXgWLj8ykaTuQMN5SNb97YCl1X4m8uX8+nLl+GcMlJNqSYO6/w7qfUdoJFqSiTwL685gQ9c3E/qNHMl5cNb92KzQ8BDdctYNaUcO1KrxKnjUC1ltJpSS2ZjhLZ7nYOOCQc0KbGO3kLIHU9V+MyD+3nfJStInALCX1/Ux+tPL/HFxya4b2eVvRVfRBVDwymdEb+3qsifndfDqm7fDRIgMMJHtuzm/t0NwjAiTh1Xry7xu6uKnDOQp69gSCzsKif8bG+d7z5b4VfjDUqRIR9INs90+a9No1usAGBGJbhISq3SV8xx0/2jhALvWb8C8GcAa/tzfOqK5Vin7KtaaomjlDOcWApb22xYJR/4T5t+uIfPPnQIE0a8bnWRGy8dYN3y/BFrXnBCnjec0cmNl/TzX09McesDY4zVLF050xIm+CDo5kBCbQXQChxLEAB4z+nqyPPh+0Z4YqzGLRtOYVnJ5/TEeZ89pXN6Ses8CoyMkA+EnRMNbvzv3dzxdJUwyvHxywb44PoBP7dOt+WiwJfLaYYrOkLD28/vYeOpRa6/ew+PjNbpzgcePdLsQyylGmRxtUC7QKNO6SsV+OJjZS7/0nb+/oG97JxoEBlp4YQmBUY8jjhQ45M/2s0VX/o1dz5Tw4QRN73KM2+dh79GIDRCFAiT9RQEcoFgsjkTp5zRG3HntSs5szeiEttZjdWlQWHXrAbbvzQfKYqzSn8px76G5UNbR7jtwVEuWlFg3YoOTuvJUYwM5djx3KEG2/bXeHh/nbGG0FvMI0a56vQSH1g/4DWclcWqvlH63q/+mm/9cpT+UsSn37yG1587gFMPyFKnLC8G/NtVJ/OarzzvFZKl2LkS4WEC2NrkP0s3nqWlkkCWygyFzg6q1nHPjpi7n6212liKb+lEYUAxl2dZp8GqkjPwicuXo/jiCnwnKjTCZ+7dwe3feZaor8Ceg3X+5IuP8fjHL+WErhxOlTATwkUnFnjrOd3cvu0gA4UAq3PXEHNYwHQtcDTUfMt3onxF2F2IEImOfDbzbeccEw3HNWu6OHsgj1Of4wHyoffUnz0/SVCMyAVCrpRjopyw40Cdk3vyrbmaFenbX97Hfzx6qFVFztUSm1cASw2C85FdaC4REut47epOFB8gxQixdfztD3bws2cneGh3GYl8hEeVXM7wwa8/zak9ed6xYSUbzuxF1Fek5y/Pc1ZfjifHG5RQ7BwSaI8DxKh5gQWwEFkHeSOcsyw3fXok8FdffYrbv/0MFCNMZAiNTBumCPc/fQhiy9e2jfDgh9dzwcrOrCstrOnLsW1/jVKzp9qGDssCG7PdpFPTqXDRoPCYhnUe/vYWfIcvCoSpuuWObSPk+gqUiiFRMDuLABRyAT29eZJaylcfHsmE6Xnt7whaENhZNzWLx4zaB0GV54xzRx0Ej4YEsFZJbLZhhXxkWFaKGD1YJypFc4QkJbGgqWNVf6E1F/jg6Wsah4g+57/dOuvt2Rbw+Gi2uvmlNiqoc8GxNCGWMprnirsmExQPcnKBcNsfrmFZV45KLT2iHSYC9cRRraVcc9nJvOWVK3AKUeDZ2jEZE6CBa9RInW4D4NzRWbO0uSCBMvRYrrtot0tUWE3aaF5LPK4UGmG8kvKRy1dw65UntTCAAHsnY7bvq/DRu57hwacPEuW84SaJ5dNvXsMVZ/Zy8Sp/9tkETeM1y7rPPekm0sAEabxnIuo7k/efVmO+CxKe+S0hm86LUfM1ogLq1OkL5OfzjdT6E6RvbJ8gttpCeE6Vk7pzbDyrj9X9BWzsyIeCMWBTx1XnDnDxqu6W3zfbct95epLdh2KXKxRxIl/n/afVGNoSzmS+nQCAjT5fuPhfXa0cq4hR5/R4u4BTXyH+an+N/3zkACbrExjx4MY65YZXn0KhI2RiokH1QJ1rLlzBmcs6/HPGdxuaTZm/++l+jcJAbK1sNU3/eRZvM6j9za/NmwOuu8523vqLz0rnsvdo5UCKyHG/Ht/cfHcu4IG/WMvq3hyp01bqE4Ftu8vc+dAIp/TnedslJ5EPTStMp1aJAuGmrXu55d7dad+KE8J4cvxzlY9e+I4mT+3WPJJUhZuRfh7sbBQ6HpIw/zJtVC3GHN9bouoLpEpsOX9FB9996xpWlMKWJcC0a0xv1YOsZrz43ENjvPObz9vOzlLgbLIjVC6YqJ8/wc20/WFF++CWPXhg06WTapPrnLVVgihQaz2sdnp8LjmqPwMoRYZte6ts/Pft3L+jTGgEI2BESKxSTx2N1PnzxaxKjK3ysXv38M5vPGeLhVzgnGu4NP7jiRtffnAmT0ewOq9GMrMpbfrpa12u++tipKRxNQUJhPY3Ll4IUiA0UIkdkRGuXzfA2y8c4KKTS+QOA0P7ygnffmqCf3pghId3ltPO3q7QoXXqU39UHbr0bjZrwNFclm7R0JaQTVemHUM/WU++88vkSmuoHgLw1+WP068EFH8u4BRqNUsQGdYuK3DWQJ6Bor98tXMi5vHRmhs5FDsiE3b19pM2as9odfJt9Vte9ePm3udbZ3FabEpxaEtvIey/BdEbyJVyJFVIY4WFf5hw1CS07h3UYvVFQ9OYA4KwkJdCRwnXqCUO/UI0Vf/Y1KcuGV9I8zOmXyQNqWGTv2cbfeLhc43IX6rqNWLM6USFJU11NCRkx+LS/KRoUsem9nkV8y1N088nmy56BIDBzQHDR0b8ueZdPKkKw5iWZN/7k45woLROnHs56laL0gP2+KJGNaoiEyYwz9kgeCRtxL9k08VVwMeswcEl/Wjq6GhIDZs1OL6LLIE2a8CL8rO5I0iFwWHDOcv/b3418/ioMjzoDoe3L9FL9BItmv4XKN4dvDIWvKkAAAAASUVORK5CYIJpYzA3AAAmVolQTkcNChoKAAAADUlIRFIAAACAAAAAgAgGAAAAwz5hywAAJhVJREFUeJztnXmcHVd157/nVtXbXy+SWpv3BRnL+4oNxrJYjAmEDAEpCUuADDGZzAecOBOWkERSgBkIkJAPyYQPiZmQBGaQ8okBEwO2QTIEbMBGRsYLNrbRYkmW1Pvbq+qe+aOqXr/e1O9J3eq26J98P91+/arurXvOPefcc849BYtYxCIWsYhFLGIRi1jEIhaxiEUs4pcFMt8DmARVAdi0GWHzPI9ltrAZtmxGARDR+R3MeMwvA6jKhm2YQ33I8sPoto1YWFgTNBfYsFWd5jNvwM4nU8wDA6hs2IphA2wTCSf+9bUPaC4b0uU75L1a3a2f+AHOKtIARsMgFZbzbn7kXy+V8sTvbNiqDsB8MMOJYwBVWbdjh3Pv+vVB8tFbHtJ8vepfFob2WlQvV/QFKCsRutXarCAGnu8CQVDBCtTADItwEJGfI+wUq/dnvMyPv3CNjCTfXrd9u3vvDTeEJ4oRTggDbFB1ktW+bru6y9z6K3HMRlX7MuN4pztpg1qwAWgYoGGIqgXVEzXEOYSCCCIGMQ7iuhgXxEDYUGyjvh8j21XZWh1Jf/MbvyJ1SOZs7lXinM7uJlWzBRQRvenOI1357sLbUX7XeOkLxYWw5hM26ipCiAiqagQBVJ7/hJ8Ijf4TVEQsqigYx00ZJ5tCLYSN2s9Quc0p1W7bdlPPAMCGrVudbRs3TlKVs4U5m+V127e7sbiX13+3erMY8z43mzorrIcEtaqViLsNYOZqDM8LqKqCBRU3nTNOxiGo1J9V5RN7Hv3p3z34riv9lrmcdcw+A8SW/baNEr7urqEr3Xz2r91M6rqg6mMb9UAFE+n2RUyEolYUa7yU6+ZSBLX6A7bR+MMvr+/6z1ZpOpt9zi4DbFLDFrEAr/tO+Q8dx/mo46ZTfnk0YJHwbUPVKiqhm8u7an1rg2DTl9cVPgyxWpVojmcDs8YAycBuuvOJdDZ/2j+6hcxbGiNlVWutiDiz1c8vExQNBUyquyh+uXa7HSi97av/pW90NplgVhggGdAr7h7oLqayX3ELmXWNwZEAwUHkZLPmTiwUVQjS3UXPr1QfkOrwa25/1apDs8UEx0+cWOy/YutT3fnlq+5xc9krGyMjvoh4x33vRTShqn6q2OWFteqj5drw+rtniQmOjwFUZcO2bWa0cKmbzq6+y83nr18k/txBrQ1SxW43qFZ+rMOVG766c1mZzcdnGB6XUbZuB862jRtDL7Xic14xf31jZNhH8JTFf3PxT4y4jdKw7xZyl9ui90W2iF23A4fjWMjHzAAbVJ1710vwmrsG/yDV0/Wm+tCIz+LKn1MogIhXHx720z3dr33tXQOb7l0vwQbVY6bjMXFO4p16zbcGLnHd7I9sGBjC0CwafCcKqogTmlTKtZX6dXe8qut7G7aqs23j5ODaTDgWzoni9apGrPNZcT3PhiEqkSJabCeiiVgbCghq9LM33flEeu0GNMml6AQdM8C67dudbRs3hg9+a/R3Ul1dVwflUiCIswBm5ZeqCeKElXKQ6upa6zp979kiYjccAz0745iYw9btOJTP++nHnVRqtW00FPkl9+fPH6y4HhqGQ57qmi+/omsA6CjrqCPCrduBg4gW/PTbU13dp4T1mgXMfK+GmZoTP2gz8rQAxjRLzWijYb1CcYlvw99HRONdQdvoRAIIqlzxIO7K/sGHnXRuTVCvqsjC9e8LYIGyrzgyNm8FV2h7iSx4qDVuWsJGbb9Z1rvma1dSjT5vTwq0TbwNW9Ugoqv6h9e72cJ5Qa2sAgZVFmITVQIb/fyts9N87Ko8H7kiz6tP8agFdt7HN3sNEzaqNlXoPkUHhl8Douu2ty8F3Ha/yIboh7X6ZtfxVBDbCQOdaCggqmy6vMBVfWPuiWuXe5zb5fJ3j1bIu8KshdXmEYKJWMHqm4Ftyw+3L+DaUwGqgoi+9quaC72BJ51UerX1GwuWAYzASEP5tTPS3HpRHt/SVAEQ/X7LfSP8dDAk54J9vusDRcV1RQN/KBDnnLtu6hlIaDbTpW0RcMO26HtheuAyN51dHTbqC5b4EHG1qnJhr4tqxBBGIsJDxAjn9zj4oT05Es8EsUHDurlij7HhNTBGs5nQ1pcO9cXzZO1LJJ2FeNEs5AaKoEzlmxRASDzs8z/W2XlesbgeGF4yjmYzoC0bYPkNUR+KXI6NvY26sOXmWFbxNLAaf+ckyDwn0gIaBqB6OcANN2DvbeO6tiTAtmg3hYi8IAx8dB5TdhNamThveFratUPUo3xHYrXR7q0WAMT6DYBzNmxVJ84TmJFOM0uA2Jg4datm/eDIqozrozp/adtGIFCl7EPKAc/IpIWuxBLgKJi4m2qFCNQCJbCQcwUjC99QVEUIfazV5b9wR3qAflSZUge2YGYJsHmzAJj67p79FdtVqgU4qLSvnWavOaKUfYsD3HpRnnWrUow2LM6UYagZp2zaPkYblrevyfKO87LUAks9nK6PhdMcgUoj4NmKLQyUar0R7WZDArAZ2EIhnc0HoWb2lwJ6UtCbiQIA4QnSB46Bwbrl0qUe/+OSAmcVXa5e7vH9gw18G3FyQvZIAsxspkyUAEagEigv6HJ407k5HIGLel0+/pMS+yuWYkoIF5DjQBlTU/11K4N1qziuk844BQAu2DYjadreygW+cUUwgjJYt+wvhdRCxT0BK8OIMlgLed0ZGT714m7OKro0LKzKOWw8O8NoI8RMO46jYfx3BcUPLTefHxG/YZUr+lL87+t6uHyZy1DNnpDnbbe5ojRCZX85ZKBmEVWMCEG92nZiTtsMIF50hkU1uqgWKM+WQo5UbaRqYGpP5XE2AwzXLW9bk+N9lxbxjGAVPBPp5Y3n5Dgj71ANdNIYjoap+hmpW166MsU1K9JYhZQRQoUlGcPHr+nmZatTDNZt5FSag2dttwkRD/TXlH2lkKqvkQRM/u60pQM7Y4Bxk8eYbTFQV/aVQ0q+zmyZdwhHYKhuedO5Od61toBVmmIv6SfnCu94YY6Kf3xOnTBmqneeX5g0hojhhC1XdXPdyhTDMROcSCjRMydqal85pL8W6SORY5/zzhhgCnY0KH6oHCyHHCiHNEJtZik2V2KHTTUK4Q7XLTeemua/X1iIbI0Jew9HILBw42lZ1q9OM9rQ8eHeGZ8nagYYbVjedl6es7vcyKZo6SjZBYjA5iu7Oa/bpezrnIeWW+fPARrxPO8vh9TDaO6nFBEdoCMGmG6sEE1OyY8481DVNicxCcl28uwJl5/d5fDey7qa7tyJi84quAaeGPQZildlIiVm4oHW7yTi/qkhn0OVEM9EEmHcRMViP+sKm67qIueAb48+L8fTkk18tO2FwzXLvnLIqK+xJ/Po9GgX7TNAvT6jcko4crgesm804Eg1JLBjEqFdJac2+vmBy7vIxbH7qYhvBG5/cpjf+/Zz/LS/QcYRdHyodHq09qdKxsDde6q88+6D3L+/giNTM0GocHrB5d0XFSg3wlgKtPdc7TbRaHsWWKW/GrKvFDBUC8fN8VFbB5gVCTDVCrZEu4W9pYDD1ZBGaJtBmeReU8ERGGlY3nhOlrW9HqGOF8dA87PPPHSEj/ygH2MMec9gO3z4VligJ2MYCeCPdhzkzqeGYyYYf8+EMX7ljCzXrkwx6ttJ4+sUSQ/J/PjWcrgWEX6gbrEa2Vftzr/fQd/t5wO0jrTNrzlEDDlUt4w0IO8JXSlD1pGmSG29pQANCyuzhreel2+K/laEqjgifG5XP599eJjlXVmsONhZcE6GKqQ9F1fgL+4/QsY1vOyMYkyAsZsnv928tsDOw1Hk9ViRiHlVqAbKSMNS9rXJ5MkctjX1x6AD2maAOjA+9be98TQfkChGP9qwZByhkBLynsGLZZBqbEfUQ966pkh3yhAq41JbrIIjwrd2j/L3u4boK2YJxUS9tIS+oxHOPM6xMzcxYkIY1yGXTfMX9x/mtK4UL+hNN1UOjBmFL+z1eOmqFPc8W6crHm87EMYMWt9CuWEZ9ZVaoE0JmvTVmd+pcw7ocBfQeWu1ZGNSUQuUwxXL3tGAg+WQUkOxCtbCsozhNWdkmxPR7DpmkEMVn4//qJ9CNo22FhiZqv9jeR4EVcFzXXxc/uf9h2jElNUpLn392bnmHny650cj/kxGaxVKDeVgOZqDQxVLNTbukp3Fse6gOtUB85LUkUTarI22XwfKAc+WQp4e9rl4qUdf1hlzeMRIpMlnfzJAfyMS1TpXTmgRrArFrMeugYB/f2JoUkAo8QNcvCzNmm6HauyHaLXDJP6eEKmukm85VAnZOxpwoBww0ggJ7fgVf6LRkQ2g41hydpA8d2Atg7WQa1ekJ/WQiN9nhhvcs6dKdzZFEO+TVCezgTbHOj00tv4T7+ZUCFUopD3+389Gee253RQ8M25HEqkkePHKND8dKJH3xiISoYIfKrVQqQbRzyCW5+P9GdP33zHmehcwVxAgCGFVzvDiVZmm3ZAgeaQvPDbMkQYg0TFEQ0SARLVI6wUzzIW2fG860W1VSLsu+8qWb+8uAYzbaST9Xb0ijQuUfctQzXKwHLJvNOTZUsjhqqXka3OlO3LctuqsYt4lAEQrohpYLlmaYlnWGbfKlGjSKr7lq0+VGWxAfTTANYJnhJQBzxFcA3G0KrIJmV6sRveMjtWLTKVIpMlQBkh5Dtv3lnnduV3xX8bGDXBWl0cjtOwth7gS+y1k7Pqkz7at+WNFUwK0bwR0tg2cIxgEP1TO742CWKGNPHwwJmYfPlJnbykkn0kR2shJUkWbxoEhXmFGSBsYrAUM1mw8J9qkVsJcIw2l6isZN9pyJcSJfipWo8+tQiOAHftqHK4E9OXcpkGaeOOKKcPpBZd9pQaZtDS9kdAihRbSsm/BnPgBOoVKJFrP6U6GMyYDEuI9dLhGzUIhjnw0RX7LxIYKQagEIVR9+MpTJX7jvCIGIbDRFsszgm+Vr/y8RH9NKQXhmEzTqR/TAQ7VLI8O1FmXc7GMbU8TBj2zy+Xe/XVQmdr+mNOl39JHh/105gkcZzjNYrMWg7I8F01ra5mB5NefDzZmHAMaxfQtSnfGcM+eMp964AhGaKqMWmC5dftBnhjyyboy7rpEJZi4OUkzkcR5eshvjqF1TgBW5AzWRpVd52ye2mydYEGogETP96Sm4seIA47ULI5pg1/j57cK+ZTLh384wLd2l7julCz1ULlnT4VHB0O6cynCVg/eDItWRThUmb7+Qk+6xR/xPEL7DFAHNXNjBCqRWPemsNqST6qBtjhI2uk/UhJdmRQ/OOTznWergJBNuXRnPUKbmOMz3ytSDxKNYRqkjKBqUdv5Kpw1xNIs6MARtCAkQGx2HdWV6hlpy73bes/IoQOFjEdXxmteHWr7xG+9X+ooWSBh0/J7fomADreBczUMCEMYrk8WsUmXSzMmttanMbKmhRCqMOnOHdwi2R0sy05/6HaoHmKbEqqD4c0mjkE4dygB5sgPAIRqOVSJCmKP27bFv5/Z7aE2fqHGCZ5hBRyjnNkVbVOnMlKfKwcYGRdamgd0TpuFsQ0EUOGZ4cnKK5nsS/oyuCLY1k32CUJgIwP1/KWpaEyt44v/b/dIgIOMBXDmA0qn4cP2GaABndUe6QCWyIHzaH/0hqDW2HtiF166PM3KvMNQQ3HNiavwYSRy8V69IsWpxciOaE1qMbEX86mhBilnvBPo+YAO/ACNMQU3y01VyTjCz/rrjNTDZv4AJOoBetMO15+SidKwWsNuc9wMUA9CXn1mPhpLS0gw0URPDjZ4tuSTmpSSNk9tbhhgvAUwm80qpBzDvlLAAwer8WeTH+S313aP5eTP4XiSBlAPlRVZhzeuKQJRQkqCZIzf3VuO0+LlhIyrnXG3i+NOC5+tJkTh0jufHp20Q0uyfa9dneUVp2UZqgVRPH6OV5IrMFwLeMv5RVblXUIdX28gYYZvPDNK2olzEhdC68ARcAwSYG6KKgQK+bTDN54pMVwPMdPo+T+7dilpMyaK52oVSaz7z+5yec/lvVFOAhNWv8BPD1f54YEaOc9MSkmfr9YJ5jwlrN2mChnH8MxwwL//bHiSvk1Ssi9cluZPr1nC4XIUEp6LsSTH/2q+5RPr+liScZpM0ToVAvyfhwcpB+BIVDBt3qnfIQd0mBAytyMPFXKew2d29lMLbFOnJkhSst99WS9vv6DIgVE/TiqdvTEIijFwqOyz+cVLuPHMPKHVcUfBogwlYfdwg22PD9OdcQkWDPU744D2GWDuNgHNZhVyKYddRxr840P90aqfUJkhyc379MtXsHFNgQOlACMyK4dTDdE27lAp4E+uXsIfXrEkykyeEKOwGiWRfPS+5+ivxdvSOZ6bTlon5wIWREpYK0KFnqzHX/7gMHuGG7jxaeAESR6Aa4R/evUqbrm8h4FKQD1QXNPMImizt2jFGKIElNFGSD2w/NUNffz5i5dFxJ/g/g9tRPAdu0f54qPDLMmlGB8j0uY4HQE3bk5La/1MJlx3onEMKWFzCwVcYxiswnvu2svtG86JVpyMJWMlp2FF4GPX93H1ygybv3+Enw/5FFOGjBvXAEtWxYQ+hCQzOdq3VwJL1bdctTLDR6/v49rV2SmJn4j+wVrALXfvw3PdiIU0GrkAJs4Rr4dRnn8Qz1lTSjG2fXRFSLtCOj4oE9rjdCQnD9wBFkg0cDxChd6sxzeeKfOh7+znz69fjW91XLg4mcxQ4Q1riqw/PcdnfzLEFx4b4enhAAHSjuA5Eq20+ILkmnqgNMLoQOmFy1L814u6+e0LuvHimgATiR/NrWKM8Ptf38PPh0OW5jMEKohEW8KGVYaqFtfAqQWPtctSrF2a4owuj6UZh5QTZSP1V6PU8Ef76zxypMHeUR/fQsEzpB0h1BMXUegwFnDixFRgYVkhzUfvP8SpXR6/c2nflEyQGIZLMg7vf9FS/tulvdyzu8zdvyjzk8N19pcCyr4liM93pwwUUoYX9qa4YkWGm87Kc8NpObyY4nYa4ltVHCO871t7uf3JUZYXs/g2+izUqILJ8pzD69d28foXFLh6ZZaezMwadqRuefC5Grc/Ocp/PF1mfzmgO2XwjBBohycfJkqAbTNf0pkK6OTLxwMFECyG7lyGP7j7WdKO8OaLlhHayOM23iEzJlq704Y3rCnyhjVFAqscLEenlEu+RYjOJvblHFbmxz96chZvYk6K1ZjRjLD53mf51AP99BWz+Cq4xjBcD8l7hj+4opebL+lpRgyTaxNxLy0JjNqiFrrShvWn51h/eo73vSjgtl1DfHbXEIP1kN60E6kQhc44oX0siGjg0boTMeQyaW6+cy9HKgG3vGglEOlLZ5I0kBYdK7hGOLXocWpx6pI5YSwVWsvItiKIDb5QlVu/sYe/3zlAX1cOi2BEOFwJePkZeT56fR8X9aWje8ZzlDBTa2BrbLDjTb/EyD2l4PLnL17Gb57fxZ985zBfe6rE0mxck62dude4zdXRsBOe4EhcKMEYunIZ3vvt/bzra08zWg+bondi/b6EEcakQtTCuNkWKekYmfKgRnJf1wi7h+r86v99gs/sHKCvmMXGZwcHayF/fPUS7vj1U7moLx1lHeuYpd/ugk3UWBLjCKyypjfFv/3aKWx+yTKG62EUAmdukkIX3DZwHGJVoGpADMuKOf7p4WHW//Nj3PXUEI6MFXGcynASxheKduLfp1qUqrEVrjTv+/mHDrP+nx/n3n01+rqy2PgM0mjD8jcvW8GHrusDaDLL0WoyJruFo5FH4uzlhGnf/6Kl/MOrVlENonHNhRbo4Hh4Hec4zsEfLzR20iwrZnlyuMGvb3uKN5zXza3XruKSlXmS6UkcR9HBDWmeEhp/L+IdgTbPHRqRZnDn288M8/Hv7efbe8oUMml6ch6+lbhWYcinX7GSd17cE1U/MXJUwmjMnG5LjZup7JhWJJrNt8pvnd+FCLzz6/spppyjr/BYAoTPt5NBbUOEQCGXTqEply89PsLXnhzmVWd38eaLl7HuzC4KqclpK60rr3kwM2aQZLIPl33ufmqIf9l1hP/cW8Yal6XFHBaDr4LnGA5XAj5wzTLeeXHPpB3JVEiYyxXBqjJSDShk3IgZWv4+HZJDLL/5wi6eHfH5wHcO0Zdzox3NLGFBG4FTI3nLh2FJIUcQhvz7k6Pc/rMhzu1Jcd3pRV5yeoGLVuQ5vTtNd8ZpOmESBFYZrAY8M1jjoYNlvrt7lO/vK7FvNMB1PYq5HGIMoQoqgmOEoVrIy8/Is+klfU1v4NGgMXH7yz4f++YvuPORfgYqPj1Zl1e+cAnvv+ksVnWlZmQC10Snmv7o6qX84ECVO35eojfjRK/DmdQpHdOow23gguCACBLtkzGG3kIWtZa9lYDbdg1y20NHyHvCspzD0qxLT8Yl60ZHt8u+ZbAacqQa0F8NqQaKcRzyaY8lXSkUg0Vatl5KaJWcK3zq5Svi+kdHF/uJ53L3QI2bPr2Tx/eMQMbFGOHASIPHdo/ylZ8c4RvvuYwXrshNKkEz7jGhGRT75PoVfG9fJa5dPBWtO+eAjg6GLDyTMYoMRIWcHNIpQzadAlVCaznSsBysWkJba1r+IoLrCK5xyWZS5I1pnh+IzguMj/m6JtruvfdFyzhvSbq5NZwRCu/8wmM8vneUYk8GP7QRTzmCl3HZfajC2/75Uf7z1itwzNSV0BIYiaTWaV0et1y5hA/eO40qOAYJsCBSwo6/RaLaihCoEGBQ4+B5HrlMmmI+S3chasVchmw6jet5WOMQYAg0ulYnpHSBUg8ty/MOv3/FEpRp9vUtCOPV/MPdI9zzaD/ZYop6YJvbT6tQDyy5oscPfz7IjicH42opR6ecI1HE8Z2X9HJ6l0c1rjYx1Xx0ggWTEjY7rXWwEu0ciMq9hHGz8Wdj5RaTZ5v8fI4Io/WQXz2nyCkFt1mubTqENqqaGljlgT2jSHAUV66CWOVHe0YJrOJbnRT6Hvc0EqmWJRmHN5xXjHwh08XA58wR9EvWbMwEG17YHfHWNPRJVrdjhIxrcE0U5ZuxTI2FlBN5LDOuaXo2p+WDWEK98bxusq5p+j6ORwIs2GDQfCN5a8hpXS5Xr87God7J6zmx9gHuf2aYnXujFf3dp4dx4jzBqWAVnJThO08OkXaincbFqwtcd25P07k1sbvEXX3Jigzn9Hg8NdSIQt9JH4kE6ADPLz/ACURSEv/CZRmKKTMlQZLPdg/U+N1/fYy7H+uPslsj65FU2pm2eqlVxUk73LHrMHc8eBCIskReem4v//DW8zlveW7KPkNV0o5w6YoMjxypkfPcSdVMO8GCORy64CBR2ZoL4yDPxK1a4prtL/vc+OmdPLF3lGwxNa6C2IylaxUyKQeTdpL/5buPD/DKv/kx9733KlZ3pScxgSogcGFfJnp7Seuij3lPwqBtl237L4xoWAvY+dfMJ7ad0T1NJFGjMwIfu3s3T+weodidJrSRARhYbbtusdWxa0KrFLtS7D1Y4S/ufCbKfJrmPmd0e9FbUnTCmNUikg7a6py23xkEeFKyVutinBwasGCrHs0S1EZJoksz0RS1Pq0Se+hC5Y6Hj2CyLn67dWJnQCO0mKzL1x/tp9Kw5FLjaxMmh2WXZBwckWaBq2hYIoS+FUmPArB2w4yDmlkCbNmsAF6+exjsSJT0hs73ypzrpkQrPOVOFTqMfozWQwYrfmydzw4DoFFe4XA1YKCc1CSa/LWUI8TZDyQrH3FQS6mq4RAAm2ceVBsqQBRVOfCuUyooBzFOEnSa/23/HDY0cs40pnpNWMwThbRDd9YFncWitRKV0C2mHXpysfQZd/OIpn6ozff3xi4QxXEAPVQaPTA0xYVToj0bIHkRsTFPYtypWfJkQ+x46Y8LQ+n4PxFYxXOEm9YuxdZCXGd2/OSeY7C1gJeft4RC2iGcEPRJpn6gGhKEOhaVUBTjgsjTbFkfsElb36Q3Ldob9SM7Yg9FuDPmKj3hS3Ke2p7hxtQTF7tmP3DjmZy+Kk9ppBHHGKI2k8u49T7JNa4jlEoN+pZk2Pyas6OdxjT32T3coFm5NeIKxTigPBR9Y0dbtG1vG3jBDREnWb6vfh1VNcf1qqrnAWw8+Q8frgGTYwCJs2ZlV4pvvvsy3vH5R7j/qaGxlxZ5kR/gqHMkUGuE0AibhxUuO7OL2357LWctzUzpB0iGkYxrrDaVCmEINvweMEazGdAeA2yMQvBexTzYkMpzOKkVhIFlAcYHZwtWlawrPPxclXLDkp9gjUPLiyNW5Pj+e6/i7sf6+XHs2//h7lHu3HUYLzW1M8iI4DdCXrl2Kdef041jhEtOKXDj2qVxWtjUIWJHoiSRnQcqY+5mVcU4jq2NjNogvA+ARzbPIgMgylZ1Dm+UUvEvd33beJnf1GD0pGYAVUgb+MVQgx8dqLDujAJ2QiYyMM5te+P5S7nx/KUA3HbfAe544CDptDOlO9gIhPWQV52/hD96+enj/jYd8ZPU9V3PVXmiv07GlTiApFa8rKE++t3SBy8/zCY1bJG2qgV1TsDAfhG1UWrsSQ6RaK//pUeGJtUlbkVySj20Si2IDqFU/XBGI1wMze/XAts8Gjad/aDxbmPbY8PUfDtWrUQBMYLKF6MP2tP/0AkDbBQLKqP53N22Ovo0btqgamfb6FpILbCR6L/98aGoDBwtgZeJxCSKBnqxQXfZqUXUNdObAAIqwuWnFpt1jI+WYKoaif/hesiXfjpI1hNCawG1OJ6xlaHnPLyvArDlhulr2k5AJxJA2bTD4ZY1deDvSWVFozf8LQC3zRw1jRwuz434/N2PDiMy+TVyE+HE+vuaM7t4yQt6qZZ80q5pJqNGziVDpexz8VndvOy8XlSnjjS2InE937azn18M1Mm4cUUSVUs6Lwj/2P++80fZtN2l9Q1aM6AzFbD5hhBVcSn+g5aHDmE8h+gVgQuAWnPTQqsUMg5/+4PDPD04+bj6dHCM8Lm3nM/py7OMDtVpBEqoSiNQSsN1lnen+fxb15J2DcrRHUk2Xv0HSz4f/94hcmkTl6ZVxbjGVoZHQqn/LajAjo4qBXbGACLK5h3O4PvPGbYafoR0XtRaGzlOT85/0aHQqBTsu7++NybI0R2/Js4xXLM82h3c/LLTOKM3TSHlcFp3mre99BTue99VXHpq4agJoQlsvPr/4JvPcrCU1CNUVDUkUzCEwScr733RQbZi2LKlIwY4FkNO2KTC6gedQr/zgKRyF2ujEoLMVR3JBQHXCEPlgA+/cjUffOnKjs4FAFQaIUOVgK6sSyEO/7ZD/KSfT//wMO/5j71059ym5Y+XEQ3qT5drwcVwRY0taCfiH45tG6c8uk1415V+iNysaq2Ko9r0S52M/6K3mhVzDn/27f38y66B5qGNo06uRHZEaJVcymF1T7rp3k2KTRwNCfG//PgQt35jH4WME+8UVFWMxTgC9vfYcmWFC7ZJp8SH44npblWHjRLmPvzgB01h6Ye1NOgjTB08P0kgMUHrvuVzrz+Tt168JDLOWk4YTYfEqEwMwaMhUe+OEW5/fIg3bXsGY6KjadHiV18KSzwt9X+i/KdX/HFCi2N6pmO5qHntpu0OW9YH+Y/s/DK5nl/T8mAgIidtmpkytqorDcuHXraaD14fHVcPbJRA2mYIYOr7a8s5QuBT9x/ij+/ah+eYJvFFNSDX7WpldHvFv+QVXIBEntrOVz8cb1aHqrAZgUdyuZTdIensFVodCTiJmQDGzheWKiG/uraHv7rpNM5dEtcHiCtKTDyONh0SyWBbCL9nuMF779rHl3YNkM84kc9AATSQdMFVv/a4M1K7bvR/XT3A5s3SqeE37lmO9cImYrdj4SM/7rPG3SFeZq1WSye9OoDIMBypBizJudxyzQredeUyVhTGHjtUbTqOmp5EpbmDSGoLJeivBNz24yP81X3P8dyITzHnYpPCUaoBmYKL3/iFrQ+tq2156Z5OXL7TYXbcufFA8h+4b0VYyP+HyeSv0PJQzAQnt8fYMVFyRr0Wsqo3zRvX9rDxgiVcsTpH1pvZxq6Hys4DZf7tkSG2/nSAvQN1UmmHtCvxq2YVFF9y3Z7WK49pZfTVtY+8ZDcbtjps23hMer8Vs0edZECb7uzKpFb/i8kUX6eVIRulKrXzuq/nLxI3cC2w+HWL8YRzl2S4bFWOi1dkObMnzbKcO1YlrBKwe6jBrucq7DxQ4YmBOmHD4qYMWc+MlYtTtQhIrtdorXyP0+j/rdKW9Udmi/jJ2GcPLSIp8+GHNolxNiMG9asBijNtdsNJgkSkW41qBNrAJokFcWkSIvmfHCUSQVxDxpPmdTamPBCKm3ExBsLGx6uN29/Pli12NsR+K2bXWNsiNjEMa38qW9If+tG94qT/WrLdl2q9DGEQEL3z+aSUCKo0C0NmHEFcp7l1hBbdz9iWMuKHuKBk9IKkEOO4kim66pcft/XGrY1Nl389jr7OKvGTscwNkr3pu+9MZ5afcosKt0oqt4JGBYJGIr7MyS4VZoYqGte8cD2HVB5tVAZE9W9qQ899kk++qnw8+/yZMLeT36Kr8h+4b4Wfz98M+g5x02cB4FchDCwSSw5pHtulrZTW5xViORBXsUWibGuM65DKgBi0Ud0nxnzeNCqfqW65Zh/AbOr7qXAiJlnYqqbJwZu2Fzy39zVG+Q3UXo+XXorjgQ0gDKKfamP5qLOYbz1PUGJeFsEYMA44XvTThtCoDWLke2L4Us0J7+D9Vw4DsQQ9dgdPuzhx06sqbN7hsGV989hS4ROPL2tUGlerBC8m1MuBswW7AqWIcRwkyWx+vnJBMnYLYRgiUlI4hDFPIzwkqt/3HO8H5Q9e/Fzzkk3bXTbfEEYvSJx7zMPMqrAVw7ZtTBJtm9SQfqw3HYY9NgiKinWh7WNuCxQuEoahcXKjddwhLjhvcJI+36SGCxA2YE8U4RPM79JSFbZhonMHN9jZtnAXLDapgR2GC27Q+SB6KxaabI2S7jbH43p020Ib37EhOaS5OTFx54/gi1jEIhaxiEUsYhGLWMQiFrGIRSzilxf/HzMHb5dhaEceAAAAAElFTkSuQmCCaWMwOAAATgmJUE5HDQoaCgAAAA1JSERSAAABAAAAAQAIBgAAAFxyqGYAAE3ISURBVHic7b13nCVHdej/PdV988TNq4Ry2JVQQEIRsQKLJMkivF1jsI0Nxphnfo9nnp8NsmG0BGNsHMEYh2fAAfAuAiSQCAIkYYyChRIKKAe0OU24+XbX+f1R3XfujDZMuHfmzmx/9SnN7uy93dXVdU6dOnXqFCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJMwjMt8VWBCoCsBQ1F4Pb07arTvZzJr165VrYeO1KCI63zXqdpKO3IqqrN+M2bnctcuKXZt184YN4XxXK2HmDKmaW2/FAKzYha55CN24Uex816tbOLwVgKqsB7PzVuS2dYQHGjF+5T4tjBbL/Zm011srB3kv5Q2KohoGh3f7dQni+er5iA3sqEl7Y4HNlMKAkRsukbEDfeflt6gPt7Lu1nX2cFYIh10HHhpSc+s6zLp12I0y8cW/+XZd2ZDGyRqEpyOcrOjJWI5CWYZoP0pePE+8dAZNjMuuQgRso4ENGqpQFWRUhF0qbEHM42J5Qow+aOv20a9dVnh+wpdV5eW34u2vTyx2Dg8FEI30a0BbX/Ab7tbV1IMLxAaXqnIh6KleKttv0oIIaAg2BA0DNAxRG0aX08OqkywUBAQREWMQ4yGej/iC8dy/2wYE1UoJeFzgToQfhr78+PoLc880L6IqL7/1Vu+2desOaBEuJha1AohH+9sukyD+3fofV05UvNdaG75WlYtTuWyfGLABhLUaNgysCBZAQVBE4nYSgUXeZosAjc0zBUVQAQVQxRjPNyadwUuBKjRKlYqIuUsM3zIiN22+KPPT+ELrVb3Jg8ZiY1F25qEhNQ+vRTZvkBDgNTft7usZGLjKavhWtfaydE82awMIqzWsDUIBVURE1SCyKNskIUJVFVQEq4oY43leNotJQb1UDUXMj4zIlyRIfXXzpbILnCMRYDEqgkXV2ScL/ut/VDlBMO8Q9Ff8bOZoVQgqFdAwUDeyJwJ/uKOqKmIFVRDfzxUQD4JKbRewyTPy97FVsBgVweLo/NEcf7M4wX/DLWOnSyr1PkF/yc9n80G5QdiohQiIJkKfcEBUUYsqxk97qXyGRqUaiJjrrZVPfu1l6TsA1m9Sb/N67GLwESx4QVi/Sb3WEd8gf6joW1O5bLpRrKAaBiieyCJ4WwlzghDNFIRQEN8vFAhrNUTkukaj8bEb1vXcC85HEA86C5WFqwCioJ3NGyR8+aYdPUuO6PsDEfNeL5vubYyVUQ1DETGx5y4hYYaoqloBk+rtkaBaawj8g0rjw1+7uHfnkKrhWliosQQLUjgmjPq3Va82vvypn02f3ChW0DAMEPGQhflsCV2KgmJDEeOlewsE1fpWa+0Hv/6y3D/DwrUGFpyQvPwW9W+7TIIrb9iyLD2w5K9MOvNWDUPCaiUR/IS5QFENTSrte9kMQa36rXpl5D03Xr7qqfWq3mYWlm/AzHcFpoyqDKma2y6T4A23DL8mtWTZ3X4++9ZGecwGtYrFiJ8If8IcIIj4tlHT+tho6Kezr83kBu96w23lt24WCRHRoSFdMHK1IARm/aZNXrwp5/U/LA8ZP3UtqoTVaoARf77rl3D4ompDz097XjZLUK/9bWrrE+/bvOH0eus0tZvpegXw8ltu8W+77LLgim8+O5jqXf6FVE/uqvpI0aoqYsSwYIythEWJgFqriNhMf68XlKq310Yrv3zTlUuejaer813Fg9HVCqA53//2rlNTPX3XeZn0mvrIaCDGJKN+Qteh1gap3j7f1utbg3JxwzdevfS/ul0JdK0CiBvuF7+z91K/UNgsnr+iUSomwp/Q1agNQy+b90QoB5XS2274hcGvdLMS6EoF0BT+7+27zMvkvolIPqxVQpF4X1dCQveiaq3xU8b4KRrV8lu+8cqBL3WrEug6BTBu9u/5Jb+n5180CNI2aFgxJpnvJywMBNSqFc/gZ3KmURz73W+8avCvXvL3d6d+8q5zG/NdvVa6SgHEwn/Ft3atS/X03qyh9W1QtyJmwSyrJCTEqFoV46mfL5j62PBbv3n5ki92mxLoGgUQR1JdefPeS/xs/jsahjkbNDQR/oSFjKpV8XzrpdJeWC5vuOFVA5u7aTrQFcK1ftMmb7NI+PqbR072s/mvAnnbSIQ/YeEjYkTDUGwQWC+f+9crb957yW2XSbB+k3aFP2v+LYChIQPXcvW64T4kdYdJZ09plMdCkzj8EhYRqtZ66axRZZetDp//jVevfnpI1cx3boF5VgAqL78F77bLJLjye8PfTPf1X1EfGU6W+hIWJao2TBX6vLBavmeQnovLu2jMd16BeTWxm8L/3b1DmcH+K+qjI41E+BMWKyLGaxRHg1Rvzzm7g5HPbN4g4ctvZV4t3XmzAOJY6StuHv6FVD5/c1irBljrJdl6EhY9qkGqr9+vDw+//ZuvGvzcfG4lnh8LYGjIrFmPXvGfw4PGmC9oaFVD65J3KCQlKYu8eEGpZL105lOv//7wCZvBxvkG55p5uen6a6+VjSKWqv5tqqf3iLBaDUXEzP97SUpSOl8QkTBoqElnCg3L5xHR6LzJObd+51wBrN/kzJ3X3TxyRarQ+8v1sdEAI77OdUUSEuYJJfIHlMaCdH//Ja/7zt7/uXmDhOvnwQqY2xuqypr16JV3a97Ap20QqM6T6ZOQ0AV4QalsvVT642+4rbh6M9i5TiYypzdbvxmzUcTq7uEPpPv6jrWVSihEe/qTkpTDrSBiG3X184W+eq3xp4jow2vndhowZzcbGlKz8Vr0yh9VjqYe/kyQjNpAkqy9CYc7KhJ6qbQXNqrn3/gLA3fNZTahOVtzf3gtgoi139334UzfQK4+Ohwg4keqMCHhsEXVIr6PVu0ngMvWrJ87oZiT0deFPKKvvXn0JM94D6q1HmrnxeuZkNB1RNuH/XzBhNXSZTdePnjrXFkBc+IDcEscohLaa/x8IYUNLYnwJyQ4FBBUxKChDgHMlRXQcQUwNKRm8wYJr7y5fIzxvTc3imOKSLLRJyGhBUG8Rqlo/Wx+3eu+M3L+RhE7FzsGO64Abl3n7mG18dupnt4MNgxJRv+OIAJeSzGSNPRCQlBr0hlQ+7/n7p4dRQVEL//OtkJaM0+YdHaVDWoW7Y48BIsFEXciSi1UalbRyHj0RMj6kBIhVEgcrl2P4o6zrDbCxinffc3SnzOkhg6eO9hRQXz5LXig4mvm6lTvwKqwXgkT4W8vRqARKsWG5aiC4aqjM/zWqTl+46QsL1vlk/eEkbpF0MQa6H4EG4bpnt5cSrxfAXj5us7KS0eXAdetw96GqLD3bapWkyX/9mIEyoGyMmf4zVPyXLwyRdpMbOPdVct1z9S47ukqKU8wJHZAN6OCCWs1VO2vDA3pJzauo6MrAR3TLkNDLtvJVd/Zd5zxvJcH5SKCJKN/mzAClUA5vsfjry/o5bLVadJGsAphVKzCsqzhXafmuOasAoHVRPi7HEFMUC1bL5Ndc9dL916IiHbSGdgxgYydf6HqlX6hL6OhDVGS7b5tCSGFIFT6fOGj5/awLGsIot+bSU5ABQIL61anefepOYp1617MfD9DUg5YRLFeJod48kaAncs7N3vrmAJYt47YcXGFDQJUkC5o20VRDFBsKL98YpYVOUNgwT9AFxHAN84ieP2xWU4f9Ck3rAs+6YJnScoLi42nAfDq9ZvUu81NAzqiBDqjAFRlo4i9/DtjK1AuCatlBDXz37SLowTWsiQDl61Oo7jRfqr8wpFp6taS7MDq3iJgwmpZjeevHevZtzY6cnzhKID1m911vbB2sV/oLdgwCJNNP+0hXu47usdjada9vqm0bPyR0wZ8sp5g47XChC5FQz/fC8a+Asan1O2mIxeN5yzGM5eK58fWZkIbEMCq0hut30xVjmMF0JMSUkaxyRvpalQQbIjBXAqwYldnZKgjy4C3RUsXqnqxDepYSYb/dqE4T/5MR3DV6LuiTi0nb6ZLEQnqVRQ97zU3aWbz66SG0+NtVQTttwBUBRF9zU2jy1U5LaxVkS45gWixoLMy3zWxxxYGYht1FeMdCftOAeiEH6DtghnP/42tnuZncz02bEQ7/+bfubLgi07+8wxRO/FaSenGIqgN/VyPQHgGdMYP0PYpQDz/D4yszfoZRMuWxAJoD7HQ29kqgPhaifnf1SggBlE5o1O36JhgGswpyfyyW5mF8kiYU9Ra1MgpACvWtf/Ftd0CiL2VKnKytWHiAGwzlnEjcSbM5rsJc4sKxgZ1FD0BIDo9qK2OwHZbABKnMTLokRo0INmE9gIW+j59k3h15wRRxAYBBlmxftOOHmB2U7/90F4LQBVEOGrTc7nRml0+6AeIdiaCaSFixDXRWENJGSFjpqnK45ev7fIBzOwaYw3FF8j7bvNRYlF0CAVjA8bq4eCzpJYARa7tbgsAgBz5Jbsq4cCOUt3dJFEBeNHuvXKg/MqJOV55RJpioNMK4+0GFHjfGT2cuTTF3ppiSd5vu1FceIYI7K4EurPhpS3h8k7cq70WQKSdPN8WUMmNVEOqDVieM1H4aVvvtiCQyNwfrlvWDKb47dMKnLMsxe6q5cc76gS6MKYDnsBIXbnqRVlef2yWK4/J8pWnK/zrY2VKgdKTEsKO5a05fFBcW9ct7KpYKQfWprI5CYNiHwBtPjikI5GAQZWCn/IxNtBqCFuKliVZw0Da7Qa2cadve1xTlxA9l2egHkIttLz1xDzvODVP2ggN6/bpv/XEPJ96sMhg1kxNeFpnALOo3rSs/0iB1S0MpoV3nJInjJ7tzSfkOH9Fik/eX+TePQ0G0mbiCuNifLftJhZnN3vGAKN1ZXfVEioYRFUMBPR04vbtnQJE2knULhU/Q3TwnwDsrli2lSyBbdm9tlg7iLpnLNaVvAcfO6+Pd68pNBN2+MYpwTcel+WkPo9Ko4uTJSl4QLFmecuJufENSLgtxsf1+vz1RQO8+fgcY3WLtdGUYLG+23YTKWMjYC3srFh2lC1WnXCqomJSYFkO8PI25wboiA9ARO3EBSvFiFIKLFtKIWMNixGXHUTnP+Kq7cUTGKmFnNrv8bcvG+BlqzOE0ajdugKQ8YR3nFagHs5ke+5smPp9RJRyw3LKgMcbj89jdVyBe0JTof2vM3r4w7N7QS210Eafmf930e1F0GZqty2lkJH6uGyMf86C0JEJ1pyu5ngCoSo7yk7LhTq9vewLAU9guBZy2REZ/vqSAY4qeM3nbH1UEwnPpaszXLgqzVjddqUzzSg01PKbpxVI76e3xFmHQoXXHJPlkxcN0J8SyoFddO+23Rhxw+SuSsi2UkhD9QCJXWar8A9Sh45deT8KL96EFs9zni+GjNZcoIDAgg9PN8DeSsgVx2T5yEv7m47PQwnCu04rkDKg8ZraVMtMmcbzjNYtF67McPGqjDNL9/MsQqzc4YwlKf7q4kGWZ4Ri3eKx8N9rO0u8emtwU8TniyHDsQzE/z75Hc/mXR+CjimAQ7WFEQgUdlQs28qWejg+mtgpfL/bihEYrll+7ZQC15zT1wzXP9iobiKhObE/xZUvyjIcWQFTvedMmer1Q6ukPfjtNVPzP8VK4Jgej0+/bJAT+nzGGs4SmO/30y3FEwjteL9vtPT7g5VOLbDMa0CX4B6+1FCeL4XsrbluvdBMR19gbzXkDcdleffaHrfKIVPbah+n6X7bKT2syBoaYXeETnoCow3L64/NcXyf7zzSU6hYrARW5Dw+ccEAK3OGciOZDsS+n+G66+ujdTf3n2/nb1dEdMYda281ZEsppNQYb5zZjHRzgS+wrxZyxYty/N5ZfYQ6vvY/FSTyBSzJGN52SoFiY/59AQLUQ3fewK+eXDikJTOZWAkszxn+/KIBBjOGaqDz/lxzjTI+yFUCZUs5ZFcl7CrfVwd9ADrt4uE63rZSyPZSSD1QfOjadMIeMFqznLs8zfvP7gVmFucfe9OvOjbHKQM+pamm7p4JU3guA4zVLL92coGBjGEmRzmPTwd8PvrSfgxKGFs3XfDu5qL4uJTsO8uWraWQasP1cVF1SV2mUzp0PMi8+QD2V+KOZsTFmz9fCtlVtQQ6PgJ1wXtFcSN3JVBW5Q3XntdPyohzcs6ivXwjvO/MvqZCONjzzuT6rX8+2HMVG5YLV6d54/H5iXEb0yRWAmuXpPj9s/soNmwzPmgxl3hOv6dm+XkxiI5mG/f6z+SanaIrpgCttDYiwL6a5flSwL6anRB33slGmQpWXQzDh87rZ0nGHNBDPrVrjS8TlgNLLiXR9eeAA9zEE9hZCZtBSzOtS6wEXnV0ljeflGdfNewa87ddxG0Tv/+RuuX5Usju6nifnY0gH1YKYDJxB9pVdUFEo3Xb/D3MjyLwxJn+717bwxlLUlN2kO2P+LvDNctH/3sfv/ejvW6+3N4qTxmrbpffnTtqvP17u/j6k6XmtGamezni1Y53r+3hrGUpN8VZREogVt7FhrK1FLKzYmmEbk2/2x9zTuMAZlLi2AEfdwruzrJlSzFktGZB3Tw8/txc2Hcebn586eoMv3RiflYOnXjkv29nld+6eTvfeKpEISVTXzufKYe4rrVQ8AzlQPnju/Yy9ONd7kixSJCnSxznkTLCNS/pJ+tBGIdGLuBicH2zWHdRfNtLIbUgmufT5j7ZITqkAALa3dpKHDap1EPLzkrIllLAaD0EFE/GP9epNy64U3l6UvC7Z/WizEzDKzSnDJsfHeY939/K9nLAYNZE5nane8Whr21RfAODOcO3ninyzu88zxP7as1ozukSK49jejzesabAaD3E71bv7kH6IFEfFNyR7FtKAdvLAdUgCuGVTvXBzngBO6IA2i/+k7q9uA5Vs8qOio3WVS3KuDk2G/E4EEZgrG75jdMKrM57M5r3KzSX1T5zzy7+5M6dZFMe2ZTXHF2lSwxHBUIVBnMpniuGvPu7z3PfjjKeyIyUQOzcfNMJec5aluqKJc+pED9pbOmNNdyS3rZySDV0y5vTCeCaUZ/vEF3vAzgQyviKQT2MFEHROQubsfdt7FwGKDcspy9N8aYT8lMK8d1fnWPh/+Pbt/PPD+5jaT6DGA+LgJjxSs9VhMgBbiNRfUSEEKEn41NHeO/3t3Drc2MzVgIAvgjvOaPXbXjp8iPK4jBnVRipucFmezlsxjWIdF5IO0lnFECnTYBJRaIHaVi37fjnxYDdFUu9RTvD7F6SAA2rvOO0HvwZCqdVV59P/WQXmx8bZUkhgxUPFYNEvUmaM+Z5pPl8sRIwhBgyfgo8n6Efbef+nRU8mX6Sl3gqcMbSNJcdlWW03l1RgvHjxP2mobC36vrUzoqlHjlo5zyeIebW9j7vgrUA9kesrUONlg+LbpdVqeFacPKOvKligLFGyEWr0lx4kE0xByNUxRPhXx7cw+ce3MeKngwWDzESCb8ZN/27QSAkUkVRTLMYwYoh4/vg+fyfW7bw1HCtuatxWpfG9em3n9ZDISWEXZIqKu4/bjlW2VEOeX4sYE8Ui9Juq7Ib6KACmEv1OF5anYXgHDVbSwFbigH7aiGBun8z03IaWgTlV06ZWVKWWPj/8/kin753D0sKaUIx48OMxKKv0xxaZso0TCs0SlXjrBRrhEzKo2KFa364lWK0LDud2sTJUY/p8bn86CxjjbDpxJ3rvgLOcWdECVUZqTvn8tZiEPmVxp1+85u7IubWabT0oelISjCY/eE1baFFY1dDpVxW9hpLISX0pAw5TzCG8YhLWgbfaJgyUWTcWcvSnLksPe24eFXwRNhWbPCx23eQS6dAvOZ8XzGICuqG24NLko4vL81K/KeqPyT+n2sZFTdehAqFTIonRmr82V072HjJ6qaSm1Y9gDcen+dbz5YJrVPdHaHFKxy/Y5Fxa7HSUIoNpdRwIz2Mh3QrzK6xZ4ni3len8i0uqinAC5g0mPnRyDNaU7YWQ54vhuypWGpRjHrrFCFWXqJKYJU3Hp93wTDTroKiCh+7fQf76pDx/UiQWs3+qMy3wpxMsz4StaGrp4ghVMOSfIZvPjnGDY+PTNsfEFsBJ/anOH9Fxq0IdOARoOVdMm7GN0Jlb8WyZSxkazFkJHYewwv3YSxiFrcCmET8LmPLu26VvVUXWLSlFLKvZqlbbY4OBqiEyrG9PhetyqJMb/R3UX7C9U8Mc/u2Cv3ZNKGIm1ebFuFfCPPK5uqEGfcJYOjNpfnMfXvYVQ6cATMNgYk/etVx+WmYJdO79gShVxemu60U8vOiC9Wthe59TxjxDyMOKwUwmbhzAFQDZXfFOQ63lkKGa5bQKrXQ8oqjsmSjQzCmKqvxVGFPJeAf7t9LbzaFihs9F5zwx8S+CjGuGCHt++ypKX933+5IgKYuQvHa+XkrMhzX51NtUy6EWIGLuKQzsdA/Pxaws2wnOoUXUvt3gI75AGZ9es0c0Rwp4hFAodxQSnXYK4pBuXR11n1mGte1KB7CFx/ex46KZWk+RUh0UGLT2TDNyfyEk4Gm8b2JF2l5NzO7iGg8XxdClP5siu8+U+SXTq1yypLslFdJBGclpT3h4lUZPv+zIjkjU4p5a615/O4EwaLUAqgElnKg1EIlsOOfadZrln6UOaWDctRV24HntbToKwFSAqWG5dhen5MG09My/21k+m8rNfj6E2P0ZZzwO6df09/fNr/wdJn1vaNh0/0UxBjq1vDPP9077brETfqyI3KkDYQc2NfeupU2NtuNOAdZqaHsqji/zvPFgF0VN9LHyqjVtxPrz4VUOkXnLIAFjgjUQuVVx+Sa3uKpBqwoikH46mMjDNeVJYU40i8K9FkkdqcgqLity71Znx9vrfD4vhonDU49ViL+zGlLUhzX5/PMmCXrjyfFbrpIW64VKtQCpRoqlUCpR6O8tnw2zkOYcHAOax/AwbCqZD249MjstL6nuGW/sXrId58p0pf1kchpJpNG/wVNa8iyCJ4xVELhq4+PADAdX0CoLhnK2csz7kwBnGKI5+ihusCcfbVoLl8M2FIK2R2N8oFOnPe7+ydMhQ76AFiwb0Fwc8cj8x5rl2SAaZj/VvGM8K2nivz39jqr+7P4oZJJCSkDxsgErds6nY9HsAPS+sF2zAFmjbhU1hisWnrSPj/8eZnfPjOkP+Md+nkmcfayDF9+rEQ9tFRCqFlnhTVCJ+TNKVo8n48fQ8cfa1GidCwlWMcUgKLTGgW6CQNUgpC1S3PkUzKt0F+JhqBvPjVGTWU8k1FN8Y3iGyHjOcdXyjil4Ik0z4WDcZ+E+3NrG8bz49m17cRZ9myYaNH4nmFHucFd28pcfmwvdorBQfEnThpIUay7NHDuutJi/st+0sItzP41XRQl7JAGSHwA+0HEBf+csdSN/m4Tz6E7suIUxfZSwF3bq/RkPETGO25DlXqglIP4Ps5s9UXwjUuYkfLcT0+cYmjdzAQToodnxUxEZ/ItBR1fyTSCh+J7hh9tKXH5sb1T3tYcP9/qHp+VeY9HhwPyKTMp6OpwEfe5JVEAk4lMct/A2qVpYHxUPxSx+X/X9jK7qpbBvB914niRatx8jW6FVZfXoBrGv5noyPIi5eAZwUdJeW6ZshrMTBxaPegSe9im8/0WD7rVqFglUMVapRwKtz5fodSwFFJmytOA2Ml6ymCKn+6tU0jcU3NCZxRAAKRYmJMydZtCen3hpIEUMP1YnTu3VlBt2dobS8EB5qrSUpr/ri6IJVClGv9W3caVWiPknp016qGSnuLSRDyteHqkwbZiSH9WsNgXmBKKW1aLqxyqs4CI/jz+79rc7+F+KqgFVXYVGzyyp8a5q3JTzpug6jx5pw2mCcPS+J6ohI62Q2IBTEIkPhTDY2Xeb/5uKpjIlv3p7hopb7IJe2j2pxgmBwsKQj5leHqkwb07q7x09dSETFURI9z4VImtpZCaGkI9+FziQKO3MP4PE6waETwMIxYe2FXl3FW5pmAfitjKOq4/1ZITcWrfTZg5HVEAAW5TxUJU4ILbKLI851FISfN3hyIWluFqyNOjAWk/PvC7jev+Iqi6hBSBwqfu28e/rXZCpnLgGXdgnfPxmdE61z0+Rn/Wa/orpmPe7O99Tv6dRvX86Z6aq/LULw/AkT0+ac9FUnbHIWnzT2sb39bma3doouUSdS7EIiihWpZlXeeb6g632Gsf5x3wTfzi2l9HC/RnDDc9XeQz9+3Fjw4lCaw2c/jHpnks/NXA8p7vb2esYaO6Tf+/g9fLPaui+J7wzEgDYErOUxhXFEuzhpwfTzuSMrF9208SB9CKAuKOc1qW9Zq/mupXAbaWGlQDyKSmny5rOjeyKvRnfIb+ayflesj7zluG37pcEK+Vi/DsSJ33/mAbt2+tMpBLYy0z8wAesm7ueikRdpTDafkoYj3Rn/bI+4bhurrTltpbw4VJBxsh8QFMIGppVQqpaRpH0Xx1uGqbB4R27sXFFxd6Mz4fu2MX33tmjLecNsD5R+RZWUjRsMpTwzW++/QYX3xkhN01ZSCbJqRlVaMDFrbifCHFhqUcWNLe9AKC0p6Q8dxUJ6HzJApgEvGe9uX5yAKYoiMq7q47ysGEpb+2S1lcQYnj5Q1LCmnu3VXnjm1b6U8b+tOGQF2ug2oIvdkUfdl4N2IH6tSC4pYuiw3LSNUykPGm5MuL/7mQEvrThi2lcEGcDr3Q6WAk4MJ8eXG9Z2q+11tc/wodkrVWU18IrCGfSVFI+4Q2ZE/dxdBl0ynyxmAxBJHwNx1rHfKux1cNrAt8mgkTPA7TMR8WKZ2Uo8M+H8AEmlEuM6+7y3Xfcq1O0ayfCyNuKizjEc9eFGnmIGjKUCxQnXg3Oh6i3KJqZnSdCft2D3c6mBQwmQIcgJmeWDNnS1fN/FtOuqX593GJkReM9p2u24RQphnLbmf9JwmtJArgBbilwLH69DRu3PWX57y5m7tO3vu6X8mRF36+k1XCpUHvSTlfxHRvW4/2+Lu07TBusiR0gs75ABbgDMBN/l2991XHXXnTYSBjWqN+O98GrWF5BxQWmTw4dwYd37+f9820VlLimlcCy1jNYkSwNjEEwPWhDmUFTyyAyVjc2vlILdp+OdXhK/rc6kKKtBEXFg+dH7wmSMhBbjaHkhSEytKsRz5SAFOKpIyUR6lhqQTOiRl7Ew57FmYcwEJcB3B19g3sqrg9u1Mdw+Juurrg0ZsW6mpdBuDDCucBCaxyZK/rWtM9Rm1vNaTcCEn5CzWYvBN0rh0Otx56SBS3FXhnOaQRnREwFeJOvqrH54ieFLXoYNLDDRGnANa25FKYCvGntpfGj9xO6DzJduBWIr+FL8LuSsDuSsjqgtvTPxVNGUb5AE5dkuanu2sUUt7Ca4PZoKDWncB0xjKnAKaaFCQOuHp2tEFgXVJV21yy7FyVFwQdfP6OWAALdyuQ8wF4RthXtTw7Ugem7siLP/bSVdnmsq3q/B4pOZcFoG4tS7MeZy6PcilOsYfFauJne2pE0RRJmdS2nSCZAkzAdUMjQi1UHtzttrRONS493vl2weochZTpmmOv5woRd8LSqUvTrCr4zrE3xe/GbffInhopIx3zeidMJHECthKZm/FO9Ad3V5u/ngrxUVdrlmZYuyzNA7vr+8ltt0hRMEaph5ZXvagAuHgAf4r7KERguBby1EidjJ9sBppI59qiw6HAHbt651BX9Ywn3L+j6rLtTMMjFUb77y8/Js+d26r0pExntgV3G6oEodKbEl59rFMAU80FEGc0emh3lR2lgN5s6vBos6midCwQIJkC7AcFsr7hieE6T0d+gKl2yLjTv/7EXrcrzy5QRThNPBFKDcsFq3OcPJie1vJfPNrfubUSrZ4kSwBzRXI24H5K0xFYs/x4S8n9bsp+AKcsTlmSZt3RecbqFmPm/5k6XqJU6r+2th+Yut8EaJ4d8MPnS81cihptJ5r35+qS0ikSC+CAuOOuvvN0sZlZZ6rEL+xdZw5Ev+jkK5x/DFCuW85YluG1xxZQnfq0yaqb/z83WufeHVXyKY8wbq7EEOg4nVMA860yZ6xqBdStQRdShtu3lNlRajQdfFPBi6yAi4/I8cqjc4zWQryF3CaHKAalGlh+58wB0p5M2VqCccvqu08X2V0OScUNnZRJ/bIzdEgBBMx/i82uKC6f3Y5ywM1PFwGmtaynuOnA7523xF1PWw+3XjzFoIzVQ85ZkWH9Kb1u7j8Np2lsWd345ChpXzh8oiamWzpzNFgyBTgICqSM4SuPDgPTmwbER4pfsDrHW07tY181xF+EKa4EpxiHLnJJSZWpW+6x+f+zPVXu2FqmkPYmpVNL6DSdcwLq/OvMmRfXkUOFQsbjR1vK3L+zEm11nboIx4l3PnThUlYVPCqBbUa2Lobii9s09ZbT+rjs6Dyh6pROAYpRdfEW//7QPkbqimdMs+01mQlMKB06HLhDCmChzwDA9UAETwzVAD73wN5pH1dlxK0orMj7/NmlKyjXrWvw+X6+NhQDFOuWUwZTfOTiZc70n8aorbipwr5qyHWPjtKb9l268i54tq4sHdIAyRTgEIQKfRmfrz06wtaxBsZML9+/J85EvvrEHt5z9gA7SwHTzTjebQigVlFV/u4XVrIkOkNhOsv31rrR/z8e3sfTIw2y0UGiifk/t3SwK863ypxtGX+OlC/srob8w327I7N+GhoAN9KFVrn2omVcfmyO3eUGKTPfzzfzYkTZXQn4k0uXcf7qHKGd3vZdxeUwrASWf7p/Dz0Zb3znHwoy/8/YfaUzdNYHsJBLM+emEFqhL5vi/92/l2eG6y5d1TTeieA6fNoT/vnVqzlzRYbhSuQUjK8z3897kBK/T3Dz/t3lgGvOX8JvnjHQ3AI9HWykMP7pvj08vKdGLhUpAI26exc8c7eVTrHAjdEO0tLxFbcasKdq+eSdO6KEvNN7K3GE4LKcx5evOJIje32Gq27dO75HtxI/qgdsKwa8/fR+PnjhMuf0m67wq1tN2VMO+NTdu+jJ+NjolGJNzP85J1EAByM+RUeEEFiST/HvD+3jji0lPCPTWhEApwRChaN6fW5601GcvizD7nLggl+6GCOuo+woB/z+eYP8zStXRmb/9Out6rIsffzH23m+GJD1/a5WfoudRAFMGXE5/sTw/lu2uE0+TH/kjuMDjulN8bWrj+SyY3LsKDXwZOZnEXQS3wj1UBmphXzskmV85JLloM6vMd3qxhbDnVtK/L8H9jKYS7uw3xZFmzC3dDAUuAsmTm2bALsfVqE343Pn1jJ/89878URmlPQjDhVenvf42tVH8t5zBthXCagHFj8OHpjnIii+wL5Kg94UfPGK1fyfc5c4q0emb6jHrVQPlf/7/eeheU5hdzxv15cO0REFsNDDAPZf4uAgYSCX5uM/3sE928v4M5gKwLhPwDPCn1y6gs+/djV9aWF3OXAm9zwFwoCrUyNUdpUarDs6z/fWH8OVJ/Q4h59Mf+QHmt/92I+2cde2Cj3Rnn+N5v4qM9v5FyNRmxlx9W8t8e9bDYz570/TKwsrEGix0TxO23VUzxgCFX7rxmcZrYUuh/30dUDT5A8V3nRyLz9884v41bV9jNVCRmsWT8a3ynYaEWfuW4Vd5YDetOFvXrmSG95wFMf2pwh1eolRWgmiJCk3PTHMn9+5k6WFNKHO3ORvFXKAQKESKKN1y3DNsrsSTijDNctI3VJuKA3rdht4xj2vmYE1s5hIDgaZMtL8YVXoyfg8vKfGe7/7HJ+76jiCGY6OwrhfYHWPz2cvX8VbTuvjL+/exw+eK2ERetMmEk5ta6Yct83ZLVFWA8u+esjSrOF9Lxnkd84e5Ige56BTZVohvq1YdcL/zHCN3/n2z8mlfRDjhH+Kc/+4nu4kZKXUUGqhC6vOp4TBjMfSnMfynEchbVgZHe0es7sSUqxHiqEasrcSMlJziiBtXPIX54h17dvGJu56OpgSjMXXks3nEQI1LM2n+eKDw6xdtp3fu3AVDasz9uh7UUyABS49Ks+lR+X5wXNl/vH+YW55rsyuSkjON+RSgheby6puijjFe8SnBJvo+41QGWtYAqsc2+fz2y/u59dPH+D4gRTglJI3C9+cVZcWvNywvO2Gp9lTtfRl081lP5o/9/99Z7oLDevOagwtDGYNZy/P8JJVWc5cnmHtsgxH9foMZpySPFR9hmshW4oBj+ypc/+uGj/ZXuVne+vsLocg0JMyzS3NXZOWrINzgCQp6HSId/JIvAtOWNaTYui2rRzTn2LDmqVNc3dGlxe31h7vknvFMXlecUyeB3fXuP7xMW5+tsxDu2uUGhZjhIwnpOJ5LvsXVI3+Z1VphM4JV4/CcFfkPdYdneeK43u44vgeluTcyBmqy8s/01EfiBSTWyp85zef5q6tFZb1ZAhanX8H6B9G3JHmlYalHChLsh6vPa7A647v4eIjc5wYKaj939Mpxlbi+xmBJVmPJVmPM5Zl2HBKLwDPjTa4c1uVm54qcuvPy+woB2Q9oRCFJ08nv0Fn6JwG6NzhoCw68W9B4vA+FENvLsVv3fgsOd9w1cmDs7IEYKJvQIDTl2U4fVmGay6E+3dWuWNrhbu2VXhkb50txYCxekg93L/5KuIOOsn6wmDGcFx/mhcvz3LBEVleujrH0b3jwhSqO5Nvtn4HjRSOZ4R33fg01z06wrKeDA0VxIjbZxVXblJdPXGbjGqhctrSNL90Si9vOKmXkwbTEz4bRnMTiaddMm7hHMhkiZVhq5IwRjimL8UxfSnWn9LL82MNbniyyBcfGeW+nTU8A71NRTCrZpkxnbxt4gOYLtKMEY7+bDAepHzlHd98hq+v97no6N5ZWQIx8QhsdXwufdaKLGetyPLbZw0SWmVrKWBr0ZXRmmVXJUAQLEraCCsLPoMZj9U9Pkf0+CzLTZwfW3XCYGT2gg/jo7BnhA/e8jz/fP9eVvZmCdQgxozP+yd5S3zj9gaUG8o5K7O8+6wBXn9iT/OE4bieIs5x50UKeDo0FQUTvxsrTgGO6k3xP88a5J0vHuCmp0p85r59/NeWCmkjFNLurIfFNLAlR4PNiBYlAFg1pHyfRgPesOkJ/vHKY/nFUwbbogRgfC7s7uWUgYgz/Y/uTU0YxQ+F4mLx3XWl6VxrB3EmYAH+v289wz/eu4eVPRkCjc3+aN4PzelU3Dy7yyHH96f4P5cu4VfX9jUtqNCOC32nAoVaX1FsvaSMcPWJPVx9Yg/XPTbGJ+7cywO7qgxmvabTds7o4L2SZcCZ0uLBFhEshpTvYcXj177+FF9+cE8zRqCdU0gTLdd5ke/MquuMoXVZefdXQo1H0GjVIfIbtFOe4h2B9VB5xw1P8dmf7I7m/AYRLzojbHw5FeJRXyk3lPecPcBtv3wMbz+jn5QRwhZLYi4jJCVaYlRo1uFNJ/dy65uPYegil/dgrNEexd4NdGgK0BoKtFiRFqegm4c6S8CZp2//xtM8O1LlDy4+EojCYNs8gk0YFOcxjDa2dLaN1Xn7DU/xg2eLrOrP0lCJlvxaPhz92TewpxJw8pI0f/WKlaw7Og+MH7A6GwdkO4iXZ8EpgnxK+MAFS3nN8QX+9/d3cue2CsvyHtY6Z2dnTzHtnBwl5wLMuMTpK8dTWGGEEAHP0J9P88FbtvK2rz/BSDXAi9awF5NKtJFl4Rvhv54b5ZX/+gi3PVdieU+Guh0X/mZ6r6YBoOwqB7zx5F6+v+EY1h2db7bNTIONOklsbQVWOXtFlm+vP4p3nTXA3kqIRaOVzM6mM+0USVrwdrwZjee2bsOQ4mExLO/N8h8P7eOyLzzMXVuK+NEGmpmEDncTsTDEIbZ/dcc2rvjSY2wrWgbzaRqxwy929kVtYwBVGK5Yhi5azr9dcQRLc+4cgLhtuhWBaEoHOd/w169YyadeuZJqwy2vdjzte4dIfADtQFr+EPkERDwChKU9WZ4cDnjtv/+MT/xoC41Qm5uIuibQZBqEUQyBb4TH91Z50388yh987+dkUimyGd/N+WPhl/inm8cHFmqh8o+vWc0HLljq5tg68yjD+SC2BkIL73jxAJuvPpK0gWo4vYSo3UKiANrF5NDWphIwFLJpfD/FB2/dwiu+8BC3PTPadG6Ftr1Owk4RRpFxXrQ9+C9v38a6zz3Et54cY1lPDvGcA1SMFz1/1LUkfk7nIPzca1fz1jV9Uej0wtwB7Byp0LDK5ccW+MrrjyLjyYJUAokPoCMl2t0WCUKAAWNY3pPlvp01rvrSz3jXN57ksd2VpjfeCVh3aQI30kVz80iQb3h0L6/8wkP8/veeo66GgUKGBoJGuRKazx/9dFMeN/J/4XWref1JvTTatDw636SM8+tceESO6yIlUAtjn0A7i3bsiPkOHw/eXR16TlGIVwqcf9ijYUMK2RRYj8/dt4cbHt3Hb5y1nHe+ZCXHDWbd19StQ8fhsPOBjZYuW3fc3fL0CH99xza+8+QIvuexvDdLqBKt8bcs8RH1foF48jpSDfnn1x7B1ZHwz0UGpGbXEzrqW/BblMC/X3kEr//q886yoX1Td1XF5UxvP0kkYKeYEDEYdULPc0E4IizrzdIIQj55+3Y+f98u3nDqEt529nJeemRvc7nQTlIGnerIyrjQuy2y7mbFesiNj+3j/92zgx//vIjFjfiKIUDAmChLEoxH941X1DfCrnLAhy9ZzlvW9HdU+JXxAKfJMQ6tVkwnlKpv3Ialy44p8OnLV/HOb29lSc6fUbKYuSZRAJ1kkhIAQYyCCoFajEdTEfzTvbv4t5/u5uKje3jTmqW86oQBju7PTMi7F3dkJ58zUwpKbJy5a8XRgF50MVX4ybYi1z+yh+sf3ceje6qkPI+eXAYxJtrHb1xkX6vfI37eCN8IeyoB60/t4/0XLGtbVOT+aMYOtFx/uBKgCv1Zb8LvZ5LFeCrE04FfXdvPg7tr/MV/72Fl3qfR5Uog2Q7cSeJInbgdJpilHm5bsWI8YUmPh7WW254t8b2nRlmR97nw6F5ec+IAl7yojxOXZvfbcePRGz1wc7tqjCe/kAkRRDBaC3lge4kfPD3Cd58Y5sGdZcqBkk/7LClkUTHYaHSfGM8PbksvLX93S4PlhuWkwQyf/oVVqEY7/GbRlAciFuiGVa6/bxfXP7CLB7YU2VlsoCjL8ilOW1XgitOX8qZzVtKb8TqmBLzo/IePXLKcu7dVuHNbhb60IZyt9d5BOeqIAghw66KHu/xPbIBm2KArokAUKKNOESBCb85DUCpByDceH+HrP9vHQNZwwmCWs1blOXNVgTNW5jl2MMvyfIqMb5qj91QYq4VsK9Z5bHeF+7aXeGB7iQd2lHl+tEE1VLIpj3w6TS7rhN5tLYqDeiR6pP2P+vHzKhCEyt+9ahWDWa+ZV6DdxElGb3xwNx/42hP89Odj7h98g0RxBTtG6jz08zG+ctd2PnLT03zoyuN52/mrJxpmbSJWtGkDn331ai75t2doWOdp71ZZSPIBzCVxb4s9VC3xAxIlyAjVDRee7zHgO2UQhCEP7a5yz/Yy1u4k6wsDWZ9leZ8VhRQrCin6sh7L8il60l6LEw52lhqU6iE7Sw12lRrsLDXYUw4Yq1sCBd8YsimPQi5NrwgWV4I4niFe1mTSSN/848R3HM/7f/e8pVxyVL5jpn88in/028/wwa8/ASLkC6nxKU5TVQmS8RDgqb1Vfv2fHuTuZ0f56/Und8QycfEOykmDaT540TJ+9wfbWZ73m1mkZ0bn5CjxAcwHzWy48d/Hf4p6rgeLRhGDCp4h7/kU0GjPgaUSKk+PBDy2r+6CiiL/QHzibnzp2KHnieAbg+8ZUp7PQMHN4xXBghP8SBgkTtnVWtf9jfj7eaxKYDl+IM0HLnAbZzqR0zAW/j/93rN88D8eJdefgUjwJqPQVLjZlIfJeHz6pmdAhE+tP7kj04H4zIh3nT3Il382wv07qxRSpisDv5LtwPPKZPM5El1xP6X5Dzo+10dBDJ6neB5kiZ2CB29sZfwEIgXClnn8xJGeiSO9ThL8g9zGE6FUD7nmlcuc6W8V02bhigX2tsf38f7rHifXn8Gi6BTm2VYVG0JhSYZPf+cZLji2j7eet6rtSiC+UsoIH75kBVd95TnXvjNdFleS04EXN63e9LjEiTNNs4jxEPGi7bUeKi76LsQQ4B20hBisuO+I8d11jIki91yg0rhXvyWOX+Sgo36MEZfJ59yVOd66pt/lBuiA6S/ilkd//+tPNufx05Wr0IKX8bnmhicp1kKMmVlW54Phicsr+IoXFXj1cT0MV8OujBJMIgG7qQjNCMJmvvwoyq75O2NciYXWGDDepHLw3zev03pdWu/XWoep1V1EqISW/3XekmYG43b39/g4sh8+sY+7nhwmO8O1dqtKJm14bnuZr963s2MbtOIWeN9Ll7pzIJh53+gUHVIAi/NokDkvrQbBZHFqrsOzn3KgfzvQiD7ps9OspxGl3AhZuzTD1Sf1NqMI200sCNffvwsCnXXnFRGuf2B39OdZXmw/xCdAXXxUnkuOyjNWD/FmfPR5Z0jiABYUB+ilU23n/SmS6V5jP5ho7v/Wtf3kfOM8/x2QqFinPLC1BP6hvB4HxyqoLzyyvdSxuAB3H9cWb3/xAD94tjgzX0AH5SjxASx4ZOLIfrDSoWDihlWW5jzWn9oPwExODZ4K8XV3jtVhlvN2xTko95YbjFadh60TW1fiVZDXndDL8f1pqoHtqh2QiQJImBVxGu9Ljy5wbH+qmRi0E3TSoNRJP9uFiPNd9KYNrzuhl2Ldztlxb1MhcQImZVaFKNXZVSe5QzbataU5TnLa6uPrlNhMdpWoupiC9qUAd9OVq07qxYvOX5xuO3fqcNBkO3DCrGiEytKsx6VHF4DZm/9x8tTWObnSOeGPr9/8qTQPU2nWaZY+gngPxnmrc7yoL8WOUkDKm4Z4aOdUQBIJmDBj3Nq/cu7qDC/qd2G4szH/WwXt+z/by00P7uGBrUW2j9UnfO6ZPVVSvpmVtaEKnieMVkMu+Yu7JyiupYUUa1flefWapbx27TJSnsxKCcSxC71pw9krs3z10VEGPdOxUX06JAogYcYYEephyEtX5xCYVdx/fJTY9x7dy4dueJLbnxyJInbMC7RKyjdtcaTFdX54a2lyZbjtoT185pbnOeOoHj54xfGsP2dF01KYya3jvA4XHpln889Gor0f828hJ2cDJsyY+B2fvSo3q+vEo+snbn6WD3z1CVSVbM5v7qKbLCftTJ0mQDbdmtFoPIRCgZ9uK7Hhs/fzu68+lk++8SR3jNoMMhjHB5SetTLbPH14yk/RQUFK4gASZkxolbxvWLPMpTOTGQzLsfB/7DvP8EdffpRsf6bpOe9UHrzJ2HjyH9Pyx2zGbSD6y28+RbkR8tk3nzqj6UDsbT9pSZrBrEeloVOfLnXQC9jBZcBE+hczIm7P/9Kc1zybcLqdKRakbz+8hz/66hPk+jMo2lWptGy0GlEYzPL333uOf/rx1mbij+kQ68aVeZ/VBZ9GOA0FAGBMRxqlIwpAXc4o5n+RKimdKoITjGV5w5LoxOHpGgBGhHpged9XH0ciV3kXTIv3S2gtftbnA9c/wZ5Sw50fOM26xmnVV/f4NKxl6jstFKx6B7rubGivAngIBRDMsDbqcT/p7JlJSZmXIuoiAJfnUpgZCG5gXfrsbz64m0eeGyMbbR/uVqxCOm3YvafKv9y5DZj+BqLYd7GqkIoOWJGptLVgQ7DhPgDWrmtrI3XEApBUelTDAEVmvPUhKd1fQoWetOtC0+2VsbHwlXt3tSYY62pUQXzD1+7fBcx8ybM3Y6YRDKSi1hKKGZn9E7yQjiiA0NgKUEXM9HtGwoJARLBWWVFwfuTpeuZjE/rBrUXU785sOZOxqohveGxnmeFKgJGZ7UdYVfCnKhaKIoQBnqEIwObp3+9gtFcBXOueK91b2quqI5gkNWjCC4mFZqQasKtUdwk5FkA/iYOHhisBu6LgpI7X2xjRoB6ExtsJwJr23rC9CiDyAu34tbNKqO52h0RGJ04kZfGWGTLLr88bqrMc1qbartaCeAD7PDOyF2gOsu2i3VMAZUgNgCBbEY8FodoTZsxMpsHxakFfzmNJPoWNHWJdThyf0J/zWFpwS58zqfeUvyGoGA9Fd+197wWjzUq0kQ74AG41AFZ4XI2PiqjCvDusktLe4k44E3ZVAmD6QUDxpp/TVhWQYJpr4vOEIGigHLc0z9JCCtWZyeOOsmuzQ7azour5KDwNwPpNbZ9Td0ABrANARB7dX974hMWDERiru3i96cpBbPpf/eJl6AKZBxgD2gi54vSlwMzzCI7WphjjKKIYDxHzKABr1rddTbZfAax1Eq9B8BAuFsC0dehJSlcUVcUX2FUKUaa/JOZFCUffeNYKjlmVp1a3Hcsk1A5EIAiUnr40b7/wCGD6W5/jz+8oBe75p5Il1Cqq+lN3hVvb8CST6tT2Kz50rQLUST+itXLFHSYXu02SsliKovgGdpcbDM8gpZaIC7PtyXj88S+eQFgL8Lo4P1XKM9RLDa55zXEcNZCJMhRP7xpxwNS2YoOUUfRQeYLVetRLaFh7EIBr17V9e0T7m3zjRgWVyh+ctlXRxySVZnpdI2EhoOqOAdtdDnh+tOF+N81rxDH1bz1vFe959bGU9tbwPekqS0DECX9xb5XXn7+K97/qRTM68CSWgF3lgK1jDVKeHHyzk6rip8UGwY5CWR+OfzuTZzgYndC5ytCtHoDF3K5eBkXs/I9ZSWl38YxQqlse3l0FZrZN10THaP31/ziJ97zuWMpjDaqNED867tvsL7dpm5l8fSPu2XxPaIRKaaTGhouP4N9+fS2qMztP0Eay+/jeGrvLAb6RQ9nFllQGhXu2bTy3zJCaKLC2rXTU6BINf4hasDqtfQ9JWThFLdy7rcJMEWKBEj614RQ+/5unc/ySLOVig0qpQbVuaQQ6obRbChphy/VDpdqwVMoB5bEGK/Ip/uItp/Ifv3kGhbTXPF5husS68f4dFeoNxRxqHwAo4gP6w+gSHZHVDuUDcHMVr177kZWxGsbLoFZZGCHfCVNEFXxfuHNrGZj5QaDxcQWhVd52/mreeNYKrrtnBzc+uIdHtpfYXW5M+PxoJWzbST4isKyQGhdqhYGcz0kr8rz6tCVsOHclK3rSbtmTmVsg8TLpj58vuwj5Q1Vf8aiXwYY/AGDt5nbrPVevTlwUgCE1bBTb96c/vc1kcpdqtRwidGRLY8L84AJjIOcL977zFI7onfnaeMzkZBvWKiPVidkwLv6Lu3lka4ls2ptxdiARaATKsp4Ud/zf8xjI+VHdlZ6MT6rlIL/ZJgWNR75KYDnnHx/j2ZE6Gf+g+wis+BmjjeqTI2VvDRtPrzOepKitdHIK4AKC4Eb1UqhoEhC0yIpVSHnCrlLAf/68iDL7M/biTUJxWm5jhMG8P6G089Sh2AIYzPssKfgM5lPOQacu34Hq7I85i5XUPdsrPLWvRsY/VGpwtZrKYpHvsvH0OkO3+HRA+KGzCsA5ORuNb2qlGKLikeQGWHQllvcbHh2dlYncighNJ6DCC8PkZ3+LCTRCbYbex9c3IvhG2vI8cRt949FR6sEU5v+KIagjyteAtucAaKVzCmCjWIbUFP/wnIcJgzskkwedyinuCQsJa5V82nDz02NsKzZcgEsbu2usVFpL26Vh8kpDGy+tOGVWDSzXPzZCJmUOYSWpxc8YWys/PTpYvxUQNkjH5KbDoRduX4CI/AvGTxyAixAFMp5h11jAdY+4nBWdOGobaIYML82nIMooNFMEQVXpy/r0ZWaW0mwqxFmOvvvUGI/urpJPmUMpSCvpHIj5Mu86t8HQLR3dU99ZBXDtOue9sWy2ldF9eL7n3mIX2K5JaVNxc9x0Svj8/XtpWO3Y2XdhJAZrV+eRUGc1UosAgXLyijx+NOfvBHFQ0z/esyfaGhPfZz9tqaognlaLAWH4efe59kf/TahfJy+OiLJJvZEPvHiftfZLZApoNEAkZbEU56zLpwz3bC3x7SdGXdx8B1L8xAJ/xenL0FkmmxJAQ8vr1rqNPZ3ISBSqs1Lu3V7he0+N0ZMxkWPxACkyICRTwIaN74xdc9ZjrN/ksbFz5j/MxenAcaJQCT+t1VIIJGmCFiPqovo+ebtLXNOJcN54heDy05Zy2tG91GrhjDz0IlAPLMuX5vill6x01+6Q1SLAn92+g2owlVOB1aBWVOQvAVi/viN1aqXzCmCjWNZv8orvf8kjBPVvSrZXSJyBi45Qld6Mx38+W+RrPxvBCB3J8mtVSXvCx646AduwM5oG+MYQlAP+6LXHsjTO0Ntm+Y/zHfz31jJffWSEvqx3KKsolHRebKV4T6n84lsYGjJskI4fHzg3+68iRRZ65sPaqCoiSWjwIixqlZRn+OAt2yg3LLR5RQDGNxC94czl/O5rj6W8r0bKm9pynQikPUNpX5X1F63mf607etZBPgckeu4PfH+rOwTkYEt/AKogniDmw2wUy9pr58RpPjcKYMOGkPWbvPIfnHmP1mvfkEyvQbUbDkdNaCNWoZAyPLS9zF/csRNPOrMiYCIl8Mk3nMS7Xv0iSqN1GoHiey52oHUpz23ucRt7QgvFkRpvuGA1n//VNc0DO9tNECmVf31gL99/coz+zCHOPLCEpPPGVkbvKb7/xTcwpHMy+sNcKYAmKupxjW1UAjUikTsk+W8R/RdYS0/O4+P/uZ0HdlTwo91+7UQgOqBT+ewvn8pnf30tKwopyqN1KpWAeji+074RKtVaQHm0To8vfHT9yXz1XS8mn/YQ2hPo00p8+s+2YoPfv3kLubQQqD1kuyGIGu/9iChrN8/Zkvncrs1v2uSxYUNY+OOffMYUlrxby8MBbstTwiLCE6FUDzlrVZ7//I2TSHmC6YCwKaDRKL6r2OBf79zGDQ/s4rGdFfZVGqhCf9bnhGU5XrNmCb92wREcuzTbnJZ0oj5hdET6L375Sb7x6AgDOf/gc3/VUHK9ni2P3VT6w7OvYP0mj80b5sw6nlsFMDRk4Fp6M3cNWpN7RIy3lKABc26JJHQa3xOGiw3eff4KPnPF0TSskupQ5s/J8/jhcsCuYh0LLMunWNqTOuBn20kQCf/Hf7SDa777PAOF1CEcf6oY3yISCHLG2B+seYIhpNNLf63MfXTeJvXYIGH+o/f9mlfo+4JWRgM6eUx5wrzhGWGkHPD3v3gMv/WSZR1VAqrjnvfJI3s8MhuRjmUfjoX/xsdHef2XniSfNvHa/sEqHUhhwNfSvqHiH57z4Vg2OlPD/TM/4blNJXDvd02+73KtjIYi4rXfXZQwH8T7VuPOVWtYvvHWE3j1CX0dVQIxTvA0qkv7px6TiYX/vh0V1n3uMerR3+McApP7tQCqGkom71GvPFS88Myz+MxmZdN624msPwdjfkzvh65VVMVm/XfYRnkE3xdF7byvYyWlLUVbfooovgdv3vwUP3quSMoIjQ4fBBh7/s1+rIF2Ewv/z3ZXufqLT1AOLCkThxaPt8XE9rGKMagNQivh27hM4sMV5nwMnB8FsHGjZfNmU/29M34u9eq7JZUzaJQ2LSmLqljrAm8qgXLlvz8xZ0pgLmgV/lf/6+NsGW2Q841b8jtYu1hCyfZ5Wq/+YfkDL/kJQ7f4c+n4a2X+nG8bNoQM3eKXPnjel2x55O+kMOCjGsxbfRI6hlUl4zklcNUXn+DmJ0dJGXFx8fNduRkSC/+928tN4e851Ho/gGog+X5fy/tuLP/RSz7B0C0+Gy+bt5iY+d2iqypsxvDQQ14hHfynZAov1epoiJgkddgixBOhHlqsVf72ymP4zXOWAW7tfCEcDQbjm4aMwA2PjvC2rz1Nqa7k0mYqwh9KOudpGDxttHzeWO2mfYCziOeJ+V1+E1EeQtl4ej209f8RBrUdpLKeqk3SiC/CEqiL1vN9wzu//izv/dbPqYfugI2FYA0E0WEgRuCjP9zOG7/8JJVAyaZMs/4HLmrxU2LVVrRa+x9j15y/h7VrZT6FH+bbAoiJAoSyG39yoclkv4+GGcIGIEl8wCIkdtKNlRpcdGwvf/+LL+L0FTmgs+v0MyVUbQYyPTdS53dufI5vPryPQt5HmEIuAVXF80P8tK/V8psqH3rJVyPTf96nvN3T0lGD5D581xsl03MdQSPEBmbax84mLBh8I4xWQ/oyhj96+Wree8FK0l6cMLNziUWmyuR6/PM9u/nD729h+1iDvkNF+MWoKsaEku31bXH4vZWhc/+mW4QfukkBQFMJZD9815tNtu9LNKqREuiyISGhbXhGCEKlUg049+gehi47gitP7gec6WyjAJ650gXxPaUlaOhHzxUZ+sFWfvDkKOm0IeubKSY8UUVMKLk+n+LI75U+dM6f81t3p/iHcxuH/u7c0H2CNaQ+GyXIbbz7f5t8319qvWTdMarJdGCxIjhFMFYLUYXXntTH+y5ayS8c39f8TBhF1XRqT4GNsvT4LWPNHc+X+Kvbd/DVh4dpWEtv1sdO1Veh48Jvy8N/VvngS36/m0b+mO5TAECsJbMfvuctks78O2EAYWCRRAksZuKtuaVqgBjhZS/q4e3nLOOqU/pZkhuPFrfqBNZlDJ64/fdQaPQ/ixN4kYnZgEp1y7efGOGffrKb7z01RhBY8hkPI9PY1ahWMZ5KtsfY8tjvVT90zp+3LPd1la+zOxUAtEwH7t4g6ewXUM3SqEVLhF3VhgltJk79VaqHECpHD2a44uR+rj5tgPOPLDCYe+HWEatEm8v3T6ws9jeZLNZD7tla5oZHh7n+Z8M8sbsGAvm0hzHTyWwkoBrieR5+GqrV91aGzumqOf9kulcBwLglMHTnpZItbBLPX6nVYoAkW4gPB9zJwC6nflC3YISjB9KcvTrPxUf3cM7qPKcsz7KqJzXl/QWhws5ig8f2VLlve5kfP1fk7q1lnh6uoYHipQy5lDM0p53STDUgnfNRSjTKv1750Hlf6Wbhh25XANC0BDJDdx0v2eyXTbpwnpaHA1S9ZIXg8CD2EVhVaoESBDbOvMFgzmd1b4rVvSmO6E3Rm/Y4oi/a/qvuyzuKDcZqIduKAVvH6mwda7CnHEDg0pZ5KUPWd3sHrFWmvTDvDiwIJd/va73yJLXKmysbz7+724UfFoICgObuQX73x7nc0sKnSOfeQa0ENgwRSaIGDyOkxRHozu+Demjd4dNxGqAXTAQiJ4EAnpD2hJRxAt/qAJwRai1ihHy/aK18vV8cfmfx45fuWgjCDwtFAUDztGGAzEfueYcY/y/x073USok1cBjTPDosEvKDdYJ4m/Ah9+lPCTfqk877WNsgDD5U/eBZfwI0A9tmfYs5YIEJjQqbMGyQMP3hu04xXuazks6v01oJwkZkDSywR0pYeKiGGONJthdtVO6TWv3dlY3n3sGQGq5F52Nb70xZmNLSYl5lPnrve0TMRklll2hlVAELybQgoRO48ywk22s0aJTVBn9W2/nDj/Op99YWisk/mYWpAIBWbZv9yF1Hq2Q/IsLb8FJQK7o0rIl/IKEtRGl9M3lnYYb1G0Jbu6bxofMfAiZMTxcaC1cBxLRo3uzGey/GmCE873KMh1aLziIQjCwkuyyhG1BULYJIOm8Qg4aNOzTkI/UPvfgmgG4N7pkOC18BAKgKGzabOKtK5mP3XK7q/V8Rczl+GmpFt0aLmiSkOOEQ2Kj4ZHrc4B/U70D4ZP2PzroOcCM+sFBH/VYWhwKIGVID1zYTLGQ/ct8lqvw26BskU8hrUIN6VREJE2WQMI5aEAtq8DOGVBZq5QbCtxA+U/ujs77jPiew/j/mNG9/p1lcCiBm/SaPNQ9prAgyH7nvOFXeLOibMebFpHIQVKFRAwhQlWgZMVEIhwMucMdl4FX1SGWEVBaCBoSNxxCus8q/Nz509kPN78xDyu65YHEqgJj1mzzWw/iarEp24wOXqOFqbHg5wovJFNwA0KhB2HBLPK5jCO70KXGtlMQZLCyijQHCeHpi93sPLyX4GcT4aKMCYfCYivm+GLm+1vBvYePpdcBZlA9vlsU04k/m8OjUQ0MG1pkJyzSqkvrYQ2dK2Fin6MsEXgL6IskUnKyrhTBAbQA2jFeALEic5Smh21AEUae0jRHEA89HjA/GgILWy6B2m6jep57/Q0/k1krDu6cp9OCce6yzi2GOfygODwUwjrB+k2HNcnnBmu3nns6mto6dTKinYxtngjlJsCeoslLQAYyfwU9Fsag+zb2kCfNP/C5iRe22jzcUHRYxOxR9GvRJTPp+kJ82MqnH+IPTxiZcY+gWn7W7lA3rYyV/WHA492BhSAVuNTy8Sw9o5n3ikd5svbwk1OwSo3ZAg0qPplJLCUJFwsO5/boH9RTfEwnDYfH90dDaMc+Y3bVUsJf3nzuy3+8MqRl/94eX0LeSdOAmKgzhFAJwUKWQsLBYv8ljzfKor6+zbEQPV4GfTKIADoWqcO21Atfizm1fDw/dmrRbN7J2ncJm2AyseUi59toFFZefkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJBw2PH/A262ceqOYKcuAAAAAElFTkSuQmCCaWMwOQAApQ2JUE5HDQoaCgAAAA1JSERSAAACAAAAAgAIBgAAAPR41PoAAKTMSURBVHic7L13gFxXeff/fc4t07avVs2WbNmWLMu9d2wDxsbGgAE5lEACJHECJIGEkvwg2H7fvClAEgKBkEBISGICVgglBmMbN8AN995lW71t36n33vP8/jj3zszOzkpaaafc2edjX+3szOzcM7ecpz8HEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBEARBENoaavUAhA6CmQBg/YYNClhffnrXkFxngjBXFu8GV/++YT00gHDWJq7zJ4IwJ2RiFvafsoCHioT64gvB6wC+DmCQTEqC0AyuYVZPbwCV78Pd4HVPga+7Vu5DYf8RBUCoDzOt37BB7RpaTwBw4YXQ1xHpvf3Jux/n/uwwWFFutdOV7vILBQBAEPgnKtvt48BjYpJrThBmgYiZiYiZPLB+QFmWxwQin32d9J5Kp3q09ywmNlxFwWyfcc01rO68EAowisGG9dCiFAj1kMlYMDBTZNnPJuzX38MpJNEVTE4eo5VzlO1YK/yid5jlWIdr388QqTWsmcm2+62Ei8iBSTZAqsnfRxDiDAPaq/pVM/xCblzZlmY/2AHb3sG+P0a287j2S2OJRNdjpPCiHh+d2HDxwHjtx0VKweILweuuBV933d6VeWFhIArAQmUfAv9ND3LaKXrHkuJjyVJH6lzhDFjqGJDqsZxEr3IIZAEcAKwBMBCUSuajfY8ZzNHlRQSZbARhjjCIorAbACjbUeFPkEUgMso1a4B9wMvl8gRkybaeItAj2vdfZaJHHDv1xIZzaKTm4+mCO9gSD8HCRhSAhUQo9LEe2EDTXYjr7+EB3yucBOA1DH0OEdYq211hJWyQBWgf0CUfrAPowNdgMJGx8Y2kJxCzsfNJ3PyCMO8wR/cbI7z3KPSzMbNSlq1IWVCuA2WbNwYe4OezI8q2nwDoEUupnyOwH9pwPm2q/uhrmNWdd0JdeCe0eAcWDjJRdzrMdMGdsGqt/Dc9yGm74J2ooN/AgT4fwMlWMjVguYAOjLDXpSIzoInK5jwRg0TAC0IbEikIBF1RDKCU7Sgr4ULZxmPn5/I5kHqSiO7V4Ns5X7z7Bxf3Dld9jpkzRBnoeGQi70RmsfTfej8Pklc8V5G6kqFfS2SttNM2tAcExRK072ki6LKwl8i9IMQfZo6UAgZIKctSbhKWi/DeLwxD4W4o5/uWY92+4bSKdyDyDNx1IQIJE3QeogB0ENdcw+rpa0HVQv+KeyeXJJC6THPwFgT6PCuRHCQbCArGwgchYGPZK7HsBWEBwMxMpAnMkYfATroAAX6ukAPRo2Sr73Ogb/yfc5PPRn+2/ga21q0H76saSIgPMuHHHqb1N0BV35iX/oQTmZ7ipVDqLaz1ZU4msYQDwC9UrPwwL18sfEFY6DAzwyTqKsuyrEQSygG8qUIRlvqpIuuHReR/8r9nd+8M30/rAbUBkjwYd0QBiCvRTVhl7b/t7sJaUvROMP2acp21RICf96D9YgAiiJUvCMJeqfIOgJTtpFMgBfi54i4m/JCg/u1757r3RG9fz2yJIhBfRBjEjRrBv/6GGyysuPK1mvVHOAgucbpSiaAQwC/mNJHSYLZE6AuCcAAwgzWYoeyEZaddBAUPgL4XAX/Do+SGH51Hk4CEB+KKCIa4EGbm3nUR+QBw6U/29GS6M+9gwkeV7RyvbAteNgfWQQAiIiJV7iQuZ1kQhLlSPX8wM4M1MSk700UgQJe8LVrzv8D3v/H9izJbgFAReEoaDcUFEQ3tTo3gv/JuXqxQ+hAYH1QJ91D2Nfx8lkGkCeLiFwShsTA4AAOWk7CspIOgUJxg6O+xF/zt9y/qfhIQRSAuiLBoW0xyX9Tz+4qfTS5xU+7vgel37bSzxM+VEHilAICx9gVBEJpJ6BVQlm05mRS8fKEE8PW1ioB0GmxfRAFoQ9bfwNZsgt/LFsGB5zPDIrH2BUFoNVF4gCzL6U7Dr6MIXHDHHfZdF10YyDLG7YUIkDbimmtYXQcA15Fef8OTrr/8yKuVsj5jJZzFXs4IfjAkqU8QhDaEmbmiCASFUgka/8Sq9OffP7d7FzDduBFajwiSdqAms//Ku4vvVIo+rWznuKBYhPZF8AuCEBeqFIGuNIKCtwvsf9navvFzG646rnQNs8K1gOQHtB4RKC2mWiO+8o7J4+DYn7Pc5Bs50PALuUAS+wRBiCdGEbBs17LSCQR570nN+pM/OD95ExCFBS7yWz3KhYwIllZRld2//taRXj/T/XHo4JOWm3C97KSGWXNHkvsEQYg3YY6AncxYZBG0X/qO9ovX/OA1vc9fE64gKv0DWoMoAC2g2up/211Tl8Byv2SnnTWl8SwYHBDIavUYBUEQ5hNm1gDD7elWQdEb5yD4s++/JvVlIOwoSJIb0GxEAWgmVVb/m2/ZvdxOdf85FL2fyIKfz/mkyALE3S8IQufCrANl2ZadTiHwvNv8gvfpH702c794A5qPCJsmcQ2zii7st9w+dYnlON+00+7y4sSkBkPc/YIgLBzCsICT6bG0X/JZ8ye+f37yi4DkBjQTUQCawAV3sH3XReS/+Qe7u+2hnv9HpH6ftUZQLPiklN3q8QmCILQCZg6IyHK6u+AXijcXxif+4KbLFz9v5kxI34AGIwpAI2Gm9RtMN78rfzZ6CqUz37CTzsnFsUkNZiKl5PgLgrCwYWYAgdPdbetSaTjwSh/6wYXdN4AI12itJCTQOEQANYhql/+Vd039Frnu3xJZ3X52yodSNsGstSEnQBCEhUr1ekOadWDZrqUSCQTFwhc3/+d/fPKhf77akwTBxiHypwFELv9Lf/J8T7r38L9RrvNbfi4HHQQBkWT4C4Ig1INZM0jpRE+X5eeLd5dyxff/+A29L0RzaqvH12mIAjDPRNrq5beMr3bTif+004kzimMTAYGkoY8gCMK+YADMvt3VbQfF4gj7hXf/8LV9N1/DrK4DWBYWmj9EIM0jUX3/W24Zu4SSyW9bjjvgZScl0U8QBGGOMOtA2a6lHAeBV/zYDy/IfBHMhGtBkDbC84KUns0HzFQW/ndlr7a7u38K5gEvNxWI8BcEQZg7RMrSfon9Qj5IdKf/7so7s/98wbV3WmaxNJZQ6jwgHoCD5RpWkTb61junvmanM1d72WzAWpPU9guCIBwkVVUCfrF4tzdeuOLHb+obleTAg0cUgIMgyvR/8w92d1uLer9oJ50PFCcmA2JZwEcQBGE+Ya19t7fH9vOFB7zxyff8+IrFL4gScHCIkDpA1t9wg7XhqquCy28c63d63JudTOr00uiED0Xi8hcEQZh3CMxB4KS7Le37I97kxKU3Xjb0gFQIHDiiABwA5Uz/UPjbydTppckJj4icVo9NEAShk2HWgZVIWQCPehOTl9x42dADp/7Tg85DV5/mtXpscUNi1HNk/Q1G+L/hp5sGysJ/YtwX4S8IgtB4iJQVFAsBQP1OT/fNl/90zxkPXX2ad8EdLN7XOSIegDkQZfq/6Se7T7d7eq9XlrXay04GpJQ1raWVIAiC0BjCFqqstbbchCLLmgxy2Y/+6OL+b0o4YG6IuNpPIuH/5lt2n6bSPbcoZfd7ucmASEk5iiAIQgtg1lpZjrJTaRQmRn7nx28Y/LooAfuPKAD7QZTtf/mNY/12l/OQcpOrfGnwIwiC0HKYWZNlQdk2+VNj5974xqX3ihKwf0gOwD6YJvy7EzdbbnKVn5uUBj+CIAhtABEpDgKw1mx39d/4pp/sPv2ui8iXnIB9IwrA3rimWvi7N9vJ5Oni9hcEQWgviEhprwQAA3ZP982REiAdA/eOhABmg5muAeih/92WtHr77yxn+4vlLwiC0Jaw1tpKpBQpHi3kcxfcdPHAE1H+VqvH1o6IB6AezHTBnbCuI9Kqu+erTias8xfhLwiC0LaQUioo5QNSTn/CTV5/+Y1j/RuuogDXsMi6OogHoA5Ro58rbh39WqK/7+rS6LgPEf6CIAixgFkHTlevFRTzDwTjoxfeeMXyPADIUsLTEaFWwwV3sL2ByH/Tz8audnt6ry6NRe195boRBEGIA0RkeZNjfqK/73T2/a+C1G9ecIe27wKkMqAKcYtUccEdd9h3XUT+5beOvd7NdH/Nm5ryGSaJRMS/IAhCPGAApJRdHBv3Ev3dv3H5rSPX3nUR+ac+yNKxtQoJAYRE5X5X3Dy6itKpB6CDfu15kCV9BUEQYgyRZydTTmlyfP2PL1n039IjoIIoAADATOs3QI317kgmE9132m7yNC87qUkpEf6CIAhxhjWTk2BlqXHO5y744cUDT0QGX6uH1mpEwAG44E5YG66iwFWJL7tdmdM80+VPjo0gCELcIUXaKzIpu1/b7vUX37w98/QGEJgXvAG84IVcFPd/0y2j70/09r+/NCa1/oIgCJ0EkbK87KTvdmWOd1XiyxuuouCCO7HgmwQtaA2oHPf/ycgJqid9DwdBkj1PgWhBHxdBEISOhOE7PT12aWzsAze+of9fo5LvVg+rVSxcQRfG/YvunjT3pu623MTxfm5K4v6CIAidCjOT7WiyrYIueOf87+u7H1/I+QALVgGIMkGvuGX0K25/34eKo2Pi+hcEQehwmHXgpLstP599dNtLPWcc0Q+9YT30QmwStCCt3fU3sHXXReRf8dM9F1vpzIdK47K0ryAIwkKASFl+dtJ3e3pOWn7E2KcXcj7AwlMArmG1bj34shunllIi+R/s+wzWC+84CIIgLFSUsouTk4GVzHz2zbeOvX6hrhy44KzeCy6Euo7If9MtY39lZ3qXlMbGpM+/IAjCAoN1QAyQVvjKqQ/ycdgIDWZaSKGABWX5Rq7/N90y+jorlX5vcWIiEOEvCIKw8CBSyi9kA6erd83SYRMKWL/AZOLCSQJkpmsAuv8mdDnJ7MNkO0cGxbyWVr+CIAgLFGaGZWll21qXgrNufH3XwwupKmDBCL/1gLqOSCtr7FNOd+ZIXcj5IvwFQRAWMETEgQ9luw44+OI1zOrpDQvHMF4QX/QaZnUdwJfcPrHGtZzHOQgsaK0A0MI4AoIgCMIMGAABrHXg9vZZpbHR3/zxJQPfWigNghZE/PvpDSBcRdq+ZfRLVjLpeqWJgKJufwsm3UMQBEGYAQNEivxcjpXt/NXlN479aN21GF8ICYEd7wJffwNbG66i4PJbxtY7mZ43eLmJgIgWXLmHIAiCMCtKeyVtZ7qWwuX/e911pNdv6Hz52NkO8DDx7847obr98aetRPoov5Bjif0LgiAI02EGKVa2rYOSt+7Hb+h9odMTAjtaEK7fYBL/ukvjVztdvav9Qlay/gVBEIQ6ELHWrNykDfD/A8LwcQfTuV8uXOv5rT/DgK+mXgCpPvZLMCv9de7XFgRBEA4EkxHIYLNWQC530Y8v7r4zCiO3enSNoGOTANcDagNR4N08/PtOz0C/Nz7mgyj8vh2d1yEIgiAcEBxumlmXrgFw57r1nSswOtMUrrL+PTX5HJEaYN8LrX9BEARBmB1m1nYqo4JCsaO9AB3pAai2/t3ugcHi+GhApKzO1eMEQRCEeYSJFDjobC9A51nE1dY/ifUvCIIgzJ2yF6DYuV6AjsuIXw8oELGnx37f7eoe1H5Ji/AXBEEQ5gSBSSlw4F1zDZtl5Fs9pPmmswRjaP1ffMuOtEOpl5TtLGavJNa/IAiCMGeYWdvJtPK0f/pNF2Ue7DQvQEd5ACLr30XiHU6me4n2xPoXBEEQDhRm5ThQxeKHWz2SRtBRwpGZ6cI7YWVKo0/YyczaoJDTkMY/giAIwgHBDCiQZXmsrWN+fHFqI65hhes6oztgxwjH9TewRUTc7Y1dYCczR/si/AVBEISDgog50HY640IXfgMA1l/bOYZzxwlIrfmPlO2Q0dwEoTOgqk0QhOZBIBXk82Dg6vV37OzaAOgo3yzudEYfgGtYbbiKgkt/svNIZbsXeVMTTCAlOoAQVwiACqeYgAG/6lJWBFhhQ2vN0tdSEBoMBaVC4Hb1LsnmJq8A0X9dcAfbdwF+qwd2sHSEB+CCC833sCz3vU4mkwLrAGIsCTGEYIS7z8B4iTFeYgQM9LqEHofQ6xIsAiY981pRMxRVlAVBEBoAAcwaxPq3AeDCC9EROQAdMG0wgYH1925O5ia7n1Bu8ghdyjMg8X8hXlgEFDWQ9xnL0wqnLXJwXL+NVd0WlqdVuFQJMFrSeGVK4+lRHw/t8fDiRACLgLRNCMQdIAiNgsl2AioVT/rfNw4+BWaFmC8VHPsQwPoboDYQdPbW3tc66cyR3tS4JqVE+AuxgQAQARMlxiEZhfesS+GsxS76E/X18y7HwoqMhfOXOCjpFB7a4+GGjQU8POyj2yEoMqEBQRDmEebASWfsol96P4CPX3An1F2Itycg9goA1gMAMQUj7yBLgYxGJgqAEAsiET9Z0njLYQm8f00ava55NorvRwpCGa6sWeYq4OzFDs4YcvCjVwv45+fyCDTgWCRKgCDMJwTlFwoA400X3HHHn9x1IWLfECjegpKZNhAFl/5k2xCUdbmfywGA1ephCcL+QACYGTlf4xMnZPDR4zLodY0bn1FJ9lM0vQqAqPIaYBQFRcCVhyfxt2d2I20TCj5LXoAgzCukgmJe26n06nTppNeAiNffwLGWN7FWAC640wh7ZaUud7p6hrRfDKTznxAbmFEMGJ88IYPLViTKgj/K8N9fIgUhYOCYPht/dUY3ehyCF3AnJPkIQttAgFZOQinWvwkg9EDHl1iHAC68EPouZsLNY+s5CNikarZ6VIKwbyxijHmM312bxiWHJuBrwD5IdTyqHljdY+HPTu7Cx++fgE1AR+T6CkI7wLD8XBYg6/Xrbx3p3UA0DmYCUSwlT3wVAGa6jkhffuOr/druPdsv5AkM1RntGYROxgJjosQ4c8jBO49KIuCDF/4RNgG+Bk4ctPG+1Sn80zN5DCYAX5QAQTh4iEh7JW2nupbl8tmTAdy5fgPUBsQzHyC2IYD1G8Kxq76z7VS6T/ueLPwjtD9s6vrTNuHqY9IN6e5nKZMX8PZVSazts5APAJKmWIIwL5gwgA0meiMA7BqKr3YdWwUgir0E5P+asm2imJdjCJ0Ml38qYmR9xpmLbRzZY5UT+OYTCveYtgmXr0wgH2izD66MQxCEA4EBYqVLRYD1Wy/9yfOJu2JcDRDPEECY/f+mHz2YDoDXB4UcAG3FWZ8ROh1drukj0rh0RaKhYliF6TAXLHPxny/mkPMYFgFcLiwUJUAQDgxSfiHHViJ1lCoOHQuih9ffwNaGqyh2ikAsJWbZ/e+sOtFKpJYEXkmDpOhJaGNMiipKmrEkpbCuz5lZ3z+PRAb/QEJhba+NfKDNvkTuC8JBQ0BgJZJKK/06IL5hgFgqANHB9hlvtJMpi5jF/S+0MUbqEgHFgLEiYyHjmEY9jZw1Ilm/pteGz1UlgZIPIAgHBROIgwCs+XIAFNe1AWKpAIQHmxThXO37YIqn9iUsEKrkbaAZq3vspjjho5tida8Nmyh0/wuCcLAQQwXFPIis497w00391xHFcong+CkAYfnfG366qR+gk4JiHsQx/B7CAsSI4G6nufNEt0NQM8S/KAOCcMAQkfY9bSVTAza6TwSqQtMxInYDjg6yje4TrVS6X8r/hLamjrs9aLILPogWDqhG5L8gHBQEaMtNELO+AIhnHkDsFIDoIDPrC5WTkPI/IRaU7W9ufnteCkdg/hfJLwjzARNI+z4AvAbXXKPimAcQuzLACy+Evss8PEvrAJoalkgtCPNGZIRzSxLwGBwK/+nqR1QSKAjCnGEov1QAg46/9Mzf77qOaCJubYHj5QEI4/8X3PBkF4OO0aUC5rhuiiA0kZp5IBL+LZkeWMIAgjCfEJH2PLbcZJ9l2asB4JqYyaNYKQDRwU11HbJauYlDglKRAYrVdxAWELMI2NbJXQ7/FckvCPMBgQMrlbJZ++cCwJ13xkumxioEEB5cDRWcbCUSSpfyAYBYr8csdDK1ApdhUlaaL4C5EoRo+r4FoWMhBrSGBp8KAIsvjNcNFittpYzG0UQWSIwZIS4wt1b+RvvXcsMIwnzBAHHgA6CjcM01al3MNOxYeQAqCYB8Avs+OOqkGqtDLiwYuPZxnTh8s8YRbTM6EEkioCAcKMRQQakIMB116ZnviV0iYHw8AFUJgATrWO1JAqAgCILQQohIeyW23OQAcf8aIF6JgPFRAELc3sE0FPVyEADNL6kWhIOCwS3qxS/xf0FoEEy2Y8NWQwDw9Ib4yKXYKABRB8CEdo9UbqJLB4F0ABTamJgI25gMUxDaFQK0chxwoE8A4tURMFY5AADgkzrGtl3FyAUx8rQIC5jqGoBW2eG1+zYtgeT+EYSDhQFiHQDAOgBYvDs+anVsPABVLYBXkh1WAAiCIAhCKyGAtQaYVgLAuvXxkU2xUQAirYqAlRwEsgSwIAiC0HIoLAVkRYvX37Apda3pvR0L+RSbEECkVZHmIxBosf+F9mdGGSBad91KDqAgNAYGBZ4HaBxacoIEEeVFAWgEd7Bdyu5JpTkIn5AZTdh/VHhLNqcXTq30b3UGQPU4mk9zj70gNA8Gw4JmXynaCqcbwFirx7S/xCMEEPYAOPTFzT3bcvro0ak8LHA8xi60BRYBBZ+R9ViWj2wyioC8z5jyGJY07xA6DEsR5Yse7/Dd7vFi8mgAwIZ4yNZYDDJiSa8XaM3B7gJjV94svUySDSjsBSuUNnuKGmv7HFy0PIGCz2WLVGgskfA/YdDBhcsTGCkyPK6cF0GIKwRzfY8VGdtyGqVAw4YutXpccyEuIQACwJM6tcZykz3wijwegIpaY3GKkLBIXIvCNKKbc9JjpGzC76zN4N1HpUAgPDbiYcpj2KI8NhzNgK0InzqxG8vSCmctdvGt53PYnA3Q6xCIJCwgxAuGUWADBnbnNKY8BjHYclx4hewpAH5+wRDorlYPdD+Ihwcg7KzEUL1k2zYzs01AKWBszWpMlIxFJ0aFAFRuzokS4/QhF188uxcfODoNVxESFvCBo9PIB+IFaDRWqIBdeXgSy9IKvgbeuCKBr57XiysPT6KkTVjGlvMgxAg79GptzQblsBYIDFJQRIOtHt9ciIcCEKJgBVEbVUbF/b8rr7EzrxHAWH1iUCxcLAImShoJBfzxCV34wlk9WNtnIwhXjtIMvHFFEkf32sgFkg/QKAhAUQOHZhTeuzptrCZlFLOBhMLHT+jCX5/RgxVdFkaKGkQSzhPal0jeEAHDZZf/THnDQDDbZ7QjcQkBAAAUOKiXx0wEjJcYhSDAoqRC2paQwEJDkWmxP1LUOH+piz84rguHZKzydRDFnCP33YfWZfDRe8YARQ0XOq3OwW9FDYIiIFvS+NQJPehyCEEY97eosirxqUMOvnpeH775bBYbXs7DUSacF8i9K7QZioCSBvbkNbJ+mMxKM+9tAosCMN9E8ZRA61NsywXrLFON78IG4AXA9imN/qRCv2tiApolNNDpRBn+WjN+75gM3rsmDQBloVONCq+JUxY5uPTQJG7aVECPqxqjts/WB6DZAq7J0l+BkfMYpww6uGB5ArrmPBDM75qBtE34yHFdOGHQwd8+NoWRokaPq+CLEiC0CYqAyRJjT0Ej0CYEULueFzGIfR/MdDIA3BWTdsDxCgEQDYKUibfUEK1qTgQMFzS25TQ8LdnGnY4F4/IfTBC+cHYv3rsmDc2YIXRqYQC/cXQaaYcQcKtW6OtAwuMYMHD1ugycvcwwkfs0YOA1yxL46vl9OHmRg5FCYEKqzRmxIMyAUbk+d+U1duY0mCserPp/xGBmkwMQk3bAsVIAQOzvz9vKSRpTAcarEgRjcUaE/SLKuxkraZy71MXXXtOPU4dcBGxu3L0l+EVegEMyFt69Oo2JUpjII0rAwcEc5mAwLl2RxPEDDjTv/VxE3oCAgeUZC393Th/euyaDnMfwNYsCL7QEm4CcPz3JHNi3DCHCfsmodiFWCgDz/qUJ1WpvO3IaActk0ikoMHytkfMY712Txl+d2YuBhNqn1T/tM0I33ttWpXBol0JJI1ptqpFD71zYWOw+A/0JwvvXZspeuf0hCgkQAb93bAb/3yndcBSQ8zQsknMiNJ5IbhCA4aLG9qyGN8dqIY6Z4yoWOQAVNOYazLQImPIYhQAYTCp0OwRm80mxOlMCAMAiRsFnJCzCx0/sxiUrkmXBMZcblWDSdbsdwm8fk8FnHxjHQEKFCWhzEV2z0U6tgGvH0IjPNvfaaFHjI8d1YVla1c3B2BvR+QsYuGRFEqt6bPzfh8axaTJAt0vw49FeXYgpFgGFgLEnzyjMuUw4nottxMoDcKBELsadubBcUDqRxRILjKkSo9tR+OK5/bhkRbLs8j+Q0xlZnRcuT+KUIQdTvjY3ffzu49YSJtrmAsbRfTauPDy9T9f/3oju1zW9Nv7x/AEcN+hgpKBhgeXcCPNKZPUDwEiBsS2rUQgWjrd4QSgAkT0XZXNuyQaY9MLcAKk9jgU2McZLjGMHHHz1Nf1Y02vPmyLnKOD31nVDoepakFDA/hEeJ0VAIdB435oMMg4dtA8lUs66HMIXzurDlUekMVqMwgFyboT5wQ6t/m1ZjZGiaS+/kHrJLAgFAED5jFoEBDr0BuQ0vCAUIjKvtA/V54IZNhhjRcaJgw4+d1YflqetOcX794YKrc3jBhxcvjKFsWJQdT3IBbFX2FjkCsCEp3HOkgQuWp6cN8UsmohTNuETJ3bjqiPTGClo2AAoOjdy3wpzIbxeFMzlO1xgbJuqsfoX0PUUqxwADUAdTMVWlQdRwWQrZ70AA0mFXtecfWkg1EZo0yZ2uKBx8iIXf31WH7ocOij3cj2iyeDdqzO4a1sBBc2wQAcv/6tkVHTtcYu82FGl47zuO/wwDVOO+RtrMuUKi/miWhf76AndYADfeSGHgaQCNIOjVo5y3wr7QeQJzvqmrj/q5qdQc93O9Xriyj0WJxaOB6CGKPajAezOa2zLahSD+RUswkEQVm2MFDWuPCKFvzmnMcIfCFsEw5Sh/dpRGYwXdWUfcbujmwVXEv/GSwHedFgKxw9WyjDnk6i/h2bgYyd045MndyPnc9R5bX53JnQsikzi7668cfmXvb9YuPrjglUAIqI65Fy4uMNIsRLTFFoEG8t/vMS46qg0PnlSD1I2TUvYmW8iy/Wtq1JY22cjH1TX8yzU6WE2zPEgAEXNWJqy8MFjusANEP4RkeWmGXj7EWl86uRuFKJzJEqasBeiCqFJj7FlKsB4SUv+V8iCVwCA2kxQja1ZjawkCbYGZjgK2FPUuGRFAh87oRsBz09h3t6IXM1djsL7js6g4Fd7ARq44zgSHg9Fpk7/qiPT6E+oppTWKgJ8DVy2MoWPntCF4YKGHcVwBCEkuhosAkoBsD3M+ZIKsOmIAlCDIrPM8PawZFDaCTeR0PIfLTJOXeTij07sKbv8m3EKovKz1x6SwjlLE5jwJBQwg6qs/6yvsbbPwTuOPLiyv7lih6sKXrkqjXetTmO4oKWTozCNqGXvnoLG1mxQMegg+nw1ogDUoewyKpl2wqMSFmg8Ycx/3GOcMOjgc2ebmD81SfhHRK7m3z22CylLkkL3hmbg/WszcMIbo5nnKQoHfOyEbvzaUaZE0BYlYEHDmO7u35rVMnfvgxgqALVd1Rq3WcRgMPYUgulapIQF5pdQ+E95jLV9Nj5/diXhr9n3bVQWuLrXwaUrU5jwgqryoIV+1iuJfxOexllLXLxmebKp1n9EbWLglUekMFyUcMBCJAoP2mXvbYCduQBeUN03olmbbsZXnjdiVQZ4AJ2AD4pyHAnhhZU1LUn7EgqJcB15WW74YGEomDhdr0v4zKnT149vBdE6Ae9f24VfbitiwmM4dAD55vXKipp4/c4Yy8HuN/x7n4GkAn5nXVdLFWEK/9EM/OHx3XhlIsCTIx66bEIQ9YcWOh6LzDU5UtAYL+lpCmnTdEFG62p8D4L4eQBadICrOwlunQowXLU2tHCAMIPYTOABMz5/dh8O756/Dn8HCsHomgMJhauOSiMnuQCotv6nPI23rUpjda/T0Mz//SHyBCQswufO7sOKLgs5X1Z3XAhE191ESWPrlI/Rqk5+wv4RPwWgxZSrBYoaW7I+xkvT20fKlDM3iIBJT+MTJ3djbb/TcuEfEcWY1x+ZxtH9VesELFRCT1c+YAylFN63tgvtYmQTKm2Drz29FwkbsrpjhxLF+Sks3d6WDbAzr+G3WBGNK7FTAJod0Zlti9xOO/JhlqnP5QtTt3hssdjY5FOMlTSuOiqNy1am2kb4A5WwjkWEDx7TVVYI5uO7t4J5GTcBPjOuPrYLXfbB9/ufTyq5GzY+flIPCoHRAFp+ncs2L1sUWVcEFAPGzrzJy6peta/VY2TEj9gpAO0Co5J4YhaTCLAjF6AU9pSWcpO9ECb9TXoapw45+MMTuluSSLY3ohuaCDhvaQKremwUddQcaKGdWfO9AzbLJ582lChXZ7RTlUSklF98aBK/viZjKgMkKTDWRPNsVKK7JzS4JkuVhGzhwBEF4CBhhL2kCch6ppvgrrxGSYsiUBc2wqSkGX0JhU+f2lt+qV3u5Six0yLggV1FvP/2YWya9OGGiZ/7dUI76aRzeJ0DKAbAb9+xB9/fmC1f90EbfddIUPzOui6cscTBREl6BMSR6GxF53OkYEKuYyWJ888nogDMI9OSUrJhoiAbL4EoAkB0BCj0mnzq5B4sC1f2a5cbOuplP1II8NcPjeHjvxzBSxMeLDE1wKiUAH7u4XF87BfDeGa0VF66tx2ub0IlMfD/O6UXfQmFkpaWwXGhWvAD0VzqY7ioG7LOxEJHFIAGEF28o0WNLVP+TEVgIc5DYYmMRcBYUeO9azI4f1mibeL+kQCzCLhzSw4f/Nku/M9LWSQsQtruoCVnDvKLMACHCL2uwv07C/jw7bvxracnyl3W2iEkEOVrLEtb+NTJPSgGXHEVL8ibr/2pL/iNN9XXlblTmF/i1QcAiEW2RflihrEohwsaEyWNHkehx1VwzEqmTemd3jaE2vuUp3HSIge/s66rbTT6gBkWmcZDX3lsFN9+dhKObaE/oRAwg/UBzD611yjP8nyzqN7/XMdQ837mKB9AIQgYX3l0DE/uKeBPzxjEQNJqC6Uuch2fvyyBdx6Vxn88l8NgQsFv87ljoVEd49dslmgfL2mjtKHS0rft9bYYyKV6iAeggVQnCgYMDBcDbCm7s3jhhAbCuL8OF/r5+Ek9ZYux1fI/Ev5bJz185LZt+NZT4+hyFRIWwdfRGRTqocPz2p+08IsteXzw5m14YEe+bUICkSfgg8d0YXWfhWxUyskxna07iNlc/bvyVYnUJGep0cTMA9DkVoDzxHRFgDFcCDBRAnpchR6n0z0C5lwpAkZLAT58XDeO6m19sx/AHHOLCHdumsLnHtiNkSJjIGmHSW0MUgejnnHN41YXDB3Mvmf7LgCDETCjN6EwXPDx0du34bdP6MdvHjdgXufWZWpHZy9lE/74pB589Bcj4Oi7iG7XEmZa/BrjJS5b/NUlffEinsWA4gFoIjM8AmFma5Tg0pEeAa6sHHdMn4N3relqedIfA+UxbHh2DH/68+3Ieowe10LA4cCqx1crwRaa4Kj9vlTluyHzTwAgYVlIORb+/qE9+Mv7diLv63K//lYRVSmcvMjFmw5PY6xYtbZDZ91pbc3eYvzVFr/QXGLlAdAwGkvcb9vaEpfhsId1b41HIO7fMwrcRYrPH5zQA5tau35C1K5bEfCF+3fi+mfGMJh2QKQQgELZRmXBVn9WWmgzVUUtJZCxogkAm+PFxAATdPieobSD/35uDC+PFvG3rzsEXW5r8wKiUMBvrevCfTsLGC2GazuIF6DhMMycHZ2DiZLGWB2LP15L6NQnfva/eABaSq0isKegsTnrY09Rw+PK+tXxxHw7i4DxUoArDk/j5CG3pYl/kTtaEfD5+3fi28+MYijjgKGgQSAiAMrI/ZojX/v7PonviZs7odJEoWfAZ8Jg2sUju/P42G1bMVkKyi7fVg2PAfQnFH732G5Z26EJVLv6AwbGSxpbwra9pWD6qqpyBlqHKABtQG1oYKSgsXkqvFk0lxuuRO+NBaGRWNSMJSkLH1zX1dKFYyLhP1XS+KPbtmDDc2MYTLvw2cxEJt5PodEfPa7jAVhIgr2aquNA0e/hcaKyx0SBlAIRwWegL+ngiT0FfPAnr+K5kULZCmwFkSB63aEpnLMsgYlqJSA+d1XbwzCXRXkuKxqjZmd1c7SFeg+1IaIAtAscCimErtLQXbYlG2B7NkDWM4qAFQdFILSqiIC8r/HBY7rQn1Aty7uK3P5TJY2P3bYZd26eQl/KCV3+KpyRVKgIoDLKcKaabv3L7DXt+MxQAghQqhxS6U7a2Dzl4w9u3YznW6wERC7nDx3XjZRFlQ6GbX0ztT/R4Yvmp1LA2JnX2DzlYzhfWTWVIAUY7Ua8FIBOXmUngiteSSv8fcpjbM+axS8mwlaY7ZswaEakAOQDjbX9Di4/PNWylePM4TXK0+fu34EHd+YxlDGWfyT8Kz+jkQNQ5ue0IS9002WaF4BqnguVJyLzWqQEMKE7YWPCY3zm59sxVdItUwKihMCjeh1cujKJSa8qIVBCAXOmOoRJBOQ8xs6cxpapAONhYrM1m+Bv9XzbqC1myQzxUgAWGNWade0NNlI0S2Da7eZSCwdNBBR9xrtXZ2BRa1aOY0TZ/oQv3L8TN22cxFDahVdP+IfCqzz48nij55o8+HalNhQAhMqS8aLUUwJ8JnS5NjZPevjYbZvLSkArZG6kNL9zdQbdtoI/bRCiBOwvZU8ljKdyWzbAtioDRdZBiQeiAMSIKBegFDB2502b4SipJkpuA1p503F5nJOexrnLEnjdoamw3r75o4n2+7cP7ML1z4yiL+XAx0zhj7LbX5Xd2tOE/4zHC5xqqz86LuWAen0lIAChK2Hj0d0F/NHtW1AM/e/NvlYj78OhXTbec3QGk9FiQa0YTIyoNkYUmVUXRwrGGNmZ08h5Zg6KRYhSKCMKQAypTrIZL5qbcHsd7bvpcOUHAXjf2q6WJf1F7sf/fXEc3356FIvSUcyfZgh/inoSEqYJtzJt5WJpE6jOw9k8AVRRAvpTDh7cmcff/Wpny3oERN6Htx+RxrKMVbXMMyCiazrRvTzdzR9g86RZ4yS2ScoCgJj1ATDUBpMWJtGNqcg8znqMrAeMWRpdDqHLIbihOh71FGioGOPp1v85SxI4cdBtSdOfyPJ/aEcOf37PdvQm7UqZH1US1ipyPRL+QCVYURXLOKDrbbaAZ6vgmp/z+7nmKLExKbR5hpRZR6FyTE11wKK0je88O4pl3Q5+47hBBJphNfEiIQABgG5X4W1HpPEPT0xgIGF6FbQkVtWmRKfE10C2xJj0NAq+6aUYJfzJTBzRDvf43BEPQMypdc2VNJt+AqFXYMoz76jurd3IS5RhLqpfP7qrgXvZ+/6JgNFCgP9zz3YkHAukFHiG2z9yk0SPayz/ad4AoS6h0jQDVfWCgvEMhMeciBAwYVHGxdce3YOHduRgKWq6JyBSnN+yKo3l4gWYNi9Et0beZ+zKB9g85WNnPkDeb5dQozBfxM4DED8dq/lEmvmkx5j0AiQsQib0CiQa4RWIrH8AOV9jdZ+N4wadltT9R9b/n9+7HduyPvqSLoJyTb8CR4IIAIfu6YjIVp1vE7Da9m7V9du4fUfZXhXPCQNhsD3s20kMVgrQMF0DYTwttlK47p7t+NZlh6MvaTXV+CaYMFGPq3D+siS+82IW/Qmrkq2+QHS/ak8iYKz9iZLGpMcoBDyteVb0fqE+MSwCiJ8CIBrAvilr8uHPUsAo+IzxglkYJeMQMo4qJ+wctDIQ7ZAAz2e88yiT+R9wWMrYJCJX8reeGMYdr05hMO2a3v5EIJj4NJWXGKNKqV/0e9WPebnG6iWYt+L6rVeuNO9QWQmgSAmocjmZ5xQIGiAFrTWSjoXtUx7+/J7t+JvXHtr0dsHR8NYfmcFNr+YQaK7q+dC5WkA5IENhxIZNCHHKY+R8DT+UYip8XSok94N4RgAkBLAQIJikQYbpKbAzp7F50seuvEY+XCA96iswZ6KmPzBNf1b32bjo0BS4yZO5ZsBShId35PC1R4fRHzb6qcT8a9z80+r8I+E/m09b2C/qVQdUHVOTGBgmChIhYIW+pIs7NmXx708Om259TYwFRMJtRbeN1x6SKpcnAojdRL6/VCf0lQIuZ/JHScSREiYW/8JAFIAFQr0ynvGiWZFra9hXoKQrC3TMdR6M6v4vXpGCo6iprrBojFlP4/O/2gmloli/CoV/daOfvQl/4aCp1yxIEaKpplwdEJ4TDaA3ZeMbjw/jhZFCS/IBAOCNh6XgqHIAIyT+4q/efT9R0tieDbBlKjCZ/EGlhO9AU16FeCIKwAKlWtAXA8aevLEEtmZNFy+fK5m+syoDVb5BnzV6E4SLV6QANDf2r8NSpO88M4rnRkrIuHbN4j5Vwr9ukx8R/vPKPpSAKOmSiMCkYCuFYkD48sN7ADRXAEUlgccvcrGmz0He0xUfUEwlYbXQj/KBom6imyd97MxpZGuSg6v/Tlg4iAIgTGvgYTJ/TYggcgvuSxlQZMqEXntoCssydlOX+41c/y+MFPDvT42YZj9MoKgmXdUI/9omPyL8G0PdjoEmHEDl11W5KqAnaeOebTn88IWxpq8cqAFYRHjHkRl4uvaSiIdYnE3oR+G+qCKIIS5+oUL8kgCFhlA9gUS/T4WJQRbpcvJgylZwwuBpJe/FhA4uOiTZiqFDM/Dlh/eg4AM9SdNwBuUGNEC18DeI0G8KNHtiIBGDFQHarMSoGUg7Fv7psWGcv6LbZOSjOWcquubPWpbAYFIhH2hYUXVIm+YCVuXdlscfsLlns57J7fHCOFx1Fn/13wqCeACEWdmbNTFR4rJnoBQwju6zcdJQotwkpBkE4f5vfWUCd2/LoSdZs8Jf1OK3SvhXktMg1n8zmKZ0VZ+L0DOjFAAFBiFhW9iVC/D1x/ZUdIdmDBFGiexPWDhvWQI5j6Go/cRktdC36t6bwYx7s2VdQYVYIAqAsFdmuhYZU57GzpwfVhL42JH1cebSJBJWcxO4CICnGdc/PYqkHS43TBUBT9VvRO1E2Kp0p/YTLI1jekJd7fkAIl0gbBAEoCdh46cbJ7F5otSSVsGvW5GCAqPi3wLAGs09bzPrNgmmUkcR4GvGREmXW/Juz/qYKAXwtd533o4gVBGrEIDWGooZLIWpLaGsDITHXzNjoqiR9zTOWpJo6liicqVbX5nE03uK6Es7FWERxvmretNUiXvGdPOyUdcSV+QHOAyZRNdu9b4bb59F+zUbmiwVuOoHVx4Swq4p1Xn3BKUIY0WN658ewZ+ctbRpQ430xuMGXRySsbCroE2oaxrNO3CRgyryThS1cetHW7iWUrlWPxodM4vQbwXV91eMEA+AMGciGaLAKPjAsQMujlvklhOMmrF/BWC8GOAfHx1GyrWgmcrlfjNd/7Ump9B0ZlQG1IQCwkZNUULgj16cxGO78k3zAhCMUpm2FU5fkkDe1zWhrMYMolofi2L1isxYcr5Z9XNrWLK3K6/LiXy1C/DETO4IbYIoAMIcqUw1SgEFX+O1Ye1/s5q46DBT+5dbstg04SFhWxUBU53lP63kD80wtoW9UVsZUJ2YWe4PQFCkUNJmJUcCmpYMEI3ugkNSsFAjVOdxCPVi+QSTSzNR0tieC7BlysfWqQCjxenNulq1uqbQmYgCIMwNrjwINJCygDcelgZQFX9vMFHi4XefHUPKscIh1Wb9I3y2ekwye7acGYkZoReg6rEGoTth4/ZNWWyaKJWrBBo+tHBIxy9ycWiXjVIwP7Z1bcZ+OZbPwFTJ9OCIrPydOY2pmiQ+KdkTGoUoAMIBoWBa/64dcHHsYPPc/4E2Xct+sWUKTw0XQwWAqlz/qKn3r3pOaANqQwGYHgoIH1uKMF7S+O6zY5V8jiaMLAoDnLa4ThhgPwcxm8APGMh5jOGCxrasWWVve266lR+59iWJT2gGogAI+0/VBKgIKPoapy5OmNa/TXL/Exlr8MaXJmCXl52tFvhVbuX66f9Cq6lVxqrzNEKJyyBkXAs/35LFaCGAUs0VhqcsTiCqBNxbWt20GD6ml95VC/ytocDfmg2wp2A68XEdK18QmkmsqgCEdiFKRCK8Pmz92wwLW4cT5rPDRfxqex49SRvlNjNl13+kBojrv60pV2eELYIIAIe/EYEZSNgWtk6VcMsrk/i1tX3l1R4bSfTxpyxOYCCpUNAMq+rarq7bqHY6aTYu/WKYpV8KGCXN8HXN6ns0swBVrHyhVcRPAZCU19YRHneCqb8fTCgcv8iU/zXDgonK+v7j6VFsmgywDBZsRXBtwGaUV/2rqjgzv3OLVIB6s3yrrt/a0vKWQzUu9SjQHZVpmpK2pGXhpxsn8fY1vdMEcQNHBWbTFOjwbgeP7Skh41Ynk5q+lwEDXrjMdikw62n4bPJiojcTotqGaVWQ7XH4hfmlbe6ruRE/BUBoDTXu/6ynccKSBBanrPKc3dDdA7AUkC1p3PJKFhqE3XkNEGBZgENGEUg6BFeZdsWWmj4u5ljeo53LDC8AVXkBAM2ElKPw3EgJz48UsW5RsuwFaiRmbQDg+EEHD+8qAFBGwAdAIWAUtVGAfa7cFmLhC3EkdgqA3EytxpyBos84bXGi3JnMbrAGoMPGP7/akcMrEx56U05Y+2+ssYAZeY8xHrZxtQhwLIKjCK4VborKq5+Vk6x4/5X3OAcS2vO+MaKSqx5Xrx8QhZmKmvHzLVmsW5Q0jZSalNC5dsDFjpzGhOejqAFmKnebjK6hekPRiPe1IiwcYqgAMKTXVSuo+LCZTQ+A05eaxX+aUv4XTvw/3jiJgDkKGYczLYeTchRtNdaZ51fGHa14aCuCowBXRcqBWQmuelnU8l9x9beea98+rnrEqFy5rbl6W7nvvVKV4l/JBQBAxrzWAFxb4e6tWfzWCQMNzwEAKtfBMQMJuBaQ8zUsVRH6oIqCMhttd5yFBhPdXXqf72wnYqcACK1g+nTmM6PbIazpcwA0y/1PmPI07tqSQ9qxTCvU6kY/NYMgKvebK3+GDpO0CuVnKlnYtiK4KlIQjJJgK5rWca16PNXKQfScWH0HR9l1HnkBiEwegK3w0ljzwgAqHMeilMLKbhvPjJTgWFalF4GcbKFDEAVA2DdVkk4ByAeMw7ttLO8yl0+j58LI/X//9hxeGffQm7QRVHeR28syv7WWWNl1W/Wa8RYw8ohSvCr12BYRbAW4FsEmwAmVAqdGOZgR962T8NWqHLy2t0Yrkr98/E0WHQNMsBRQ0sAvmhgG0GzO8dH9Dh7dXUQGgEh+odMQBUCYA6YJTzHQWN3nIBmu/tdor2w04f9ySw5+lO2/t/7++yEcavPPqY4gj3ILigGQ9aYnQZoGLwSlTAKiHSYdOmF82AnNSEtVPteGUWScJhd9N6NBUy0zFK86v0dOHKo66ios6WRt1prwiRCwUQvu3pbDb584CNWEkFN0zR03kMB/8ZSIfaEjEQVAmBMEwNfAugEXgFkRsNETshU2/3loZx6upaCndZOb+ehgqFOYNj1pMPwZsOlKyIF5lmvebxGDOBL2DJuAhGKMFjR25f15Gev+MlHSM1rp0hyP197ePdvprz1m0TEKNBCUH5taeQKjGDA0m2uq5JsleL2Awazh+Rr3by9gV87D0ozTcFs8yms5dtCFY5kxTd+jeAOE+BMvBSBalrvtfZqdxPRgN4fCLKr/b3QCYGQl7sz6eH6khKStwiRxqrxYK7UbcH3MZtFW/+SqNwds4the1E+eGQTGRJFxz7Y8PnbK3IXw3MdshNRzIyWw5jC2bZ6L4tz7GkKUoxfMckwZpiSuutcCw9TFV1Iyp//uaS4rJEbgh6dRR+8JkybDts9gwFEKIwUPj+8uYmnGKYeFGkV0Wa/pd9DvWigGpglR9TkW+S+UieRSvHIAY6YACM2nZuIPNJC2CSu7mxv/f3RXAXsKGn1JG8He3P8tmpVnVRBo+nNpR+GlMQ+TRY2ehGqoHIkUjHu25bEzr5HXgfGeUNVeqXq09T7DnANvL62eAz1dHnLNzxlniKpCAKjKoyh7WkJBq0JXPExYxdfAvdtyeMPhXQ3PA4jG15+wMJSy8PKEB1vV+noEId6IAiDsJ1y23npdCysiBaBJ8f8ndheMq7jK4q94H+IxIWs2yYRbJ308uLOAi1amG2bJRs6RXbkA9+0oQMOsPDetNALYr0O3Nx0hyp+o/cjat9dTH2Z8JGF6c8Dy8yY50LEUntxTDHvoN/acR4pP0iYc2mXjudES0jJbCh2GLAYk7DeRArA0YyFhUVNWaIsm+qeGi7AtqpSJzTbAdqXK4A4A/Nez4w0dbqCNwnbjxklsm/KRslS5U930jeo8N32rrpyo3WaDa7b9g2b9VTPBtRU2jnvIegEUzeVzD4zo81d2201ZjlgQmk2sdNqow5bci63D04zBlFEANDdWg2QYAVTwNV4YLcG1zFrx5dhym7j/9w9z5QYMdLsWbt2Uw5N7ijhuUWLeKynMcSNMlTS+9dQ4Uo5CEKVytPMhmkZFY2I2jndHEXbmfGya9LBusPEtqCPv0/IuG6YIpFKkGL4DMTqgQoOJY3qaeACEvVAdzTWbZsahXda0Vxu293AHmyc9bJ3y4IRKB6KOcTPG2m6338zxMExp4GQpwHX37g4bFM1vhz5fMxQBX3tsBI/sKiDjKOhpx6d6b+10zOqd1xAClCJkPcYTu4sA0HCrPAoxHdJlwSEO8xGqaKdDJwgHQKw8AFIG0GymH2cCI2DGYWH8v9GJWNHed+cDZH1Gd4KgqxPYqvPMqfav2oAohR5AeYxsjmF/0sKtr07hSw8N4w9PHYSneV76A0Sfc/fWHL7w4DAWpW34YZp95VRV+9Ha0ac2U/EEwrg8GNum/KrXG2+BH9ZjwyqHHKLxiOUvVDP3gFc7IB4AYXbqGDzUxOs7srieHS7CZ57ZAGga7TghzxaiIPgM9Cdt/MX9u/Ffz4zBUWTWjj+I4+uHwv/x3QX81s1bYauoC9EsyZLteMhqIZqm7tlEeG7UeACa0RAIQLnEsaIACEJnEDMPAOKoZMWXaUXP4cIsinBSk3oAREyUNAIdCoKy06EJWWDzQc0Yy06BsE9A0rbw+7dth68Z7z22H4AR5NY0i33vHx81Y7IV4cEdebz3x5sxVmSkXcv0IyjvuPav21QDKI+zqliQIy8AYazYnGLryCGzpi+BoZSNsZKGa+19ESBhgVLrALi2dUOZC+IBEOYEwZSyNYPIwnt2pAiH6k28bSrA6lJlhYcKDBNBEaHbtfCHt23Hx+/YhuG8DztceS5gRhA2zameXzRXXiOYTomBZnz9sWG89fuvYLLE4YJJVLPLfeXutwn1hkimENW1CZsmPGQ9PaMHVKOwqdLSWRA6ifh5AITWEPr/A0bY3a55jOQDkIKxmusVpbezTCOq8esTCAxWAHS4+A0R+lI2/uWJUdzx6hQ+dvoQLlnVjaG0Xfe7lT0gZDrs3blpCv/w0B78fGsWfUkHllIIojfG0v1fPy8hqm6YKGl4AYOc5igAmqOyynqxf8kHEOKLKADC/kGmHWxPQmFpV3OWAY5wq1fUqUtcJmBCtMJdJZahwKzBDAykHOzIBfjwrVtxeI+D167M4MzlGawdTOLwPrf8J7tyHp4bLuLB7TncuTmLx3cXYFsKi9IONJPpRhpZ+2RUjnbpmHhA1OgDjiJYTVhQKdpt0iEszVjYUwjgWvGIPAnC/iAKgDALtRUAxgoaSCosSze+DTDDyKysp7FxvATXitYAaOBOG8UMgzb0AphmBmXhHDDg2gqLbMKeQoB/fXIU//rECDKOwmDSKtuak57GWMG09U05Cn0pGwAZlz+psmIBFR2uWbwAMSI6hI5S2J0P8PJ4CScMJZvQCwBIWISlaQeP7C7VeQPifFiFBY4oAMJ+EcmvgAG/SZKYAHjaJAEqqlpnI3YTbk3ZHTHCGIDpd68ViMy3Y1bwmeHYhAHTfB4BM4aLFQ3CUgr9aQsUHpOACUQKTAQiAmN6yV85clJ+Kk4HsFIDYEIAQMFnTJTC49WkUfjM8bvsBGEfxE4BkCKA1lBditXs/aooAZCiMcQkma2a2lyAyPoHl5UAU2NZEWxBVY8Dx65838pr4QeRSSg0PfNDs78q0dD8TVU1QByo5zUhLlv8TYgAzDqcSjlgXA6m0Awqd298iJcCIH2AmktNwzjm5vYBmDGWTjjvZU0mKm8zDZZMpVvouieOagXLisPsFRBRCMFsZeM+Ci1Ua06ofdzmcJ3H00oEmzkWrsw/IvyFWuLZByhmCgCAWB7lOMK1s2+VUGruQDDz7qqxpGNFzXEtm5ZckdfVPvsoGWLGca+uiAiT/craWfRaJKjC5+t+TjtTfb5rr71WXodxO45C44mnBhBDBUBoLm1yQdOMB/FkWiiguhrAPE9U7Q2I8gWi91Z/TuW56S1+qf6xilXcfy90yNcQhHZAFAChzSFTxjZrj9wYSoR6SkD0PBDqBNOt+WnpAzO+MtV5oQOFfxWd940EofmIAiDsB1WurSY7BJhNa9yOk2EzlIDq11BJECy/nWveUPV4eor/zP10GLpcidJswlyMRtceCkKTkAaXwpwwWfnN2Q8DSDmEpV02PG18AR1FXSFS5caPOvkRhfX90Vb9fNXfdLLwj3olaKDHVViWaW4zqmZXHQhCMxAFQNgvGICtCHsKPjaOe+a5BhthUROW5V2OUQA6cRKeJsinvVBnm+21WT6zwyAYy78vobA0UgAauL9KMyrGxjHPLATUEs+DIDQGUQCE/UYRUGxBE5a8rzvN9q/D/gjtWQR++eXOFPzVKJj1D5q1HgXBrH1hmlF19rEVFh6xygHQqCqRFhpL7TGO8tTQvNUAoyGs6nHxM10wz3X8ua8+tnvJu6iX6d9px6bm+xCAUgAs73OQdqhpoXhLmRUBOZx7Ou0wC/MAA6zjd23ESgEQWk/AwGghaMq+OJzhl3fZ8LUGwWrKftsHmvZjQRNeC77WGExbSFgEzU0IAQCYLGkUfBZ3qdBxyDUt7AdmmlVE8DTw5J7IGm+svkuheXdIlw1HEXTc+mwK8woB0Mw4NFyNstHWVnR5bxwvYU8+gG1R7Cw8QdgbMfMASC/g5lHbda/y022y2riyx4Glok7bYg4vHKZ3AiQyCyOt7DHTFjcpBuAoQFHVvBO7jopC44mnXBIPgLDfMDNsBTy5uwgADU+Kij7+0C4HfQmzSt7MXcbvphMODHP9EY7scwFUPESN3B9grvdSJ/aiEBY8ogAI+4Bm/DZebI4vXsGI9yUZCyu6HRQDsf8XMr4GelzCuoEEgOYVPIyXNIJp+QaidAqdgSgAQn3qTK4MwLUUNk2VkPN0ZfGaBqIZcBTh6P4ESkGdNdllLu5Qpp9YRUBJM5ZnbCzrMiGARsv/yMPw3EgRjqIFUIEiLDREARD2E5MAZREwVgiQa1JtfuSGPW5RAkHkhi0vySp0LHVKAIs+48g+Fym78RUA0T41A7tzvpkoyykJ4ocSOoN4JQFKDmBzqbP6qq0II/kAr4x7WJSyodkoBY0issJOWpxEslwJwDIJdzq1CgABQcA4ZXESgKkGaGQOCsN4HbKexivjHlylEF16lbUaBCEkkksxq1QSD4AwC/UnOEWEQsB4dbwEoPGlgFEP9uMWJbA0Y6MULISugEIFM7MGbBpQnbU8BaAJCYDhz51ZHyOFALYVPVdn4SZBiCmx8ADcVfW4tihNaD6aGY/uLuDtR/c2fF+RG7YvoXDsogRueTUL14qdoi0cBARCKdBYlrGxbtAkADZ6cR4OLf1nR4oYLQToTzllB6Qg1COO14Z4AIQ5wQAcS+GpPUUwN74UEDAKBwCcvjQ5SzlWHG89YX9RBBR8jWMGE+hLqKbE/yPP1hO7C9CghnscBKEViAIg7B/h/KdDV+zGMQ9TXgDVhEqAaPK9cEUaaVthxjowIv87jOknlMDwNOPClcb9r5uQjh8ptk/uKcJSe7vERDEQ4osoAMKcYJiyvJ05H69ONGdZYCtUMk4YSmDdgIu8p8MLVyR/R8LTH3ia0Ze0cOnhXQAA1WD/f5QAmPc1XhgpImFJCaDQmcQiB2A6UgbQPOodZ4algPFCgGf3FHHcomTDM7IBINAMRxEuPjyNh3cV0OUaV7DQiVQyfSwCJkoa5x2SwqoeB5qbEP+Hseu3T3nYlvXhWAQNBoHMcqSCMIN4lgHETwEQ+d9cakoBCYSoLfo923J4x9repjhBozDAG1d14UsPjyHQ0TRdPVBxx3YEVdccAfACxhsPz5hSQN14ZVNrhlKEh3YUMFYIMJB2qsJOBLnOhBkwYimbJAQg7IX6E51mIGErPLwzDy+cLBtNFAY4fjCBo/td5L2a5VljduMJszH9RPqa0eMqvOGw5rj/gcpVf++2XPi7+U8QOg1RAIQ5o2EUgI1jJWye8EypXhP2G2jAsQhvXd2Fgq9DV7BI/o6i6nRaBExF7v/e0P3fhCEoRfA04+GdeSRsZZIO68l/0QmEmCMKgLD/VE14tiKMFQM8sMNYSboJAXkVXq1vX92NgaQFb4bWIcpA52DOZcCMd63tAVFzsv+jBadfHS9h41jJKACzSnrRAIR4E6scgOjmlGm+FUSTHZtQFwMgwi0vT+HX1vY1pU5awcSAD+txcMVRXfjWU+MYTNnwq7tDyZwcYyp3toJpw3v8oiQuXdUFZsBqgvs/iv/fuTmL4UKAoYxVub7k2hL2QgxTAMQDIMwdIoIGkLIVHt1VwFRJl2P0Tdg5AOBda3vgKAorAeJ22wl1qTqNioCcp/H2Nd1IWFSzHG/jiBIM796ShT1jBUDRAITOQhQAYe/MMucxgKSt8NJYCfdvzwJAU8ryLDL7OWd5Cm84PIPJUlCzGJEoA3GHwCgEjCP6HPzGsT1mFcomzFRR/f+unI+7t+aQdizjdZzm3aJpPwQhzogCIOyD2eOfBEKgGTe+OGmealK3lGgvv318H7yAwxHy9BeFeFF17dhhn4n1a3owkLTMMtBNGEIQarB3bZrC9ikfrjQAEjqcWOUAyHLALaLWDcoMMBAwkLYt3LlpClMljS5XNSUMr6q8AOcfksb9O6QxUOwJzx2BUfQZh2RsvOeYnqatNwFU9nPji5PmMYc1/3WvK3EBCFXEVC7FzANQrQHI1rQt6vwDlJ8jMumASZvw8lgJ92/LgtGcTO0oETRpEz57ziDANddF7e+ytflWOV9Rl8kPn9yHI3qb0/kP4d4j9/+926aQdii8lqN7oPqdssm2ty0+xEwBENoKMjl5AQM/fmkCzSzLt8L9nrUshdcflsF4UTclTiw0gPCaoXDVv8N6bLzv2F4j/Jt0TiP3/8/L7v/Qm1XP+yDGv9AhyJQp7Aez5wEETMi4Fm59eQrDeR9KUdN14I+dNgCHUF7CFQAkeBsXKucpavzzeyf2YyBpGQHcpFEoMhUlG54dgxVpHbOGHkQDEDoDUQCEOULTJkaGqQZ4ebyEO16dAqFiTTUai0x3wLOWpfC+dT0Yzgew5YqOF+GlYhEwWQpwyuIErj6xr2mufwDQYCgCNk2U8MstWXS51vQlp0XeCx2KTJfC/lHPE0oEkIng2hZhw7Nj4cTdvBmTlEkI/JMzF+GIXgd5v6pvm3gB2puq82NW2wP+3/mL4VjUVOufw46S33tuDOMlDUsRptcdyAJAwr6J42wTryoAxDHNolOo34ORQQiY0ZWw8bNXpvD4rjxOWpJCwAyrWd0BAQylLXz27EX4jZ9ux1BawY/XqpwLGkcBu3IBrj6+F+cdkkKguSld/wBzRStFyHoa//HkKFJOaP0TAKoTzhI9QNgLcZt2xAMg7B8zNK+qmZAJFhGKAeO/nh6tvL9JRAmBb1vdjSuOyGAk78OO9JUoHCFaY3sQnYewlFTBdPxb1ePgT89cBM0ANcv3D5R7DNz68iReGishZSvjmOCq8r/ZrntBiDmx8wCIC6DFMFD2BrBpB8RgBBrIuBb+94UJ/MnZS9DX5CSu0GDDX5+/GA/t3IzJkoZrhb0BNCOsWxTagWn3sKn7/9xrhjCUNta31cShROGqbz81ClV29Vcv/ru3XgCCEBLPKkDxAAhzYDaXfugqTdoKr4yX8M3Hhs0SwU3szBM1Bzqs18HfX7QEeb923zG7MzuZMPZvK2A4H+Bjp/bjsiO6EGjUtHVuLAGbfha/3JzFrS9Poic53f0/AzH+hQ5DFADhAKlUA1BoJQUMdCUs/PuTI8h5uuklgRYBvgYuOyKDPzq1H8N5v1IVIPK/PYiEPwFjhQCvXZHGZ85ehKCJNf8VzJX79UeH4XN1zf9s/f5FAxA6C1EAhLlRbw4se0kJSUfh5bESfhI2BmpGZ8BqLGXyAT5z9iK8dkUaY4XA5AMAEC2g1ZjjrwgoBIyhtIWvvH4JFDU/z16zKf17abSIO16dRHfCQhC2/p2hCAhChxK/HIA4Blo6jqrsKOJpp4PZlAR+6YHdePPqXrOkKpqcCwDjnPjK65fg9Rs2YaKk4Vrh0sHUzNEI02Aun5+CH+CblyzHyh6naRUjNUOBIuAfHtqN4YKPRRkXPoe5ItPml/B3uWSEvRLPJADxAAgHQcVuq/QEIHS7Nh7akcOPXhgPY/PNvSmifICVPQ6++6ZDoJkRaGPxxez+7BzCa8BSwM6sj7+5cDEuO6ILvkbThb9mU2b48lgJNzwzhr6kDT9Mbi1b/zPGJBqA0HmIAiDMnX20SNUAUo7C39y3ExPFIKwUaC5RaeDJS5L4+9cuQdbT0KEFKg2Cmkwk/MkI/z84tR8fPL4PvkZLOjdGZ/+v792BiZKGZSnUdrg0iNAXOptYhQC0BkjL/N0W1NZGs3GtM5vGQBnHwsM78/j6o3vwx2cuga8ZdhPru4FKUuC71pplZT9y2w5kHMtUMJbdvUJjMSEiRxGGCz4+cnI/PveaxdCMlizeFDBDEeGeLVP49lOj6E3a8APsXdZLCamwL0LvP8esE5B4AIQDg2Y8CH81lpTPhL6kjW88OoyxYgBVr6taE7AV4GnGu4/pwWfOWoQdWR+OIvEENINwUnQtws6sh8tWZfD5CxYjCHWv1qhf5tz/3a92o+zyp5rkP5LWv8LCQBQA4QCpI/hRKQlkAAlbYdO4hy/cu7MluQARtiL4mvGx0wbw0VP7sWXKqwggUQIaCMNRhO1THl6zIo2vXbzM9GRCa8SrSTYEfvzCOG7eOIHeZCXzf289LgShUxEFQDhw6nkBohR8Mn0BepM2/vmRPXhiVx4WUUuUAALKveU/f8Fi/OX5Q8h52vSBJ4gSMO8wwCbksyfv49fX9eCGKw5Bf9JMN02OBEUjAoEwWQpw3S+2w1YKTBXBL9a/sBARBUA4CGbxAlDkBSBYFqEQMD571zYArZO10UgDBj5++gC+9LolmCoFCLQoAfMNcSXh73dP7MM3LlmG3oRq6hK/tURVIF99cDce311Ad8KC5tky/kNEDxA6HFEAhHmifi5AwEBfysYtL0/i3x4bhqVMkmCrRmiRyQl4zzE9+MeLl8LTjFIQJiiKEnBwMEOFmR4jhQB/cEofvnChifm3Uvjr0BvxxK48/u5XuzCQsuEx9iP2LxqA0NmIAiAcHLXW0zSjKmoRTMi4Fv7f3TuwJ+dDgVq6bKYT5gS8+5ge3PT2Q9GbUKZjoCgBBw4zbAUUA8aUp/HV1y/B58KEP0WtE/7h0AAAn71rG7I+V8r+9hr7b9boBKF1xEwB0JjecUm29toiwsflFsGMpK2wfcrDZ+7cCqLmLhRUDzv0RJy2NIlb3rEC5x2axO6cBwWGkutsbhtr2ASM5AMsSSv88K2H4H3H9ppSv5Zl+xuCsOnPtx7fg1s2TqA/aU/zQBn5z1WDrL6W2+DYyhazLV7Eqg8AgLge5w6n1nI2v1PYFwBM8MHoTzr4zydG8KbVvXjT6r6WtICtxgpDFIf3OvjRlStw3d278aWHR5GwCEmbMGNBQWEGFhiagd15H1cc1YUvv24JFqdts6xvi61oHV5fr46X8Nk7t6E7YcY1zfKvd46lY6QwV2KqA8TMAyC0LXvpC8BkEgI1ASnHwid+tgW7cz4UtTYUABghFcWn/895Q/iPy5ejO6EwnDeLCIksmEl0PGwCsp5Gztf4P+cN4btXHNI2wh8wOikD+PjPNmO4oOFYoW8nzE+hqDeFxP6FBUrsPAAxVLIWCDWikkKvABGIFZhMK96kY2HzpIcP3/Qqbnj7kSYU0MoAMczuGYCvGVcc2YXjFiXwybt24caXptDtKiRtJd6AKiwyWfU78wFOHErgry9YjAtXpMs1/u0g/KPOk3973w787/PjGOpKmHOoKm1/I+E/7dRK3b+wgBAPgDB/zOoFCP8hgs+M/pSNHz4/jr+5bwesMCGv1RCivABgVa+DDW8+BN+8dBkWp23jrQC3hWBrJQrG6h8rBGAGPnv2IvzsqpW4cEUaflhm1w7yMwiz/n+xaRL/5xfbMZBxjfCvrfkv0waDFoQWEDsPgNDOVHsBIv956AUATD4AKfisMZh28H9/sR1nLM/g/JXdLc8HiIhCAgDwrmN68NrDMvh/9+3B9U9PoBRo9CYUQIQ20FmaRmTVT5UCFAPGxYdn8NmzF+GUJUkAprdCs9d5mA0NQBFhd87H1T95FZalKq38iUBQFS1lRgVL675DtOdyh8rwngFCr+c+qlNM/63K+KP36/ADFtDlKswBUQCE+SVy/VeeABCFAggcegMIgG0pXP2TV/Dz9x2DwZTd0lrxaqIxBMxYkrbwpdcuwfo13fjiQ6O4/dUsGEB3wgrf07pxNhpFxurP+xo5T+PkJUl86KR+vPuYHgCAH8b628UzwjDVJbYifPimV/DqeAkDaRc+R3WI9UoSmj/4crNMGKHNzPDZhFVKAUMDCLRJYmQYhcbdh6/WZxP2iD7TDr9u0iIoItiqoiAwczk/QljYiAIgNBAybeHKToHQFAtbAicdC5snPPzGjzbixneuMRMTqG0cshYRmI0Vdf6haZx/aBp3bs7hL+8fxi+25OAoQrdrgaizFIFIoGdLGnlf46h+F3965iDWH90NR1FZeNjtcqJCglD4X3PXVvzohXEMZRJVrv/qhX/QVOs/EvgqFPaeBko+o6S5XCrZl1DoSVo4ss9BwiIc1uNgZbcDTzMGUhbWDbh1P5vDz98y5ePlcQ+uIowVAzy1pwgG4fnREnKexnAhgB9m3DoWIWERHFUZkwakBcYCJF4KQHV5ttDG1C8LjCx/ZgKgEGiNvqSD216exKd+thmfe/2KliwbvDeIAAuVsMCFK9I475A0bn01i28+MYZbX87C04yehAXHMqGBOIYHKDSSWQMTxQC+Zpy6NInfOqEPlx3RhUWpisej1bX99Yiumw1Pj+Bv79uJwZRrBF4k/CtNKVAVEzB/3IBSj0jgA4AXMAqBLnecHEhaOKrPwZp+FycOJXD8UAIrum0MpW30JeY3LWuypDFR0nhprITnRjw8saeIZ4dLeGXCw+5cgIIfwLEISYvght4CzRzLa7ilxFQuxUsBEOIDVYR+xU7h8HkFkAZgkgIXpRP48gO7cPySNN57/GDbKQFAdVjALDH8xlUZvHFVBnduyuGGZyfwo5emsCfnI2kppBwFS7X/REoEqPC8FEI3f8JSuPiwDK5a2423ru6GG7oDIsHfLu7+aqKkv8d25vDRmzch5Vio1PpXdf2bxvyX/REioc8oBIycp0EAhtIWTlqcwmlLkzh7eQonDCWwvMue9Vhqnhn3n5m4WEMYLojGEb2/21XodhUO6bLxmkMrbx/OB3hmpIT7tuVx//YCntxTxLYpH6WAkbIVUg6FfTJYPAMdTAwVALka259I4FdRZWUZ3SCaoI2QHEg5uPrGlzGQtHD56j542iwl225YofGo2YiWC1emceHKND42WsL/PD+JH704hedGisj5jKRNSNlGGYhCCZXJdG/X8YF8731/XsUVbcYRCX2bCIf12rj48F68c20PTl+WLP9lwAwFakvBD6CcPLp5ooS3fvcFFAIg5VpVDX9Q5frnGlc/V56f8zGviNuo+sELGOPFAEoRjuh1cP6hKZyzPI3zD03h0O6ZU23ARshTmPAX5QWUL/u5hCVmeS+H/5hrz+zLImAwZeG8Q1I475AUAGC0oHH/9jx+sSWPn2/J4enhIvI+I+MoJMOTbxSTAzlWQrsSUwVAlID2hytVALW/U/VLBIYGKULGtfHhm17BoT1rcOKSdFt6AoDpte5R7H91v4tPnTmIj58xiId25PGTjVP42StZPDNiYrCORUjaKnSzVprU1E/Gmp/rm8IkPiJjxXmaUfAYpUDDVoRVvQ4uWNGNy47owrmHpNEdZpoZZYWhiNqiMmM2TPycMF4M8Js/fAnD+QC9KQd+WHlirrMoXlFP+GP673PEUiZRb7KkEWhgccbC29f04Ioju3HuIany8YwItBmDAoDIm9Lg40vRvjB9X1ylFCgi9CcVLl2VwaWrMggYeGhnAT/ZOIUfvDCJjWMeGECXo+BY4hWoTySXWt3abG7ESgEwTmMR/7GiNhRQ1SAIUDDpRwoBa7i2hfGij7d893n88NeMEhBo08u9XYkUgcg6sohwxrIUzliWwp+dM4SHduRx1+YcfrU9X3azFgPzndww7morKrttI4vN/ODKoaulLOMqL5pDa/44YKDoM4q+LitSi1IWThxK4LSlKZx/aHqGkAq4YoFabW7lRRUj48UAb7vhedyzJYvBjFu1yp8yragr5vT0n1T93P5DZJQOTzPG8hopm3DOISm8e20PXndYBsu7KlNqEGp4isj8XRtdx1SjFEReLYRrJ5yxNIkzlibx8dMG8MuteVz/zDju2JTD7pyPrrA5VruHuFpB3A5HrBQAIe7sPR8gYEY6YWO86OHN330ON797LdYuSrW9EgBEbluqWPXRRBoqAwAwVgzwxO4iHtxRwOO7C3h+pIQtUz5GCwGCsIzLIjIhA5gQiKNo1klFM1AMTJxZM1f9vbHWDuu2sWbAxQlDSZw4lMCJi5MzXNFBqGGoNo3v1yMSOnlP4+0bjPBflHHhlcNKYa1/tXU9Q+DP7ctGgr/ga4x6AfoTFn77hF78+rpenL60OmRifpaPZxt7UKope7Vo+jXc5VY8Ay+MmTDXvz45jlcnPCQthYyrTBVB3CSfAEAUAKEZTOsNQNNKAyv5AAqARsCMTMLGcN7Db934Mn78rqPRm7BioQQAlTh79USqQyuwL2GVywkBIyy2TXl4ZdzD1ikfr4x72JnzsXGsBNdS2Jn1sX3Khx0qBNX7CNgkeB3R68DXwEDKwtH9LvrDn0syNlb2OEjVqdUru6JDoRYndJVy9cnbNuGuV6ewtDsRCn8gSv6br5I/grHcC77GSCnA4b0OPn76AN62uhur+01pnrGe2ztXYi7UXsNRi+fVfS4+dcYgPnB8H27aOIWvPz6Gh3YWkbAIXa6S0EAMEQVAaA61DYKq1wpAJR8AAHwN9KUcPLIjh7fd8Dy+f9Ua9MRICYioJN1Nd7NWJ2Ot6Hawotup+/eajYtb1RFYzGaJ5eQ+ivF1qIBEGf/t5oqeC+VGUUT42C2v4p8e3o0lXQl4UWwQCiA1i/CfRRnYC1Gb6tGcj8NCwf+B4/swVFUSWQ6ZxEyR2l+q812iMNdQysL7ju3Fu47pwYbnJvHVR0fx8M4i0o5Jeg00x84VvlCJnwIgOYAxpiYfoLY/AIwXAMTwNaE/5eLezVlc9u1n8bXLV+G4xe2bGLg/VLtZgZokwLCMK8oIB4xg6U9ae/3MyPVaXTZWnVWuqhSQOBN5UcYLAT568yv4rydHMJQJu/yV3fvzU+8fXV6j+QA9rsJnz16E3z6xr9ILQVcUuIVEOcwVJok6ivDuY3qw/uhubHhuEn9x3zBeHC2hP2nBUmQ8TQuFeOYAymJAQquoscimuW1NDNfXwEDaxaM78rj828/hsR052MokYHUCFevRWJu2MkJFUWWFwn1t0XstMv34qz+jU+RToEPhHyb8/cfjwxjKuAi4rCoZy79c+w/MSPqb8XgmBHMMcx5joqTx7mN6cOc7V+JPzxrEopRVtmwtRW3RsrpVRPkQDOMFiRSBu965Ep89ZxEAs2BUdB0K7YsoAEJzoToTcrUSEE7mUSzXZ6Av5WKipPHm7z6HR3eYFrztsIJgo6H92DqdKOwzUQzwtu8+j3s2T2F5d7KS8EcqvG4oXOo3pPbg7MMLYpEx3obzPo5d5OL7bz0EX79kKY4ecKcJ/oVwzPeX6vBAwIzBlIX/76xB3PHOlbj8yAzGixpFP74eu4WAKABC86mnBEQoqlhypABllIC062CiqPGW7z6HHz03Gi7dK7HGTsYPhf+Tu3K47NvP4t4tU1iUcVGK3Ptlj1Gt8K9RkfYh/G1FmChpMDOuO3cId7xzJV5/WKbc1lkE/76p9gisHXDx3SsOwb9fvgyLMxaG875pHy0Hse0QBUBoDXvLzFaocucaP2LAQNqxkS0x3vm9F/CtR3ebxCuOZ+99YXaMIDGW4wNbp/Cmbz+HR3bkMZCuKvWLFETQ9Da5M66r2fcThU/25H2cuSyFm96xAp84YwBOeL1Frwv7R+QRiBSnK1d34453Hob3rOvFeFGHCl2rRylUE7MkQFkNqKMg1FQGoJIMp8xMwkQgBqBMYqBrKziWg9+5cSMe25nF5y8+rJxwFNfsdqGCZrMepEWEf3t0Nz528ytQSqEvZcPjik7IVYmOJg8werEmyRRA7XzBMFZ/wdcoBow/Pn0A1507BIsqIYeFluA3n1Svm7EkbeHrlyzFBStS+JO7dmGiGKA3YZXzeDrnMFdn5sSHmCkAcTzEwl6ZpTyQAePW1RpMMA2DlEagTSnbYMbFPzy4E8/szuNbVx6FxRkn1hUCQkX4BprxiVtexVce2Im+lAOlVJjtT+Aqy7/8O1D+OS3jfxZsRRgrBFictvB3r12KtxzVVS7RFCVy/rCo0nL419f14sTFSXz41h24f3sei1JWedGjTiJmRQASAhDagdrJuzIJ07TsbhU2J1EImDCUdvHzTZN4zb8+hTtenoCtKKyzb/oXEA4CRiXe//JoEZd9+1l85YGdGMy4IFLQ1Z39qt3+s9X6z3hcecYmwnDex/mHpnHbrx2GtxzVVU4oFdk//1BYoeJrxvGLErjpHStw9Yn9GC0YUSnHvLXESwGojgDI1jkbAHBU9xb+jGq5gUqJFxTCBAGAFHxW6E062Jn18ebvPIu//uXW8spsC6oGOcboUFuzFeGHz47gom89hV9smsSitCnz4+h8h+fepIiGHoDq66R8/VQ/V9miRYF3ZH383on9uPHtK7Cq10EQeo1EDjWWSDnPOApfet0S/OPFSzFV0vB8NmsStHoOmu/5LCbESwEQOpcooFv+BdM8AZUOb5ESYCR9AIWkYyHj2vj07Zvx9u8+h11Zz7iSpTVpWxPV92sGPn3bJrzrey9gsqTRn3Lgc1gOqoDofFPZCxR+QD3Lv06quUVAKWBMlTS+cvFS/O1rlyBMMRGXfxOJelsEDPzGcb3437evQHdCYaKkJXTXIkQBENoLqnlQUzJIFJV8VbLBNRQYCku6EvjJC2M4/5tP4n+eGYEVrsIm3oD2Igi1MksRHt6excXfehqfv2cbepMOXNsywl9FZXwHL/zzPiNhEf7pkmW4+sS+aQv2CM0lqhTwNePCFWl8/60rsLrfxXgxECWgBYgCILQZNLsSEHoJyk1fqDo2TPCZMJB2sTsX4N3fewEf/OFL2DFlvAFRT3yhdTCHiX5kGjn99S+34uJ/fxr3b5vCUCYBjdp4P4Wen6rQDzAn4Z/zGT0JhR+/YyXedUxPuGJiJ2WfxxM7bOZ14uIE7njnYThzWQrDeR+OKAFNRRQAoQ2pk8xVbu6CihJQ7gQXWozK5AUkbAsDKQfXP7EH5/zLE/jnh3aWe+IHWsICrcD0zzdW/+0vj+O8bz6JP7tjCyxl8jh8pkrhfbkJVBj2qVYK5yj8exMKP7xyBU5anJAqkTbDDvst9CYUvvfWQ3HuIWnsESWgqYgCILQn1VneqBICNF0JmLZ+QNg0SJNCAIXBtIuxosbv/+QVXPHtZ/HQtinT1S10QYoe0Hii8IulCDumSvjIjzfiyu88h6d25zGUMSV+AVTFo4OKZ6ei5AHlkA/CxxF1hL9dLfzftgInLk7A1xDh34ZEjYNECWgNogAI7c0+1g4oewBqwgFQCj4IrmVhMOPgZy9P4OL/eAafuvVV7M555cxvyQ9oDFECpqUIXsD4p4d24px/eRL//PAupFwLXQmT6MdkVSl7lfNHUSgAmK4EVF8DNcKfYVrSZquF/1Ak/Jv33YW5oWZRAmxFoqQ3mFg1AtIAiCEu3AUDozzhz3bOq55nUgDrqhcIDILWGn1JG4HW+Lt7t+N7Tw/jAycvxkfOXIaeRGWJVyXlYAdNUNXJDwCuf2w3vvyr7XhkRw4Zx8KidLiEb611j0jwm8cMVE7/tHPPqCzzW3V9wOQW5PwAPa6FH14pwj9O1CoBb/vBFty7NYf+pOka2PZ3ZlgCGDfZFCsFwBDDYkvhIAjPNWHvdxcRiI1wmC4bzHMBA0QKizIORgoBPnP7Znzv6WF87Ozl+LXjFsEJe79GpWmycMn+wwB0uYWuOXB3vDyOv7t3G256YQxJx+RkaKDc0W+Ga7/a5R996oyTwNNfr/qpCCgFGkmL8KO3HVrl9m/kNxfmk2ol4H/eeigu/+9NeGRnAX1JFYPVP+PZCEBuDyE+7EdeQDlrfFqVgHnMpOBDwbEUlnW7eHG0iA/88EWc/80ncP1juzFZDMo5AoFmqRrYBzrM6icgrLRg3L5xDG/9r2fwpuufwa0bJzCUcZFxLQQg4+5XqpLoB6t8vqa5/KsXgtpHvB9V78gHjL9/3VKcuDgZJvw17KsLDUIRyomB37h0ORalLRR8lpLNBhFDD4Cw4Jm2fkDoI65+LlpAiGA6yTFXZAmbsIDHGinHQsax8NTuAj74wxex6ucJvO/ExfitU5dgKOMAMH+qWbwCEYxKOaUVKmSlQOOGJ/fgq7/agcd35cwEnnRAAHxQRRED6sT69yfLv+b3GiwFbJ/y8bVLluGqtT3wNEsSWYyxQiVg7aCL71+5Aq/9zqvwdbi2QKsH12GIAiDEk1mVAFQeg0BgcJQ4wmySSACALGjW0MzIuBbItbB9ysef3bEZ//LITly+uh/vPmEIZx7aXXZrB5rDQoO2j0jOKwyAq5L6ouPxwnAe//3UML739DCe2JWDayl0uTaICEGVkJ9m0c8m+IH9zvKvxlbAnnyAj502iN85sR9+hwv/WqdUpyqlUbOgU5Yk8ZWLl+Lqm7ej21Wxi7G3O6IACPFlhhIAVEz/et6AKKMsShQ0zWU0a4AZCcdC2rEwktf4xwd34l8e2YWLj+jF29cN4g1H9WNx6BUAOl8ZqBX6FMbsi77GbRvH8KNnR/D9Z0cwkg+QciwMpN3wyNYT/Cg/phnPo77gn/Z8fWwCxgoaF63M4AuvXdJxrX0jb0vZgUU0wxUenafwcuwoT5VpFgS8Z10vnhsp4S/v24MlaQte3Jbca2NEARDiTTTb1fMGRM8TAUwgimr/q8ICYPM7MZgZPjMcW2GR4yLQjJtfGsf/Pj+KVX0JvOHIPly+ph/nH9aL7rB6AAhb27KZoMu5bTEkCncA04V+oBkPbpvCjc+N4OYXx/D4zhwYhJ6kjaEus6zrDIsfqG/11xX8wLSjtg+XP2BixYWAMZS28E+XLJuWKxp3mM01ZUfelqovNVHwEehI92X0p50ZioGvudz4Ku5Yynyfa84dwgPb87hrcw79CQVfPAHzgigAQmdQzxtQnRsQChViMsK+NiwQPg8YJcFnY89Gsew9+QBff2gXvvnwLqzqT+CiVb3TlYGquTbqLWDm7va0yIzlaIQIgHLyY+Te9zXjoVDo3/rSGJ7enUfO10g7NvrTDgCantVfLdwP1N0/7fl9k/cZ/375MhzW4yBgLo89rkQKmKUINpmkyodencS9L4/jly+NYTjr4dldOXiBEfBaA0ctTqEvZeOsVb04/4g+nHZYD7qTldLWel6DOFHt1fjaJctwwbdfwWRJw7VMe2/h4IiHAnBn+DNaDhhVPwWhTGj9c83v5V4CFQWB2LxWVgTKJiRVvAYgBGFxr2tZSGUsaGZsm/TLysCR/QmctCyDS1f347TlXThqMDWj41y0DkFk2KpQGDZjXo5SIhjGlcxA2To0X7Eyis3jRTyyPYubXxzFg1un8MyePPKeRtKxkHZsdCXMpGsW06EwuS96XC3QI8GPULGiymCqH9ez+vfjvrYVsDsX4E/PXoTLj+zqiC5/UaKpRYRdkyX8x/07cP0DO/DI5knAC8xxUwSylTmE4WW9+8UioBk3PbILsBQOG0rhqpMX4zfOXo5jl2UAhOsvxPj4mMoAxmE9Dr5y8TJc9cMtcNX+XStNI34VgADiogBUEdPjLDSNULLO5g0ApnkEypZ/qAhw+bWqzzPis+weTzgWUo4FBmPLpI8XRkbw3SeH0Zu0cGR/Eqcsz+DclT1YN5TGkYMp9Casuu5YXSWYyyOtimDsT3ZBFAOu1XGmxYyjz6r6uJynsWm8gOf25HHf5kn8ausUnt2Tx56sDwaQsBVSjo2Mayx9ZsCrZ+2XP7e6LbP5nffH3T/jtb1jETBW1DhvRRqfPXco9sINqAjoiYKPv7ttE/7pF1uxfU8ecC0kXAUrYZXnvNrSVLLscthJA3h1tIjP/+RlfOWuLXjXaUvxqUsPx+qhlFFAY5yvYhaQAi4/sgt/cOoAPv+rYckHmAdipwAIwn5RNzcAmFURCN9DYS5A+b2o+vtQsdBVyoDrWEg6kctV4+k9BTy8I4tvPLQLaUdhSZeDNYNJHLs4gxOXZnB4XwKrB1PoSlhI2aryudPGPoevWf1d6/xtwIzxQoBXxwrYPF7C4zum8OiOHJ4fzmHbpIeJYgDNgGsppByr7N43CWhRGV/VVt4PVXZWndxXO54Zv9ex+ufwXQMGEhbh71+31JSL7Zea1L5Ewv+el8fxwW89jWc3T0KlbaR7XGhtBL6/l9R3nubxAhI2wepx4QeMf/n5ZvzPIzvxhfVr8IGzl5sQA+K7DLKlzPn/9DmLcMsrWTw/UkTGURIKOAhipgBEMQA548J+Upb7tdcMz3wtsmSj11Hdi7y22sCEChgcrm9vFIu0a6HLtcrd8XZlfWyemMBNL45BkRFegykHfUkLK/sSGEjZOHZxBoFmnLAkg96kBV8zepM2juhPTmt2WzN6EICdWQ/bJkqwVSVu72vGlokSXh4tYDTvY+tkCeMFH1lPI9CAYykkbAXHIgykHVAYz2cAQfm4RUI/+s7R9w7/iazJskegdnSYqQjUfW3/72VLEXbnfPzlBUtw/FD8V/eL4v1fv3sbPvLtZ1BiINPrwtcMPziwOY4Z8AMTbkp3u5j0ND74zafw0KuT+Pur1pj++jzLqWlzoiF3OQpffN0SXLZhE9pHFsRTLsVMARCEAyQKnE7LDwBmeATK7zXvN65zLgv7mg9FWZEIvQk69BBEn+vaxkNQDiQwMFnSGC0EeG64CM2MQO8Bg+FaBAWT/JV0FAbTTh3FZfp3miwGGC/4sMKJvRRoMAgWAZZSsBXBsQi2ZWPAMepNNFWZ7P3oe9A04T7tGJWfNz9pRry/9jjXHuPZXt9/FAGTpQCnLU3hD08biHXJH8NY/rYifPi7z+GrP9sEN20jFS6cNF/78AOGZRGcLgdfvW0Tntw2hR/87onoTdlgjqcnIOoPcP6habz/+D784yMjGErbMWgV3J6IAiAsIGrzA8LnAMyuCFTeF/kDuK62XxW8jz6DUOUhqGBbFhwbSNeOgCsqhmbGSD7AvrCI0Jdyy79HuQbTghhcbd1XCW8V/qwJg1TkdpXQr33f/rr5675+YPga+MsLFsMJ15GPa6ffSPh/4gcv4qs/fQXpvgQC5oasTBmVFGa6Hfz86WG85WuP4a6PnWr6C6A9K1T2hVImGfUz5yzCjS9NYqwQwJGVAw+IuN5DgnDgTHNvl5+sbDNej34P16mP+tercN2BaWsOhO9VVc+psAc+WYCywEpBQyGA6Zjng+ADCIigQWEzHQXHtuBYe9lsC8pS5b/R4ef44ecGIGgosFJV+68eT701EyrfNfp+VO/18iGr9RjUUQwOUsrYijBaCPDrx/biwpWZsOTvoD6yZUTC/z8f2IEv3PQyUqHwb3SHOy9gZHpc/OKZYfz+hufLazfEEQWj0C5O2/jMOUOY8jQskWQHhBw2YWExzXivEVjRa1yjDEz3cYdblMCnjH1MKnSNq6q/VVW/z1ycCGSFW9VjZZVfZ5gFjGbdYLaKklHn88r7UjXjicZXeUyRcoNQ6KPm+8w4BlUbU41TpErwM1DXabIfEBvh1eNa+NOzFoW5D/GU/lHM/4ltU/jQ9c/Aca1yt8Vm4AWMVJeLr9zyCv79VztgKWqI16EZRCsHvu/YXpy6JIXJohZhdgDE75ixbLIdxBYx7fc6lisDRqjVCLoZru5qQV+xmMsCtNpyLgvUaku76rnyawewzfiMep9fPZ6a8U57Tx2hT1TzXJXQrz6u1e+Z8drcz5elCGOFAH98+iCO6HOhdTxXhouEfMnX+OB/PoPJQgDbbn4GOzPDTdn4/f96Fi/tyYeCtMmDmAfCgBtsRfjLCxZXjmOr55eYlSXGTwEQhEZRr9yt8mJlq37fNO/3dAFLtZuK3OrVXgAVdeaZ8fdz26r+XtWOg6aFLMq/T9tXzXenesejVgmo893n83QAKPgah/e6uPrkfpO4Fkfpj0qjnxse2YUHnh9FOu20xPrWDNiOwsRkCX9x86sgotgusBOtGnjhygwuWdWF8aKObWioVYgCIAj1qJsnUH5x+lZPIZj2GdVWd+Runy6My/F4VUcg78+mKn9fq3jMDD3UxPLrfe/pmk3V79VP1753frEUYaKkcfVJ/ehPWgiibooxI8q4z3saf3XLq1CuBa1bZyr6AcPNOPjOr7bj2Z3ZMB+gZcOZF/74jEG0W3PAOBArBaC6C4BssjVnMx3tzDbL6+Wt9v11/oZqXzfx/JmW+FxDAJW/qeQJ1Oxr2jjqjYVqvs9e/qb2tXneACAfWv8fOLGvvCphHIm68N3x/CieenUCbsJqucC1FSGX9fCv9+4ojzGOWGEuwLmHpvGGVV0YK+qyItCqLU7ESgEQhNZC+7B6qf5W12rfj33MdZvl48zP2vfWs/Bn+U4NtvTrYSnCZGj9DySt8nK3cYRCgfT1u7ft/dQ3kYAZKmnjOw/twETBLzcIiiPRsD9+xiAsFT8h3Epi2AcgjnqW0HHUzuI848G+P4D2473RW2gfz+11P/uzg9n+pvn3GsFkrPcnFdav7QEjdHLEEOP+J4zmfNz90hjItdrC2mYGXFth0+48Hto8iYtW95sqhXnO42gGFpnvc+byFE5anMSjOwvocpsd1ojkUryyAGN6WwlCm1E2ovdl4df9o1m26Q9n/NmMz6j3mXMdd+tNVEsB46UA71rXi8N7HWiO70QVCftHtkxiz0QRrqXaxtJWBCDQ+OWL4wDibVZpmLDGH5w6AE/zfOejdizx8gDIUgBCbJhtBuJpPw7sM+b4ftrLe9rwXgo0kLIUPnBCf6uHctBEh/fBTZNgT0Ml0fL4fwQDABF+9coEgHi2Bo6I4v5XrO7Gmn4Xmyc9JJrZHTCmSQBxVawFIabMkhcwr7uoF+9vbgz/QLEImCppnL08hROGkqbnf/sPe1aioe+aKLXd4WcAZBGGsyX4Op4VFhHGmcFI2wpvP7oHUyUd26TRZiIKgCC0Awea+Le/yYBxgQBPM957fF+521uciU7HY1sngTbrV8/MIFvhhd05TBaDWPcEACrrYLz72F70h6tqCntHFABBENoCAlAKGEszDi5Z1QUAHdPjvZ2T6xTFtbnydCKF8eiBBE5bmjJrBHTCF2sgHXJ7CYIQdywiTJU03nRUF4bSdmwb/9RDbNHmEBn97zmu13gAOuUCahDxSgJELPMsBEHYDzRMw5y3H90bPiOztzA3Io/Rpau6sCzjYNILYFPzQi/xKgKMoQdAhL8gdB4EIO8zjuxzcdbyFIB4Z6ULrYFgvABDaRvnrUgj68Vz8ahmETsFQBCEzsMiQs7TuOiwDLpchSDmWelC64h6L1xxVDe0ZognaXZiFwKQGIAgdB5MRuC/5tC0+b21w9knzEbQROOczcqMhFG7fx/NbL7PLGFzZrOZQhNqa6s6WjHyjGUp9Ccs+Fqj4WmOMe0DEDMFQDoBCUKnEbX+XZy2ccFhRgFoxxpuBqDDLnOKaL8y+6PSNLsNv08EAehK2Gassw2zTv8orc0Sx+1W4KBglJUj+lycuCSJu7dk0e2qBpeUxlMDiJkCIAhCp0EE5D3GKUsTWJx2ypZmuxAJO0tRWTEZyXl4dMsU7n95HHuyHp7YOgWqM2gGg0B4dMsk7DZZByCC2YReJosB3viVR+sqKURA4GusGkrj0L4Ejl+ewWmH9WBFf7J8LII2VAQCZtiKcObyFO54dQqKqK2OfbsgCoAgCC1FEaEUMM5cnoIiwNcMu02kiWYj3CxlxnjzU3vwr/dtxz0bx7FzvAh42ljHSmHWhZXAsFwLVhuuuEdh46Xbnx7G7IMjgIcRtWXs6XJx4vIM3nfWMrz5hCEs7nYBGEWgXTw3kTJ27iHp8Li32YFvE0QBEAShpXBorZ17iHH/17OkW0Ek0HzN+M/7d+CLt2/CY69OAAQo10IyYUMlzXv3JV605rZ1DhOAVGrvooDCf5iBnKfxixfH8ItnR/HZwSSuPv8QfOiCQzHU5baNEhAN4eSlSSxO28h5AawmlgPGBVEABEFoGQRjgQ6mLJy81EjTdpD/vjZKyaNbpvChbz+De58fBVwLqYwDoJI01yndZoM5fBGLADtUfnZmPVz7/RfxjV9uw99dtQbvOHkxNJuwRyvPI8EoK0syDtYMJHDf1iy63PbzwLQaKQMUBKFlEAHFAFjZ42IwZYPR+kkpih9/677tuOALD+LejeNI97hIuhYCzQg0L2hBwjAKkK8ZjkXI9LjYOlnE+q89jo//zwvlfIBWHyMTvgHWLUqgpLltPEvtRKw8ABphhmerByIIwrxR9BnHLErAtQhBC1f/q072+8T/vIgv3PIKbEchlbLhBzLr1IPZVHAkbAuwgb+56WU8vT2L6z9wHPpTNjS3rqFTdMZOWmxWlQQ3XnbE7SqJlQIgVYCC0FkQEbRmnLjYuP+5hSUAQej2/8gNz+MrN72MVF8CmnlO7vGFSpRhn+l2cdPDu3BZ7lHc9tGTkbQVmFsTDogs/uOGEkhZCgE3UAOIqVxqtbdNEIQFDDPDtgjHLkoAaF0CYCT8/+XebfjKra8gHQr/Vrux44YXMLr6Erjv2RH8wQ3PQxEZwdsCIs/DUQMuBlJmeWAJAkxHFABBEFoCAfA10JewcHifSa5rhfzXbNz+v3p1Ar/7n88gkXYQiPA/YEq+RrrXxb/ctglfvmsLbEUt8aJEiYDdroUV3Q5KQXskmLYT8QoBAIitr0UQhBkEzOhzbSzLmKmo2fNzJOTH8z7e+29PQTPgtEhgdRKBZiS6XXx8w/M478henHyo6cuvmpwQwAASFmFJJmoJbKEx8iOenQDFAyAIQksgIhQDxpH9LhK2adXabAUgavTz5bu24PlNE0gmbRH+8wCz6clf8gJ88vsvmidbYH1HDYDWDSXMAlMNHUP8rpt4KQANX9FBEIRmES3dmrIVnBakikdCavdUCf9w52bYaQeBjtuK7u1LoBnJlIPbnx7GHS+MmnyAJitX0d56XKtZPRtiJaNipQAQw2v1GARBmD+0Blb2mvh/s+2ngE1S2PUP7MTO3Xm4tpK4/zyjCNAB4+/v2GyeaLJ4jCz+FT0O7Oa0Yo6VjIpHDsCx4dzAdD9KJYDjpbgIgjATImMlHtlnesk3uwTQIkLJ1/jWfduhEkoWi2kAPjOcpI3bnhnBC7tzWD2UbklvgCP6XNgqvMYac5oZygEYvwp/VzCF621NPBSAkIDJa1QKhyAIzSW6j3Ne8+fJKCHtie1ZPL55Eo5riwLQCBhwLMLUZAk3PTWM1Remy3kXzaTgawS6PKSGETcvdbwsaYviNV5BEGaFYSzBwX0sRNMIIpXj3o3j0F7Qsu6DCwEGQIrwy5fGATS3FC/aVW/SQtI2nSYbCat4yahYDZaCwAdLiq4gdAJRE6ATFkdNgJq372hfd70wBsgqcQ1FMwOuwgOvTiBbClfla9IBjxpLHdXvYlHabngzIPEANIL1RmH3Kf80+8UxKEfJAs+C0Bn4LbiToyYxe7KluMyCsYaIMFnwkW9BuAcw1SYNlhgKXgkB2fcBqOSttTmxuvQtzw2Y2Wr1OARBmD9a0fxHEWGi6OP5nTkox5L4fwNhBlxLYXTSwzM7sgDQmcebFOD7rR7FnIiPAsBM3e5UAcAWsixAvHaCIBwEzIAnEcWmES0h3HkwgxSxX8hbjr0VAPBUPORTPBQAIsa1oC1/fE6emHfCsqrqOWSTTbZ4b60jHhNg59Da492g65fZZDn6pSLGyCgA17b4wt5PYlUGCABgjAHU6nlDEIT5oIX3MQMtW6luQcItON6MSoypWt+c12EQm3oWNUHpgAGOTU1JnBRgM1YOnoByJAQgCB1Cs29kIoCZ0Z2wsHooDfZ1y5YhXggQAb5m9HU7WL04Ez7X/EWBGvfhzOQ4AHjj8KeOmcQ1IBDFQj7FSQEAABDUKDgAZGlnQegIWrIOAABbEQYzLjiQyaTRaGakXQv9qdas+mgrgmqk45gIYIw26uMbRXxCAGFZReDgUeUHYFkYSBDiDRF8Dbw8VsLZh6SbuuuoHe0Zh/fgxod3yGTSQBQRdMnHccu7kHatpnYCjCIA2yY9jBU1LEXz35+XwFA2NPjx8JlYtAEG4uQBCLMqVZE2sleYAlkkvQAEIb4QTEvejWMlAGjqQjyR+DnvqF7AUs1aKW5BQgAQMM49stcsDtTEY82hzb910sN4Mez4OP/7J/i+CU8DsekBAMRJAQizKhVZo+AgByXNOwWhE0jZzZ+GIgv01BXdWDmUQsnXTe1EuJAIGLATFi45ZgBAa9bLTdqqge2eiaADrZS1vVF7aBTxUQCIGNewGs59J8tMz5uki3i4WQRBqA8RMJwzzVOaKRiixLSepI13nroUuuDDEg1g3rEUoVTwccYRfTjjsF5oZlgtyPkYzvvQ3IBrjJmhLKW9/FSJgxcBlDvXxoH4KAAGheuu04B+BOQAFQ+PIAgxgzWgFOHxXQUAzc8Mj7wA7z97KdIZp0Ob1LQeDhhXn39IWH3R5H2H+3tiVxG+z424xpgsF8T8YnZqdATMsakAAOKUBFgFEb0wTfDH5nALglCGTAU1g1sSg1cEBJqxdkkG7zxjGb55xyake1z4jV4yboGgFKFYDLDusG6889TFLVkGOEJHF9h8955ikwAI0Mu47iIfT7MFIJjHPTSUeCkAYXIFAY/ALwDguHkwBEEI0WAkbOC54SJynkaXq0xTtSavCsjM+P8uOQz//eAOFDwNZZEkBc4DCoAuBfi/bzoSrqUQaIZq8owdKRyP7MxBRQ1k51MDIDZfioNHAADr4lVQEi8BGsZWvMnCs+wV9siqgIIQbywCsiWNsYIxmpp9Mysywv7IRSl8+V1rUcr70hRoHrAtQm6ihN9+3Uq87aQhBLo1sX+CyfUYzpsKgAZcXwp+QbNt3QsgVhUAQNwUgDARcOq60/Yw87PkuIAkAgpCLGE2DVr25H28HJUCtmD+tBQh0Iz3nbEUH37D4chPleBIkdEBY1uEXM7HmUf344tvX42gRa7/yJuULWlsHCshYdH8Xl/MDGUrXSpMBbpgegDEKAEQiJsCYAhbAvMjrBwwoezUkU022eK1ERGCgPHscBEAmp4kFqHIKAFfXr8G5x8ziOyEKAEHgm0RcvkAi7ocfOe3jkfatUBoblgnIhL2r457GMn7sJQRFvN4/TJsF2C8MDU5ORa3BEAgjgpA5GKx6HZwALSmrFQQhHmCYWK0ANCqBp9ERhlhAD/83RPxmnWDyE56sBRJf4D9JLL8D+l18dM/PAWHDyRN3L9ViX+hKH5idwFTYRfAeZXOBA3bBcC/xHUX+bgW1nx+fDOInwIQulgsSjzAxVwWZFmSByAI8USzERxP7S7A14wWhInLKDLWRH/axm0fPQUfet1K5Kc8BAHDtqT3+GxYYZ/93EQJr1nTjwc/fSZOXdHdspr/Wh7bmQfQEEuREASAsu4EELv4PxBHBYCIwUwj9z22A1o/Q3bC+Hpa7cuUTTbZ5rwxM5KKsHHUtGptRa14NRS2qrWI8JV3Ho1/+cCx6HYUcpMlMIyyIh4BI0xtRVCKkM/5KBQC/PFlq3DbR0/B0m63pZZ/hAo9Ok/uysMiAmvM37WrmQHL4kIua5H9AIDYxf+BOCoAAHAtLGy4KgDjHtgJ44oRBCF2MAOORdiV9fDUbpMHoNFCDQDGEwAyc/wHzl6O+//0THzwNStgw1i5RZ+hFMFWFFq/FIYQZt/anX2NX5H5rtF39pmRy3ooFHy84bhB3PZHp+ILb1sNW5mqilZb/szmPI7lAzw7XETSpvm+rjQ5CTCC50bue2xHHOP/QNz6AERU+gHcCr/0+4irIiMIAhQRSh7jni1ZvGZlxngAWiw0TeKaSQxcPZTCN957DD72+pX41r3bcMMju/Dq7jwQaCNlFEHZyliGs4zbovb2HHizNT8Kv5MOtGnqrxlQwEC3iytOXYr3nLkUF681Pf5NnT+1NIwTocGwQHhidwFbJjx0ufO84BOBYTkAcBs2XBXgWrYB+PO4h6YQTwUgdLWw6/8SpdwYlNOPwGtIn0dBEBoLM6Aswj2bs2Cg5a7jaqzQomVmHLssg8+9bTX+7LIj8OCrE/jFxjHc9/I4xvI+XtyVN/1gZhEyU8XAdBhsn69WhggYzDh1h0YE6ICxvD+JxV0OjlvehfOP7MPph/fg0L4EAPOd2yXeHxEpkfdsycLzGSpBxms/fygEHiignwCIZfwfiKsCEPYDGP8oxns///i95CYv43xJA7Da8g4TBGFWNBgpG3hiVwHjhQB9SavpHQH3hgrr2DSblsXdSQsXHd2Pi47uL79nNOfVtT+i9rdv//oTuP3pPUilHARt0maQyFj+g2kHD3zydPSm7LrHnTWjN23PUMyi72EparuFlKKx3rslW9UBcD4ItUHbVVzM7VCUeQRALOP/QFwVAIMCkU9/9dgNAC6rPN0eN5cgCPsHM+BahC0TJdy3NYtLj+wpu3DbCUXGvR1ZvMZbYUIF/Wlnr3/rNKgN3XwQeQC6EnuvYosUIEIlJ6AdieL/26c8PLQ9h/R8x/8JAbkpW/vFn47+yZHjuIEtEMWm/3818Y2dX2sWXLDIvVUXp3JQUg4oCHFFEcEPGHdtygJobSXAviBCOSFOkSkPZK6/BZrLj9sZLzDj1HqW7wJzjqIkwDYz+KcRCfuHd+SxbdKDa9N8H38CayhyfjCvn9oC4qsAhGGA4VVP7ITWT8BJIkxRaXVlk2yyyTbHLWCG4yj8bOMkSkF7xZP3h06vAojBV6jAZrQ/eWEybBNL83etMjOTbQXF3ITFhdiW/0XEVwEwKFx1VUBQ34PlAoD0A5BNthhuWgNpm/DErgIe25kHwSgFgjAXmAFLAZMljVs2TiBpK3Mdzd+1qslNg3z/7uFPnboN17CKY/lfRNwVAG3+8X7Ahck8SEkYQBBiikWEoqfxo+cnAKDt3eZC+xG5/+/ePIWNoyWk5t/9b1Dq+uhRAz69acR68LiONK5hNfmpU17QgXc7JTKArA4oCLEkYEbSUfju06OYLGnYqkGTdwto5zBAGw9tzkQNm//10dHw2pnHb2ey/y0uTG5P5NQPAZRz0eJKvBUAgwIAS9F/Q7Vxqq0gCHuFGUjZhJdGSrh78xSA1ncFnC9Kfvt+Dy9MVIw7Ufb/jikPP980hbTbiOz/NMD8s93XHTcVZv/H+sjFXwEINbDAC37M+Yk9sFwlYQBBiCvG6v+3R0fD3+Jtn0YT0VFDqbazTQgEDjRW9CWRclVb9V44EKKckf9+Zhw7JjwkLDXfio2CXwRZ1r/N66e2kPgrAESMG9ia+vQpu5mD71MiTaB4u2UEYaGimdHlEm55eRIvj5XCxXnaTHLOgWjohw+mAM1tpc4QARwwlva6SNoK3G4ayhyxiOBrxvVPjMJxaH5b/zJrOCmli/mnxqd2/xzMhKviWftfTfwVgApEzN+AX9AAddL3EoQFAwNwLIXRnI/vPDVWrrGPK5HAX7skBVjtldNAAKAZxyzNAIj3cQ6YQWHr34e255Bx1PwqjmQW/4Gif8V1F/m4FnvvmhQT4twJsMJVFOAaVhN5PNjNjz6skl2ncSEbgKgjTpIgLCQCzUg7hK89uBu/c/IABtL1W9TGgag98FmretHT5SLnaVh7WTOgmZh++YQL1/S1eigHDcHU+n/hnl0IIk/LfB1kZoZlW5ybyCY8+9uTgAk9Xzc/H99KOsdSPhaE60gD6itMqtVlzbLJJtsBbpqBhK2waayEH784EeueACoMYSztcXH8IV0ISkFbLHZEZJL/+npcnHFYL4D2WoRpLujQ+n9+uIjbX5lCxlWmAyPm65pkDTdNWvv/vecz67ZjffyT/yI6RwFYDw0wpW3ewIXJnbBd6QkgCDFFM+DYhC/9ajdKgVlQJ643s2YjXN9/9jKw3x5VyhYR/LyHK04YwrIet+xCjyMME8744v27kC0Gpnx0PndAihB4UCr5DwCA9fP54a2lcxQAIsYNUDs/cVIWTF8jNwWA2+NuEwRhTmhmZFwLD23N4b+fGTOWdJusojdXrFB5eesJQ1iyKAXP1y0XtpoBshQ+eM5y80Q8D215tcUXRor49hOj6Epa8OfzOmEOyM0QF3O3T+TWPoxrWHVC8l9E5ygAQLkns9b0j1yYykLZUhIoCDGFQy/AF+7dhVLAoJh6AShUXgYzDj5y4Qr4eb+lax1YilDIe3j9cYtwwVF90By/tRciIuv/b+/bhYlCAKcR30MpgmX9Da4jjWPbqpDjoOksBSAsCcx++oSdHPjfo2QXiRdAEOKJKQm08Mi2+HsBFBE0M37v/EOwbCiNYjFAq2RulPz3Z288vPJ7DNHMsELr//pGWP9gDTeldH7iuUm77w4wU5wX/qlHZykAALDeGAlkqb/gUr5ougPG0nAQhAVPwIyUq/CZO7ZjJB8YL0AM72YiI2gHMw6+8s6jEfga1II2R7ZFKEyW8PFLDsf5R/Yh0HG2/s24P/mzbeXW0fO7A2ayXSKmv8Qfr8xjA2K98E89Ok8BINK4ga3JT534HHvF71KyW4F1R2ltgrBQYAaStsLLw0V85cHd5az6OGIpQqAZV544hI+/cRXyUyXYVvOmYNsi5HI+zj9uEH/1liMRhPHzOBIwwyLg9pcn8aPnxtGbMJn/8wazhptWOjf+3GQm9R1cw6rTrH+gExUAIPQCMJGl/oKL+SLIIjBkqWDZZIvhFgSM7qSFz9+9Cy8MF6EUxVYJUMp0q/v8W4/CpScvRna8CNdu/DRsW4Rc3seyvgS+99snQCnjf4ij/GeYuv9SwPj4rdtgfLw0z9cdM1mh9f+Ha4o4FtRp1j/QqQoAkcYNUOIFEIT4wzDW81RJ45M/24Y4x/QIpipAM+P69x+Ls9cOYGqsCMdqXDggsvyHulz86EMnYajLAWtuWQ7CwRKEY//yr3bjkW05dLnWPCuErMlJdbz1D3SqAgBUvAC2+gsu5X0oi0xFQFynDkFYuARaoyeh8KNnx/D9Z8dhEc2vy7eJGKubMJB2cPMfnIzfumgFsuMlAJjXeLwigq0IufESzjqiF/d86nSctrLblM7FVPpHFQsvj5bwV3fvRHpeXf/h5zAz3BQRdEdb/0BnLQU9kxvYwlUUdP3Fw/9A6b4Pc25c2gMLQkxRZJbVXZyx8eDvrMVgyi4/H0dMgyDz+Et3bMYnvvcCSl6AZNoBwVQ8HIjUsZTxJuSKAeBp/M6Fh+IL71iD7oQV66Q/APA1w1aEK77zEm58bhx9KXu+6/413DTByz88ld52Lkbe6OFaYsSzAnWfdK4HADB9AZjJIvvPdGFqBJYjfQEEIaZoBpKOwqaxIj5x69ZYJwQCRvgzm+/wBxetwC8+cRrecOwiFAo+8lkPGsZ9bymCovprIRDM85Yi2JaJ6efzPnJZDycsz+A7v3sC/uk9x6A7YcW63h+oCP9vPDKMG58dm3/hDwBETEoRlP5j/OFlofXfmcIf6HQPAFDlBXjo05Qe+HPOjQYgJV4AQYgpFhHGCz7+822r8J7j+2Nv1QKY9h1ufXYEX71zC259bgTZyRJgEWArKEVwLUJ52ibADzQCDdNi2NdAwsJ5q3rxwXMPwXvOWArHMsviRopCXIk6/j29u4Dz/vV5lAINpea5JJQ5oGS3xfmpW6Y+fdIlWH+DhQ1XdUzXv3rE+JLYT5gJ14KAp+xM0n9cOYk17BVYlgwWhHhCZASmqwh3f+BorBtKlgVEnNHM0zLzn9uZw0+f2oO7N47joU2TmCj42DPloSzRGejtcpByLZywvAvnHdGL1x8zgLNX9ZY/sxOUo8hLUgwYF3zrBTyyPYuuhD3fOSAMUhrKDoinTpj81BnPgVmBqCOT/yLifWXsLzfcYOGqq4L0Xzz4BivZezMXsgEQrue8MI6AIHQOHFYFFH2cvCyDu35zNRIWQVE8y9pqCbRZmKdaocmXNLKlAM/uzMILF0fSzDhqKIWe/7+9e4+yq6rvAP797X3Ofc0zEBQoSkUsEjQmMAHEaoM1FWW5ln1Mlor2oSKotEuXoGBI7gygtV0+6KrQonWp1SLOxHbZVoRFa9IqAcIA4RGsvCHhMeQxr/s+5+xf/zjnTiaTQALMnZl77/ezOIu1su4rueee/Tu//du/nfXQk9m3s3t9wDRm/hsNNUI99f/pG3fg2jueR2+HjzDSubl2x2sKAeci6TzCuqk9Xy5eftq6euZ4Dt5hUWuF8+PwJF9ox1X3DJuOnj/R0jinAoiamGcE48UAnzzzVbj2va+ZHihahVOdvtk/1F2803oGYW5XEiy0+nf6w/v34iMbn0BPbs7v/AGoEy8t6qLHU+Xiyr04o4ABaKtW/s/UPmnw7VCoimeDL2hQmYL1hQWBRM0rdIqeDh//cMcufHfbHnhJk51WUV/GZ5PtbVXj7MDMw2n850Yw/dhWESWD/93PlvCXP9uBXNo0puhTofDSgij4wt7BMydbednfbO0TAAyKwzDMxGWnP6bV0mWS7jBAazZ3IGoXzsVdAj/60yex+YlCywUBdTOr/WceL7Q6oNm5ZJpndynE+294DMXAwbdm7veBUI0k2221ND5cWHfqxnZJ/de1TwAAAGslwpDa4vq+a1x58peS6bRQbZsvm6jVKOIBMOsZfHDj47jnuTI807xNgige/AFgvBLhD3/8GJ6ZCtCRsnP/naoqPF9crTymaXsRVAXbB9rqxGnB2PEQksrO3FUjp0oqtxVRCLjIQFoxjiZqD9YIpiohTlqawW0fOwm9GdsSKwPaTb2A0RrBef/6BK6/Zw96O30EDQnoNJSOJZ4Wdl9UXNd3Tbvd/QPtlgEApncLLF3edzdqpYsl02khGi34jic8ePB42UfkHLozFr/ZXcG51z+C8Uo0XSlPzUEVcIgH/4tu3IHr792Dnk4PgXOY83NGo0iy3Z4rjm8sruu7BvlNXrsN/kA7BgDAvqmAy/uuduWJ/5ZMtwd1bfflE7WS0Cm6MxZbniwwCGgy04O/CC76+Q5cc9soenIN6PQXv5uDlzauWtpl1H0KUAE2t2U9WHsGAMC+VQFRdIELqmPw0jLdfJsHDx5NeYSRojfnYcsTBZz7LwwCmsF+g/+NO3DNraPoqa/1b8R5AuNg02KiyqcK607dhSEYDA4yAGgryaqAyfV9j5pq6ROwaQNjmQUganJBPQh4cv8ggIWBi0+9f8H04L9lFD2dfuNWcqiGku3xtDx5dWHdqo3tmvqvY4VMfpOHwbPD3JV3fcN0HvEZLY6FEPEO/UQiWsx8Kxgvhjjr+E7c+OET0dMCu+G1kpm7IX76xh24tvGDfySZTqvV4h3FNzz8NqA/3jCuTdb8H0z7ZgDqBlZHGFJbOunRi7U0fodkujwuDSRqfkGk6Ml52PJUAe/6/sO4b7QM26J9AppN5BRG4qV+5/3kcVx7+/MNHvydwvONi4IxzwQfwtp+h+1oi25/L4YBgIhiOxRr+51ngg+5qLYH1jNQXiWIml3oFD1ZDyPPFLHmnx/G7TuL082C+ANfGGGShRkthjj3+kfipX4NK/hLGBvBpsRUS5+YuOz0x+J5/9be6OdwMAAA4nqAobhLoNSKH4CXlrgegJVDRM0udIqejIfJaoTV331oum0wdF/TGWo8xb72vnc9W8Kq636N254qorerUev862+sgeR6PVQKg4UNqzYir2097z8TA4C6tRIhv8krrj/9v1Cd+iw6lngK8CQhagGBU/jWwBjBx3/6JD5/y9NwiNPQnBJovJkbFX132x6s+f5DeLYQoCtjUYsa9++v6kJ0Hum74thPiutPG0BePQxK2LA3bDKshpkt6QaV/fK2b5lM1/lammBRIFGLqPfUL5RCrD6hG//0/uPx+iXp6bQ0L4hzr76jX6HmcPHNO3HdnbuQSVl4tsHLM52Li/7CYMSH+4OJS988DgDtPu8/E8/32VQFAxAMiuauvGeL5LrP1OJYBGMtOGtI1BI8I5gsR3h1p4dr3nc8/vjkXgBAlCxJo1cuTqzE7Zi3PVfG+T99AiM7iujKeXBAAzdjFUCdg58xCh1LBYXTJtaf+Xi9DXyD3rQpcQpgNhEFBoC8iheWz9VqaSTeNCjidABRiwidojtrMVaNsPaGR/HZm3ZgshrBSlIgyFj/FQmTKn8jgmvv3IV3fu83GHmmiJ4OD5Fqg3didw6eDwXGUC29e2L9mY9jSC0H/wMx1H0hQ0MWa9dGPVfe/rqa33mXAEsQVBzEMGgiahH1deiFUohlR+dw9XtegzWv7waQLFXjtMBLMjOD8sjeKj7z8x342a/HkckY+NY0vhmTqsIYJ+lO60p7+ssbztzIef8XxnP7xdTrAQa3rkK642aBMgggakHxHHUEC+DPVy7F4NnH4pguHwCnBQ5HfVw3Evdf+OqWUXxtyyj2FAN0Z+t3/Q3+EKoKYx1SWYvK1CdK6/u+zcH/xfGsPpTZQYC6JQhrDiIMAohaSLIyEMVSiGN607j8Hcfg/L6l8I3AKaBgIDCb03jcrXdXvPmRSVx6y05se7qIdMYiNR93/UB98I+Qynr7Bv+4y2vj37x58Ww+HMmJlB3cukrSuc1Ql0EYgEEAUevxjKASOtRqDiuOzeGv1xyHc06MpwUYCMRmD/wP7qrgslt24t9/MwERoCtt5+euH0Dcr0Xi7X1LExeW1592Ha4b8XFBXzAf797M2vssfimSEyp35cifSbb7e1otatwtkEEAUauRpICtUI1rf999Yjc+d9ar8a4Tuqcf0441ApEqDAT1+OfBXRX83W2j+NH9ezFVi9CZtgDms8GSApBQOo7wdGr3daUNfRcy7X/42uncfeWSEyt35cj5SOWuRRR4iIK4JkDBf02iVqJAvdqnUIkgItOBwNkndMMmv/e44l3QqnsMqcYDvzfjL3j/aBnfvON5XH//XhTKEbIZC88IIk228G3kv0X99VUVYpxkuqxWCteVLl9xIfKbPAysjrjW//C06CnbQMl0QGbwzrdJKvsf4OoAopZnRaBQFCsRjBGsODqHv3rrq/BHJ/eiK7nrVQAuCQaafYag/nepZ0IAIFJg02OT+NqWUWx+ooBKNUImY+GbeKvleR1xpwv+MhZB+cLyupXXJSu3HNiw5bA1+Wm6QJJMQL0wEKpLUKtEMMYu9EcjosaxRqCqKNYc4BSvOzKDtaf04rzlR+LNr85OP66+z30zZQY0+cwA9tsy+enJGn78wBiuv38v7n6mBHWKbNrCGoFbkE2V1EGsIpW1Uk0K/pJi7Xn/KE2uSU7NRWh2EGDsEpQLDAKI2oCRuE6gHCiiWoRs1sOqY3P40xVH4pwTu/Fb3an9Hh86TdoQL56AQBVwiAv1ZgcqU9UIm5+Ywvfu2YP/fXIKuycDwDfo8A1EgGihWuqoc7C+QSoLqUzGgz8L/l62RXIqNqlkOiB3xa0rNdXzHVh/JcqTIcRw7wCiNiCC6e6B5SQrsLTLx+8d34X3ndSD04/rxMlHZfZ7Tj29rsnzDQTJfw1Tn5qv3+EfLDPx9GQNW58u4caHx/GLRyfx2FgVUCCVMkhbA6e6sLsnqovgZyyAMQ1KF1Y2nDHEpX6vDAOAVypJPfVc+ssl1a7um02mc5UWxwMI/IX+aEQ0f6zEo3gtipcQQoFcxmLF0Tmc+ZoOvP21nTj12A68tid10Oe7GSl4IA4OoHHW4FAXakXSWz95Tv1V6vUIB3v+WDnCtudKuHVHAbc+VcDIM0XsngoABaxvkPUMIFigNP8sqiHSOQ8u2ota+Zxy/vQ7We3/yjEAmAv1+adLftWVXdJztWQ7P6qFvRHUGchiSfgR0XwQACb52YdOUQkcEDrACJZ0+Dh5aQbLjspg+dE5rDg6h5OXZnBEzmvo1MDecojHxqrY/nwF9z9Xwr2jZfx6dxlPTwbTny3lG6Q8AwHmcQ3/YVANpPMI31ULd7pi8bzaVW99mIP/3ODgNFfyeYPBQQcAuau25dVPDSAMgCiIIMK6AKI2VN9+2IhAEbfJrYYuLqkHIJ5gadbDcT0pHJXz8Jajc+hKGRy/JI3f7kkhdIqejIfXH5E+6OvXV8SNFgI8PVmDZwVj5Qj3jZbhVDHyTAlj5RCP7K1ibzlEkGQmYAHfM0hZiT/bjHqARUNdvMyvo9dqtTSUmhi/cOIrbx9jwd/cYQAwl/ZtJewyV4ysFT/9jzDeElSKIURYF0DU5urp+PrSOqeKwClqkSZzAEBSlZf0Jlb4nsHS3MEvH/UAYLIaoViN4jeIF+7HD0hex7fxYZLphHo9wKIa8GdSjeD5FtYHgupgef3KAQBA/5DF8FoO/nOEAUAj1LsGXr51peZy35FUZqUWxyMABtLsK4SJaC7VswQyo8NefU5fINNBwouxIvBM3Ktgv9fR+NXcjLqARU81RKbTQ1Tbq2Htk5UNfUMYUot+ODb4mVscjBqlXp16ya+6Mkt6vy5e6uOoFqEuioRTAkT0Ag7WSO9Qtw2z7+SbrTFp/PHVAaKS67GolW71SsW/mOJ8f0M10znSfGakq9JX3ftxsfbrMLaLUwJERDNpCJvy4PlArXp1JRy7BINnh1zm11gMABpNVTAMg7US5fIjp7pM5lrxM2doacLFm1hxMyEialPxPEeETLenYfVZCaufqWzoGwIEyDuDQVmolkNtgYNPo4ko1kqEIbWlwb67KzcN/64rFwfhpw1SWQMgPDCBR0TU4lQjWE8k1+tprTxkxib6Khv64uY+UOHg33jMAMynvBpcIQ4KpAdH3i2e/zVJZU/R8lTc5Yq1AUTU8tRBAWS7DcLa86rRVdV1K/4eAJjyn18MAOafIL/JYvDsEP1DqfTyN3xRjFkHL+WhUgwBtVwpQEQtR6GARvDTHmwKGpRvMIH7XHnwtGeQV4MBKKv85xcHmoUSb10ZAUB2cOQM9dNfgpf+fdRKQBhESW0Avx8ian6qEUSs5HqhtdJDiFy+smHFDQB417+AOMAsrH3ZAADpK+76KIy9UlK5Y1GenP7RLPSHJCJ6eTSex093GoTVmsL8bXVq9Kv4mzUT6B+yGOrn2v4FxABgMZiR/urI3/qqyO+8HCIXiE2ltDrl4u4eDASIqFlofN1KZS1EgDD4eRTWPh8Mnv4AALCd7+LAAGAxmZEK8/Nb32T89Drx/A9AAdSKDASIaJFLBn4/YyWVgauW7oBE66vrTr0FQDLwwwG8618MGAAsNjP6BgBA+kv3rVHVS8R4a2AMUC0wECCiRWbGwO+loEHlAUC/UX3qjh/gWxcEyGu85JxL+xYVBgCL1awfzAGBQKWgAByLBYloAUVQxQEDf/DQDzG4tgaAG/gsYhw4Frv+IYtl27W+1fC+QMCsgU0BlULcQ4AbDRHRvFCFwgEwSHeIGAMNqgcO/PE8v0MT7UPUbjhgNItZgYB35d1nGcjHBPiwpDpSWisDUS1KvlIDgUz/7PgtE9HLUd9VKN5V0AHiYIyHVAcQBdAouAWe/81aFTdh8E0c+JsMh4ZmM2vpTCo/8kbx/A8o9GPiZY6DOqBWAqAhAANwrwEieplUFSIR1FmksgIvDVRLU6puo/O9b4dfXH7b9GM58DcdBgDNKq8GpwxLvZkQ8rd3Z2zq/U7Mh0X1nZLOWQ2qQFBWiImg7DBIRIdjOsUPeL5FKgeENSAK7lPFD6yzN5QH37IzeWhStMzK/mbEAaHZ5dXgFMjMNbX+l+5bblQ/AufeC2uXwUvHWYEoiFN4UGYGiGgmB8BBVWBsPOgLoLXyThh7i4j8qLrt/34xXcw3NGQxDLC4r7kxAGgZKhiCQT/2ddbKb/LSqSPPVtUPwkVrxEsdB+MDYRUIKklqDwIoCwiJ2opqfDMABdTApgz8TPzHQXkSYjaLup9U0tl/wxdOnpp+Wn6Th4HVEbv3tQZe9FtRXg2w2ezXXzt/e3fa+KugOAci58Lak+FnABcBQQVwYZIdgEAZEBC1lhkDvkJgjIWXBqwPuAAa1nYCuAUw/2lTsrV8aZLiB+K5/eFhYHgt5/dbDC/yrU3QP2TQ34/92m4Oqc0+8sCpURi9A9D3wEUrxE8fCS8NuBAIqlAXKDD9nP2CAp40RIvPvpE5GexVEd+pqxHjGXipZMCPoLVyCWK2i3P/A8FN1Uxu6/53+vWpRc7ttzJey9uGCvqHDZYdJQfsvJV/4AjrVVbYCG9X6DsEshzGLkW6I17546K4CMgFCqB+JwEoBKISTyMAzBoQzQfVeHmeaLLFLiBQqAgEAmMNbAowNj7CKhDUJmDwkEJuFZhfmpQ3Urn0TU/t97JDGncX3T4wvdyYWhsv2O0pzgwsO0qA1e6A9pxfGenxynqSMd5ZgCxXwQkSBctgvaPgpQDjx4GBujhjEIXxTYeLktcRt28BMQCogLEB0Uujs9PtSXdQYwwkqeP1UoBIPNBHYZLBCyYgeEjV7RTgbnHutqrpuReDb9w96x3i3Ugf3KUY7uedfhviVZnipTxrh184IADioKDofsemsks0qKyCMSeqMa9FGBwj1jsaUZhGuiMHaJxmFJNkIhFnEJTXFqKXxHgzYmgAUS3+XVWKEYyZVOcKMPYRuHBcvNS9iKL7DcLdla6eB3HxAYM9UB/wT1mtvMsngAEAHczMgOBQF4uhIYtHz+jOFEY7NZN6A2qhKtxb1PN7JYpURQWqy2G8XrhwZlqAiA4gChGBIoC6O0UQqIiIIJAIW5HpDDUqPVfz/edQqVUx2Fd6oReazvI9uEtnNg8jInppVCXuQqgW+U1e/H9lLwGihZRXg/4hi7zGv8n+IQtVBtl0WHii0Cuk8Z4DAwOCUwYEGAa2HyXAagCb44c8uEuxrJ93H0SH68FhiafkZjhllwL9wHYoBuqlt7yrJyIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiImpZ/w9d9tKhgauARAAAAABJRU5ErkJggmljMTAAAUseiVBORw0KGgoAAAANSUhEUgAABAAAAAQACAYAAAB/HSuDAAEAAElEQVR4nOz9eZwk913n+b+/EZFHnX1I3boBy/fF2HRLloxtWbZkjGX5gtYOvhhgwbM7HDPDMePlsIXN7DCzMAt7PBbPMLPHsPxQzxhs40s+JBlblm01MAYzxmZtkNQtqdVnHVlVGRHfz++PyMiMzMqqruqurMyMfD0fj+6uysqqjoyKiIzP5/v5fr4SAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGBSuGFvAADsCDOuZwCAwXLOhr0JAHApuGEGMHp6gvkjRxXsu17BMUmHCo8f0zEd0iF94LCLd3cDAQCT6Jb7LHr2XP/752PHjunYTxxK1n2BpAGAEUICAMDu6gnuD33gWHTo0CEdO3ZMhw5dfDD/tlM2v/j1U9ZccFzXAAA7a/9lmls56Y/eesXSdr81TxrkSeuz35I/ekS+/QQSBAB2ETfKAAajEOjnQf5fL8oeuNWtHx3pkQfzLo7CtZXU1+dnbqrP1m9eO7/szSnoPNOFkqWSuzmqRzenq4mXil8HAOASmUlBKJlveu//rQvcmplzzlk7cA+CSDLfbCbJv01Wmk3tl6StJw0OPWyVQxLJAQADRwIAwKUpBPq33K/w2XNym43iH7nvydnFqYOBzpxWNFWtVqPox+WCqqVpYM58VzBvCuVkLgzna3tq8qlUHN83ZRexdE1K19a6vwgAwI4xORcomqls+FZjJq2dbyw5ycskBUFX0kCS1edn3OrS6hdXF5Yfmjt4mat+l+z3LncLG/2vefVAV2KApACAS8DdMoBtMCfrzMnfbEQ/H8X3ca1WCYOfcEFU8WladU4/IRdU5VOZc0Ftz/Ssc9mNk3P9g3lLE5lZ7ORk6tz3OGVJADkFTgrELREAYJCcS8z6v9k4J+fCKOrcXncnDfJCgrXza7I0XTAzi6YqLllNvujMvlCbn6qsLjc/v7qw/FDtqsuC6rmTyUbVAz/xsFX+elH2wCuVtv5z3gEBbAkJAAAba43ubzayf+QvbXZxSUG0slithtG7FASR92l7FN+kqDY/PeuC7OYnWY5l5pWH75YmiZmsHdz3C+YdQ/sAgDHQLzvQSho459T6t+LCKH++wlpNQTWb1NY8vyZLkgW5wEm25s3/ztSe2Xjl/PJDFq48uO+ay8P/62nuXO9/sa5SwEkSSQEA63FTDaCjFfAf+sCxaPZZh/qO7r/tlM0vf335pvrszM0r55cqgQveJRdUzadBbc/MrAt6R/G7g3zJoq4fSHAPAJg0hUSBOXlnzpuKyYFO9UChauBcWIvCZC15MAjCL8r7pJkmvzOlldV+lQI/8bBVSAgA6MWNNzDJLhDwH7nvydkVTdXzkX1L0pvDqejmdC2dr++bkk+LI/pqB/rrRvEJ8gEA2JpiFYFTaiZrJwZaFQNhTTIvNRdXlmS26r3/nal9s/Hq+eUvzjx/5qF+fQVICACQSAAAE6Yzh//kAbm+Af/cwXp1eeXHzbk5mf9xOVevzk11jeybT7M5+Vndftj+AQT6AAAMhpnJSZY1GfTOybkgilzQqRRYPbuisBYuJCvNB+t7Zx9aO7v8pekXzjzYLyFw6Hcerhz7iUPZfQA9BICJwc06MAnM3KEPHIuOvetw1xz+I/fZ7MqcNgz448WmzEzme0b2JdFyHwCAIcurBYqVAkGosFZTNLX1hMAt91l08ClZVh1AMgAoM27ggTIqNO974NYgUaGj3ttO2fzy15ZvqsxOvTJeXP0xF7jpfgF/q91+Nl+fkX0AAMZAlhDoVAn0SQhUwoU0Th9ypvstmvrdqKnG0Vtdu4dAdzJAYqoAUC7c1ANlYeY2Ku1/+9/YwaVHl3/MhcErw0p4Uxqn87W9U2ouNCUCfgAASmqDhEC9piDKegiYt0Zlrv678Urzfq+lL374ZQcWiz+hPVWAygCgFLjJB8bckXss7A36j9xns0lV0y5Z+TELglvCintpUK3OWSqlq4U5/AT8AABMkE5CwEnmgiiSc6rOVxUvxkrj+GRtT/131xZW7l/fTNDp0O98hWQAMOa46QfGkZm75X6FD7xSaf4m/IbPPzUXaPbmylS1q7TfJ1K6siazJLFs4j5z+AEAQLuHgMlSJxe5qKLqfFVr5zpTBSz1989eN/O7//EZ7mT+bbeYRQeP0jMAGEcEAMC4aDfyuyEuzun/gYfi1wSV4JXx4uqPhZXKwcpcpau0vxP0E/ADAIBNmJlJSXGqgAsl32wuprE96OQfCC35d0dfMf9U/i3tngF3uXSYmw5gawgIgBF35B4LTx6Re8B1Svzf/jd2sHE8K++PatH3BdVQ8VJTlsQyWeLksqX5KO0HAADb1jNVwEVRWK8prEmrZxtPVebq/25dz4A+1YkARg/BATCK+ryJHvncwoHURf+tqXtOf7y0bHJKnRQS8AMAgJ1n1k4GhJWo2DOgMlf/XR/7+//zTZV782e3pwhQFQCMHIIFYIT0G+1/y5dWvi+qVl/RPL/64/V90wfStVYjv/ac/tZoPwAAwKDl0wSkiosqqsxW5ZupktXkk5L/XKTk37anCFAVAIwcEgDAsJm5I0ePBkePHPHF0f5E0Y9LwSuievR9QS1UvNiUpTFz+gEAwGjIkgGpTGFlZsYFNWntbOOp6p76v02azc998CVTn8yfest9Fj1AIgAYOgIIYFjyrPitxdH++PuiavCK5vnVH6/tmz7g16R4ealV4u9aJf68bwIAgNFiUupk5sJKVJmrya+lSlabn5T85+LUf+CPb50/lT3R3JGjCpgeAAwHCQBgt/UE/m976NT8ytrMzcFU+E9k+r6wXlG8uCpLKfEHAABjpqsqYNYFVam50DhjPv3tqSvn/rfff4471Xqau6unAhLA4JEAAHbJkXssLK6Xe+QT5/YnU5WfltM/ckF0eVSvqrm4aHKOhn4AAGDsmSx1ZhZUalFYryptri0EUfRg6u1//uBLKkwPAIaAAAMYsCP33BPec+SId603tR/6ul2+cmLxH7kw+unq/NT+ZLkpHzez7rqO0X4AAFAyZianVC6MoqkpmY+lQJ/0K+m/maotf/H3brp8QSIRAOwGEgDAgPQG/m/5Uvx9oXP/2CfJS8NqbT5dbconzUTGaD8AAJgE2XKC8hZU5+ZcstqU+eSUpP8tWol/++hr956RSAQAg0TQAeyw3sD/ri/F32fO/rF5vdYFFSUrK5KlBP4AAGBimVnqpCCoVF00XVVzceWMM/12uNr8X0gEAIND8AHskAsF/vHSoilwniX8AAAAWlrTA4KwEkWzNTUXGmecORIBwIAQhACXaOuBP/P7AQAA+molAlxYiSokAoCBIQEAXKT3mAXvlYzAHwAAYIdstSLgVqUSiQBgu0gAANtl5g4dU3TssIulvLkfgT8AAMCO2UJFwJF7LDx6l0uHvanAOCEBAGyVmbvlfoUP3OoSSXrz/Yu3h9NTPyvvv88FFTUJ/AEAAHZWT0VAvLByWoH7X//wtz/yPh29K5VZcOToUXf0rrtIBABbQAIA2IIj99wT5m8sb/rU+ctUCX9Szv1yZWY6bC4ueTkZgT8AAMCA5BUBQRjV9k0pWYnv9Zb+5gdfMvXJ1tezuIb+AMCmSAAAmzhyzz3h0SNHvJyz13zi3P6pqcpPO+mnqvPT+5vnGzJLU+cCAn8AAIDdYGZmSiozsxVZLBfoE6ml/3OeCDj0sFWOHVZCfwCgPxIAQD+98/wfXL3TOfcfwmr1srixJkvjRKZQjuX8AAAAdpuZ9zK5ysycc4EpbjQ+omb6I390+57TEv0BgI0QvAA9iuX+7Xn+afp9PvVK4yR2UkTgDwAAMHxmljopiKZnXbq6ctqF+l8++Ft//P5WfwCmBQA9CGKAlmK5/6s/+Nhlc/v3/6ScZfP8FxZNzskR+AMAAIwck6VBEIZ5fwDz7jf+802VeyWmBQBFBDOA8jeG9eX+zUXm+QMAAIyFdn+AmYoLxLQAoA8SAJhoR+6x8OgRmZzzb75/8fZwZupnlRTK/Z0iiVF/AACAcWGy1FlnWkBx2cDioA8wiQhsMJmKTf6O3BO++afv/GV5+8VoZipqnm+V+wfOiUIxAACA8eIkWfe0gHQl/VSyuPKv//C2uU/JLDhyVI5qAEwiEgCYOMUmf2+5b/G2cHrqF8Kp8PbV08vezBvl/gAAACVhZmaWVOfnKvFyIw0i9z6aBGKSkQDAZDFzXU3+1G7yF7sgqAx78wAAALDzzCx1zrn6ZTNBshLfa9ZpEkhvAEwSEgCYCEfMwqPK5vq/5U+W73Rh1Grytywz32ryR/IXAACgnLJ5AeYtrszMZk0ClxsfWTx77kc+85ZrTx96+OHKscOH6Q2A0guGvQHAoB162CpHnUt111H35s81PhxUax+2JL1sbWExlnlzzhH8AwAAlFp2r+cCV4kbS2m8tGRhberOvVcd+MYbPnX+jmOHD8cyC47cY0wFRalRAYDSKnb4z+b6137BhZXb184veLnMsLcRAAAAQ2KWhLV6lMbNxIXu1/7wtz/KSgEoPQIglNIt990XPXDrrYmO3BO+5Wde/0s+8b9cmZkJ44XFRIGLhr19AAAAGD7z3lwQWP2y2SBdiT+VLDb+9R/etvdTeo8Feq+MBoEoGxIAKJ33mAV3O+fv/MS52+v7pn8+nKrcvnp6yZtZq9wfAAAA6DDv4+r8fCVeXk6DIHjf6XTq1x641SVHzMKjjgaBKA8SACiNYqO/H/jC6uvN2R+FUT1sLi7Q4R8AAACbylYKkJs6OBesnFz6aOOps++8967vOEODQJQJCQCUQrHk/80/9fo/DGvVO9OVFe+9t6zDPwAAAHAhJjPFUX26IpeeiZdW3/nh2/d8VGaBxJQAjD8SABh7ecn/Gz517rba/HS70Z9zLhB9/gAAALBNZj6NalNhGjeTIAjez5QAlAXREcZWseT/TV9Yfb1rlfzHizT6AwAAwKXJGwROHZwNVk4ufXSFKQEoARIAGEvt7OuRe8I3tUr+k5UVb5T8AwAAYMd0pgSYS8+kTAnAmCMBgLFz5C+tevQFrvmGT527LZqf/oWQkn8AAAAMUHFKgEL3a+c+/eX3P3D3rckt91n0wK0uGfb2AVtFtITxYeYkOTnn3/Cp83eEs/UPhWGVkn8AAAAMXHFKwOrpxkf/6BX/6g3S3Z6+ABgnJAAwFvLs6i3vuS/a9+qX/KJ5/0suCCKLkyz4p/gKAAAAg+QkmclMzer8XNX79FPJwtK/+vDtez+dV6gOexOBCyEBgJHXyaq+J3jT537hw/V903esPLXkZebkqPkHAADA7jLv0+rsfJj6Zpour76RvgAYFwRPGGmHHrbKscMuzub7z/5CEIS3N88vNl2gKocvAAAAhsZb4ipRZKlPXBS8/+xnvvRrD9x9ayKzQM75YW8e0A8RFEbWkXssPHqXS1/38TN31OanPxyGtaC5tJC6gC7/AAAAGAFmJueypQJPNT5aPTn9xqN3uZS+ABhVJAAwegrN/t74J8t3hkH4QZ/4wOLE0+wPAAAAo8Uk01p131yteX7poytPnX3nvXd9x5l8MGvYWwcUkQDAaHmPBZJ0i+4P9r3qhg+Gtfqd6cqq92nqXBBwvAIAAGAkmVka1adDC9IzzcXVd3z0NXs+lk9nHfa2Ablg2BsA5G65zyK9Vzry/KNu7603/lFlbubOeLmRmvcBwT8AAABGmXMuTFaXUyW2vzpT+/DrPn7mjmOHXfzaj1lt2NsG5AiqMBK6O/3/sw9XZqbuaJ5djBW4yrC3DQAAANgq894HlYqCSuiT1dU3ffhVrBCA0UEFAIbu0MMPV446l77hU+due/NDv/jJaGrqjuY5gn8AAACMHxcEgU8S+cRHTuEfvelzjffc8t77Azln+XRXYFioAMBQ5fOi7rj3/OuqM7WPZJ3+z6cuCEOJBCkAAADGkZPMt1YImAtWTi19tHpy9o1Hv9a6wb2bZQIxHGSgMDQ9wf+HLUkVL51PsmX+CP4BAAAwrkxyzkkWrDy5sFadn72jebDxoSPPP5oNwFIJgCGhAgBD0R38Vz9siXc+SeSc42IIAACAcvEWV/fPV5oLjY9WT370jUe/doRKAAwFwRZ2HcE/AAAAJkrgKs0zC3F1fvqO5sE7qATA0HDAYVe99mNWO3bYxa/7+Jk7CP4BAAAwMfolAd7bWgob2CVMAcDuMHOSnJzzb/js+Tuieu2PfJwGBP8AAACYJOYtru2br8TLjY/+0Sv+1Ruku31nSWxgsEgAYPDeY4Hudv6W99wX7Xv1Db/oE/ulIAyjNIk9wT8AAAAmjllcmZ+v+DT+dLrY+PUP377304cefrhy7PDheNibhnIjAYDBeo8Feq905Khc88DSh+qXzd6x8tSil5nLOqMCAAAAk8e8Tytz86FP1nzcaN750dfs+VjeK2vY24byIgDD4GRBvh25x8LmgcaHKnPTdzTPLazJqcahBwAAgInnLXGVKHBRaM3Fxhs/9v37P3rkHguP3sV0AAwGURgGw8wdOqZo/2lVp6OlP6jsmb2jeXYhVuAqw940AAAAYFSYmQ+iSC4KzK803/jiz89//K/eK0dPAAwC868xEK/9uKrHDrt4yp3/ufrB2Wzkn+AfAAAA6OKcC3wcS16hi8J7jl19rH7UuVTGEoHYeVQAYMflc5de9/Ezd1Tnpv/A4qRqaRox5x8AAADoz8zSaKrufJx8rHpy+k1HvyaTJN3t/JA3DSVCVgk7qjv4n/qQknTGkoTgHwAAANiEcy5MVlatMjv9+uaBxoeOPP+o03uVNdUGdghBGXZMHvzfce/511Wmqx+2xDufJGKpPwAAAGCLvMXVffOVeLHx0epTH33j0SNHTO8VlQDYEQRm2BEE/wAAAMAOCFyleXYhrsxN39E8cMeHjhylEgA7h4MIl4zgHwAAANhB65IArcptMyq4cUk4gHBJjpiFR51LWw3/PmRJSvAPAAAA7IT2dIClj57T7Jsk6YFXKpVzNtwNw7giSMNFu+U+i446l77+Uwsvq81Pf8iShOAfAAAA2Cl5JcD87B3zyfkPPnCrSw4dUzTszcL4IlDDxXmPBQ+8Uv7IPRYGUfAvXBCGFiee4B8AAADYQYGrNM8txZXZ2Ttf/7Ezdx477OJDD1tl2JuF8USwhu1rzT06cvSoax5ofKgyPfPyeGk5VRCQjQQAAAB2mvkoXVtLKnumP/i6j5+5I0sCPEwSANtGDwBsj5m75X6FkrRXS39UmZu9o3luIZZzXIAAAACAQfHeXKViLgqtudh448e+f/9H835cw940jA8SANiWvOP/nZ869+Ha/j13Ns+cjxUEFYk+JAAAAMDgOJl5H0SRgkpkcaPxyj++ff/nb7nPogdudcmwtw7jgQQAtiwP/l//safurO7b9+Gk0Ygl5h8BAAAAu8b7JJqdjZLV1T+pPTV769EjMknGygDYCnoAYEuOmIXHDrv4dR8/eUdlz9wH07XVROaZ8w8AAADspiCI4qWltDI9+/LmgcUPHZGyKbqtPl3AZkgA4II6y/2deVl1fv5DPk4CH8ehnOMiAwAAAOwyFwRhvHg+rszP3bH66XN/yPKA2CoCOGzOzMkFduQeH64eWLovqtdfniwtJXT8BwAAAIbNxdH0dGVl4ewbPvF9Bz5CU0BcCAkAbMzMHTqmaP9pVevR4h9U5ubuaJ4/l7ogCIe9aQAAAMDEMzMXRWkQhVpbWnnzjV/c97G/eq8cSQBshCkA2NAzPv7N6rHDLq65sz83dXDujnjh/BrBPwAAADAinHOWxIF5RZVa5Q/++Opj9aPOpTIjzkNfVACgr7x86HUfP3lHZW7uDyxOqpamEfP+AQAAgNFi5tNoasr5tfhj593smyXpgVcqZWUA9CIzhHWKTf8q8/MfsiSdsSQh+AcAAABGkHNBmKysWmXP7Otnk3MffOBWl9xyv6jcxTokANCttXzILfdZ5KLKvwiCMLQ4ThQEBP8AAADAiHLOhc1zi3F1bu7O137sqTsfuNUlR8xIAqALCQB0ueV+hQ/c6pLZ5NwHK7OzL4+XllI6/gMAAABjwHyUrq4k9b1zH3z9p8687Khz6S33GffyaCMBgLYjZuEDt7rktR976s7q3Nyd8fmFhKZ/AAAAwJhwzlmcyrkwclHlX7SD/1aVL0ACAJK65/3X9859MF1dSSRKhgAAAICxErgoXlpKK7OzL6cfAHqRAMC6ef/OhZHFqWj6BwAAAIwfFwRhfH4hoR8AepEAwAbz/h1zhQAAAICxZSH9ANCLBMCEY94/AAAAUEL0A0Af/PIn2BGzMJv3v/CyaLp6n49jWZyGCpyTDXvrAAAAAFwSJ5n3aXXP3nDt3LmPfPQ1+95w5B4Lj97l0mFvGoaDBMCkMnOHjinaH6laP73w8Whq+uXJ0nJC6T8AAABQMqYkmpmOmkuLb/zo7fs+ckQKjjqSAJOIKQAT6tAxRccOu7hy8uzP1ffPvzxeWooJ/gEAAIAysiBtxj4Mo99//TFNPU8yvceIBScQv/QJdMt9Fh077OLXf+rMy6rT0z+/dnYpdo7gHwAAACgl5wIfNy2o1aZ09tzv3+2cv+WVxIKTiF/6pCku+RdW/kUQVmZ8mgQs+QcAAACUl3MuTNfWfGV27g0sDTi5SABMmCNHFTxwq0tm43MfrMzMvry5uJA6R9d/AAAAoPS8D9KVlaS+Z+6Dr//UwsuOOpeSBJgsjPpOknss1F0uvePeM2+ozs59KFluJHKi9B8AAACYFN6SaHYmSlZX/2Q1nv3+vee1evSIvJxjHbAJQAJgUpi590jui588v7dScY8GYaVucVNyjioQAAAAYIKY9/HU5XsrK6cX7v7o7fN3H3o4axA+7O3C4BH8TYhDxxTd7ZyPAv+T1dnZKYubKcE/AAAAMHmcc9HaQiMNwuCnXv+wpl7/EaWsCjAZ+CVPgCNmYdb1f+FllenpX4iXG16i9B8AAACYSM45n8QKa7X9/uy537/7buePPP8o1eETgF9y2Zm5Q8cU7Y9UrZ1e+DiN/wAAAABIkpxLo6npMF5aeONHb9/3kSNScNS5dNibhcEhAVByhx62yrHDLn7dvWfeM31g33tXnjoXuyCoDHu7AAAAAAyZmXeVqpQmq7Zn7sAff0SrkqS7nR/ylmFAmAJQYkfMwtd/ROkdn154eWVm5ufWzi7FzjlK/wEAAABIzgU+blpQq0350+d+X3c7f+T5DBKXGQmAMjsq3X238zL/viCqzFqaOjnHCQ0AAABAkuScC9PVVV/bM/+G133mzCuO3uXSW+4zBg1LigRAWd1j4dG7XHrHvWfeENXrtzQXF1Mx+g8AAACgh5mX96kPFL7/9k/azMGnZDJj4LCESACUkZl7zxHZaz5xbr/C8Pd9mprjBAYAAADQh3NBmC4tp7V98y+vBgs/f/Qu+UPHWDWsjAgKS6jd+O8TZ36ltnfPe+OFxUTO0fgPAAAAQH9m5ioVL+/P257Z6/74kFb0XjkaApYLFQAl02n8d+blldmZn4+XG14iewcAAABgE845n8QKa/X9/tS535dzRkPA8iEBUDZ54780eF8QVWaVpkbjPwAAAAAX4uTCZKWR1vbMv+F1n6QhYBmRACiTvPHfx8+8IZqi8R8AAACA7Wk3BAxoCFhGJADKwszpiPxrPnFuvyqtxn/iRAUAAACwde2GgPvnX17Vws8fvculNAQsDxIAJXHomCI5Z9VAP1WdnZ2yOE4kx+8XAAAAwPY4FzXPL3sXup96zSfO7T92WAlVAOVAgFgGZu71h5S+5hPn9isIfjpprEo0/gMAAABwMZxzliRpdW52fzXQT8laA44YeyQASuDQMUV3O+cj+Z+szs/ttyROaPwHAAAA4BJE8fKKuTD86dcf09SxQ0r0HiN+HHP8AsfcEbPw2CEld3x64eWV2Zmfby4upWL0HwAAAMClcM5ZGnuWBSwXAsVxd1TSXc7sk2ff56LKrBoriZxzNuztAgAAADDWnFwYrzTS6vz8G15775lbjr5GnztiFh51Lh32tuHikAAYY/nJ99p7z9wSTU/f0lxcSJ1TJBH+AwAAALg0lv1lZqkF3t0tuVfqKLHGOGMKwDg7elSSFHh3t3POZJyMAAAAAHaQUxQ3Gr4yO33La+89c8vRu4L0iFk47M3CxaECYExlo/9B+tp7z9xSmZ6+JW40UuccJyIAAACAnWUmOdeqArBX5gORGD9UAIyro0clmQLv7haj/wAAAAAGxDkXdlcB/DdUAYwpKgDGEKP/AAAAAHYVVQClQAJgHBVH/5WP/rMiBwAAAIDBcHJhvNxIKzOtKoDXXPbAkXssPHoXKwKMExIAYyY7yVqj/1Ot0X8x+g8AAABg0HqqAEQVwLihB8DY6Zn7z5J/AAAAAHaBU6sXwEyhF8A99AIYJ1QAjBFG/wEAAAAMF1UA44wKgLHC6D8AAACA4aEKYLxRATAm8gYbr/vMwisq1Rqj/wAAAACGhCqAcUUFwNg4qiP3/GXVUv8+Rv8BAAAADIuTC+OVFR9NT93y2k+ee83Ru+6iCmBMkAAYB2bu6F13pSv1ffOB003Jyqqc8bsDAAAAMBzOzIe1mjmn10rSt84eIz4ZA/ySxsChDxyLJMlXp/5RZW4ulCyRc27Y2wUAAABgQplF8dKyAuntr/nEuf3H3nU4lhkxyogjATDqzNyxdx2OX/OJR/a7MPrppLEaynt6NwAAAAAYHuecpUlSnd9zIAr0U1Jn4BKjiwzNiDv0Ow9Xrt93yC/tW/jl+tzce5oLC7GkyrC3CwAAAMCEMzMXVZz59Ewau+d84nVzp2RS1rMMo4gKgFFm5o6961AiKXQ+/UdxY0UyI6sGAAAAYPiyKoC4Oj+/P4zsbTKqAEYdCYARduSoApm0vOfsTdHU9Lz5NGXuPwAAAIBRYbLAx7EsTb9fztn1+77lh71N2BgJgJF2NCufMferLoyqlqbD3iAAAAAAaGstCZhW5mZf87rPLLyCJQFHG+UZI+rIPRYevculr/3kuddEU/Vb4sZy6pzjRAIAAAAwWsxLklnq33fknr+8XTrKyOWIIgEwolrraKbO9NqwWrN0ZdXLKRTtNAAAAACMECcFycqqAummeN91c390+wtOy8zRDHD0MJ98FLVOltd+bOFAGKZfc2F0wJLYmP8PAAAAYEQllbl511w4/76ZhX3vP3lA7oFbXTLsjUI3egCMoEMfOBbJzIVB+rbq3r0HLE1ign8AGG1ukz8AAJSeWZiuroaS/aSk8IFblcqMt8ERQwJgBF2/71tezpmZ/37fjGUyfk8AMELywD50UtS6QifW/09q2fNCJwXcBgEAyso559M4jaZm5htziy+RnB05Srw5augBMGKKzf8qU1OvSVYaqRPN/wBgFAQuC/xjL5mk5diUemlP1Wmu4mRaP+LvTXpq1cubVA2lWuAUOClyWXKAyZEAgLIw7+XCsCqXvp9mgKOJBMCI6TT/868NqlXTSsNLIgEAAEOSj/SnkpYTU+Kly+uBaqH01qfXlXjp710W6Tl7wr4JgMRLH39sTYlJf30u0X85kyjx0qmmaa7iVA2yJIAnEwAAGHPOFCSNhilwNAMcURQjjhKa/wHASAlcNtq/FHtVA6eXHqzohfsjvebamuqhVA+3f3leik3fWEh17FSs+0409eiyVzWQpitOoiIAADD+aAY4wggsR8ih33m4cuxdh+M7PnH2H1f37f03zXPnYkmVYW8XAEyawElmUiMxXTEV6NarqnrxZZEOH+i+JOcl/IGkzVK1+eh+b75goWn6xGNr+oszib54MlYUONXC7PkkAgAAY8nMgmrNpc3VU8u1/Vc9cKtLqAIYHUwBGCHX7/uWP/SwVR47de77/VpTJgscORoA2FWhy0bpzUyvvLqqf/KCGc1VOtfi1DrN/LZaAFB8nilLLpik+arTXdfXddf10kMnY/3rry7r1KrXXDVQ4JgWAAAYQ845nyZpODU9P71y/lZJnzpyVMHRbDYdhozoclS0smJ3fnrxCp8mjykII6UJ5f8AsEvyzv7nm14vOVjRf3N9XYcuz0b8E8tG+Xe6i38+9z9vLrgUmz70d6v6/31rVWupNBU5pSQBAADjJ67u3VtZO3f2f545v+/nvnX2WHDsXYfjYW8UWAZwZBz6wLFIZs4nyQ9V9ux18mlM8A8AuyOQ5M20FHvdelVVv37jnA5dXslG65V17B/EEn55g0GnLBEwW3F62zOm9CsvntVs5NSIvUJZVjIAAMC4MIvipWXJ2w9JCo+963AsM2KbEUACYERcv+9bXs6Zmf9+i+PQZPxuAGDQzBTIFPtsOb9/ccOc3ntotj0yn1cF7IYg6wGo1KQbDlT0/7xyj773iqrOrJkiJ5IAAIDx4Zwzn6bR9PT+xtziSyTpyFFiz1HAL2EEHLnHwqN33ZW+9pOnXlOZmX1NstJInRxL/wHAIJkpcNkyfd6k9x+e1U0HK1lJvgYz4n8heUWAN2mm4vQr3zOrV11d1emuJACJAADA6DOfyoVRRS59/088bBXp6LA3CSIBMBK+dfZYcOQeC0OLXhtUqyYzP+xtAoDSMmuN/GfBf2rSrx2e1eEDlWyu/wgUKAZO8spWFnjPuiSAqAYAAIw8ZwqSRkNyuunxc0v7j951V8o0gOEjATBsZu7Yuw7HJw/ImaVvjZeXncxYnQEABiILnJ2yVsS+EPynls31HxX5G3QxCXCuaZ0VBUgCAABGmXNO5uPKnr1h4uO/L7X6nmGo+AUMWb4kxvTa+Vuj+tT+NI5TyYVUeALADslHzWXt6nnnpJXE9Os3zrVH/kcp+M/lm54nAf7Zlxd17KlYc5V8dQDLntV+jQAAjAgnmVlgzTh0qe449LD979d/66g/NuztmnBUAAzZt84eC2TmAvnvD6emKvKe8n8A2El5yXwrQA6ddL5puvWqqm4YwZH/XvkKAYGTfuRZU4oCp6TVoLD92jzRPwBgxFg2DSBdXZFz7tb9p5/YxzSA4aMCYJjM3DHn4lv2PTlrc5W3xYtLMrNIrP4HADvHrD1AHjppKTHdeLCi/+HFs0pHZM7/heSNAZ+3L9Kv3TCrd395SVOR2kkNa/89Bi8GADA5nHMyi6P5vYEWzvyIpF8/9IFj0TEpHvamTSoqAEZAdc/0tFwwbdRvAsDOsk5oLGVBdOqlH37WVHsu/biEzIHrLBF4+ECk801rLx0oieaAAICRZGZyTqF3wd4j9xgrnQ0ZCYAhyptgVC15a3V+z4ylaSzH8D8A7IieYDiQ1Eik266t6gX7InlTp6HemMgrGd7+zCnNVQpTAQAAGFVmUby8LKX+R08ekDv2rsMx0wCGhwTAEF2/71v+0MNWMbPX+Th2JuP3AQA7oWcg3EmKTTo45fRz3z3Tbqw3boLWVIAX7Iv0jmfWtRzb+tdBFQAAYJQ458ynaTQ1tW967fytUtYIfdibNanY8cNi5o7edVd69bml/XLu1mRtRc74fQDAzugZ/XfSUuz16muqqoVOfoxHzvOy/9ddV9eeajYtYN1rIQkAABgl3vtwaqrinH/dkXss/NbZY8Q9Q0ITwCHJm18kPv771T37XHz+bCynCus4AcAl6hP8epOqgenQ5RU5jW/wL3VWBZiOnJ6zL9SXTyaaq7j1L5uegACAUWEWxUtLstT/0MkD+vljd7WmAThH8LPLyLwMg5m7ft+3/JEHH5lypjus2Qwp/weAHdAn+A+ctJx4fe+VVX3P5ZX2knrjLgqkdz5zWpXANqho4J4KADAinHOWJj6cmto/3TxzuyTp6FHinyFgpw/J0bvuSvXYdaml/pZ0bZXyfwAYGFPsTYcur2aN8oe9OTsgn/f/nD0VHZwKFW9U8s9UAADAqDBLKjPTFWfuRkl63teex4oAQ0DQOQR504vGvvOvCKemU5Olw94mABh7GwS7TS8dnAr1yqurcirH6L9TNvc/cNJt19S0HHuqKAEAoy5MVtYk00sOPWyVv9Lzk2Fv0CQiATAE3zp7LJCZU+pfV5mampL3nuX/AOASbDjSbTJJtVCqj9uaf1sQOGk2cu3yf+tX30AVAABgFJgF6dqa5HT7/tNP7NPdzrMc4O4jAbDbzNyxdx2Obzl6csabva25uCiZ0YwRAHaYyRQ4qRF7ff91ddVC179j/pjKKxm+79qarpwO1fSbvDaSAACAYXPOyXxcmd/nqlb9ESlrjD7szZo0JACGZGo2nXJBMF2O2agAMER9gtt8JDwvlfdmpQn8e0WBUzO1zasAAAAYBWZyTqF3bi+j/8NBAmCX5VmuMJj+0crc/IylaUz5PwDsPCcpMWlP1emF+yrZYyW72nqTKoH03fsrWvMXSAJQBQAAGDazKF5ekjP7sVuOnpw59q7WcoDYNSQAhsHMeef3OleGVlQAMESbjP5LUupN8xWnF11elVSe8n8pey0mqRI4veiyitYSX7oEBwCghMxLLpiamk2nhr0pk4gEwG4qzP93Zj8WLy8x/x8ABsybtJKUe/R7JV0/xYGpAACAkeOcszSNK3PzM2Ew/aMSfQB2GwmAIZiaTafkgimZH/amAECp9C99L8fSf5vZ8utjGgAAYAQ4FzjvPH0AhoAEwC5i/j8A7KAtB7MTEPSaTcTLBACUAH0AhooEwG5j/j8A7A6zCRvxXv96mQYAABhJ9AEYGuZb7BYzd8y5+JZ9T866+agz/58CAADYIYVgd6IC/x5mmy93cKGvAwAwSK0+ANX5PTPxgvtRSb9+6APHomNSPOxNmwQkAHbZ3IGpum+mU+az+f8TfIsKADuq3/XUNni8bKznTy5bKcBUrvUPAADjzkmyYh+ADxwb9iZNDKYA7JJ8/n+ylrwrmp2fMe9jY/4/AFyc7YzwT0I1wAaZjklJgAAAxouZRfHSoszsv73t02fn6QOwe6gA2G1BkARh4LglA4ABa/cAmJT7idb7Sp7wIMcMABh13mpn/25/Y9ibMUmoANgNZu7YiUPpkQcfmXLe35qsrUnsewDYMTS7a9lqtcMkVEUAAEaa+dRHU1PVg9915jZJ0tGjxEe7gJ28W+52Xo8tpGb+Vt9sSmbsewC4GBcKXnu6/xPqkiABAIwY55zMkmhmumbmbpSk533teeGwN2sSEITuhlY2a2HuqlvD+nRqPvXD3iQAQIn0q/ZnlB8AMNrCZGVNkl7y2o9Z7a/0/IQ+AINHAmAXHDp7fWs/u1dWpqem5H0qGgACwC6ZhEC41es/f6kE/wCAUWcW+LU1ObPbqvOnqrrbMUi6C2gCuFvMnPvkmcRSa43UcHMGABfHej7rvZ4We99P0rV2mz3/zWgUCAAYolZc5FzDn2nWJC0Oe4smAQmAQTNzx5yLX3vdqXkF+odxY0kyi7jpAoABsN4geLJWAbCJer0AgLHmnLM0iSvze+fXFvXjkv7HQx84Fh2T4mFvWpkxBWCXzE1d5mWqU5YJAAM2iWXwXTmP/q97gvYGAGCMuCBwznx12NsxKagA2CUri4t1Vw38dis0AQBFtvk1tFj5X/wzCfq+3mJFANUBAIARlJrkrSozpw8cG/bWlB4VAAN26APHIklKoua7KrN75ixNYhoAAsBF2kowb5qs0f+N2AWSJQAADJtZFDeWJBf8xG2fPjt/7F2HY1YCGCwSALslcEkQBhzMALCLTJqMZIBZq6nfsDcEAIBtMpN8Wju7b19j2JsyCUgADNixE4fS137sGzV5uzVZW5PY5wCwY9avAAAAAMaJmU+jqZnqgZOnb5UkHT1KvDRA7NxBMnO62/mVtcqUc+5Vfm1VMmOfA8AgTMJIPwAAZeKck099ND1dk/RqSTp09nripQFi5+6GvdOJmS2z9B8ADFghCTAx5f9F+eudtNcNABhjTuYlSQtD3pCJQAJgF8wtTtWdC8JhbwcAAAAAjBwzSW6aBoCDRwJggPIVAOJK8uOV+T2zrAAAABgpVAoAAIatvRKA/cRrP356jpUABosEwC5w5qsuYAUAAAAAAFgnW7q2Pjd1mR/2ppRdNOwNKD0zp4+fqprPRlkYawGAnXOha6pt4TllYdrK6zWxViAAYBS5IPAri4t1SUvD3pYyowJgUMzcsXcdjt/woVOz5txPxI0lmRkJFwDA0ExKMgQAMEacc5YmcTS3Zy6uNH9c6kylxs4jATBgjWYYOHN15lkCAAAAQH/OBS6Qqw97O8qOBMCAxQfiVLJ02NsBAAAAAKPMe0uGvQ1lRwJgwOYWp+pyAfsZAAAAADZiJudcnRUABovAdEA6SwA2WQIQAAAAADbSWgrQnP3EGz50apalAAeH5gqD5l3ducC1Gy/TCgAALt5m19BiC3zr81jZbW0ZAAAARpM3yVy9WWW5mkEiAbAbem9IAQAAAACZTrzkV5ohVeoDRAJgwKqBluUkk5HKAoBL1ptJtZ6PybhO9msHAIwnk0kKlNpbr9u//MCwN6fEyK4MyLETh9Jn/NY3aidW0lela6sKnAJuyQAAAACgh5MipelKNF3/N988eask6ehRYtUBYKcOgpnT3c7vuSqsLzTtVcfPLms1sSB0jMsA2D1UHQEAgFGXtUlz7lQj9qc0UzPnXiVJh85eT6w6AOzUATq/llrotLySOp1YTrUUm8LWHTmJAACD4iSFTkpNYu0RTIrioR5y3APAyMt7pHtJJ1e8Tq1J5hM555eHvGmlRgJggOKkEkguCFx2cD/R8Hqi4eUkBVQDABiA0GVvpOebpqnIKU5JAqD8nKTYZx+bpIXYFAVUwQDAKKs4qZGYHllM1UhMkZMkJzNHn7oBIgEwQJc3712WTy2/BQmdtBSbTjS8VpOsGoAkAICdkCcWzzdNgaR/+Lxp/e4r9urFl0dqxKaASAgllY8eRYH0azfM6396ybwOX17RyRWv1MSxDwAjJl8Z/dSq18kVL194TM4pEBUAg0QCYBBaDSuW5990q6vP1M3SVK1gP3TSapIlAZgSAGAnBE6KvWklMb3kYEXvv2Feb3vGtC6rB3rHM6cZBkWpBU5abHq945lT+p7LK3rB/op+4+Y9+kfPn9F81amRZKvwcBoAwHCtL/m39mPZEyywtRWZc696xm99o3bsxKF0WNtaZiQABiBvWGHOvSqYnquZT31ehGvKblaYEgDgUuXXkkZimqm4bPTzpj36nssrSizrAfDC/RW95EBV55vGvGiUTl76f/VMqDu/c0q+ddw7Se985rT+/S379IqrqlpOTInPyks5DQBgOHpL/is9F2QnBdZclSl4lb8qrOtu52XGZXuHkQAYIOf8snyi3tuNPNBnSgCAixUF0nJsWkpMt1xV1X+8db9uvqIqk+RN7UDHJL3jmVOaqzglRvCDcgmddK7p9cbvrGuu4tqVdlKWCJirON19aF7/8sZ5TVeczjat6zkAgMHbtOR/3ZOdnGw5WEsJiwaEBMAgmTZtQdR3SsDubR2AMRS2AvuTK16HD1T0GzfN672H5jVbcfLW6QWg1r/epBfsr+gdz5zSYtMzHxqlEThpMTG97MqqfvD6bPS/eHznSXWTdPMVWZLsHz53Wk7SQtNU4Q4IAAbOuU1K/jfGFXqA2LlDtm5KwIpvnxikvQAUVQKnhWZ2ZfjJ58/oX79kj244UG0HOf2C+zwJcOd3TunqmVCxpwoA5WAmeS/9g2dNq94a0u89tvO5/96k2YrT2585rV+7YV43HKzoydYUPKoBAGBn5TFM4LJqxY1K/jEcLLEwQF5ZhmWzQD5vhJGP2i3HpkaS6uBU0C7ZzZ9HQgCYHPl7ZF4p5M30RCPVy6+s6e3PnNaLL6+0y/03G9XPrzFzFac3fmddv/21ZV1RDxRbOa4rF9p+28JzysB6/pRVfqgHkpYS023X1vTC/ZULngd5n53UpBdfXtGLLtuj/+ebDf3+3zR0PjbtrQZKTCTgAeAiFa+dgcuStI83vJZjk3PdMc9W3rsxOCQABsjkLlhhYT3/qlAms+ad9lYDBa7T1AjAZGj3CpHp/JppruL0k8+f1TuelZUwJ/k8/63U0bWqAH7w+in92alYD59qaqYSyPMOizGTB+hNb7q85vQLf282e2wL54FTds54y57/zmdN64X7K/p/vrmszz/e1P56oMBlU2l4wwWA7Sn2OGskpjNr2epExelYxedtzilOmKg1KOzYAXLyy1u6K1n3fdnJcXrV9HjDd508ACaAmZyZApnONb1ecrCqf3HjHr3zWdOSOk3+tip/aj10+gfPnpb3JvOWpeeNKwvGROt4DWRqJF5vftqUamGn98VW5dPuklY1wG/cvFc/+YJZBU5aTbxCx7kBANvViV/8JcYvTvKpXd68d3nHNxKSqAAYiGMnDqXP+K1v1GTuVba2InkLLiYREElajU0nEtMVU0G7yReAsspqkEOXBScrselVV9f1qzfMb3vUv1deBfDC/RXdfk1dnzmxppkov6aM0ZDnZtfAfkMMZa+Jz5my8rHSvt7s3HCS1rx0WS3UG79rqqvp5Xbl1QBqVQM8Z2+k9//pohabXjMVp9RLZnl2YUzODwAYAte6np5c8VqMsyVXA11cHtV8mrr6TP283nSr9K57dfRoICnd6W2eZFQA7DQzp7ud91eFdbngVba2KneR+3ldg8CGV34vUsr7O2BS5aONrQB/Ic7WLP/1m/bofTfMdy3tdylcKxP/Cy+e0+W1oNMQ0MSIJ0ZT4dyQJDkp9ab/4cVzmqu49nzSixW03qBTk248WNX/++r9etlVNT3e8O2vc34AwHqDafTnnKWpD6bmas65V0nSobPXE6/uMHbogARrqTnZRU0BKOo6uRLTI0t00QTKoxNU5COZZ5teNxyo6jdu3qubr6hmzc108aOcRXk39Fro9OanTamR9FsWkCAHo6L7WMxvMm84WNVNhXNjJ4StXjuzFaf3Hp7Xz7xwVmot09u1SgBJAADoP0ipHRqkdE7yiZzzTAEYEBIAg7Wj+zfvnnlyxevUamd0gtsRYAwVRjXDVvPPpVbJ/2+8dI9edHlF6QU6m1+M/A37jU+b0mW1UGu9ywLmo53AMBVH/YsPmentz5weyPtePlc1aE0JuPvwvGYrTo0kK2dtnydUAwCYcFErQXqi4bUU2wCWU3WSEacOCjt2zLQbbKx1GgRealkwgF3UEzysK/m/sVPyP4j1yYvLAv4P3zOndKMOagQ4GJY+x17Q6ip9+7V1ffdlFdkAkmNSdio4FaYE3HZZNiVgxbe/vtl2AkBZ5QlSaSca/WGYSACMqchJK0mWBDi92im7ATDCCgGDk1QJpHMDLPnfSKAswXDTFVXdcLCq5Y2y9wQ42G19jjknKfHS5fVAv/DiuS0v+3cpNpoSkDfi7NpezhMAJWfKrovt2GMtu+5RiTyeSACMqWIW7tSa6eSKz5ohkQUARlNP8C9JJxperxxwyf+mmyTp7c+cljfbOIbhnR27ZYNjLXTS2WaqN13ksn8Xq9+UAG+mhbhP5R3nCYASC5VNUzzR8Fql+njssQzgQFnhz6A4VZzUSLweWTQdmHKajZw8awUAQ9Z6d2xH1tm/kXNa86YocPqZF87q7c+cbpccD6LkfyP5soDffVlFt19b02eOr/VZarQ1YcDytQdH4ZrSuw3W83G/dQDzf8t4x1J8XeO6BmC71b56W0gFzmkhTvXyK6s68vSpgZX+b7ZlUlaBcOPBrFLn//7Gsr58sql9tUCJz7c2P0+KrwcAxplrLe9nemIlm+sfONdaUWjQ1ziuoYNEBcDYM5msdbthWSfOFZ89VsZ7XWBsmGTdC7Nn8/29vJnuPjyvdz5rur00324G/7n8//5nL57X5XWnpreeELkYPPNmjEEpltFbz1ey4f4fec6s6q2TZBhvbVGQJeledHlFv/HSvXrl1TWdaKSSTK54nhjnCoByCGRajr0eWUy1nFgr+Wq7EPxj0EgAlEx7ucDFVMsx7TOBoempqY9cNt//cGu+/40Hq0p8p+nYMBSXBXzL06Y3WBawhXnOGJQNjq3ASeebXjcdrOqF+ytZf4whJrbzvgBO0q/esEc/88JZuVZfgK7t6rOCAQCMi3xw4ImV7uX9UB7EhyWUFx92qgHoDQDsqj7N/k6vZfP9f/Ole/Wiy6tKLRtVHLbOsoDTuqwWatVvMoJJEgA7bZPmE6mZ5ipO73jW7MjE03lfAOekdz5rRu89vEfeTInvaQ7YVdUAAOMhkLQcW8+oP8pmBG4/MShUAwC7rKcjeLHZ36uvqetXb9gj0+7P999McVnAX/yeeaXeNp/fR1CDgbP26P8PP2tmJEb/i/KqnbjVF+BfvmSvkg2bA3K+ABh9jPpPFmLCkqMaANglPTf6Qas02DnpZ144q1+9YU87gBmV4D/XWRawphsOVLXQzNf1JXjBAPUNjrPHYi9dMxPqzu+aHqngv6jS6gtww8GqfvPmvTp8oKpzTU8SAMBY6Rr1jxn1nwQkACZEuxpgqXNy06cY2Cl9gn+fdc597+E9euezZtrZ9VF+XzWT3vnsWc1WXJa80AZJAAIaXLL+x1DeEPNc0+tN3zWtuYob6fMm7wvwosur+s2X7tUrr67r9BpJAACjr++o/6hebLGjSABMEKfsHuSJRnai+xEqQwbGVk/Drzz4T830L1+SNfuLh9zsbysCl00FeOH+it75rBktNjdpCCgR0ODS9MsrtUr/F2PTy6+s6cjTR3f0vyhPApiy5oCvvmaTJADnDYAhyoP8wDHqP8miYW9AqVnhzwjJS31Wk1TzFae9tUBBobsxgC3qV/aftoL/m/bqhoNZs7/KmKRaA5dNBXjDd03rg99qdE0FcKNyddjselq83k7KCobF4fERfc9Zp08Q3Ftpki/758fkfanYHPBXb9gjSfrMY6u6rBYoWfdyR7mmAUCZRU5qxKaza6aVJOv5E2gEc5OmbFQCA0ECYID6r2o8PK7n49SkU2umldRrX81pJnLtGxWmBwAXYNYVd0VOarZG/n+9EPyPU5VNsSHgm75rWr/1F4u6YjpU3FoZwBVWPJeU3TEMuV7wQtepcYiHL4X1fDzyr7fnLjOfZpKfQ+eapu+9cjSW/duu/H0zTwKYSZ85vqoD9ewcysP+bBcM/9wBUG7Fe/k8wX9q1et807ruT0Ytzh7597ESGJNxKewE0/obxMhJjcT0eMPr1Fp2CchLgQFsoBXE5OdS5KSF2JSMcfCfy28SjjxjWi+/qqaF1lSAjd+QeZvGxcuPK6esaeZslC2vN65HVX7KOye978Y9evW1dR1vJO2vdb+ucX2VAMZBfi8fOmmlda9/ei1LRm7+vo6yIwEw4fKLgCSdXs0uDitJn6WMAPSdwxu1GpYdPpg1ARvn4F/qBDD10OlHnzPT9Wj/hoC7slkog01K/8PAabHp9cPPntULL6uO3eh/Ub7ZgZPed8Me/cwL56TWqiBdr8k0gnW3AMoibN/fe+7v0YUEANqirgxh1iSQCkWgpc+NesVJp9e8brm6rn/z0r168eXjHfzn8iqAF15W1U0HKzrf9ArbFwNWBcBF2OQYcZJWU9NltUBveNp4NP67kOJ0gB9+9ozuvmGPvJkS3+e1cf4A2GFO2Vz/fNRf6oz6AyQA0FasBjizanp0udUZVPQEwITbIPg/teb16mvqev+Ne2RSKYL/IlO2LOBclPU24DqAnZSP/jvnlKZev3R4j+Yq2Rq1ZTiN8pU/Yi+95GBVv37TXqUkAQAMUL6035MrXicaXquM+qMPEgDoK2yNAD7R8HpihSUDMcH63JiHheD/fTfuaVfKlOkcKVYB/PCzZ3R+zSsMNpsKQACDDfQ9Nlql/85pKfa68WBVN11Ry0b/d3frBq4SZMnBGwpJgDjtk+TgHAJwEfou7ZdkS/s5Rv3RR9neZ7FD8qZMgZOWk6wa4Mxqp0kgMBE2CP4bienV13YH/2U8LdrLAj5tRtfMBGqmxZUPSALg4nWt0uhN73j2bKlvUkPXSQL8y5v2KmzdfZEEAHCpIietJqYTy15PNjwLjeKCSADggpyyIOD0WjaXqBFbu7SRWxWU1gbB/2pqmqk4vefQfHs+XVnfaPNzfK7i9OanTevcWtquAgC2ZJPGf4GTlpupbr+uru++rCorwdz/zYQumw5w48Gq3vGsaT25kqrS7y6MJACALXAuvz/Pmvw1EqN3F7aEBAC2rJ1hbHg9ybQAlFmfG/DASU2fLZrzK4f3qBK4UpYr9+osCzijl19V0yINAbED8rnxl9cD/fPv2dMuYS27qDUd4AefPq07vrOuk6tp//m5nEcA+ugt988qdDtJVWAryn7vih3UddFhWgDKaoPgP/Gm1Ey/ftM+veRgtatpZpl1Lws4q9RbV/k2sKELLPvXiL3ecv20amGWTJuA06k9ta4eOv3qDXt127V1nVojCQBga3rL/RmMw8UgAYCLwrQAlNImwX9ipn910z7dcDBb6m8Sgv9csSHga66ra7mZFl4/VQDYHqfsBvayWqA3XT/TDoonRXGJwPfdsFe3XUMSAMDmNir3574bF4MEAC4J0wJQGv2Cf/UP/ifxGM87Cf/z79mjy+uBYs+NBzaxyei/c06p7yz75zUZo/9F+et1TnrfjSQBAKxHuT8GhQTAQFnp/5iscHHyTAtAaThJqTpl/5Mc/Eudqp9a6PSW66fViFkWENvRKv2fgGX/tqpfEuBs0/e/xnA+AROnU+6f6slGKm9WuD4MPwYY/B+/A3sR/Uzq+y52VHaiZuVJ1ipPSilPwvjYoPS/kZj+x5v26caDVSUTHPzngtb5/KbrZ3RZLdBqYVlAoK3v6H/n30lY9m+repMANx6saiH2/SsB2GPAROgu9++9n86DY+DiRcPegFIrJrEmQeuGpZ2xTFLNRk4HpkKFrfLh9n0hWQEMW/sYtM6x2HosCqSnVlN9/3dM6SWtkf/+N+STxSnLx89VnH7p8B79sy+eUzUKZNaqBiqmA5xaJ/wO77jNrhvF6631eazM+r32Ydng/8+W/fPtZf+8USkmtaqNWgnGH3/urP781Bk1vSlyWXPE9inkJTnrzMcBUCr59XCpaXpqNc36DRUen6jzfpJe6xBQAYCd07oBNWt1OlZrztJSojOrXqkvhAKc2Bi2PCNl3Y+FTjq1mur2a+v6lcN7Jq7h34UEykYmbrqiphsPVrUU+/77Z1ICb3TbYO6/k5RM4LJ/WxW2Rvyev7+if33zPiXe1MwrbHqTO54TCyiLPMfnJDXiYrm/FBafxGmPHUQCAAPlXDaycWbN69HlRMuJKXAEVBgBfQKV0EmNxOu2a+t6341728cqh+t6JmVl3GbtXdm3FwCg7Nw615y8Zf+2I2i9X95wsKp/dfM+Ra27//77iXMNGHdOneTfkyupTjB9FruEBAAGrusC10h1YjltLxsocYHDEGzQ8X81Nc1UnN5zeI8C18nMo1vgsl343ZdVdPt1U2q0Ent90bxscmww+h84aTE2vfyqmo48Y1pGVc2GQifFPksCvOOZM3pyJVHU706N0woYa+0BslUGyLD7SABgV7RLnFqN1U40Uj25kspaJddc77Br+gQpecd/yfQrh/eq0hqh5AK5sc6ygPNdywICG/nR58yq3uqkybGysSjIAoMffMa07vjOKZ1ZY2UAoCzyID9b1i/RmTVPRRR2HU0AB2hU+jGNguJof7vJSWJaXU40Vwk0Xw0UBZ2pjZQ+YSAKN8z5MeZanyzHpt986T695Aqak21F3rgsXxbwf//aovZWAyVmCuR27fy90P8zKVMnexdPGrb8/MpK/00vu7KqF15WmeilNLfKKbv+1EOnX71xr5a+cFZfeaqpPZVAifW8P5rRTAEYA/k8/+XYdL7p26X+xXuNUbh2jwIWARw8BriwK3p7GOWBV1LoD7AUd8qfOOmx43pGy/LPAiedXkt12zV1veSKbLk/gv+tyffTm66f1v5aqFW/QfKOkcry2+D8ik2arTi9k2X/tiVPsAVO+vHnzWar63jj/ALGSPE+w5v0RGue/3Ir+M+fMyqJW0wOEgAYqrw/gPX0BwgdKx1h8EInLSder7m2rl+5YQ+jk9uUByNzFadfOjTf6VoOKDuXFpte73zWDKP/FyFszRF+/v6K/qeX7lO0WV8SkgDAyMn7XzHPH6OGBACGLr9tKfYHOLGcajWx9trr3Nrgkmww77+RmmZbTf/ypBPvy9vjJDW9dPOVNX3fdXUtbtYQEBPDSVrzpiunQ/39Z84wx/UihS6rorjhYFXvfHbWFHDDJApJAGAk5O+BZ1a9HmvN80+5BmKEkADASMkzo43E9Hgj1elWc5S8USC3N9i2DYJ/k6kWSu9pNf1Lafq3bXlQVw2khaZXslkjQIKTiWKyVoWN6Ssn1xS47DqecBhsW9Tabz/49Gnd+Z1TWko8STZgBLXvYeP+97DAqOB+FyNpXfZ01bfLR7mIYss2CDpDl625+85nzuglV1QpTd4mk9q9EkzS//X1Jf3wZ07rs8dXNRM5pYMK9kkijI1iqfo//+I5/ZPPn9Gxp9YUtXq8eH6VW5ZPlauHTr98eI9mK04rG0234RwBdl0x8D+xnM3zp4oVo4wEAEZaPgfyzFp3IoCmx7igDW6EAyctJV53fueUfvAZ00oI/rclH/WPnPSnT63pn/zJaf32Vxe10PSaqexe93+MkA3OtTwJMBVJDz3Z1Lu/eFb/59eXJHWSRxwvW5M3BayGTu85vFe1MKuy6IskADBw7eWt1R34N1rT4OhjhVFGAgAjLb/AFhMBjy4nWo5ppILtc5JWUq/ZSjaSVg8dVSVblAdrgZMWY6//++uL+udfOKMvPbmmK6aCdrMjoJc3aU81O8v+l/9yXj/7J6f15SfX2jfPHDdbk78PvuSKqt75zBk9uZIqdCQBgN1UvC/1llUTFgN/7ksxDqJhbwCwFfkFN19K5clGqoXIaW810HQlu9pyE4m2DUckTbXWCFq1Ne+f0f8L84WlER98fFW/9vBZnV71mqsE2lMNFPtWWQ5rkmMDaesCfcVUqK88uaaHnljVq6+d0j87vFdzlWDj7vbokvdR+MFnTOvr52J97vE1TUeu//sf5yOwY0zZqGngpMRLC2teC7FX6gn6MX6oAMBYaZdc9awYQOYVHRvN+zfm/V+EfK7/Yuz1Sw+e0c99/rQaidfeWtAuSybIwFbFJs1UnGarTg8cX9Hf//gTevDxlXYlQEoid1P9+wF4kifAgPSrRO3q7M/JhzFEBcAgmZjkOCiFYL+RmBpJqum8IiDqUxHAEgLl55SNeOXv1oXfd9DqRs68/60zZbszctKXnljV3Q+d1mJsmokCyUmJNzn1THIc9Hl2oZ/d73o7Sdfh3te5W695K7+Xwr++9eF05NSITT/3uVN65bVT+rWXXq6gdZPN+bmx3n4Av/zlc1k/AOtZLie/JpIeALYtn/IWqDXiH2cj/vlqN2Hx7W8S3l92myl7s8BAUAGA8VS4qQ+U/Wk3YVlO1ejtEcDFufyKwU/h9+1kanrTbMS8/63K1ys2M/2fXzuvX/rCKS01vaZDl+VYNjqfOM+wkT6JmdRLkZzmKoE+80hDP3P/k/rTJ1fpJ7EFXf0AnjWjUytekbPuc7P9PsnOBLaqa8Tf96xG5aVQhdzapCSXUTokAFAa7WVYmBowmTbpRL6Wmn7lhj3tef8cDhtLLFu/fanp9ctfeEq/ceyMTFI9CjYpz259gR2Ljbg+2djWCFpqpn31UF95YlX/+P4n9eCJRrvfy8CWlCyBvB/ADzxjWrdcXdPZpm3cFJAoBdjUhUr9Q0cxKcqDBABKpysRsFFFAMqlzztyNjXdtJKabru2rpuuqMkoLd6QKQu4Iuf0pcdXdOQjj+pzx1d09Uw2Uywbke3sPNfu4a7C/mfnYhsKx03iTXPVUJXA6WcfOKl3/8mTrZtxR1+ADeRn4FTo9GPPm9VsJW8GuMEFEcA66wL/1e5lpwn8UUb0ABgo6oOGxxV6BHg1Eq/pKNDeqtN0Jct7eUaWSsAV6vC636KdpNib5itO7z40T0PsTeQ3Od5M/+FrZ/V7f3Vea16ajkIlZnIu37f9boPy+RS7cT71bXXe83HvPJBJOc+H/X6zye+mq15W3Y+1vyalljWzm6s4ffrvlrTcTPUPXrBP33PFVNdKFOjIqwBesL+iH37OjH7zzxd05XSoOO/RUWwI0L4ITso5AWzMJAWte8XEW6urv2X9bVyWfMyuWpwvw8F+HyQqAFBSnZvhTkWAb00NSNSIPRUBpdB/4r+1Hl9LTb90wx7VQicvxqf78a3gf6np9Uuff0K/8ZVTrZJ/Vyi/zgO53lJ/EpyQLpiYsQ2Om94T0mXnbj4l4EuPN/Qznz2hLxxfbk8JIG+7XnsqwPXTesXVNZ1d8wqdybo6aLX2udFVC5Ote8TfdGY1LZT6W2HEn/c3lBcJAEyMvj0CmBow3jaIBvLf823X1nUzpf8bin12/H/58YZ+4EPf1uceW9bVsxWp2IStt2zC9XxCWQX6ptY2f8zlH7vO4659PGVl//O1KJsScN8JvfuBE5I6PQPQ0Z4KEDn9t62pAAm9ToAuG5b6M8cfE4gEACbORokARyJgvGzSij7x0uVTgd59aA+l/33k8/0rgdNDJ5b1s/c9pkZsrZJ/qR1SONcOzTac/8/tEvqcX915om2cgO3nZhUoTtJcNdQn/3ZR737ghAJHX4B+OlMBqvrh58xoqVXl1rd8mQQKJsiFAv+AwB8TiAQAJlZ2I5klAh5vpHqcioCxZzKFgXSu6fWW66dVD51SMRJWZO2RQdN/+Opp/eLnHpdzQafLf2FEtmvHXWgnut4EwcZfxwTrOr7WH2eu8LhzTtYK9i+fjvTZRxb1k596VH/6RCMLeFkrsEu+fOIbnzajy+qBmr5YytyDJABKbrPA3xdG/IFJRBPAAfLKMiy8zY6e/KLvpUKzQFMjSTUdOe2pBpquZGEM95gjqM/Nqymbu3duzfTyq2q66xkz7Td5ZMw6y4K/+4ET+uP/b0FXzlRUaS2PmPXz6wRnrmfkP/u0z8Rt4CI4SdbuL+lab5ZWGI5zWd8JkxIv7atH+srjDf3Zkw39m1ddqxuvnlHiTREZW0md/TlXcfqlQ3v1cw+eVRSxbzBZsuZ+2Xt/7KXza14LsVfi1TXAwwz/0cXvZvCoAMBE6m0dl99/OictF6YGLPdMDeCCNAI2CP6dshLY2dY82Hro2iMA6AT/kvTu+4/r3r9d0LVzVZlzrV3amX8tqXvHFUZqL7q0G+XW51joqgQplPav+9ep8Fhn+kn7Z7SOy8SkPfVIUeD0Tz/7mL58YllR4KgEKAiUJa1vvrKm266tq5FYayCCKgCUW/5+H7VG/E+tej26nOh0odQ/fx4BJiYdCQCgR78eAXkiICIRMLICl3Wy/+HnzugF+6tKGP1vS83aN0fvvv+47v27BR2YrijudPqTgo1G/9c3a1uXVqH8H9uxruS/+/HiNIB2MqD1xMSkShgoDIKuJEBMEqDNuVaVz6E9unwqKDQEJAmAcgrcxoF/RKk/sA4JAGADvYmAxxtpu2lM/obCrdMu22T0f81Ll9UDvfFplP4XZd2Ns7WO/3kh+E+8OiP+7YBfnVKY9khs94dtwwjqSSSMnW1XAbRH/iUFQednuED5gejlVAmdwlYlwEMnllUJXLZM4CBfzJhwklJJ9dDpLddP69yaV+jYNyif/D5tOTY91Zrj3xv4c9wD65EAAC6g3xvMqVXeYHZd35Gq7DHnpNSbfunwXs1V3PpgdUIlPuuL8KdPNPRTn3pUn/m7RV0+lQf/rYDKObmugL/PGL4rBnLbHP3H5LjIbv/tEf/2t+eBv3oSAu2P5JVVAjjn9IsPHNd/+OppqZUMZFC70xDwrmfM6OVX17TYanDLVACMs/xIDVp56uXYdHyZARpgu0gAAFtULDE7vZaVmJ0qvOHQh2r3mbIb3YWm6YaDVd18ZU3euLBJajdH+9KJZf3Upx/Vl04sa189Umqd+dWdpn6tz4P8o0LZdd8a7Z5/N8Oo/cTrXwXQ+xz1HGZB5/mtY9S1M3udSoBqGMjk9D99+Um9+4ET7aatkx7T5gFQPXT60efOtqcBSSQBMH7yozPKA//EdGI51YlGqkbCFE1gu7hPBraht8nM6VZFwFOrXsssITg4m5T+p63Gf//gObNdje4mmTe1g/+f/exjipzTnlqktBhAuays+oLz/nsrAjYM4Djwoe0lhXqmBLhWL4rOQ8XqgFYSoGuKimStz6+Zq+reby/o3Q8c715UYILlVQDffVlVr7luqr3MLTAueu+5zqx5Pb6c9WZqJLauqz+ArWEZwEGi1Whptd+UJKU+W182kDRVcdrLEoK7JnDZvv/pvzenF16WNf6b9FWvUjMFcnroxLJ+7rOPZZUrYdAn+O+e9++6mq6p83j7J/fMq2D0H9vg5PqPPOcd69pj1k750n+dxIBlgb6ypxRXDMyXDYy9dPlUpHu/vSAn6T0vu0qVIOsTMMlHYb6v3n1oj/7LqaYWYlPk8gRqz54x45zFyHDqLOV3Zs1roekV++zxdiKLe6zy8sPegHKjAgC4BL1laY24VZbWyk6bWnPVxPvURdtk9L/ppWtmQhr/tfhWw7/Ym37lT05IkqphmO2tLQX/QSfID3qC/+K/PUECnf/RZStVIsXnuJ5nrJt+cqFKACcXSIk5HZyp6MN/c15Hv342WyIwnewrb14lVQudfuDp01qOfaEKgKkAGD35PVPSqrJ8dCnR6VWmWwI7iQQAsAOKjWmCQiLg0cXuNy7et7Zpk8Z/WWNGrzc/fVpzFSevyd6/1lrqy5v0K39yQktNr3ollN+p4H+Def+TPb6KDW2rQsRdYhIga2jpAqfYS1fOVPR//sVpfenEsiqhUzLhpVhha1e+6foZXT0dqulJSmP05I39Nrt/4pgFdgYJAGAANspg5+sxM2ft4uXFwrGXrp4O9ebrZyRN9uh/3vvAJL37geP65LcXNF0N5W2Hg/8eGwb/jP5jA+uOmR1JAuRfb313KxHws599TF8+sZxVAkxwEiB/L5qrOL356dNqxF7hZjXUVAFgF+Tv5UFrmkqj1djvOBWUwMCRAAAGyKm7YeCji0k2PSCma+0FbVD6L2UN7s6tpXrz9dnof55YmUTFvfTu+4/r3m8v6MB0Jes/sdPB/1aW/CP4R26riaOdrARwTianWhQoDJz+KUkASVmC1CS9+foZXVYLtJoagRWGpmtVpZ57I5opA4NHAgAYsH5Z7uPLqR5fXr9uLTaWB//Zsn9eL7+qprueOdlz/02SN5OX6d0PHNe9f5sF/0neBl0i+Mdw7WoSIP+65OVUCQOFQdCVBEgndHQ7D/bnKk6/dMNepd7a1wGWBcRuyYP75dj01IrXYxtURwIYLBIAwC7jDXALNrn5NDnJTD/6vDnVQ9dOsEyi1JtC5/SeP3lcn/x2b/C/nZF/XXrwD2xk1ysBikkApzAI9I8/85j+8qkVhW5ykwCBsh4hN19Z040Hq1qKvUKSABgwBkCA0UMCABiSDUvgJn3uW7/70Na/oXNair1uurKm776sqnSCR/8Tb4oCp4eOL+veby/o8q7gvxXRu2CLI/+FwEvqCcS2Evy7DYM8QNIFkgD9kk2u6+OLSwJkzUFroVNipv/jz07JW/ZdE3ddbcl7hbzz2bNy1jfsBy5JsSmyU6EXElMggZFBAgAYoo2a4PR2v52spoEbd/43Sc5M73z27K5u0ahJLQv+v3xiWT9332OaqYatZdPzkX9tEvwXhlt6R/6dugO1rg83CfCJ/bEVGyYBNnle74ebJgGyx3qTAImkPbVIDz2+rHc/cFwmk5/Q4DfMCqj03ZdXddOVtVYVQPY1qgBwKTZaFvnRxURnaIIMjJRo2BtQbibJi8sctip/Y8wy5qkWm6lmK4GmIqeZSnajm5rKW/Zu7b+6H5IpdNJiM9XNV9b03ZdXJ3buf2pZ2f9fPrWif/yZx1olztlIp6R2cJQX9soFrXjKlDdJy5/XtftcflRZ4YvWeupGtSjdz9sdvf+X9XxsPY9P0vV3DF6zU9+gsnOE2frnueLDJus97y1/vPVEk5xzMuclnz2WSto/FemT315QJXB6/yuuzqbQTOCcq3zvv/PZs3roiVMyxoJwkYqDGE5S00vnm14riWk57izZO4GnGS5ZHkNhELjqAyPIqTM94Mya14nlVCd65syVM4t+gdF/Se989tyGzyy7PD+SetP/8eenlJqpFgWF4N/1mfMvdbICrbu0Qh5A+ZfXDbXmHzLyjx12SZUArnO4Bvlz+k0HaD1SOLYTMx2YjnTv3y7ooePLCie0KWDosl4A7SqAJlUA2J7iaH+xp9HxpURPrXgt080fGGkkAIARtdU32LyBztjfovWd+9/p/L/Y9Lrpiske/fetEctf+fzj+uKJJe2pR0osH7HPSp83LvsPunIA3aUCne9hzj92xSY9AbqOu016Arjic/IeAFLXFID1PQGcZiqB/ul9k90UsFMFMKcNwn6gS3Fufz5AcbYwQHG2zwAFgNHEFIABssIf4GIUA/vi9IAza15uTZquOE1HTrOVQNUgK5YqLnWdvwePxzG4fivzUX9vUjWQ3vncuYk9p1LLgv+Hji/rU3+7oH31SIlJplaJvwukVnMzVwjkTU4uaO3L9ijfuuH/VuVAcXpJexJBtxEL/C90LEzS8TJ27znObTgdQCoci87J2tMB8u/JR/yzicVmrj1rwGVzAFo9Q7p/oJcpCgMtJ4n+jz8/pd969bXZl3qnxJRcsQrglqun9MCJVc1WA6WtMqN1jRLNRu7cx+5xavWPkLQUm1YS01Ls1fTZSGIx4KdoG5cqfx/jWBocKgCAEWZ9/kjZG7FrVQWcbC0l+GSfsrux6UDRJwgojkk1vemyeqjn7a92NRGaFPm8/794akX/tNX0z+c36D3Bv3qC/ywQ6kQ37eDfqdAPoDfYH4/gHyXg1kfeeeeJ/GPrfV7X8do5nq31HCsktaxnSUzJKbGsKeCDJ5b1K59/POuh4cfiSrmj8veHQwdrWkutK/EyeXsDRcWBh9B1Bh6K0xET6zT8G7vkIzDhSAAAY2iSSvFCJzVirzc8bVqB1O4kPCl65/0nrRUAsoHNQK4V/EvqU/afTw3oHtVX8eOukv9Nyv4J/jEwm00H2OB5bqOvBO1H2tMBCj0wXCEJsL/e6gdwYjL7AYSt68Krr5vStbNhTxKAXgCTymmCph4CE4opAIPkxRUSA9fuFdD6eLlpWmqazgdeM5VA05HTVOSypQatk6UfmXBuk9F/J2ktNV09HeotT59tdxqeJPm8/1/83Al98fiyLpuKlHhJclmsk+++fP5/XhbgXKeuuV0qkP/jOnMCunb/JsH/qFzHNtuOfkNQkzIs1a9UaKy0DtT1ZSetr1if53WmA+Tj/tmzAkk+O/5b0wGK+yWbKmDykmYrof7pZx7T77z2O/TCA1PtaptJ4JQlVPdWA73l+ln9r189r/31UMlYHj+4WPkZlN8jxJYl3RutTv6mLFmU32P0PU2BncYcgIGiAgAoiY2qAh5vpHpkMdHpwjq8kev+nlFSHHkKnbQce73l6bOaq7iJG/0vzvu/99sLhZtzt8HIptqf5wmCrYz8t35i/42YkGAIo2DjY831O4alwvFZnNoi9VYCqM/5YpKiwCkx0+/82Sml3iYuuMmbqb756TO6eibUKlUAE6G3xN8kNRLTieVUjy2uH+0vfg+A8UcCACihdlWA64zynFn1emQx0eONUZoisPEtRT76f91spDc/fUbSZHX+75r3/9nHNNua998O/rvmNkvF4KZv8J/VQ7c+3kLw79Y/Dxi4Pj0B2l/aaApAz+oA7SSA60kCtO94nOSy6TN5P4AvFvoBTFKMm78/zFWcfuDps1pNfNd7AusDlI9T9l5aLPF/bDHRieVUjaQz4l/OpYYBSCQAgFIrFs3mb+Z548DjS4lOtrL8an3d9Xzfrm1g+9Pu0f+lptdt101N3Oi/KRtoW0m8fufPT2XNlsIg6829LvjvXvpvw+B/uyP/E7O3MXrchsmni0sCtBJnXT83/zhLAuybivSpby/owePLcq0KqkmRJ1bfeP2M9lQDJd42P/snKUNSAsXRfqesxP9coWfQuTWv2LrvE/gNA+VGAgCYMFudIjDwZMAFbiK9SdXQ6YYrapImKxxNfdbo7+jXz+qBR5e0tx5lN+XtUflOMN8J9FsBTdBvX1H2jzG0Y0mAwuOFVTKkvEggG/WvVwK99/MntJb4rvYaZeeUXW+nI6fn76+q0Sr9zlEFMH62U+Ifusl6fwVAAgCYSFuZIhAXkgHF79kNoZOWYq9XXF3X4YM1eZuc8v+89P+rJ1f07796WgemK0q85BQURjMlBfnIfyG477qR6wn6Cf4xjradBOh5xrokgLqraFpJAa9A1TDUYtPr/Q8+kfUNnKCR7qwfgvQjz5tTLcwSApt/w+Tsm3HRG/RLlPgD6I8EADDBNpoi8NSK16Ob9Au45BuGTTr/59sTp6bDV9SyRrATdIeSxyr//i9Oayk2Ba1mZQryr6qn7F9ZYsD1/hQR/KMctnJcdpX2tx8szH4pBv1qT5/pTKXJqqKmq6E+8e0FffXkigI3OUsD5tf25+6r6vJ6qDi9wDQAjITie3jvvP5H+yT0CfoBSCQAAPToHT3o1y9gkKMHTtJqarpmNtSrr5vKbmwm5EqVmhQ4pwePL+lLjze0px4qNRU6/kvdHf+ldsDTjnv6B/2dZxP8Ywz1OT7XHct9kwAqNAAsjPr3/MziKhpRGOjffvWUVhLfXjq17JykxGfX9Tuvn1Yj9l1VV6wIMDqKQX9exbfZvP6o+3QAABIAANbbbEnBRwvzB6WLSAZcYPQ/cNJq4vUDT5/R3mrQKn8vP1N2QV5NvN77+ScUBU5m+ehkcaQy3xtB4fHe4L/wg4tBDsE/xtl2kwCFfzvTATqPZ4mBQpPAwMmbNF8Ndf8jSzr69bOKApctDzgBwiC7/r7l6bO6bi7SGlUAI2OjoL/f+3LvvP7JOHoBbAcJAACb6u0XsNFNh3TplQFOUuxN85VAb7y+tfTfhFylzLImf+9/8Aktxl7VMJBJ3aP9xaZ/eUSzruN/T5lz/q0E/yiD7SQBupIBnUqZLOjvfKWYVHPOKfbSgZmK/v1fnNFXT64onJCpAHkVwFzF6bbrprS4toUqAAzMdoJ+iXn9ALZuQm6tAVyqQd2M9I7+ryWmFx+sajoK5Cdk6b/Usrn+Xz25ok/+7aKmKq3XHnRKlhUE3YF+v+C/iOAfE+TCSYBCFUD78aDzcfH5zimQ01Ls9e//4nTeImAi5Lvhxitqmq26Cy+HOAGJkd1E0A9gN0TD3gAA46f3JsXUuUk535QqTpquBJqOnKYi1x5F8j4L9ze6mXaS1lKvGw/WFQWdOalllu+PlcTr3331tMLAKXCBvKRigNLeDevK/gs2aPrXF8E/xlXWon/9w3L9R6nbz289w0kyJzmTLH+s8zOdk7w57alF+tLjDT14fFkvvWZG3sp/Pcpf34sO1HRZPdCp1U41kpQlbDdMKOKi5O8BTllA7y17P200vRqJaSWxdiPc4rJ++fcCwHZRAQDgklzaiEV35/+11PSdc5Fefd1U9twJuEKlPhv9/4P/elb3P7qk+Vqk1KtnRFLq3CJ2f9i2nY7/BP8Yd9teHrCnEqBfU8BixY2TTE5R6HT3Fx7XYjPN8gg7+ypGTj4NwEl649Nm1EztwkkPqgC2jZF+AMM0AbfXAHbLpjc1y8m6m5qgcFMTOmlhLdVt101pb20ymv9la287LTa9/vM3zmtfPcped9AduHSW/Osd/c8/L0wL6HwjwT/KrdjvovjwRkmA1lfbf7viz2idL4XPJakehjq1muqD3zgvJ01EQ8C8GeCbnj6juYpT7LubAZZ/DwwGQT+AUUECAMBAbHaz80Qj1SOLiU61bnZM2Tz4vbVAN15Rz75vAuLUPJj44DfO6fhSrGoYFOIZ1z3vP3886Al5irG/W/9wl0nYqZgsWzmk+zYFVLEAoM/Py845b9JMJdR/+uuzWmym2eocO7DZo8wpe93TUaAXH6hpNfE9VQD99kDZ98rF6V1Rx0xKCPoBDBk9AAbJrPMHmGDW+jtPBpikxJvOrkoLTgpkCgPpu+Yi/b3Lq5LKP9e2M/qf6j/99VnNVgJ5M7XrjJ3k2rND80UCW4+ZWk+wzlxmFeYwt7+n8O2u9cG4X47WXU+t+2vtr1vhsd3YsGGzCX/Psa5/XPvRQifRnmNjXccAk5xzMpfvw+wZtcDp+FKsD37jnH74BZcp9aao5Bcob9lrvPGKmu5/bEXuQudRfomaxEOvcLlt97hxnVkm3kvLiamRmJZjL2+taRat56yb0z+J+xDoNZHvY7uHBMAAWeEPMNHagank1d3wKF/q7vhSov/mmbMKnFMyATfYqTeFgdMHv3FOjy3GumyqIi/Xfs9zrURAFutnH7vWDXanILfzr7P85jN7rH3dKV6ASngxumCT8i08pwxMk/6e49bdMLavIP1iV+v+0LXSbZ3AX3KWJQjyKoCjXz+ntzxzr2aq4abNTMsgbF1/X3XdtH7nLxbUTL2C1vKJ1v67Zw9MyIFXiPczhaRT3sTPvLScdoL+uJVTKk55a3/7pOQogS2a3Pex3cMUAAC7pjjKUbzAp960txrotuumFBSntJeUKbvBXku87vn6Oc1Wwyz4l5SX/mfPK8zxD1R4TIWy5s7PVG/wnyv7DoUkbph6j/POOH/v1/MpNZ1zyNpTAQqPtZ7tnVQLAz22lOgPv3lOgSt/L4BsGoBprhroRQeqWkmsa4C/76ufkBE7r8IUN5cF88Upbicaqf52MdHjjVRn1rLgP08O5EjYARgmEgAABqvvTWHnMWem2Juungl101XZ/P+g5AGrtW4I3//FJ/TUSlJYZsups+Rfd6Dfd95/zyfM+wfW6z5d+lTPtD/tJAacXNeqAF7S3lqo3/2LM/rqUyuKAqe05AGvt2zK1kuurCv1pvXdD8r9+ovaAb+yfZIH88ux6fRq1tcmn8/fiDtTS/L+N8WfAQDDRgIAwFCFgdO5Na87njYtp6z8v8wha2rZslpfeWJZn/j2omYr2eh/V2OyXL4EYLExWfHfrqXNyrzXgC3qm/Da4NzouzRg/ln3qgAmpyhwWoq9/t1XT5f+OiV1TwPYUwvV9FnCNlfmKoDiq8gb+DllDfzOrHqdWvV6ZDHRE41Up1b7N/Hr/TkAMCpIAADYZd1N21Jvmq8GuvXaqayUsuR31fn98ZdPNJR4KQwKl+H2kn/dpcp9RzC3sqPKvjOBfvoc91tZGrD9td4kXOs5Xk5zlVBfO7WqRuwVuHKvCFCcBvDiA1WtrVsNoFx6R/nz17oUm06tZl37H1lMdGrV68yqV2Kd5+aHSZmPBwDlQQIAwOBcYDTISWp60zUTUv5vyjv/e937t4uar4ZKi7uoK/Dos97fRgOZ/b5Q4v0IXIy+SYBCgN+eCuA6pf+u8ByTUxQGOr/m9YffPC+p/L0AitMA+lU92BiHvF2X3guM8p9ezUr7pe6KgN6fAwDjgAQAgF3U3ZI+DJzOT1L5fytY+M9/fVaPLMSqRYW5/0Fh9L9Q+t/dAWCLpf8E/5h0F3UOFM6mdhKg+2d5k6aiQEf/+pwWm15RUO4qgO5pAMG6aQB9jeg0gH5l/fnjy9sY5e/9WQAwbkgAABgOk5IJKv8vjv7/p2+c11x79D9v/NcZdexu/NcThJR5JwE7aatTAXqfVzgV298R5FUAUj0KdHwx1n/+67OSyl0F0D0NoDZW0wCKHfY3Kut/opHq7xYSPckoP4AJQgIAwGBsofw/Tk1XTUj5f+pN3qT/9NdndWIxH/3v1/hP6x/bAKP/wPZtbypA/linIWBq0lw11H/6xnmdW0tLXwWQTwO48cq64nR0pwH0C/hDl70VbVbW39Wxn1F+ABOABACAXdJ9OxUG0kLT6wefMaOg5OX/+ei/N9OH/ua8Zopz/9uj/+oqO77Q6D/BP7AFl3pOFL+/XTLuVIsCPbYY61PfXpSp3FUA+TSA266b1sHpUM3URmIawFYD/keXEj26RFk/AORIAADYeVu4OTTLbtbmq8HYlJReLG/ZKNPXTq3qVCNVJcxH//Ma0+J8486HXQjugYuz7akAhSqAwnyAThVAKwkQBvrKEw05qfTXMEmqR071qH+1w25UAVxKwJ+/31DWDwAkAAAMgZMUe9O+eqgjz5yV1BllKqM8hPgPf3FGa2lhqoMrBiKdhEDf0f+un8foP7CjCudk+6H8r3VVANk0gNlqqPsfWdJ/ObmiwDmlI9r87lI5Zf1aaqHTq66b0uKaV7gLl5t+TfsuNeAv528IALaHBACAXdB92+WctJKYXnFNXXuqgbxtacr7WErNFDinrzze0BdPLGu+Vmz+V3iic+seovQf2CFbTaStW3Gj8FC7CiD/kU7OOf37vzhT6ilMUvvypJuunNKeWpC93h2cBpAH5/k+3KhL/2kCfgC4ZNGwNwDAhLFs+b+lptffu7yqKHCKvZW2AaC17mq/8kRDqUlR6NRM1R79N7nisuMt5dwXwFA5ty4ozc5Byz9pRaGd5+UPKQgk7zvPU9bTY6oS6C9PraoRe83Xwq4gtkzy6/PfO1BVNZRW006AnrPsaraln5fvp/zZocseS3y2+5di01qa/VlNsyljqXUKMlzre/KfVfwXALA5EgCDZCIFjQlkmx7zzqQ49TowFepFB2qSpLCswb+y5n+nGql+76/OqemdFtasPY82dNntss+LsQq7zhXmI3fikw1G/yfpGrPZa+13vZ2Ua7CJ95wLKZ4+/faRa4X77a8VEgaFx7JnZUFpFAQ6v5rog984r3e+YL+8maKSTmfyJqVeetGBmv7k+KoqgWsnOLv2Z8/n+YdB61IVKNvVaSuoN5OWYq+09a9Z6/+y7HvyqRhRv4CfYx0oJ5Pkh70R5UUCAMDOWndDtv4OLfVSPXR6aWv5v5LG/0p9Fgx8+P87r68+taYDM1UtxamCICslnq1lI2tzFUlBXsKaVQVkcVyn4VZJdxGwe/KpNxtVAeRfz8ene6sAFKidYWk913tTLQz0R984r3c8f197ScCyna9OUmJZH4Dn7q/qk3+7orlK1uC0+GrzoLxdyq9OjrI9up8URvcTk3PZ10ydZop5kz8r/GBifQDYGSQAAOwey+bJrqamW6+bUmpSaOVNAAQua3Z4/6PLmq4ECp2UthqISdLZNS/J6XwzK56tR05ToZM5p7lqoEDZcol5U8B8pbHOYORWC24BtPWOWG/69dYnPY9lQW1WBVCNnE6vpvqzkys6fOW0vFkpq5ry1/Tc/VXtqwWKfefiXZy779Qa2Ze0HHuttkbxFps+G9TLR/eVfbu39eX8vR8DAHYOCQAAO2cLTZ9CJy01U73oQE31MJv/XynhzXI2muV0ZjXVg8cbmqqEWQDfmvsv51qjXU7esrvm5di0FGf9EM43fVYdUM2WDJwKs2W4srLjzhSBYlKAagFgK9ZnALp6AbSD/p4qgM5f2Xls2aehczoTez10vKHvuWJaPYPipZFfpr/nYE21UGr6bJQ+kdpJzXNrqZycVlqj+6Ys6ekK3987un+hfAwAYGeRAACwa5yym8YDU5FedKAqqbzz//Py/4/8zYJOr6a6fKqitNhh3GUl/vmnUmv0rLDOeL7UlSlLFuSjZPPVoD36P1cN5NTpmm3KYpbexljl3MvAxeoXdhYf6/Nxb2VA6/PUm+Zqoe57ZEn/3YsvK+00AKnTB+DZ+2v65N8ua64WqpGYVtLsGpSV8rv2NUlaP3e/92MAwO4iATBA9GMCip2gWqNBZhMx/z+7GTZ99pFlRUFQuBa4QmRQ7INdUHgoaCcEOmW1p1pTB5ykc82saVY9cqq3MgTz1aC9DcXSWl+IYcqSGLjQ9XWSrsG852zDBsPOvZX/vSsHZAUAgSTf1U4gCpyebKT6sydXdPiqck4DKPYB+I75iv52MdE1liUqg9b0pqBwvWknIa3E87wA7Lj8+kEPwMEhATBQ3I5hgvRtydw95hNIWk5SvfLamVLP/+8q/z+xrOmKa72R5XMA8vFB647Anes8p7Xv+o1RRq7z9XxprGz6QPbx+WbaTgpMhU6ppKnQaSrKbtbz9bI3qhbI/5/RtPkxtv7VTNL114v3nO3qt682OaZ6Egd5g7vIOZ2JEz30eEPfc2V5pwHkSY1DB6s6OB3Ky7Il/FrXpM5Vq4QvHsAuIgUwSMGwNwBAWVw46Aic1EhMN19VVz3M1tEu421i2pqY/+G/Oa/Tq6mqYdAz+l+YClCwpX3hXDskKd5m51MAwlZTrawBl+mpVa8zq16PN1I9spjokcVETzRSnW49nlgrCVBIDERu/RYSVqJ0Ni++KZwErvsht/45qUlztVCffWRJ1loKsIznS74rvvequvZUAyWpb+V+y/hqAaCcqAAAMCC27kNT1sAu8eW+WczL/+97ZDlbK7vvs3qij3aHrD7RxRb1/j+B6w7gk65qAWtPIZCybPBca+pA3lugVejcTi7kP6ffVILtby0wAnpK/Ps8Qf17AXQed87JzFQJnJ5cTkq/GoAkrSTbTHJQFAAAI4MKAAC7ILtNXEu8rp2t6G3PmZMkhUH57gjz8v9za14PnmhouhK0OvW35vsX5/8XXn42srjz+6PffP9itUA++p+YdHrVt/88upTokaVEf9eqGDiz6vXUqtdy3Jl6sNWqgXKne1A2bt2J2fdJ6j2nQ+e0FHs9dKKRVeGU8MB3ypKbs9VAb3/OnBZj3+4zsrkS7gwAGFNUAAC4dFu803VOWk1N1RIG/rm8+39e/n9guqKkKwLfoPHfOv3qk3duv/XvLVD4umWj/8WKAanTWNC09aqB/P/bqHIg/35gZG22JGDrseI0gP/+ReVeDSBvCJj4jV5fWV85AIw/EgAAdoVTFvy/8tq6KoHLgsGS3R9mo//Z6/xsv/L/Dar73YjsiI2C8t6pBHnjwURZ1UD+3HNNL6cs0J9qNSDM29LlTQjz7w2D7t2R9y0gQYBd12cagJNrt7Tr/npPF8DCUp5mpsg5PdlI9JUnVvSSq7NmgCNyeu+YfGWSm66sa389VOwtu4aV8cUCQAmRAAAwAOsrAgInNeKsAWA1dEq8tbrZl0vgnEJn+sqTK5qOCuX/7de6QQXAheb+D3lf9Zvrv9WqAal/5UAeSvVWD/RLEBQrCPLPSRRg97jWgH9xCQDJWStR4LLFPaqh07k10zfOruolV08rNWsHzGWRv5yXXl3X3mqgc2upoq3MAyBBAAAjgQQAgMEya68DXfYGgPn97ReON7SWmILiTXG7/F+lilK3UjWQP69f5UD+PXn1QG+CQMqSAsUKgvx7wp4uNqb1s1Gyn+lU4sNOkgp9JrAd7cOip8TftT7KqwDax3O+7p9MiaTUF3+W0+nVVCuJ6fPHV3TkOdl0p7IWw6/ErUaAeWKE4B4AxgIJAACX6MKRlXNuIhoA5qN9f35yRU+tpLpmrqLYa9MbY+fchW+cx/TGeqPkQG/lgNRdPdCbIJA6FQQy6+k/0PlfnJlmK10t3JSaVA2cpivjuQ+3airaWkd2V8pQNLPR688D+mIgnn/cb+A6NbUTTfm0nuXEtJq0klRmCmRaSaSVxCtw1kp0St77bAWQR5cVuux7y5Z7KjYCfNtz5vS+L5/Wgamovc86ypr6AIDxRgIAwKXZyt2tWekbAJqyLuCrqenPTq5qthK0boiLYW/x342Uc//06nfYbJogUKuCoPWNnSRBdwLg3Jp1fZOT6fxaqi+cWNHLrynXnOw8OI1T05+eXFU9dPJj2Hp+q1u8weSZTYN5qTugL/6sVNLimu/6/wMzraSmlcSUXaqyr3rLGnxKWQIg/xmBOpUtaiUAq6FTM80qgV553UypjrmiPBGQNwI0s4GtZgIA2DkkAAaJNbAwCfqO+nR/6iStxqZXXpM3ALSRaXy3kwInhZIeOr6iehjI8kHsdt8w19VDLNsHFxgidBf4ekltmCAoTAHo9wbmfeF7TaoE0v93PtaDJ1b18muytdnLNCc7cE6r3utPT66qGjj5vIxiq3bo+Oo3yn4hFwrce5+b+qxKpN//nUpabPp1LyWQegL69T+z63taQWzg8sA+mwaQJaWyaQJ58/9sJkBeU5G9GjNTJQh0vNHUn59c1SuvmyllH4D89dx8VV37a6Hi9cP/G6AqAMAWTOB9z24iAQBgcFrz/8PAaSU1fe/VxQaAw964ndWe/3+iobXUK3CB2gE/o/8DsVnJd1EtdO0GhGWUetN05LIlKHuHyXs+X3eE7dAh12+U/UI2GoXv9zxTFuBvlN/oG8wXvj8P6HsfX5d8cK5rhL/4b/7tXUUWxeRe6xmpSbPVQH9+clWriakalq8PQLER4GX1UKdWElW2Ut1Vth0BAGOIBACAS7C1O/68R9Sp1X7jd+XQmf+/2pr/H2bz/4thxHZvfLlR3h7XGrHNIzSXBYWzlUC///UF/fcv2qvpKChNDJL6rAnb0W8u6i9ONXXZVKTUrJB0sj49Jnpe+Q6MTG82yn4hmwXu6/6f1im0URXARpUEVnjORl/bMufa5e59NyJrB6B6GOiLxxul7QOQW45Ni02/ye+9LGcbAJQHCQAAF28Ld7VOUuxN+2qBXnZ1PXusZPeD+fz/Zmr685Ormq2GFxwN3VLzP26ct6kwv6IgUNasbSUxTZfsXS816WQj1akVLxd4JT5PNLVGsXchAZD/1H6j7Fv5vq1MAZA2D+SLX995/Y+r9V/Pp/iYgsBpLTV98fGGXnFtOfsAeDNNhU4vvbquT/ztsuaqQTa9SyrfiwWAEgku/BQA2Kr+N8mJN+2vR3ppKwFQtvmwUqsZmzd94XhD9chlZcJd5dcE+4Ox+X4zSdUo0ImlVH/0N4utEefxH481SVGrn8YHv7movfVAzrLmicP4k48Au23+yV/LVv7smu1en7qm+WTbWgmcTq2m+uKJFUkay+aMm3HKGiNWWwmA1Yuo/gAADAcJAACDYdYZsXNOsfdqxOW6Ce7V9NYJ/iWtD3Ww+7LfRyV0+txjjfZI9bjLA8o/O7mq40vZ/GsvydzWA+qd/DNRnNu4iWnr4SxBkyVHyr5/lmPbXs6kZMkQABg3JAAADE7rRs/UacRWRvmI8n/8q/N6bDFWrTXPvEvhtW+p/L+EVRLDkpppvhro499e1ueONxQ4l82VH2P51JrfePiM1nz/LvNlXGljeLZawZOd26lJc9VQv/dfz2up6RUFrrSJgHroSpFUA4BJQQIAwMXZYgAVBk6La6l+6Dlzmq4ESryVdjw8clJSbPy35QCsrHtkAC4yqM3nZD/waCMbtR7jaCybXeK0FHv96ZOrmq0EG5eYkwS4OBe13wrf0+rFmJhpqlLO30HYivrf+pxZXT1T0VriO3ug63gc45MNAEqoZO2QRoupf7diYFLk5cFeWQVAGW+DTVlPg2Zq+uLjK5qqZPOybbPGaxiswlJurQeU+KwK4IPfWNTPHb5M9TFemi3v/v8fv3Zep1dT7ZuKlNpWXsk4vtoR1Tq/iytOdHUptCzpdHbV68Hj5W0EKGXX9sBl17wsuWZUnwC4aBM5tWyXUQEAYFckJc6G5Q0AHzzRUD0K1d1jzlH+v5t6911hTnYlDPTYUqyf+ewTcm6DpdxGXL7c5JefWNFvHDujuVp+vI1rOmOcbL2RZ9YIMNCZEjcCzKW2/dUfAADDQwIAwA4p3AFad/42kFQLd32DdlUztWxU2ZQFoZT/76Kt7UOvbF72f/rmgr78xMpY9gIwyxJOv/nwGZ1fu8S55SSaNnfR+yc7/01SFLrSNwLMru+9VTfSpq96zM47ACgTpgAM1MT2SMZE2Oxmz7IyUElrqenq2VBvfc6cpM680bLIy7H/3/96To8tNnX5dFVJOwGSrwDANWBn9dufvXOO+x+frrVs3a9/+ZT+4PXXZr8dNx5pmNSyY+2zjy7rvkcXtb8eKTWv9nHmCq/ZcdztjE2uc63jZv00gOz4S02aqwT6j//1nP7hi/ZrphKUqk7DKVvidboS6K3PntX7v3xGB6YjJe0SKI5BABeLa8cgUQEAYOACl40QldlqYvJdt/YXufwfo7IDku3X1EzztVCfeWRZ/92nH1cYuPYqDqMsNVPonB5+YkVv++hj2VSTTZ6fLU3PsbTztrhPW/s+S4JKaYmnQDlJtehClSijf44BwKQgAQBg+7ZzL9caHRuDGOuSzFb7LP0nbX/+Py5sCz0UupqQ9eRlEi9dVg/1h988r8/+3ZKiwBVGLUePt6zrvzfpf/zSU4pTU6Vd+l9Yfm5THHcXZ7v7LX9+ZwnUSiBNl3QlgJzvSXDYuC+1AQAlRgIAwEXY3o1d781hWWQrAGTz/79woqF66FRcBfDCyh0U7K5tBMAu6wcwUwn1jo8/pvsfXR7ZJIC3zpb/yCce02cfXdbeephta/sluXVJjgsiEbU1FxX/Z9U/JikKnM6spXrwRENSeRsB+nWzbsr5OgGgDOgBMEi0AECZbXaz19MPsKxLAErZEoBrideDx1c0FYUyryy1alI7eugeFNwYU2a3Z7N9tVE5RmuOtnkpdE7mnN76kUf0e6//Dt36HTNKWj0dRkEe45ukH/n4o/rDby7qiplIcapCoNlSmFzu8uknG+2frR6P6NhwX7nW78j6PrcSOJ1a6l4KsIwXw1roshGlbfQB5HoHYEOspT5QVAAA2L5NAy9r3wyHzmmx6fXW58xpuhIo8VbGe1+Zk6YiJ8tHkO0i5/+Xcu8Myjb2VX68Wvf3eMtGaEPn9NY/fkT3PZJVAozCkmbZcn/Z/c8/+Pij+uA3FrLgv31D1Arw+x1rF0o8k5jennX7ym38td5cqEmhk+pROc/tvKnrW587p6tnI62lhWv8hY6zEay4AYBJQAIAwECVvQJAyub3OvVpglWIzcq9B0aT663AKHwlL4H3JlVCpyhwetsfP6J7v72o0GWPD2OJQFPWWT10TgtrqX7s44/qD7+xoCtnKq3gv7Xtva/J9Xzg+n6x76e4gM32V9+v9SSaJNWjct9udSoACOoBYNSV+x0JwEgo60BPPp/3weMNnV1NFQVB7yBzj+1O1Mb2dHVc3ODLrudjJy+nSpAlAX7ojx/RP/jYo5JaUwS0e4Plecl/FDjd93dLOvx/f1Mf+/aiDk5HitedRPnSf27dozQE3GkXu7+yniD1MNCDxxtqpllVRxkvh2W9xgNAGZEAALBzJuwmMB/sevD4is6upapwRR0xbn0VgMvLMlzhHTDrsB86pz21bHWAu/7o73TfI0vtIo7Y20AqAvIR/7yh5Pm1VP/mK0/pRz/+qBaaXrOVMJuSUNzuC66CsOEnGJjeyovsAzNpKnR68PiK1rwpmLjmi7bBxwCAYaEJIIDt2XYQVP6bvumKa48Wd2w0Ar2BiQsMdoBzWzwee7uN5Z+3SunNJOdkZjJzunw60v2PLumzjyzqTc/ao9+49Wrtq4dS67tSb+25zxfzW8tXSPOWNRzMmw7e++1F/dSnj+uJ5UR76qGmKkE2slo8NrqSTN3VDBxBw5JNALLOp53DzUkmp+lKMHG/H5NxVALACCIBAGDgyl4e6i1v+p/X93LTOzyF6Kv1YfuRQtyfzdXo+WIrGZB4p/l6KPOmD39zQX/2RENvedZevezaad36nXNdqwTkSwcGTnKbJHHS1vOioNWj32UrSJxZSfX//tUZPXSioU9+e1HVMNDl05FSk7y5VuyfB/rFhn/BRfaZ5NjcGVttYe8kZ6Vd/q9oEl4jAJQBCQAAl2jzm77AZQ2iyqxvgoMGgCOiK+rv/3heBdD62Jm1yu6luWqgpxqp/tWXTuq3HpZe+7Q53XTNjP7+c/dpuhJoeovzPopJg/Nrqf7LyRXd/3dL+sNvnNPfnGuqFgWaq4bZlAArTl5oz10oBO+u6+His7oDfI674ek+3kzlToQ6Zdf5hbjELxIASoIEAICBcJLWEq+rZyp663PnJHWWjCqb6YrbQiU6gdlA9J0GsN0qgNbvoysJkC9DbIpCp4MzFXkzfeLbi/rI3yzof334KdUjp7e/YL/i1PTSa2d06MoZeevM887/m9ib/uNfnlbsTX/25IoefGxZsTedXk21rx7p4ExFZk5pa1s6fQv69ytYP4rP8TRwm003uUAxgCm79k1Xyvd7csqqYKYrgd763Hm9/6EzOjATKaEaAABGFgkAADvIijNhJZW3AiBv2tZMTQ8eb6geuVKP8I21VvDWnqndTgLkUzY2SQK0npJYlhGYr0VyTlpKvBZjr1/9/BNKvGl/PdSeetiJ+gu8SccXY3mT6pVAU1GgIAh01WyoxGcj/p1t6FPuH6jwQws/vHfu/4VG/yn/32XZ8RYFTmdXUz14vKFXXJslicKS/S7yCoDe67+kvudE52vGcQkAu4wEAIABs9IGxoFzWvNeDx5f0VQlKNz6bvOGlhvgS3OhKoCuR3uClK4kQOv72kkAk2ut65j9Y0olyUtREEgyHZgJ5JwUp6bza36D7ZMOzFQkl83rN8vao8W+tZkuL/Z3nW1oB/+FKgBK/0daV4JJah9+lcDpVCO7Trzi2pn24VU2Zb3OA0DZkAAAgEvgJE1XAq1tFPwVn4hdVpwKUEwSFGr8u75WCLDNlDXas071QCsJ0P6yXDZ63/rWaJNKl+x5/ebwZ4G9a3+cb7ekoKe/wLrgfxsHFUmmASgmmTaeB2CSQqdSTgEAAIwfEgADRDIck8wKf8ouVfH1dm7yewYCMUhbWRKw9zldOYF+lQCd56n1pXbyoJUMaH+/9S4D2e//7/xXXaP8kqw43784JaFnqL94dHWWnaP0f5T0LgdqMnkpayxZYtbzp39KpKTlDwB2TH4NucCwCi4BCQAAQDlsYypA/njnW3qCEtezYkA7oikGME6u9Txrf22D/2pdV//CF13hcSfJBYVvdN3fUnyuRHC/m7aSZAIAYMSRAACAndY1uNs90svo14D1jfd7pgLIOqP5xSRA18h/a6Q/LxPIOwJ2/fqsXdbfXcLfq2fUsyuId93ft8Gh4tymD/b55o2eg4EoHmLtD50kzynPqD8AjBQSAINyRtKcJqcGGpNjo+PZuj9sT5cu+/Hffo2u/K91HLhCJNb1++hNAqirA3m7NWBxrcBiUqD9/Vub992zUVv4uPj/9PuaOj0EigmEvtUL+aYWn4MdsdG+7D0Uite+dv+HsgfBrXPGCv01CP4BXAzetwYquPBTAKBlO+WvnWgK2D1bScZsEKh1hylOUlBo3Fd8hutO/Kyr8ujV85x1QXvr/+rdbit8V7/t2EIyjlNwl2z1eJsEk5D4BYAxRgXAQE1SGzRMhn7H8kbDXv0+L6vN215tyl3E9+DCNpuT3xvxF57XntNfHLhsD/gXGwj2zAffdG23YlM/bdC0r+c5rakJhRdT+N6e/gT9jh+OqwHp3adbuN45tY6dSfh9eE3G6wQwWF60ARwcEgAALgE3eiib3uaAKgT7gbqSPRtW86/LHPR7UvfnheDf9f1Z677Q5+dt9DwAAIAMCQAA2FGFpnDdD2G3bdi1vSdAL/YEKHy9XQ3Q9T0ub/nf83Oc1gf+Qc/nPT+n+Glhky/whfVf637iJl/DYBWrOTofAgAwSkgAAADKa9Ol23rK5Dd4bt5zrzs/0G8+f++If67QbqfPIP763gM9278dxP+7jKkWAIDxQgIAAC5FOxgkCBhZ200CSH2aALh2RYC00W97C9H3RlP+t7yE3yb/B6X/AADgAkgAANghBMAYYdtJAuTPV+/Dnef1q9Tf8AxYF+yrJ3G0lVF/Av+RsOlxhPUKCTWOUwAYCSQAAOygnvXXuU/GKLlgEkBanwho/WX9yvuLj9nGIfq6KpHe+fytr20YIBH8Y/xsti4GAGB4SAAAwCVioZoxcsER3I0SAb1D/b3hzVZCnd7nF4P+bY76924TRp6fyIRob4NMAMCwkQAAMFCmct/4Okm10Glh2BuCrVvX9b/vk1r/brCue1ft/1bGOjecB7DJ/73Z5hFQjZPAZdeJMrvo6zzTAwBgVwUXfgoAXByTFDppulK+mzsnKfGm6Uqgtz53jxabXmHgega7GPkaaVsKOrbwO3SF3/uGfy70fxWffKH/i2NqJLn1HzrntJaYrp6t6G3P3SNJ2XWihKYrjvYIADAGSAAAGAgzKQqks6upvnB8RZLkS3h3mFcAlO+VTYgtB9RbDNC3959v72cS+I+tslYAmLLX1kxNDx5vqB65Ul7nAaBMSAAAGJhK4HR2zevBVgKgrPeFZZ7iMDG2NbK+2VD/dp4/iG3DqCrrdSJwTmup6cHjK5qqBKW9zgNAWZAAADAwZZ4CgJLKg+2LPmQvIdBf92MI/DEenJgCAADjgiaAAAaq7E0Apez1lfwlTqBWEmC3IxoC/lIq+zVQmozXCABlQAJggMyURQW8KaIsNjuWC1/Lj32zybgprIVOrvV6GQErm2JAbl3/7NyP7l1iECNtO9dBZdfAauhK3w7UTDIvWcBhDODitQeOWGN5YJgCAGDgypoEyLt5v+1587pmtqK11Jf+Jn+ytUr6nbv48vyu72WViLILnbTQTPW25+7RdDVQ4q2Uv3GqoABgfFABAGCgTOXvAVALnUrY4BtbQck+LsDUqhIa9oYM0HTFKXIkAQBgHFABAGBgvElTodMXjjfUTE1BSW8QU8v+tF9c+0UyBwiYGNb3Q0lSUtJS1nzJvy8cb+j0aqqI8n8AGHkkAAAMjLUSAA8eX9FaagpKOloamFQLufEFsF6grAKgjPI+Bw8eX9GZVa9KcJHTYgAAu4YEAIAd5Dr/tD7MpwCU8RbPSUq8aboa6G3P26OFZspUAACSsuvDWup1zWxFb3vevKRO35Cy6Z4C4Nb9TXoUAEYHPQAGimUAUDa9x3K/Y9vWfZyalbYRoJTd4tYj13q1JX6hwKSz9l+9DxY+zj93kkxRUN4KgFziVbj+Oa3bR67PYwCwIa4Xg0QFAIAdtP6CbTJFrvyNAJeaqbyVs8M3gNx2bkpNzkmN2CstaQ+A3HTFydproK5PAgMARgcJAAADY5KiwOn0itcXjjckdZpGlUVe0fuya2a0vx4q9kxpBSA557SamL73mmnVQle6KihTdv1rpqYvHG9oKgpK9xoBoIxIAAAYqErgdGY11YPHVyR1mkaVhWtF+y+9Zkp7q4HSsr1AAJvY+HwPnNSITTdfPaVq6EpZIRQ4p7XU9ODxFU1VXOmu7wBQRiQAAAxUVgWQzZEvs5XYFAWuPUW46z6Ym2JgAhTm/5skM4VBa4nQEjMTwT8AjBESAAAuwdaCem/lTQDkKwHMVgO9/Xl7tNhMt9fpm7tmoHSck9ZS03WzFb19AlYACESeEwDGBQkAAAPlTZqKnL5wvKFmagpcOW8UnbKRvsRvNS0CoMyck1YTr2pJA/+8n8sXjjd0ejXtVEABAEYaCQAAW3cR3e2y8tBADx5f0VpiCkrYIS9/TTdfPdVqBFi+ub4Ats5JWmk1AKwE5WsAKHWKl75wfEVnV70qeaLDiSwoAIwwEgAAdobr92H2kVlWJhqW9IqT5zS+95op7a0FStbd7bMsFlBqPad14FzpGwDmZqvBJpVdZAMAYNREw96AUjN19QQCSmGz47k3zi0sC52k0lpimq4MbtOGbSU2RXI9572JG2CgDHq7e3Z/qfihSao4U+p3YbOGyCStxl6O+x0AO4lryUCVdDwOwKgwmWqR0/GlWL/3X89JktKS1cMWGwH+0P+fvTuPs6Ss7sf/OU/V3XudGWA2ZhgEURBBQFBQREAFREQQkhi3xC1GE79J1Owx5mu+MSb5fn9JNAbUqLgP4AIqKJsgyCIooqwDDOvAMEvv3Xepes7vj6q6t+7W23T33T7vF5fpvlvXrb63us55znOeFw5grGDhdOFUB6KeNs/DlgAoehbr+lz87gu7swFgsLqLYKpo8bX7RjGQMvM8rnfXfiAi6kRMABDRChD4CpS6fDRMAAyE5bBE1LssgIxrunb1k4gIUPQBYcKTiKhjMAFARMssODE0AEpWu7aqKxrh++0XDGB9n4tC7eLf3frCiXpW494ejgjGCxa/fdgAMomgJ0i3hsfFquNct75KIqLuwh4Ay4jn+9SbBIBCg38ABOXx/SmDr947ivcftQr9KdO1M+PTriDtCsaKFs58X6HqolZYIKJ2ouX/iwTVQN36qfatwjWCr9w7iicni9gvl4AXq/CKHf5nx+MeEdWI2ol0edFoS7ECgIiWkDT9Nponn0l05wlf5fUZ/M4LBjBesHCbntwyPUjUjQTBqPj6Phe//YLunP8f5whigX+TtG73vnwioo7EBAAR7aP5nd05RjBasLjlqWkAlTWku028D0D1S+zSF0zUC2Y7YNXcZFWRCSuBupEiWOaw6CtufWYG2YRBl/V1JSLqakwAENGyUwgSjmBP3sPPdgQJANuFGYByH4DDgj4ART+a+9t9r5WI6jkiGCtY/M4Lunv+vxGg5CtueWoaGVe6NqFLRNSNmAAgomVRe9IbLRvl1I2Md5+0K8glpP51dvsLJ+oZjRsAKoJEYDfP/48UrSJdFfxL1T9ERNSemAAgooWZrWlTw5uCdlC+BQaSDr563xgmCxauaRAgd7h4H4BzD+nHSN6f//xfDqERdbBgpL9kFavTBr91WPfO//fDev+v3DuKJ8dLSLkGtTmAyjfd9/qJiDodEwBEtGIEgKfd2wgQCPIjAuDUTVkMJoMS4MYY8BN1EyOCqZLFiRsyGEwZWO3O8v+II4C3oOVcunlvEBF1DiYAiGgFBCd+jhGM5ru7EaAJKyROXJfBhn4XJRvvA9CFL5io282zAWBUAXDqgVm4RrqyMV5VA8Ad8QaADO6JiDqF2+oN6G4KnvRT96p9Xzd4n0t4ffAfEkbw3FQJP9sxjVdtysGqlgPmbhFNAxARvOF5ffjnO/ZgXV8irATQmnvy2EDU/hp9Tqt7AAiAorVYk3Zw7iH9ALqz/B+INQB8eipsABjtC4n9H5jz+CY8BhJRMwrAznkvWhxWABDRIiz0pC0IfhUK16DrGwGKBK/x1E1ZDKZqpgFo3Rex27p5rxB1i/oGgEYE0yXFiRsyGOqB8v+CHzUAjPZF7b+hbt4JREQdigkAIloxvgIDKQdfu38UM6XubAQIVKYBnLQ+gw19idg0ACLqRiJBBUA3l/8DlQaA37h/FE9UNQDkEY6IqFNwCsBy4gwA6loyr3mxlQLPyv0NgBnPIu8psonl3cpWqZoGcHAfPvXzvVjb58amAUQlEDUdtKIvecwgahM6++dRg49t0bNYk3a7vvwfCHbHeNEGh/T4OY6E/5vP8YvV/0Q0G84AWFasACCi5RU7QVQASUewY8LDN+4fBVAZUeo28WkAA0mB5+vcSUEFunbokKgT1X0c49N5asr/13V3+b8CcI1gpmTxzftHMZgy8Gc9XEmTr8Hgn4iohZgAIKIVIuV/rYYjSC3dnuU16zSAbn7hRD1GJOz+v6m7y/8jeU8x41mYrkxzEBF1PyYAiGh5iVQN/vhWMZgy+GaX9wGIpgEgXA1gvGBjZcH1TcSIqM3MoymnACj6Fmuy3d/9Pz7/f8ekh6Qr0Or6//mnBLps9Rciok7CBAARLZFZyj1rGEi5D0A3K08DODCLlCPw2eWfqDuEH2Ujgsmi4tj90xhKd2/5fySa/x/kAgSzHuu7eUcQEXUwJgCIaEUpgKQr2DFZwjfuHwHQvX0AHBFYVZx8YBavPziHiaKFE418zdpYrDv3B1Fnq6/csQDSruAjL13VtdVMQO38/5Fg/r+tHv0nIqLOwAQAES3ObCWcDRrbl7+K4l8VjBV0jiZSnc+Gvf9O3phF3tPYbuM0AKK2Nd/yf89ibc7BMfunAVR6f3Sr6ZJixtP6+f8ClvUTEXUIJgCIaAUFJaO+BQaSBpc+MAoounrkzDECAXDeof04eNBF3u/uEmGirhcerBwjmChZvP2IQThGgqU/W7tlyyYa7f/utlE8PVEK5//PZv5TwoiIaGW5rd6AbtatAQ3RQqmEiz7HPhSuI9gxVcJNT07i1Zv7oNqdA0hRM8DVGQfvOnIIH7t1D1alHFgN90ez19ytO4SoI1VX7AiAvK84eCiBd71oEEYA6dLPqwIwEnT/v+7xKSQdKVc2BSoNAHneQ0T7arbVkmlpsAKAiJbQ/EZ9ovmkI3kfv9w5AwBd3SAv6gr+ziMGsTpl4JUbhXEaAFHbmcexyDGC0YKP8w/tx2DK6erRfyCY2uAIcMcz08i4JmgCOM9pYPW3dfOeIiJqf0wAENGyq+sDAMBXIJd08MvnZuBZrTTH60ICwKqiL2Fw7No0pkq26+cKE3WlMDdgVZFxBKccmAXQ3TGtDRMit+2YxoyvMIbl/UREnYwJACJavH0YAVIFsq7gxiemMJr3YaS7x8AVQMIRfPi4VdWj/1wNgKjNVVfqOCIYL1qctimLV23Mwmp3JzBVg4TtdY9NYM+MX9+zhQ0AiYg6ChMARLTCKuFvwjHYk/fx3W3jALp3OUCgsiTgy9ZlcPrmHMYKtkHQ0L2vn6gjzCvpFpT7/+lxq7p+rmo0XQsKXPHIBIbTDnwbv0ejwJ8VAkRE7YwJACJaGSJ154Kqwaj49Y9PwLMK0+XnilGw8KfHDodfzyN8YBUAUQtp1ZeOCEYKPk7flMPL1mWgXT76H5X/3/L0FJ6eKCERjf43WAWw8Tc1unhfERF1CiYAiGiJzTX6U7nOKpBLGNzy9HQ4DaB7lwMEguBBwyqANzyvD+PFsAqgm180UceY64OosKpIuwZ/9tLhrh/9Byrl/9c/PoGxoi03NI2WdI3+ISKizsFlAJeTxi5EXUtmH6XW8r2Cu1UPqCFhDHZNlfDdbeN491Gr4FsNSk67lA1X9zt5Qwbf3jYBI+HUh3IioGZtQK6tRbT8BICd+y6er1iXc3HM/mkI0NXNPKPyf98CV2wbx1AqLP+PH48k/N98jlE8lhHRfPFYsaxYAUBELRAOG2lsGsBjvTENIBpBO+/QfqzPuZgp2uAcutkfOwWnARAtt4YfsXi2UuGKYHfex1tfOABHpOuX/qsu//eC8v/a7n91gxyzVIDxMEZE1BaYACCiZdDkJLBBH4DqaQC266cBRJUQqzMO/uu0A1AKB/+7+kUTtbs5kmyOCEYLPl5/cB/+8OghABorh+9O5fL/xyYwVvArr7em6oHz/4mIOgunACwrzgGgXlJbF6oNvq69X9AIL+FIOA1gFO8+anXXTwMwEoyuveagHE7dlMU1j01iMOXAL99DEeRnY/tQmSkgWj6zlOBEs3IE+IvjVyGbMPBVu3oEpar8/+ExDKWdcJWW6BhU++9couM5j19ENB88Viynbv77RUQrpS5Wjx24RZvcTctXqCoSBj0zDQCoXhFATHhN1d872+De/INItOQajv5XPm+OAGMFH6dvzuKEdRn4Xd75H4iX/08G3f+dBquWLKgBII9fRETtggkAIlpZ5WkAtasBOLjl6ameWA0AiK0IsD6D0zfnMFawcOY6IrMXAFELKMQAf3rsqq4/LkWqy/8tHFN7cJLY/6uvq/+aiIjaCRMARNRiQbCfcAW7Z3x856ExKMLO+F2uUgWwKqgCYIBPtLKajv4HHAHGihanb87hZesy0B4Y/Y/K/61VXPHweHX5/2yvnfP/iYg6AhMARLRMGo8G1X0VThFQBRJGcOOTk+HyWiuwiS1WrgJYl8Hpm3LYm/fhVr3uBsEJkwREK0ZVYbUy+t8Ln76o/P8XO2fw1HgJCae2Iius4mJQT0TUkZgAIKKlsZCRofJ9pXzxFRhIOfj+w2O46YkpGBH4PRDsRkHFnx23CgMpp+uXFiNqG3ON/gOYKFpccFh/OPqPrh/9B4IjsmcVn7ptJwq+wvTAayYi6iVMABBRazQ4pzRGUPCB6x+fgK+9MdjtiMC3ihPWZfCRl67CSN6HwyoAopYSACVfsbbPxX+++oCg330PxMEKwIhgNO/jrmdn0Jc0CGZjSU3ilvP/iYg6FRMARLSM5jkNIORbYDDl4IqHx2DDpQB7IdR1jMAq8I7DB7Guz0Xeszw4Ey2nOUb/EwbYlffw7iOHkE4Y+D1SmePboNf/dx4aw65pDwnHNC7/r8X5/0REHYPnmES0MpqeA0YjS2EzQCN4aryEX+ycgaIyH7WbRbtmKO3gv05fixmvdklAVgEQrRRHgN3TPl5/cB/+4MVDQeO/XmhKgqD3igC48cnJBnP/YxjUExF1LLfVG9Ct9gLIoDcaBhGVicw7MFURALWBbjANYMZX/Mvtz+GyNx3UE6NuQHDibRV4zeYczn9+P7790CQG0gZ+ef+EXbiJaN/MMvofzX/vSxn85QmrkU0Y+Ko9MVrihysc3Pb0FK7YNo7BtAOvXP4f3atS/l/Ziyz/J6KlE/VGsq3ekC7WC3/TiKil5jo5rJkGoMFI+HWPTeDGHmoGCAT5E6vAp089AGv7HJT8OcqOe2S/EC2vWOM/IxjJ+/joS1fh+LUZeLb7l/2LCICSVXzq9ufCJv+1x+4m+4Hl/0REHYUJACJaWrOeDM5yN6mcYBoRzHiKG56YANA7ca4gmPKQThi858gh7JrxkKgqPZ593jIRzWGWg4kAyJcs1vW5eMfhg7CKnin9j5r/TRYt7np2Grly878aXP6PiKjjMQFAREtsASeHEpWWVneXjqoALn9wFHtm/J5pBggEAYeq4g+OGsLZB/dh97Q3+whkr+wYon01R+M/ATDjWXz29LUYSjvl63qBbxW+Av9zzx7snfHhluf/Ny7/r2D5PxFRp2EPgOWksQtRL5ntPV97mwLQ2IzSsC1AyhE8tKeAyx8cxXuOXg0/XBWg2wmCeW/ZhMFfHr8ad+zIQ8MO5MEeatQLgP0BiOY0y3HJEcFk0cebD+3HazbnYDXoy9ELFIBrBCVf8eV79iLjGFjboPw/StZqzU3N9qsIz3+IaHHYBGBZsQKAiFZAvPa/2SKA1dcqBGnH4MYnJiHonZNxIAhGPKs4fl0GHzl+FZ6cKM2e/OBJNtHsZhn9NwJMl3wMJg0+fdoBsNpbVe5Wg6X/7to5g2cmPSRdqamLiP9LRESdjgkAIlp6Czl7rpsGEPAVGEgZXLltDLc+PQ3poWaAQDAVwLOK9754CG87fBDjRT82FYDLAhLN3+xd/1WBtCv43OvWIu2a8vW9Iuq+8q+3P4e8Z2EkFvTXHJur9ktdk0AiIuoETAAQ0QppfLJY91W8QkAEAuD/3vHcbD2ou5IgSAJkEwYXv3YtBpMG0yUbq4RgEoBoXmb5WLhG8NRECX963CqctjkXLPnXQwcaXxUiglufnsK12ycwnHbgN7ojm/8REXUNJgCIaOU1XQ2wvhngYMrBNdvHcdvT0z21JCAQ7AVfFSlH8LnXrkXaFaj2ViKEaJ/McrxwRDBe9PG2IwbwvhcPBUv+9VL0j8ro/7/dvguq0dyH2nTrIvYJkwVERG2LCQAiWh4LnQbQ7HoJgt5P3bYTpbAZXi9xwqTHaZtz+NPjhvHUhBfrB8AqAKKmmn4WNJz3bzGYNLj4NeuQTRg4Rnrq+BJUOwhufGIS1z02gYGUA7+qwV/zfv/s/k9E1LmYACCiFTTXNIDwu1g1gFUglzC465lpTBaD+am9FuJG/QDe9+IhvO2IAfYDIFo0rZ73/9q1SDlBkq3XwtjoMHHD45OYieb+1+0EaVz+P9vO4ug/EVFbYwKAiJbRLCeCtTeFo/2VG8PVAETgOgZ78j6+eM9eAMGa1b2kqh/Aaxr1AyCiKrMkwYJ5/x7+9Ljh8rx/p8eC1mjpv7G8j8sfGMVQefQ/WvKvejoWR/+JiLqH2+oN6G4auxD1IJFZy3Crv260tn0gqAIQfO6Xu/GuF6/CYNpp+IhuVtsP4J1XP1PuB6DlvaGVe7NZAPWk6JjTaLF65bz/kG8VrhF8/ld78PBIAfvnXHiNDtUS9QWI3Sg1x5qG+5qIaF8oANvqjeharAAgomU0R/Avla8lSpbVLTutUCjSrsFjYwV8/ld7APReFQBQ2w9gFZ6aKCLpAPV/KMN9yakA1HMaJd2j4B/IexaDScHFr1nbk/P+gerR/8/fvRsDKROM/pePx9Gl2Z6pTd7G9NrOJCLqQEwAENHyWqJmgL4CAykHn797N8byPlzTe70AgJp+AIcPYsekN3v5ci/uJOpdDZNeQdO/gh98HD732nVI9ui8f6CSPP38r/bgsbEi0q6JHSak7jjM8n8iou7CBAARtcDCmwEqEFYBFPH5X+0G0JtVAPF+AF86cz3e/Px+TJVsmARoHPwQ9YQmFS9B0z9BwgDfPHsDTtucA4Cem/cPNBr9d2Kj/zXH5YU2/yMioo7ABAARtdY8mwECiFUB7MFo3u/JFQGAYI9YBYwEo5kDKYO8Z+HEplRU4VQA6naz9BpJOoKnJkv40+NW4dRNWRR97dkGmr4NOoZ8oW70P9wh5f3SqPnfHHowoUJE1ImYACCi5beAE8O6eoByLkCqqgC+dM8eGOnNKgAgCP59DYKbz71mLRRA0UaBDZMA1EuaB/8JI9gx5eFtL6w0/Us4vRmoKoKqh3xJcfHduzFYHv2vrciS2txreBPL/4mIugETAETUIrETyKYJguj6yqHKt4pVGRefum0nbn96qtwYrxdFJcynbc7hW2dvgK9AyUfz0c0e3U/U5Rq+rYPgf+e0h/MP7ceXzlzfs03/Iho29P/Aj57As5MlJB2pnvtfH/HP/8k5+k9E1DG4DOAyKq9ExHNuIlSW52qi6iYJlrYrr0tty18rAFeA3TM+/uW2nbjs/IMhPfwZMwJ4VvHqTVl88/Ub8FtXPg2FIGEUVhudlPfaAorU1Zo0/UsYwbOTHs47rB+XnLm+atpML/JVYURw61NT2HrfCIYyLjyLILdataJfZQqWaOywLBL/ZgW3nIh6jgIaW9jortZtSddiBQARtdAsJaUSH5GqHp3yrGJVxsE12ydw61NTkB6uAgCCpl6eVZy6KYtvvWEDfKvwbZQuqaFgJQB1hybBv2sEu2c8nPf8fnwlDP4VvRv8A5Uj6L/dvhNGBNLk2NpgHVYiIuoyTAAQ0cqZ7Zyy0W3xztTR12FiQCCwGpzQ8lS1OgnwjbPXY7I0S1NAzHY9UQdoksRyjWA07+PUzTl85az1wV3R28G/rwoJR/+v2T6BgbQTJEzjZfsSP87WHI7nmvvP8n8ioo7CBAARraBFNAOs/wIIG+ANpoMqgNuenuzpXgCRKAlw+uYczn9+P56d9pEwTZYH7O1dRZ2syefciKLoBxUAf/OyNTACKHq3438kPvpvNUif1q+2AvCUkIioN/BoT0QtNkszwLoT1Nj1YRmrAvinn+3EdMmiSajbUxwTJEI+/9q1uOCwfuyc8mZJAvT63qKO0+Q96whQ8hWeVVx2zgYcvzYNX7XcKLNXBX0PBNc8Oo7rHpvAYDT6XyYNDq9s/kdE1M2YACCilbWoJQHD76r6AgRVAMMZF9/fNobP3rUr6AXQo8sCRgTBCb8RwSVnrsf5h/Xj2SkPTv15foBJAOoUswT/M56Fr8C33rABr96UhWcZ/Ed7azTv4X1XPQHXMcEubDj6Hy391ywJG78vERF1MiYAiKgNzFEF0OgkNLze8xVrcglcfPdu5EsWjjRsfddTovF+AfDlM9bhgsMGMFawsNqkHJpJAGp3swT/UyWL/qTBt96wAaeGwb/b63X/CJZMNQJ86Vd78Mykh4xrao6NUVZQ4tfMX48nWIiIOhUTAES08vapCqD6WgWQMIJnJjx84Oong9WqGNCWA30RwVfOWoetb9gATxUln0kA6jBN3psJAzw37eGsg3O4++1bcOqmLHwFg39Ulv27fccU/vm2nRjKOJXqqEZTq+oSreDoPxFRl2ICgIjaxCKrABDMc+1PO/jW/SO47ekpGDYEBBDsHiOAr8DrtuTwzbM3wGcSgDrJLMH/zikP5x/Wjy+duR4DKQNfEa58QcFUIOBTt+7EWN4iYcLR/3jwz9F/IqKexAQAEbXGUlUBhM9jIHAN8MmfPYupkoUqGwJGHEF5icBvvaGSBGgYLDEJQO1ijuD/vOf34ytnrodBkARk8B/wNaj8uWb7OK5/bAKrsi48jv4TEVGICQAiaiOLrwLwVTGUTuCKbWO4+Be74Bo2BIyLlgiMJwFmPNs8CcBEALVSg/efIAjynw1H/r9y1vpyvwtW/QcUwYld3rN47w8eR8JIZVea6JSPo/9ERL2MCQAiap3FVAFEKwHET2DDE1vPKtb1JfAvt+3E7ZwKUKc2CdCfNJgqNUkCAEwCUGs0eN8ZAawqxgo+LjisH18+Yx2D/wZUFSLAB656AiN5i1Sjxn9Vnf8b7DyO/hMRdTUmAIiozcxSBRA/ca29Luz+7xjBWN7Hp259FqbZ0nc9zDUCX4FTN2Vx99u34KyD+/DctIeUI02WCVzpLaSe1iD4d42gZBWeKra+YUMw8h9N/eEHvCxq/Hfb01P41v0j6EsGfREAxEb/UXcYlaYBf6Odyx1ORNTpmAAgoo5Rnw+oPxn1LDCccXH9Y5O45tFxCKsA6jhhY8CBlMGXzliHNx/Wj+1jRQCNAipOB6AV0GTaiWsEI3kPnlV88+wNeN2WHHwN3qesRK9QBLtvqmTxyZ89A9dIJbBvNO+/WSA/1z7lPici6nhuqzegu2nsQkQNCZoEmNr4dglvi64SrSx6H7sp4QDv+eFjuP99LyqXwfLctcKRsHGaAb58xjoctV8K//GLvZgpAdmEqU+aqDLiomVUU6guQWPP3TMlnL45i4+8dA1esSEDzyqX+WvAD/fLf/58J67YNoYDB5Io2fBGiR8/o6QAAGiYJCgfTJt8HX8sz2eIaCXwWLOcmABYToz/ieav2edEqu9TOQWVSlBaE6yqClKuwWjewx9e/Ti++IYtsIxf6xgJcyci+MhLV+OYA9J4z4+ewVjeoj9l4FkNdm15p4ffMA6gfRV/T9Uk8KKS/4mSh/MO7cMlZ26AhFUrDP7r+RoE/3fsmMSnbt2JdblEEPyX96sAKvXxfbTTZ4n5Ebtb1X2JiJZLFDvZue5Ii8UpAETUBmaZa6rh19rgtvL1ErsEfAv0uQ4uu38E1zw6FgYQPHutJQgSAZ5VnLYph1++/WCcdXAOj48VgbDUurzvozpj/lGmfRW9l6reW1HJv4+Sb8P5/hugCD67XOavXrz0/x9vfgYTBR9GwoAfCIP6+BSA8KKVYqrKbY2+RpNjMBERdSomAIioPcw1PC8NvoxGsRqeuwaThDOug/f84HHkPQuB8By2iag54GDK4EtnrsOnXrU/RICZkoVT97thaRPti/r5/sESf4LdMx5O3ZTBt8/diNdt6YMNk1D170ECKqX/F931HK58aAxrsolK47/4KH+8D4DUNv5DXcxPRETdiwkAImpjs4xKSc2olsS+Do9sFginAvj4wx8+DiPBCTM15sSnBBy/Gl86cx0GUgaTJYuEqVklIBp6JFqI+Kh/yDUCq8BYISj5/865B+KVG7NhV/vWbGYnKJf+Pz2Ff7n1WazrS6JogUrQH/s6umIx+5PJFyKirsIeAMuIp8ZEC9RgPv+sjanCplSq8duik18FVOCpIpt0cOn9I/jdI1fj9C0DYTkxT2obEQS71bOK0zbn8Mt3HIwPXvssvnrfGNb3JeAYgRdPokS/L+5PmkuDUf+EI9gz4yPlAFvP2VAe9bf8jM4qyr95qvjfN+/AWNFiVcZB+aNpgOrR/+BrCb+vnlE1j9UBiIhWEFsALC9WABBR52h2bhqd4NaUuVYeJOhLObjgskdwx9NTcLg04JzqpgScsj8gij0zHpKO1P8quD+pmQZL/EXN/J4cL+HUTRl8hyX/CxKV/r/7ysdwzaPjWJ2JSv9rqqFin9S6sv/gyvg3c9xORETdgAkAImovDU84ZdbbpeF3lSSAAkgYg5JV/O+f7ih3t2fIOrtoSoAJVwn4xtkbcPrmHJ4cL8FT1Ddla7KWO/Ww2lF/CQL8PTM+IMA/nbwfvsuS/wWJSv+v3T6Oyx4YwZpsAl65CgrVx8gwGVAO/hnQExH1PCYAiKizVZ3YNm8I6FnFcMbFtdvH8e4rtwcj3OwHMKdoSkDJKk7emMV3z92Ifzp5P6xKG4wXtXx7FSYBqEEyyBGg6CumSorXHpTFN16/Hh89fnXY5Z+j/vMRTV+6/ekpXHDZw+hPObDxkf7yWV19BUDdB5Wj/0REPYkJACJqPwutAhApz22tTAWobggIMfAssDqbwGUPjODa7WNhmTuD1flIhFMCRICPHr8at75lM954SB/GixYlXxs0CWQ1QM9qEPgbASZKiv6kwTfOXo/vnLsRJx+YhWc1LPlv0bZ2kPK8f6v4xE93oGSDqRTVK/nVjv43Kf0nIqKexQQAEXWN+qkANVUBIrAA+lMuLrjsEdzOfgALEk0J8KxiKO3gkrPW4bJzNqAvabBrxodFZW53GRMBvaPmdy0Ako5gvGgxVrB44/P68Mu3H4QztuSCBk/a4P1CTUXz/t915XZcu30cwxkXXsOu/4K6vigc/SciohATAETUnhZRBVD5t/lUAA2DjpIFPsF+AAsmqIw6KoDXbcnhl28/CP9w0hoYAHtmPDiNRnSZBOhetYG/BO8RT4Enxz28+sAsvvemjfjyWeswmHKCShKA8/0XID7v//IHRrA6mwiCfwlP46pG/2ON/xo9GYN/IqKexgQAEbWvxU4FKN+v+VSA4YyLa7aP413sB7Ao0Z61CgymHHz4pavwjbPX47UH9WGiqBgr2vrSblYDdJcmgX/JVzw37WFV2uCfTt4P3zl3I07dlC0njVjuvzCVef+T4bx/N1jur0Gzv6qv2fhvyUmTixO+9/f10uz5iYiWktvqDSAiWmoiAtVwwno83pRwqF+CpoBrsglc/sAI3nrkOF5z8EDYiKxVW92ZTLiLfas4+cAsTj4wi+sen8JnfjmK65+YhoViIGnK85eB2BcMTDpXg3n+BV+xp+jjoMEEPnr8arz7xYMYSjkAwM/WIgUJk2Ca0id++gxKFugzAs/WNv6LKgEqpf+VvigxHP2fVfzVG6nvn1DwFapB81Mt308wWbLIe2FpyyJznCLAQNJU/n4BEAgUQfVHIt7vAahKWjOtSkQLwQQAEbU3kQajxrGzrNrby9+H9xEAGv86ejxgVdGXdPDb334Y3zz/eTj9oMHyaBvNXzQtwIa7+LTNOZy2OVdOBNzw5DRcA2RdA6sarlcOJgI6Uc0c/6iR5njRYn2fiz8/fjXe9eIhDKWCgNSzCscIg/9FiBJrRV/xnu9vx7Xbx7AmlwxL/2vn/Vfj7p5btI+c2FyUKMCPB/XRnxQjwMb+RNXhygCY9hSnbsrh2APSsLr4qS0lH/jq/eMo+BZGgqQpwj9lYwUfuyZ9OCbYltpkQTxBoKqIcgNMDBBRI0wAEFH7m2tUpUESQKDhVRKO/EejZQqEJ9DBiZNBySredeVjeOgPj0TaNbDg/KjFiE58axMBV2+fwh9e+yyemfSQdAT9SQMBqhMBTQIZahdalXNzRIIR/ykPCUfwpkP78R+n7o+hdDDiHwX+bPK3eJ6vSDiCf79jJ77+6z3YNJxG0Ud18F81DYCN/5qJDi9OWBlRsgpPg2B5T96vCvAdqQ7qox4xKVfw1hcOIBkG2tFz+hYYTC3NX4w/OmaofPwEUP5bdOfOPG55egaZhIGqlpMFec/CMQajsQRByhFkXAOFIuUE28WkABHFMQGwnDR2IaLFk1gGoGrNK618Gb+tfH5cKaUEBJWztuhxBr61yLgOxvMe3nXldlzyxoODp6pd1o7mLYr5/PCk+owtOdz1toNwyX3juPXpGVz16CQUwEAqlgiwCBI1AOqaOPIYunKqPktad5Mjgrxnsafo45DhJN5/1BBOPjCLUzdlATDwXyq+BsH/ddvH8W+3PoN1AymU/OhWqf5Xw6BfY6X/8Q9Q1C9Aax+PymG0drpUJyq/lkpuxBEJgn0LKBR7iz48C6xKGwwkDZKugz89diAInKMA35FFBfXeEvSRySUa/8xTDszilAOzVdf90TFD8GwwtebOnXn89KkZ9CUNfv7MDG5+Oo+0a/DkRAlWgXSDpEC0+k2DjzpRazF2WnZMABBR+4tG8ptNBdDY1/H7V2UEwjPDurMdgW8t+pIOtt67F64RfPmNB8MLl9yixYvKvq0Cw2kHHzpmGB86ZrjSI+DxaVhV5BImnEKgKJ+S1jY5o5VR1awh4EjwOyzZyhz/Pz9hNd515GB5xD96KD8z+y6ahnTH05N486UPwzWCpIuw8V9NgKjV7eLK+c35zkXvkpPsaA84Jgj4fQXynmKq5GNV2sFASpB0HPzZcQPwfMVJGzM49oA0BEBfsnmgXxvUO03e39F0mH3V7NdhNZiyFv8J8WRBdYJgGGMFC6uKS+4dR9Eqfrkzj5ufziPjGjwxXgqbtwZTCFKOhJUMsYQAEXU1JgCIqHMseCpA1EQJlTLz6CRabXAfI4A18FVxQF8Sl98/grceOYbXHDyIklUkGNDss3ijQMdIrEfAND7zyxHc+Wwee2Z8ZBPhKFXUJ6DcI6D8P1pWsTJ/VOb3jxYsMq5gTdYJmvsdVT3HXySY48/f0L4Lyr+DZNg//HQHSlbRl3Ir8/7Lg/+xKoDwa6m7rdH33VH6H22xGw/4S0HAvybjIOkITtuUxeFrkjhxfQbHrW0e7MeD/HiAv1RB/UI0+2lOWM0QF/9TaMPpDECwzVH1woeOHS7fZ6xg4aviq/eNY7Jo8fX7JzDjWeyY9GABDCYrCYFoygCTAUTdiQkAIuogjTIAtdfVj/zH/1+5WyxZYIIhTqsImgJe/gi2vvl5OG3L4D41daKK+Ml0pUdAFqdtzmLXtI+v3DuGz90ziu2jJaTcoE+AkWB5Ro2qNjowUGl7NRUxjgSdzwueYveMh4xrcPrmHP742GG8dG26HECx1H/pKaJDkeKt33kU120fx5psIghQxTQI5BskBLo8+C+/P8Nmfc/N+FiTjgX8q5M4cUMGxxyQbljC71kN97OUj+ud+h6Ob7UTzXkIRZ/oaFQ/nhT442OCpMCHjh1G3lN87f76hEDCEWRdAyNAwkh5vxFRd2ACgIg6y5yrAqAmHyCVtsnl0litvi38WhVwDGBVcMFlD2Prmw/BqVwZYMnV9gjYL+vgT1+6Cu88chBfubfSJyDvKwZTBokw0Kw6CWVVwOI1KPEXAYo+MBV2Pj90VRLvf8kQXrkxSNJEfKswDPyXXFQhE3X8v+y+vVjbn0TJAlWN/YDqJoCIfdmlx6j4+3OyZFHyFev7XGQTDt5/dB9O3ZTF0fs3DvhLNjh2S4cH+wsVr5CI1CYFcgmDXKI6ITDjKb5+/zhueXoGt+7Io+QrnpnyMNTsOExEHYkJgGXFLoBEy6fR5yqeBKiZCqBaXg2wamnAmkaCVjVsAiX4/SsexbYPHIWUa1gJsAyiHgGqwbznVWkHHzp2GB86dhjXPz6FG5+cxne2TeCZKQ+7ZiyGUg4SBrGT0Fgih2an1V9EI6lFXzFZsvDDxminbMnhxA0ZvPXwQazKOOVHRDm0ZnOgad+U/OC48+93PIuv37MLm4czKPjhwcrEE5zx/R/cLuWJ/3FRdUBtH5T4XebbKGDliQSj9KWa9+dZ4fvzLS8cQMaVuqZ58YBfAE7hiqlNCsyWEPjjY4I+Anc/l8f1T9Qeh4NkgBEpNxIkWnpRd2BaDkwAEFHnWeR5axD3RxUBqO8HEHbS9lWRSRiMF3z83pWP4qvnPi+cl8skwHIQAVyRqj4Bp27O4dTNOXz0hNX4+TMzuKHqJNSvG5EC4k3O+UsKVM/pN02C/rO29OGkjVn81gv6sX+2clpQNb+fu3TZeDYI/q/bPoZ/vfUZrOtPoRgF/41G/oFyBYw0Lf1v+k3j+7eBaJqQF1ZCzHgWw6nw/bkhU/f+BCrvUcOAf8FmSwhEUwZedWAWrzowi48evwo/fyaPG2JJ2bxn0ZcwSIQ9A3zmAog6BhMARNSZ5pwKUHN7+H1VP4ByEiDeD8AANmiW1Jd0cOl9e6EKfO1NTAIst3ifAD9sapVLGJyyKYdTNs2eDCh3s0a4vJXGkz099AsL38fRlOB4V/SJkoVngdWzBP0A5/evpGi1keu3j+GCy7bBiEHKFdhoab9Gc/glmv/f5Pcz17z/Nps6E+87sWvGw2DKYL+Mg3cdOYR3HDGINVmn6v7R+xPonZL+ldAoIWCrjsNZnLIpiw+/dBXuejaPf//FCO7aGTRwdQwwEO/b0rJXQUTzwQTAMuIBkKgV5k4CRPP9A9FIG2p6AwCeKtb2pXDZ/XuhAL7OJMCKiZpa1Z+EVpIBdzwzg588MY1vb5vAVCnsZh1f3soEz9G1CYHwtUgU9NcE/PmSxVRJsSbrIOEIzjgwh1dszOG3Zwn640kYWl5R8H/d9nG8+bJtcI1B0nGC92tt8B8t/xcF/4hVNC1UG/x6o/eZr4qxYqXvxB8cPYRTDszi+HXpcnl/vDKI78+VI2h8HO5PVpIBz015+OaDE7gl1rdlKOUg5bIqgPYN3zrLiwkAIupcDasA5rhP06aADebZajCndG0uicvu3wtBpRIgegQtr2YnobmEwas35fDqMBkQdLMew0TB4uv3j1eWtyonBAAHQYmwogOrBKJgP/zaCCBhIFTwgzLomTDg3y8bdkXf3IfDV6dw0oYMjjkgU9ckjUF/68RH/s+/bBtcESQdE86pblL6H1v6r+nbtc27/osEy9lFq0ykHcGZB/fhxA0ZvO2FA+W+E0DYcDKcz8/3Z2s1Og4bAfbPueWeAdc9Po2bnprGZdsmsG1vEelwNRcBmAggajNMABBRZ5trKkCzh6Em+Iv/Gz0vAKiiZBXrcglcet8eQBVffdMhgAImDJ5oZcyWDAiaV60CAPyv41bVJQQKvmK86GPXZKVctTYpAKASgIUUWLkEQTzID7+P5u1HP7/gWYgIJsNu/UaATQMJzHg6Z8APMOhvB75Wgv/zLt2GhImCfyBo+hf7vZVH/BsE/wtd8q+FojL/vGexp+jjkKEk3n/0EE6uWWUiPqefDSfbU/k4jOrqjGhZ1w8dM4yv3D+On4VVASrB8dYRriBA1C6YACCizrdP/QAMAFtTEQBU1p03ABQla7GuL4Wt9+9FwnkEl5x7SHkUj1ZebTIAaNTNOkgI/PGxwb937czj5qemkTCCL987hmJNUgAIEwPh+gIiQMqpXX89/FlhBcGiEgPxwD7+miQo3y+Fr8PEAv3g+0qwf+qmPhxzQBoJR/COIwZhROZcBo1Bf+tFS4re8fQk3rT1ISRdg6Rx4ANoPPIfzfevuX3W4L+JFoz+O+FhdbxoUfAUW4YS+PPjV+NdRw5iOF1ZZcJn34mOFD+mRH1bVmUcfOiYYXzomGFc9/gUPv3LUVz/xDRmPL88PcBXnbN4j4iWDxMARNTF5pEEEEA1dr9gzcDYt1F1gEHJWqzNpXDZAyN426NjeM3BgyhZZefpFov2frPlrfqTQWB8yoFZnHJgMNr4hy8ZBlBJCmQTBgVP8dX7xpD3FY4EFQZPTZRgG6yeFlUQaO2N81Ab2EfP6VtgVcZgKO3AAJgOA/3j1mbgWUUmIXjb4c2DfYDLoLUzqwh7iCg+ftPT8FTQ7zjwopH/hk3/pPIGl/lWHLW+9D8K/MeKFqKolPkfPoBVYeAfX2WCgX/niydkK1UBOZy2OVeZHvDQBB4eLWIgaZB2DRMBRC3CBAARdYcl6wcAlEf/a1YGgAQn730JBxdetg2XXXAoTtsyyEqANtMsIWAVsGHlR6OkAAD88bHDYaAGFG2QECh4wVzk6HlKfni9H4zkL+T81QgwXQoC+2PXZqBaKXmeLlm8YmMWxx2QhkXw9msW6AMoL38YlUoz4G9f0XtKofjdbz+Ma7ePYb9sIvgdSoPgv9z0r/J9+dY2Lv2PB/4GgtM35fDBlwzhtM258n24ykR3i1cFRG/vaHrA/zp2GF/49Rg+9+tRPDZWYiKAqEWYACCi7jGffgA135YH/MtJAAU0KrOtrQQIbnIFsCp486XbcPkFh+LULawEaGfRb8WRoAEZ0DgpAKDceTwSTSOoFU8ULHRjfDt7YF/Li1UZxIN9BlCdoTb4v/T+vVjXl0TJIgz8a6aZNGr6V3tbw+8bjfw3uX6JNQr8P/CSIZweBv4s8+9N0a86mh4wnHbw4ZeuwrtfPITP3zPKRABRizABQETdZc4kQKMMACAaa05Ufo6aKQQIvrUI5oYXxOL8SyuVAL5WmiNRe2uUFADqR/P9JiX+tYmCxfBqnlsRTA+Ix0cM9DtbNOffajz4TwV9HqIeI83m/QdX7Nu8/2UO/qOpJmMFCyMNAn+N3td8H/ey2ukBQynTNBGQcoSrBhAtMyYAlpPGLkS0suo+dzVJgNokQTg/VyGA2vA+0eNs7Ovgvj6AlARJgAsu3Yavn3cIzjhkqDza1+6rylFjtb+2ZkHLvh7WGdh3vyAhKBgv+Hj/D7Zj6317sb4/hZKvYYm/VKYfAbGpSNFxJrhdFNX3A+rzmM3m/S/T+YcI4Ipg2rPwLHD65upS/3jgz3c5RaLjXrNEwOfvGcWOSY/LB/a6KHayrd6Q7rXvQxhERG1nHqecTUbTgv+bmvvUjNCFo3S+AknHgWsMzt+6Db97+cOI6ggW0RuOOojs44W6m2eDRpLXbx/Di/7rHlz50CjW5qLgv8GIfnnkPzotkzma/s1V+r987zJHgj4Yz00Hgdo337Ae3zl3A07bnINqZd4381vUTDwR4MUSAbf97mace2g/xgo2mE4iy/pWJupZTAAQUXdqeNYwRwltlASIz5uNTsyjWtfouvBiEczLHky7+NZ9e/DWbwdJAAGTAES9KGoKet32MZy/dRsmShZ9SSdYOjI6npjY6Vc80Rg7xjSc919XXtRs3v/Sc8KgfrxosTrj4BOv3A93v2MLztiSC0Z0GfjTAtUlAtIOLjlrHb73po04fXMOUyVF0Q/66/BtRbR0OAWAiLrXvJoCNrpPdD1QWREgeqyt3A4DqIVCoKpY25fEpfftBfAwvnbeIeGSXzwhJuoVtcG/awRJxwTJwHgyMdIw+J+l4/9cI/+zXr84AiDhCEbyPqwC5z2/H/9x6v4YCpfzi45x7H9CixVPBACVVQOu3j6F91/zLJ6Z8jCccuAaqeudQkQLxwoAIupBs5ypxqcClMtyYw+pPXmXynSBkq0kAX6XlQBEPaUUD/6/FQX/Uh/8S/yYEiYSy9fNd7m/Jpa4XtoRwFPgyXEPr96UxRXnbcQlZ63DUNqBZ7U8z59oKUR/cf2wh8QZW3L45TsOwidesR8AYM+Mx2kBREuACQAi6m5NzxQajcJVf1+dBGhUsouqJICIQckilgR4BIpgrXifaxsRdS1fgzLl8si/EwX/0jj4B1DpNRJ+u6Dgf3nn/UfN+8aLFqvSBp981X747rkbceqmbLk/l8uybFomTvj+swoMpYKlA7/5hvV47UGVaQEOswBEi8YpAETU/ZqV+dcu86f1UwMEgEa3VXXsRuX+sekAUlUJsAcC4L/P3oKBlMNlAom6TNTt3hHB1Q+P4i2XP9y87L8qcRhvNBpc2iX4d0RQ8C1mPK0r9+cxjFaSCf/k+lbxqgOzeNWBlWkBe/MWOVcgwio7ooViBQAR9YZ9rgQI/9dw/i5qKgGCJMD+fUl8f9sIXvRf9+C6R8eD7tk8UyHqCtFHWaF4y+UP4/ytD8F1BInZyv6Bytex6yqtAOaKrpcv+o5G/YOmhQaXvXFDXbk/g39aaVF/ABubFnD3Ow7COYf0YbxoWQ1AtAhMABBR71h0EkCC8bmqE/cmDb1i0wF8C/SlXEwUfZy/9SFc9+gYEkY4HYCow/mq4eik4q2XP4Kt9+7BYNqFEYHOVvZfvr58RcOEQN1t0fd1lmZCtCOCoq8YL1qcc0gf7n7HQeXu/iz3p3YQJah8BQZTDr5y1jpc9sYN6EsaTJQsl1glWgAmAIiotyymkVZVzy5Tf59ZKgF8q8gkHLgOcMGl23D1tlE4EoxmsBiAqPMEZfCC8YKPt377EVx63x6s7U8G8/0Rff7nCv7DxKLMElhL02/mvHq+BEDCCCZjo/5fOWsdBsMpSwyqqN044bSARtUAVoNkFRHNjj0AlpVFkGPhWT5R+2n2uYzm9aOmJwAqPQGi5QBjLQSqewKE/1OFiMCqIuEY+GJx/tYH8cYXrMJX3nQInLAagOWLRJ0h+rxe9+gYfu+7j2C04GH/vgRKVsNYP/ybLyY8DiiqRvzrBvTjt8cOJrXfNzpeSZPr58mErU2eHC/hd48YxGdOX4vBlCk/I8v9qV1Fb814NcDVL+zH735/ByZKilXhtBXqZPz9LScmAJYR37pEbWq+581NGgMGsb1BkASI3af2a6DcPFBVYYzBQEbwzXv3AAA+e/bB5ZE2nmwTta8olnBEcNW2Ubzl29tgEUzx8cP5/uUjhUiDQL+67F/C44OWb6+9f8NvYlfv2wHDEcFUySKbEPzzKfvjz45bFSYkeSyizlGuBlDgjC19+O6bNuJTd+zBNY9PY3XagVXluXiHUgTDqLQ8OAWAiHpTeR5/3Q3V1zdrDFge7Ys/V/OeABADDcv+1/YlcOVDI3jRZ+7GdY+OwREuE0jUrqL5/lYVb7l8G87f+iBcR5BNmHLwH5it7H+WY0Tlm3nM+a99zMLES/4HUwaXnLUeHz1+NSRMYDD4p04jQLjULvDKjVlc8aYDcf7z+zBW8DklgKgJJgCIqHfN97xg3kmA8EmbJgGCAMBXoD/lYrxk8eatD+GqWF8An2WLRG3Ds0HJ/1jBx9u/8zC++Zs9GMy4cExtp3/TPPiP1f9Xzflv0mukwTc1z7k4URz01HgJZz8vh3veeTBO35yDZ7XcYI2oU0WJdAXwtddvwGVv3ICSVYzkfSYBiGowAUBEva22XLdyQ/39GnwfnOPPozGgiRqDBYGCr0A2YeC6gvO3Poi3XL4NAMp9AYiodaJqHdcIrn10DC/6r7tx5UMjOKA/AatRp/+aZn/xbv7xCqPyFIDY91XHB8wvsN+H4N8RwXQp6FPwz6fsj0vOXI/BVFDBwOCIuoUjElbrBFMCvvemjTh1Uxa7Z3w4IkuxYAZRV2APgOWksQsRta+omVbYjys2mbfyjcS+1+rvg/9Hzb8AaLx3QOz+Ep6ZhGch1gajFoNpF5fdtwfjBR8fPWk9Tt48AKuVETsiWjlRoz/fKv7llh34f7c9g+mSRV/KgbWI9fdAJdivOiY0rgKQ+H3i/f3i31eurHypsasWcj4RPtYxwGTRYiht8IUz1uH0zbnymuos+aduZMJqgFduzOIVG7J46w+exvcenkQuYeCEf4bn3QuIVh5jp2XHCgAiongnrro/OrXXN/heo2trTv7j30c/QyRIEITXqwalxGuyCVz76BjO+cYDuOrh0fIoBqcEEK2ccsl/Pij5/4sfPQ5VIJcIg//yaZMEX4s0OTZEI/4GgvhSfw2C/WbBf/m5Gt1vbqJAyhE8N+Xj7Ofl8GuW/FMPcUQqUwLO3oDLztkAzypKNqx64Z9W6mFMABARRZrWB85zOkD0f5HY8H1UHhy7r4nNF471BViVcZEwBud/60G85bKHAHBKANFKqC75Hw1K/h8cwfqhFCACi+rPK8RUl+jUNQIEguA/dvucZf8Njj/znR5QI9q0J8ZKuOCwflxy1noMsOSfekw0JcBX4IyD+7A1TAKwLwD1OiYAiIjilioJgCgJELtIzf2regcEJ+eOEQymXFx2316c840HcNPj4+UGgUwDEC09XzWcnaP455ufxlu//TDGCj76Ug5KGtYKV83pb/BZjnf4bxT815lH8D/r9c05AhT9ynz/r7x+fblpIUv+qRc5ElT3nLY5hyvOq/QFSDAJQD2KCQAiolpLmgSIP9bUjAJGSQApj/QpBBaKNblwSsDXK1MCBFwukGipRNNMg5J/D2//zrZyyX82YYJ2HTDVc/urRvJjn19g/sH/fEb+mz12Dq4RFG1QzXDJWevx0RMqS/wx1qFe5hopLxV45fkH4k2H9uHZKQ8pRxaRZiPqbEwAEBE1stSVALOtEFAOIirzhstTAhyD8775IN56+TaM5j044ck80wBEi+erlmtzrnp4BC/+7K9w5YOj5ZJ/rUrYRdN6Ygm82mk9sekB8w/+Y1UFs95vflwjGMn78KzisjduwOkH5VD0Od+fKOII4KnCatAX4ILD+vHEWAkAE2TUW5gAICJqZgmSAFIOJFAJJmofU3VbJZDwNYg5BlIOvvvgCI767K9w1baRctjAagCihYmP+o/mPbz18m0475sPYaJoq0v+42X/0qByJ/ii8k85+G/w+a57XOyxjSwi+E8Ywe4ZH6duygYlzmGzvyRr/omquOHnywjwldevxz+fsj8knDbDjwv1CiYAiIhms49JgMo940mA2Prh8fvXriUeu19/ysFE0eK8bz1UVw1gmQggmpUimANcHvXfFiTUvvvgCAbSDpKOxEr+az6HdcF/bSIvPvIvLQn+n53y8KZD+3Dl+QfilRuzbPZHNItoEQARwUdPWI1LzloPq0DRZ58M6g1MABARzWVfkgBVUwLC4MKgEjg0CjZq+gJE1QBJRzCQDqsB/qtSDWBE4HG5QKKGonL/oEQ+HPX/VjDq359yAEQl/7GRfalJBAD1X5en9sTL/mt+eO1zLFPw/+bD+vG1szfAalDizCCGaHbB385g5P/0g3K47I0b4KsyCUA9gQkAIqL5WGwSIHZdfGJAdcTQqBog6gtgwrtHQQrQn3IwXrS48NKHcM7XH8CNj43DDbt8c1oAUUABlKyWK2U+efPTOP7iX+M7D+wtj/r78S7/YqoD/3JiDqjr0yFA0Oxvljn/82321/C+c6sN/qNncBfxXES9KukECfRTNzMJQL2DCQAiovla6iRAw+aANfOK45UCiFUDuIJc0sGPHhnFhZc+iE/e/DQAZZNAIgTTYgRBkHzjY+N4w9fux19e8zj25j0MpJzwMyKVkv/y567RfP/aCp2aUf/y/Wb5frZmf0sU/LPTP9HiuIZJAOotTAAQES3ErEmAJuXCNddVwofa5oBS/TR1UwKCryW8k1VgdTYBQPCXP34cb/zGA7ju0bHyU3hWmQignmJVw0A4aPL3qVuexoVbH8Q1j45jw2AqXApMYp+/6HMXjfzHnqyuMWflOqlNCqD2cVVXNN7YRY7UM/gnWnpMAlAvYQKAiGihZj1xry3lbxAc1FYDREuMoUHAUX5M7VKBAhGBZ4O7bBhK4frt4zj7a/fjrZdvw0jeg2uEqwVQT4ia/BmRSpO///oV/vq6J2AhWJ11UfSDcn8pl/sDlcRaTZDfdOS/5nNbi8E/UcdqlgTg54u6DRMARESLMd8kQLP7loOJ+GhidL2J3Sd2m4mPWFaSABBB0VcMpFwMZlx854G9OOHie/DPNz9VXvLMKlcLoO6jWunu7xrBjY+N4Zyv348Ltz6E8aLF/rkkjIT3KX92gEoybZYl/qoSeFL/Wa3F4J+o4zVKApRYCUBdxm31BnQznmoTdbnoRL5hYB2dLWjz+4ajleXrwvn7AoWqCR4r4W0anu5HZco2ek4N7iKAH/64/pSLPXkff3HNE7j5iQl86GXrcfrBg8EzK6AIRkqJOpUC8K3CNQJXgu7+n7trJ/71lh0YLfhYlXGDJoCq4ecsCPi1apQ/9oRVSYHgY6fh/eKz/XUFR/3jR5CkETwz5eECBv9Ey642CXD+954GrCBhAF9R/vzR8uH+XV5MACwnjV2IqDuVA4cwYmh2ZlB7oh7eV+N3UACi5cCjcmPsSRWV4KUmNxB9bzVoBrh+IIVrHx3H9Y+O47SDB/BHJ6zDa543BEFwcuMYaRaqELUtP3x/R8v6fe7Onbj4rp3YPlrAcCaB1ZlEbNpLFPijfnS/LPZ18OGrBPpaGfGPVuFA/Klrr6uaAhR7zviPm+c5QfS5TjhB8M+Rf6KV0ygJoBpU4tjZ/tbTvovOZ2yrN6R7MQGwrJgBIOp6WvNNs497XZVAo/uGo/lBDUDlyauCGY1VDCAW/cfPRgRQRclXDIYdz695ZBTXPTqGU7cM4M9O3IBTtgwCCEqjHZHFViUTrRgbLtnniMAC+NRPn8Lnf7ET20cKGEi72D+XhG8VvtW6Ef3qMn9UVd0AiCXWKp8jQfyzFd6pLtAvlwpUvkftl7NVCs0iDDaenSzhgsMGGPwTrbAoCXDa5hwuf+MGnP/dp8KkHIIkAC0jZgCWE3sAEBEtldqy4uob575vXVlybJWAqjXJa0cZw9ujZQXLl+DPpyowmE6gP+XgRw+P4cKtD+JTNz9VaRQYzpFmiwBqR1aD96YRgRHg2kdGcc7X7sNf/vgx7J3xsX9fEknHVAL/Rp+J2jn9jRr9hQ+rrLSBJp9T1F/XzELuW8M1gl0zHi54wQC+9gYG/0StUJUEOHcjfFX4dtEfa6K2wAQAEdGSmu2Mv/a2RveV8P9RCGKqgxY0+bpuObP47cFoha/A6lwCVgR/ee0TeOl//4qJAGpLiurAXySoYjnn6/fhjd+4H9c9Oob1Q2m4xsC38UH4Rp+BRo3+apICscRa+f9N5/vP9Rludt/5C6Y3+Dh9cx++dvaG8j5h8E+08lwjKIVJgK1v3IjJkuVnkToaEwBEREttIScGtSP6QNVIpdReV14loGZEM7pPVWBjUF4+UAARgW8BA8H+fUnsyXtNEwEKLh9IKy/e1b828D/3G/fjmkfG0JdyMZhOoOSjJv6OB/QG5cC/9vbyt9XJtCXr8t/wvvPnCFDwFQkj+NhJa2Akaty56Kckon2UCCsBXnNQDm8+bAA7p3wk+KGkDsUeAEREy2EhKwRE96+9b3hdFJRotApA7Vzk8tPF5j7XNh4L+wJEqwr4Fkg6Dvbvc8qJgIvv3In3HbcW73zJ/tgvl4AjXDWAVoZqkHCKuvpPFn3c8dQE/r9bd+C6R8dgIRhIJyAIqlmqRvyBWKAfT4LFfkDVaHz1iH9wTc1UgForFPwbAfK+wirw7TdtxPHrMuWmh0TUWo4R+Kr44pnrULKKSx8Yx/5Zl8ly6jhMABARLadGgX3lRswrCQCUEwHlJED8vhr+L35deRUBCYN+i3JiAFr+0rdA0jjYv89g94yHv77ucfzfW5/GS9f34Y9fth6nh6sGRAEaVw6gpeSHZf5R4D+a93DRz5/FF+7aieemS5jxFEMZFyICa1HTVy82ot9oPn/t1/HvyxU2NUmBWg0D7+UJ/gXBxzfpCL529gactjkHL1zqkIhaL6pMAlCemvODRybRlzBMAlBHYQKAiGi5LTQJADSpBojXDsQCfpHKagB11QAIbzNBIkDC78uJgmC9Ac8Kko5BOmtQ8hXXPDqG6x4dw2kHD5YTAW64bZ5ViICjkrQoQeIpSCY54ch9sJzfs7j4589i+2gB/SkXSddBOhkG/lUVLVKTAGg0et+k9D9WNdAuo/6RpCN4crSEfzn9AJy2OYeir0g6/IwRtRNBkE43AnzxzPU49HMPY7JokXEFPnMA1CGYACAiWglLMiUg/F9VNYBB1VI55URA9Wh/ZfQ/qgio/pEiQYRlw6ccTLtQBa55dAzXPjKGs54/jJM2DeDtL9kfqzNu+aGqChFWBdDcqsr8w1Htax8ZxY2PjWHrb3bj4b35YDm//mRwIq1B8A8gFvBH/zYo6Y80u6081x+NH1f1+Lorm7+wJQj+HRHsmPTwOy8axB8ePQzPKhIM/onakpHgWJZ0BP9z5npc+L2nkPcVKUe4PCB1BCYAiIhW0rJUA4Sj+9HjG1UDVD1f9HVtIkDDmCgYyRAoBtMJqFr8YNsIvn3/Hlz082dwwYvW4FUHDQbTA1gVQLOIj/aLAK4I9s54+PIvn8MtT4zjhw+NIO9bDJUDf4EXX2KrrtQ/+l94qQv849/HvpDaq5Zg1H+251kARwSTJYsLXjCAr569IWz6N+dPJqIWciQI9l9zUA6XnbsRv/v9p8uFd8wBULtjAoCIaKUtJAnQ7P5V1QDB11oezq/cVgmetEF/AFQnAqpyD5WKAEAwmE5ARLFz2sM/3vQU/u/PduC0gwfxv16+AS/d0If+lFN+Ct8GTcuYC+hN8SX84qP9u6ZL+NIvnsNFdz6LR0fySLsG/WkXQ2F3bc9KObSvb/AXG9GPriurLfeP/q08puqt2HR5v7orm7/IJXpzGwGmSj4GUw6+eOZ6GAmaHHLaP1H7MwIU/WB5wI8cvxofvnYnNgwmUGIZALU5JgCIiFphMVMCGt0/lhwQCLQc0McrAsLnjFcEVE0LCJ9HYkmCmukDVgFVQcIxWNufgm8VP3pkDDc9Po51fUmcf8RqnBJWBcSblnlMBvSE2qA/mtu/Z8bDV375HG5+Ygw3Pz6OvXkf2aSDA/qSUAQdta0N3ruNA//o+3kE/tH3jbr7Nyv3r3vO+PMt5P4LJwg+bpmEwf+cuR4pR9jxv4vM1ROOv+bukHCCBOb7jx7GL3bmceXDE+hLOGwKSG2NCQAiolZakmqASmm/hIG/luf6xxICs/UHAILbxVYaCyL2swSQsKKgFM7LHs64sBZ4dqqE/3PTU/i/tzyNs54/jFdsHsTvvHg/HJBLMBnQxZoF/ZNFH3c8PYHrHx3DZb/ZjYf2ziDtOMgkHazKJmABeBp0sZDovThbqX/8PRqZdZ5/dG3sMQ1j/AUG/k0fsziuETw9FjT9e81B7PjfqaJDqVUtz/8Wwbx+lyU/St4GS8xFj6XOEf3uskbwhTOCpoDjBR/ZhGE/AGpbTAAQEbXanEkAYH7VAOH/wmkBWnX/eDUAKsmB6Oy1/HgT3sFWrlPEkgIa9hAM+wQIkHAMDuhPwVqLHzw0iu89sBefvOlJvGLzAF65eRC/zWRA15g16H9qAtdvH8Pl9+7GMxMljBU8DGUSOKAvFT4OsBoPcmpG9WtL/ecM/OOPrdy3nUf9I44Ixos+3nJkpemfw+C/Y2gs4E84wfvMEYETu89kwYcNG7ZWEUCtYiDjNmz06NngOB31zaD2JwiaAqbCpoBv+wH7AVB7YwKAiKgdlM/0tMkZQ7NEQIP7lwN1CR8RbwLYJBEAVI32AybWQyD+AyoVBeVz07BxGyAYzLgQBPMio2TAP82RDChZhZFgfWWe77afqHs/0HykvyroTyeQdA3WpdLB3H5tNBrfIPgvXxe7ver7BtfFbivf2rTBX83zVt+wwMcsXnze/xfOWI+0K4h9CqmNxVeyiAf84zMe7nh8HDc/NIJkykG+ZPH5n+1AwbPlpo4RRwSlgo8Tnz+Ml20ZQMkHskmDd718PdIJg75UJY2gAKxVGMNjY7tzJJgK8JqDcvjw8avxEfYDoDbGBAARUVuZa8yg9napTCauvV9410rqIBqSiEZaY9MCaqcGALHvoyRA7aoBKD8umh7ga1QSiXknAxI1lQEAykEmT3pXXlDwofAVSMS69wPAVNHH7bVBfz4Y6Y8H/QqgVDe3P/oi/MbEv48H/zF1I/6xx4RfS/zGWd8wdU8++45YhuHX6KPKef+dxbcaJCjDz8JUwcdPHxnF7Q+P4s4dk7jlwRFM+halyVK5g6Ok3VkXm/jBr3bhB3fuDK4wwCd//DiySYPfe9l6DKQd/N4J67DfQLJcGcKqqfbnhA1N//DoYfyS/QCojfEwstRUBSK66t8fGnDFPgnjDsD3tLxWFhHRfM150tDo9mYVBJXn06pAvvbrJrdVPbdWf6+x7+s2I6gUMGFsVvQtpksWnrVYnXFxypZBHL5fFiduGsDLD+xHLhkvomVCYCXUBvy1dk2V8PV7dmGs4OPr9zyHZ2NBf8IIXMeUg/5KGT5qflmxkf7aEf2Gy/c1SgpI1X2rqwrae9Q/kojN+//w8as577/NRSX80dtr90QRn735aXzmpqfw3GQJOlUCkg6cpIEjgoQj5aOgP9vIrwLGSHm1B1Wg4Nmg2eqMBziC4b4ETjhoEH/yms142ZZBDKSDYyMTAe0tqubJe4pDL2Y/gEVRlEz/qoSd3PP3z/3xCz6Oi+5M4H3HlVq9Wd2EFQBERO1q1t4AQONqgVkqCMIR/cp5o1ZWDdDo9pqKACC2DbHgrdH0gKrChEqvACCY/61QOMZgMG3KyYArHhjBt369G4NpF2v7EnjLUftjMGnw1qP3R9o1DRMCCpSnDFR+As1HlL+Jl/QLAJFKMDKW93DXjknc/Pg47ts1jZ9sH8OeGQ++BQbTDpKOwbqBdDk5E03/qBrkL38Ry9rUjubXZXSkPviuG/GvSjHEnreBFjf5q1U17/8lnPffzqLAPzrG/Pi+Pfj/rn0Ctz02hpHJEiTpIOkI3KFU0Nsi/CxETf3mw7cKP/a9G2ZJ3cEkVIEJT3H1vbvxo4dGcMBAAu9/5Ub80asOxHA2OHX3fIXjcGpAuxHE+gGctR5v+z77AVD74XFjqcUqABxWABDRkpllZD+6fQGPkTAS1Ph9AUDD68pLC2rs1prn0/CJGlYFBF+Xx8PqNkXDwBNwJDhxLlmL8bwPEWBDfxKZhMHvHrUfBpIO3tYkIQAwKdBMo2C/kbG8F5QxPz6Oe3dN46bHxlD0gb3TJWQSDjIJg4RjwhPb6PcYG4mPzmwl3hlCYoP48cC/QRlH1e9MKrNO6hIC8eoCafzWnnX0fuVH/aNdYwAUrSKXMNj23kM477+NlXwtN+f70b178O/XPYEf3b8HVgE3DPz9sBHmchIEVQJWFUVPoXkP+++XwQdP3ogPxhIBPhNJbSmq7vnXO/bgI9fvxIaBBIp+TYNeaiysAPAn9/z9blYALAtWABARdYS5ThuiE8D59AcIB/qDiA2VosVo1D8KWRqc5MafL3qORlUBEvQX0Oh6iW1bGOFFswdsuMJAwnGwf18Q4E8ULcaLPj52/RMwIvi3n+1AJiF450sOgOcrXrF5AC/d0A8A6E81TgpEnHLZefcFXPFfT9SVXFAZ2YdU5u8DQbDvK/ClX+xE0Sru2jGBnz4+jpKv2DvtIR0G/EYEawfC0U0NAv+6kfl40B8f5a8N+gVh34maja/Ki9csXVn1HPFQWcL3bgNN8+ytG/WPT46Z8RTfOGc9Ui7n/bcjDZNbCUdw7QN78W8/egw/fmAvrALpcD6/tVp1bFnW7UFlGkHSFTgDSeyeLOHvLt+GT9/0FD7wyo34mzO3lOedcypJe4l+L+9/yTB+8sQ0rnlsCqvS7AdA7YEJACKiTlEuyS//r9GdELvT3I+rSgREV8UDMYFGvQE0SApUkgSoTi7EA5pywBfeP0oONEoGSOXnl0erwxHnA8KEwGTRYryo+JvrnoBaxVDGxUDKQcoRvPOY+SUFItEJfG3VQO0ebLW633BsND8SP+l3RBBfVaw22P/F05O46fExZBIGT4wVgsDGNcgkHBgxQcBvywtAlkv7y6picYlyRDVBf+xfqXlsVZKpOvivPMTEHxD7ukECocHja37g7FYoAHdEMFH0ceELBvC6LTlYBYP/NhONovtW8Y9XPYZ//PFjKEx7SOcSQeWLnasCa3mpBiX/CSdIBOyZKuFjlz6Imx8awZ+fdRBOe/4qWNW6Yxm1jiA4xOQSBn974hrc8cxMOLWEFQDUekwAEBF1mqoR99nu1CzYb/C4utsqj5eqcutYMA8FJIwCq54zFvxHyQWpfdqaZEA5uJRYbkARTamNEgKZnAORoEx3vGChCJMCvsVQNlFOCrzjJQfAMUDKMXjHSw5A0glGY4bS7rxGyhqN8jVLGCxag4A+rm47a0bzgaArvxd2KL/z6Qnc+NgY+pIObn8qGNmvD/YN8nmL/XJJCCQY4Q+fy7M1P6x28L1R0F8zit+0lF7ibwCpv17CxFP5Po0e28Bi5vnP9ZxLyAAo+BbDaQeffe3aoEKDMVpbiYL/kRkP77zkPlzxsx1ID6eQySVmb+TXAlEiwBVBZlUG19y/BzduG8G3/+AovP7INeVGcywGaA/R0oAnrM/gz09YjQ/HpgIQtRITAMtKYxcioiVWDqbnc4ypGuKPXdUoSdDo6qAqQOPTBcoNA1FTFVCzgVXJhai6ADWVAYhdH68OqH5aP6zTFQHccLh7/1wilhTwoVD87XWPQ1VhBPj/bn0ajgDTJYtXbh7ESzf2A6rIe8H3x23ohyIIon2rGJxnkmCfNQjo46aKflXn6JJVXPLLncj7tjyn/JJf7kTeUzgGGM37GJ0uAcYg7UoY7Cv2yyWqgn0HUUl/VXRf3qaKeLQaBfyoCeZRSdo0Cv7rrouN1kvNEn61ylc1mIdSd1v88bNUxzR9zuWhAPKexTfO2YBM2AnczPkoWilR8H/VfXvw9i/8BrtnSsiuTsP3NZia1KYUQNGzyOYS8H3F2Z++G+cesz8ufc+RcMNKBvYFaA/RVIA/eMkwbnhiilMB5o37ZzkxAUBE1MnmVQ0Q3XFfKgKC7yuJgDCQ1wZVA1VJBKl5zphoJDleARDdUWPPU5UQkLqX4Yd5VhEJkwKK/fuc8CkrlQJGgO8/tBeX3bc7eKBVDGUTGEo7UA1G9qdLfjlJYFXLwVr8tiBhMK9x5lnVBvRxUXBf8LU8mmcVeHKsUMmjQDCQjl6nwDUGawfTwVxmBSwUDgS+jW9sgwC9dpS//GW4VbWj/OV/apIDDX/EXKP9Te7TzGJH/Bdwt6ViBBgvWFzwggG8bktfWPq/sttAjUXz/R0j+P6vd+PNF/0KRQWyKRdeB43Oer5CBMhkXXz3jmdxPoAvv/1wDGVcJgHaRJQzDaYC7Ic7npmBF/5t6Zx3GnUbJgCIiLrBgvoD1Nxn1h4BscfERo0lahQo4VKC0W1VVQHxagHEgvd40K+xEeSaioIosVA7yFubEGiw2eVzeJVypQBUMZByMJiu/IiSrxjJ2/IT1CUJ4moSBvtayl0b0MdVB/fRNcD+fcmqO/s1D64u448CeFT+rftZ1SPylatrRvlrb699soZBv9R82eA5a+9XZ47b5jTb45ePIEjwrO938dnXrmPpfxuJqmqsKs6/+B5895e7kEo5SIUjtZ1Gw6lEmYEkrvjVczj0b0bwlXe9CGccvrpqRQNqnfhUgL84YTX+/MbnsF/W7cj3G3UHJgCIiLrJklQEoP62utsrVwZXB8GgRlUBQCwZIJWgvfxjo8Cxpmogvu3l2yoBfNV94uXc8aqDeFKgJma1sZemNqgaqJwgB4mKeJKg6pVWJQxiP3tBpOqr2oA+zq+qrAivC5c8lPj+alY+P1uwj6onaT7KX/XDaoP+BoE8Yr8ziWoTpP6xDRMHtU/X7Mb5jvi3LvBxHcFz4x7+4oQ1yCQMfKuzTveglRFU+gSfo/MvvgdX/HwnMgPJYAWNDg/GfKvIplzszXs45zN343sfOBpnHr6alQBtwjHBNKzfe/Ew/v2uvRgvWiRNk+VMiZYZp6IREXWjcgA2653QNHis69Te6HagNqATGIgIRCQ40y5vh6n8vOjx5R8h1c8T3/bydsSuFwGMiX1vqu8TDy6rnjr+3OE2ouYiAouggiC6eBbwbRD8BwkDE7s4C7xUHus6Br4NGg4G/1b/3LptQ/Bay9td+zuuer3xfRHuo7n2n9TcDzW3lfdh7e/NBJfoNhPsWwnfD9XvEal5jkbvr2bv3dkeNJ/HrwxHBKN5H2cf0o8/PGYVVBmAtQPV4LM2VfBx3ueC4D83lAySal0ShXlWkUo6gCM49zN344f37oGEvU2otaIjwHDawcVnrIdnW3qYoh7HBAARUTeb1xnGHImAZs9R1Qm+JogvP7wSFFYnAyr3qwSuNUG/xANLqXzdKKg1pj6obZgYaJAcaJIgiC4SXifx51uqi5jgeaUmIVG1LTW/pqpfV4NtnjXYrw3qTf3jq34Htb/WeNAfew8YlBM/Ek/2VP2eZZb4vcHrrXvhc2hx4B+xCBI6f/XyNcglzJL0i6B9VwzL4f/fDU/gilueQf9wCiWv+wJj3ypcx8AT4Hf+59coeLY8+kytZSSYevK6LX04fXMWe2d8VgZRSzABQETU7RoFk43viKbBVlWQ2Oyh9cEzEASE1cmA+H0N6qoD4psS/exGAetcSYGGwW+D5EBdgkBQ8xKaBN/7YF7PX5MMqEkcNHytzZIgtfurap/W7PByIqZ2Y2NBf7AeYk3QX/Wg2M+NPWfdfojdp+lOmkObBP5AsFsmCha/9cIBvHxDFlYVTptsWy/zrSLlBt3+P3X1Y0ivSqFY3TCjq/hWkUo4mJrx8Tv/82t4NljVoFsqHTqZIuhD8ecnrMFQ2kFJlQlCWnFMABAR9ZJZA66qO6JxImAez1F1n+oAM0gGxKcJoCZArBk9ro1Py/eNB6sNRrhry9hrg+WGAXODJEGzUf+Gj1nAZZaKgKbb23SbG1Q71D6+Mkxfs/2I/Rvt1njAH6+yiAX9QOORfql57obvj9r3RsM3UJPb4ndpn8AfCDap6Fca/2m4MgW1lhfOgb/l0TGc++m7MRN2CO32YNi3imTawfdufxYXfuHX5eUBqbUcEVhVvGxDFn9xwmqMzPicIkQrjgkAIqKeNN/gabZgLB5czvYUVdFl7HmBup4BdVMFagPw+GbFg8yaQBQ1I99Nn2+WBEFt0D1rwmCRl3k992zJiAaPaTTvPp5Qqft1NQn4y08/R9BfVWEwx/tgzqB/Hu/J+bznWsAxgsmixR8cNRw0/uPIXstFQb5nFX9zxcMo+YpkwvRMObzvKzKDKXznzp344b174DpMArSDeEPALUMJFHzLYwWtKK4CsJyitZd5rCWithWddugcx6r46UmjO8Zun3VoLX6/6uukfMAMvtfycn8Se97a1ZNrf1Z9kiG+fGHl+jleQ/z2ursu4anabJs/68+p3d9Sd3XDx2vtddJwl5WX7NPq30lwY6PnbbaJjX7fc2xj07vFf5/tRQDMlCzW5ly8+6hhAOCoXhuwqnCN4LzP3YOf3LsH2f4kPL8N30DLyKoinXbxps/cjev/7Dic9LxBrgzQYoJglZfhtIP3HDWMP79+J9YPJFDqsfdmUxpeuneWTsuxAoCIiFAexZ3vfWcL3KrKzmd7mvj9akesg9Hm+gqB2OPmqhKo2tyaQBez/eya513KEf95TQ2ofU2xbasdRY+/trqX3uj1xPafMbGXWJnL33SUfyFVI7P+/mf5XdXddZ7vpRYTCVZx+NyZ6zGUdqpXqaSW8G2QhPn+b3bjO3fuRLqv94J/IFz60BEUfcXfXPkIpop++XpqnaAKQPGBY1bh7EP7g6kAnDJEK4QJACIiqphr/nb1nTFrIFcOTucIHKXmvnXPGXxflxCoipXnSgpI402u+tkNHtIwQG90mY8mj61LBDTahoa7pMHzGtSX8sf3VbxxH5oE/LHnrN2mpi+r5r6zvv757Kb5JhtazxHBWMHi9IOyeN2WPlhVcHC1tVSD/NbItIe3fuleOEmnpyNez1fk+lz85Fe78G/XPQHHCDxOBWgpQTDInUsY/NXL10AE0HYsb6KuxAQAERE1MI/Avfb+S1YZADQOuqt/VjkhEEsKlBsLGtTPqY8Hx4sN5JvmABoF8nMF9vP5kc0eNFegD1SN7FeN7seft+bnzCfgjz9mzt/nApMkHTDaX0sRBPwfOWFNuXKVWsuzQf+FT9/4JMbHikj30Lz/Zjxf4fYn8Jkbn8LItAfXkV7OibQFRwS+Kl6+IUgejhUsqwBoRTABQEREs1vwaOwcQV/VCO9Cgu5mCQFUXVdJDKBJYgDNG+5V3wmViLpp5L+El/jPa1CyH79E0yFmCfSlbrvrdujiAv55j/QvIOjvoBH/uGj0/3Vb+nDihiyUy/61nCrgOoKRaQ+fvvEpmLTD0W4E+yXpGjy3ewafvvFJCMD90iYUwIdPWA0jrAKglcEEABERzc+iArUFJAMWmxCoK81v/LOrKgZQEzSLBE8VX4XPCMSY+p+1bBdAjKnfhtoAv6Z8v3mgX7MPGlUjzGdHzxnw1+/reenQoD8uGv3/8AmrOfrfJuKj/8/tnkEqYTjSHfKtwsm4+HRYBZBgFUDLOSJQVZzIKgBaQVwFYBnxmEpEXSs6QVnQ2WP8pKbJ46TmfjrLfRs+de1jmz+g+hQrWmGg9jq0IEidOzdf/9Kk4ZcLIwt8/CJ+UBed2Aaj/z7OODgY/bcc/W+5aPR/92QJn77pKZiMy2XvYlSBVCKoAvjPG5/EX7/uIFgFEg7ft60UJQ8/fMJq/Gj7ZFUVQK++e3v1da8UVgAQEdHiLbp8e54jxk1H+hf4I+pK/QVad0HNJbges14Wavbna7wdqNvWWfsLLGRbFlQVsMjX3sEl/rNRKISj/23Fs8Fypl//+bN47rkZZDj6X8e3Ckm7+O+bn4YNEybcR60VrwJ4zZY+jBYsjAiPKbRsmAAgIqKlsSTJgPkkBGp/1iKC8brYu0lZ/pwJgPk0FpR53ie8NJkesE95h2bTABa0kxby47oz6I/E5/6fxLn/bcOEb7kfPbgXYOO/hoJeAIKR0QJuf2wMAsAyA9ByURLxI+wFQCuACQAiIlp6+xQALjDwbJgUWCLzyQHMlURoFMDPdlmS7W7y8xf0YvfhZ3Y5DWtDOPrfPnyrcIzg2gf24qq7dyGVdlj+34Qjgrxn8bEfPIqSz33UDqIqgJM2ZPHaLTmM5n0mFWnZMAFARETLa19H6xcTLc8WjC9LxL0S5lMpMFcAvlSZhwbb0CMcEYwXLM45tJ+j/23EajC6ffV9e4CShWv4O2nGU4WTcnH7Y+MYm/HgGE4DaAdRMvGjJ6xBxjWszKBlwyaAyyo+g5OIqNc1KDuvOzzWXiGx6xZ7Ql/znPMJ1lp92J7XS220kYvZR7X7t9HvYK4f0eodtnJEBHnf4pRNWSiCwJOxZmtp2MhuqmDxzV/shGRdLnE3GwXSriA/UcIXb9uBj5y+GZ5VNgNsMRP+bTpubQbr+lzsmCwh5Zjw6Npr72cFYFu9EV2LFQBERLRCGiRF5xyE1pqvay/7uh2zrEbQystit3tOs+3DJs/bcNuWYls6jwCY8XwcMpTABS8YBAA4jP7bxkzJx1TBb/VmdAzfKkZnPI7+twlBZSrLO188hMmShWOAXjrG0spgAoCIiNpH03L9fXrSRVzawUpvd5OpBVTmGMFEweI9R6/Cmkwwx5x7qPWi0f4v3roDYyMFdv+fB88qTMbFl257BtNFiwRXA2gLjhE4ArzvqGFsGUxgxrM8xtCSYwKAiIjaVzm2jQJSrFB8vlLJgRYlIer260ru284kAPKexaGrknjvUcMAOPrfThTAaJ6j2QshAkwXfeRLrJpoF4IgOTOUdvC+o1dhuqQwPM7QEmMPgOXUe9WRRETLQ+q+iGlykJ3r2Dvfc6q651mmk7GFPO1sr63p88zxA/i3qjkJgv3d0z4+eMwghtIOPKtsNNcGovn/k3kfX7ztGRjO/58XVSCdMBgbKeLzt+7An7+GfQDaRZRYfNdRw/h/P9+Dgm/hQHrnEM3YadmxAoCIiNrfrFPOFzmC3mg6/FK1GViM+W7PnNs0j/3RytfZiTSYm5t2BKduzgHg7Ih246tyJHsRVBXTRe63diIArCr6kwbHrc1gsqDlBoFES4EJACIi6k6zLZMXL3nvhNL3unh+ltdFS86RYO7/Gw7tx6s352C59F/bySUduOWO6TRvCgyknFZvBdVQAAkj+MuXr0HGFS4JSEuKCQAiIupRNVF1qwPqWYP6TspWdB8RIO8rTtmUKy/9R+0hCoxueGgEk5MlJLim/bxZVUjS4PptIyh4FkbAfdcmjAQl/8eGSwIWfDYcpaXDBAAREdFs5qwkWKILtaWo+d9hq5K44IWDELD5XzuJkjE3bBvBzGQJSc5hnzergCQNfrJtFIWS8n3dRgSVJQF/78XDyHtsBkhLhwkAIiIioiYcIxjNW7z5BYNYkwma//E0vP3kkg5geqhR2lLRYN8xB9l+oiUB3330MIbTBiWfSwLS0mACgIiIiKiJYEkug9MPYvO/dsY50ovHfdee4s0AX3lgLlgSkAcgWgJMABARERE1IACKvmJtzsUrNgYJAJ6AE9FKsRo0AzztoBzynjIBSUuCCQAiIiKiBowR5D3F7714GCJg+T8RraioL8ObXzCIw1Ynkfc4DYD2HRMARERERDUEQMm3GE4bvPvoYTjC5n9EtLIEQeJxTcbBm18wiNG8hcvjEO0jt9Ub0M04o4qIiKgzGRFMFS3ecEgf+pMGVjn/lohWXnTYOf2gHD591x6UwqUvujnOUAC21RvRxVgBQERERFRLgJJVnHZQDgkj5eXmiIhWUpR4fMXGHDb0J1DkwYj2ERMARERERDFR+f+ajIPzDhsEwPJ/ImqNaBqACHDuof0Yz1sej2ifMAFAREREFGNEMF1SvPLAHIbTQfk/T7eJqFVEAEeA12zpw0DawGMVAO0DJgCIiIiIYkSAolWczvJ/ImoDVdMA+lyUfCYlafHYBHA5aexCREREbU8AFDyLjX0uzmf5PxG1gco0AMFvv3AIH7v5ORyQdbuzEiCKndgFcNmwAoCIiIgoRhXIJQyyCQb+RNQ+HAEG0waOCMcXadFYAbBs9gIYAEsAiIiIOodjDHZPe/jgsauQdYO5tlx3m4haLapE+t0jhvB/btmFkm/hSLdGGd35qtoFEwBEREREiMpsLVZlHJy+pQ8i4DzbZaKx83uruug+CyVfy89Bi+f5ipKvUK2sO78QguqpMot5DpqdALAKDKYMXr05i+9tm0B/0oBvfVooJgCIiIiIQr5VZBMGJ27IAqg036J9EwUpvlVAUFVV4YjAWeTzJpzgefpSLgcNF0kEGM4tfUhQ8hVGws8Qk2lLwldFwgiOWZvBt+4dw1DKYfKLFowJACIiIiIEgVDeV7z24CysBqNtjP/3jW+DUWU3DNSjfycLPjyrcERw22Nj+NlDI0iknCBBsABWASPATQ+PwkmZBT++l2m47/Ili7+98lEk3YW/2UWC30HKNXj3ieuRdA2srxjMuuXkTMTzFY4Rfqb2gRPuvGPXZrAq56Jkg9UA+K6nhWACgIiIiAjByXW+aHHs2gzSrqBkFQlGKwumGoxUOkbKZeGTBR/5ksUXbt2BibyPL962AzNFC8cAe6c92MkS9mlCc9IgmXK4ZOMCGREUSopPfO/hfYsiBfjUNY/DNYJSwccrDhvGsev78LJDh/DygwYxkHHLyR/P12Bde/bWWLDocHTyphzSjmC6ZNmjhBaMCQAiIiLqeQKgZBWrci6OXZsBUBlto/mJAn/XCNxw3/34vj246cERfOmuZzFVsBgdzQMWkIwLE8b7rhEkhlNQLL5M3LfsA7BYIkB2ILlPJfqqwNiMF/wOBbjy7l248vZnkehPos8VnHDIEE45dBjvevl6rOlLlB+jUE6zWSCrwfv9FQdmccW2CfQ7wj4AtCBMABARERGhMv//5E05ACz/n6/awH/PZAmf+9kO3PTwCK66ZzdQsjBZFwIg25eESLCmeRTxq1aa+VFreEuw/6MRfiiQzLgwWRclXzHuWVx9z25cfddz+I+fPInfO24tTj5sGK89fDUEwkTAAggATxVpV3Ds2gy2sg8ALQITAERERNTz4vP/fRtUozMemZtvg1J/VwQj0x4+feOT+PRNT+G5XTOAa5BKO3CybjA3X8PAP45xS9eIx6C+VfgIAlZXBMmMC8kCz44X8Y/ffxT/9GOD171wNT502ia87ohKIoDNAufGPgC0r5gAICIiop7H+f8LpxrM464N/E3GRW4gGZYq65KMLlNnin7zUXPGhCNwBpOwFrjqvj340f178LoXrsb/On0TXnv46vJ92R+gOfYBoH3FBAARERH1tGj+/3CW8//nw7cKgcAY4Pu/3o3f//K92DVWgEm7yA4k4VtlST81pFqZbpDJuFANEgFX3bsb5x57AL7w1sOxKuvC87UypYDqRH0ATtyYxfcfZh8AWhjT6g0gIiIiajXPKoZSBidv6gPA8v9myqOzApx70a/whs/cjZGCj1x/EglH4PnKQITmxbcKq4pMxkUq4+K7dz+Hw/7uFlx17x64jsAq+F5qQBA0vEy7gldszCJfYv8EWhgmAIiIiKjnRd3oZ0q21ZvStoqehWME1z00gjP//Rf43p07kc64cBxBiYE/LZJvg/dONuVi97SH8z53D/73D7fDqlYaRlJDvgKG0RwtEKcALCMLNjIhIiJqZwLAGMFE3sefv2wI/SkDzyrn1MZo2LA/6Rpcde8evPG/7kbJs8j2Jzm/n5aMZxXppANA8XffehB3PjGO77zvKLhG2BegRrQv3nnkMP7zzj0YyftIGEG3pC95VFlezBkRERFRz4rWnlcLeMrEfS2rwXQIq4r//cPtOO9z98AaQTaXYPBPS85qUA3QtyaDK+56Dmf8+y9w/UMjcIywr0QDSUcw4wX7pZv2Tje9lnbECoDlpLELERERtR1BsAb9UNrBKzZkAYDzaUNRSb9vFedffA+uuPUZpIdTcMO5/kTLQRFMN8n2J3DN/Xvwk20juOIDR+OMw1ej5CsSbA4IIEjOJRzBKzdmceXDE+hPdkkjQMZOy44VAERERNTTogaAr2QDwDJVwFeFquK8i+/BFT/fif79MsF0AJ6c0wrwfEU2lwAcwTmfuRtX37cHCUfKSwr2sqgRYMoRnLQxiwIbAdICMAFAREREPY0NAOtFfRAu+MKvccXPdyI3lEShZDkwRyvK8xWOYyCO4I2fvhu3PDoGx7ACJY6NAGmh+HYhIiKinuUYwWTB4h0vrjQA7PVxNN8GZdY/uHcPvnPnTmQGkih5DLioNaxVuK5ByVf8zRUPw7cKl+veVxoBvngYG/sTyHu2549dND9MABAREVFPUwAJIzx5RhD8iwh+eO8enPfZu5FKu7C9HmlRy3m+Ip1z8ZN79+L8z92DqYIPz3LpSQBIuTxy0cIwAUBEREQ9zQjYWAxBUzHHCAqexe/8z6/hARDDOf/UHnxf0TeQxPdueQb/94YnkHAEHvsBQDVIAnBP0HwxAUBEREQ9SQDkPYsN/Qm848hhAOjZtcZVg1LrqYKP3/mf32Bqxkcq4cCyLQK1kZJvkV6Vwr9e/Rh+eO8euKZ3mwIKgl4dfUmDt71oCJMF27PHL1oYLgO4rLgOIBERUfsSAArXAOkeL6P1wnn/n7zmSXzvlh3IrUlz3XVqO6pBVcp40eIt//NrPPNPJyOVMLAaVPL0IgGQTZgw2uiWuEMBMPu4XFgBQERERD1KIQJMlXz4PXyu6Ycd/29+ZBT/ctV2ZFalWFpNbctaIJNyMDHt4a2X3AsjgPb4PJWJog9oNzUw7e3f53JjAoCIiIh6koggX1K88sA+pFzp6WZ3IsDf/3A7xqc9iGGHdWpvvq9IpBx8+45n8dOHR2F6dCqAhBH/yQfmMJh2UOrBfUALxwQAERER9SQjQMFTnHxgDilHYBVdNII2P75VGCP46cOj+Mm9e5DuS3CNdeoIjghEBB+/envPfW4jJswAnLypD6szBiUuY0rzwAQAERER9S4Bpko9XP+PIOnx8au3B/OoW70xRPPkWUUy6+Inv9nT01UAQHAM83swgUmLw+M8ERERUQ/yrcIJR/9v+M0eJLMu5/5TR3EQLF/Zy1UAQFDNxI8uzRcTAMuL+5eIiKiNGentFQBKvuLvf/goVINgiqiTBFUADn5y7x5c+8BeOD1aBSAIjmPd9MoVyjhqmXDHLhPJeSqCPItxiIiI2o8AyHsWG/oTePuRwwDQU2toqwavdyLv4/bHxmFSDjx2/qMOlBCBX7S4+v49AHprJFwQJEFySYO3vWgYkwXbHccxtSoi+VZvRrdiAmCpiSguujOx590nTaqvF0umD1Dxysty8sILL7zwwgsvbXMx6M0KAN8qfKv4zE1PIj9ZQsqRYJ8QdZiSVThZF9+4cyd2T5aQcHpvFYtyBUAbHFP36WJVYZyEnRyfLPr5zwEA3nust7R7i5gAWDaiIoYVAERERG2ul0YMAUAVcB0BIPjszU/DJg38XouYqGuoAumEwY5npvH1O58FgJ7sZdFVL1lVM+k0KwCWidvqDehu1kQJLSIiImovvfo32irgCHDtA3swMlZE0jU9N2JK3cUqIEmDq+7bg/ectAHJsApAenAcrluOa74/yYHqZcIdu4x6e1EhIiKi9tcN02UXKhrtv+PxceSngpJpok5mVYGEwc2PjsI10h3z4BfISPfUHXdDAqOdMQFAREREPUkkWD+7l042VQHXCGZKFnc8HjT/68Wu6dR9EkaAouL6B0cAdFlJ/DxMlWxQ9dDqDaG2xwQAERER9RwRIF9SnHxgDilHghHEHmEkSALcsG0EmjA9FyhR91EFkq5gcqKIOx4fA4Ce6WsRTXM4+cAcBtMGJX6gaQ5MACwjrl9JRETUnowIip7i5E19YQKgN0bOokTHT7aNQEoajJoSdQHfKiTl4OePj6PgWbimN1YDMGEG4ORNfRjOOChZ7YZjGWOoZcSdu4xEJA9lGo6IiKgthVMAekl0VnL9g3sxOVEsN0sj6nRRI8DrHhpBoaQ9199jqmThd0MiUwQiyEvO45FpmTABsBzC9So9zX/OTo1PwnESUP55JSIiaje9FiREBtIuYKSn+h9QD1Agl3LYBLBjiSfpPlirF+9590mTuOjOBER4mFpiTAAso0w6nWfgT0RERO1EAUyX/G6IFojq+L4i7/mt3gxaLBGImDzAwH+5MAGwjLh+JREREbULVSDhCKbyPr7ws2dg0i48zlSkLqEKZBIGI3vz+PwtOwCA7++OZRlDLSPu3OXHfUxERERtQwHkPcsKAOpKquH7mzoWG6kvL+7cb8vfswAAStFJREFUZSQ5T0WQL6/PQURERNQGenCKNPUQvr87mKqKSL7Vm9HN3FZvQFcSUVx0Z2LPu4+dHPyXey92cn1/pZOjHqCJVm8aERERRTS8EBF1gw4+pikUjpOwU6MTnuY/ByBorP6+Fm9XF2IFwLISFTH5oMSuQz+MREREXYt/m4mI2kN4PFarmXSaFQDLiBUAKyFaCIDnGURERO1B0dGDZUREdTr5uBZus6hYNlJfXty5y05zgFNJAhARERG1mGF/IupifH93KKsAJKdpl7/AZcQEwHIZftQCgDX2ei1OF2CMYRaAiIiIWk0VmCr6XAWAuo4AgNXg/U2dxiKZhkKvH8k/l8fH1ECEsdMyYAJguVxwgQWA8dzPbkB+Og9xnI4sxyEiIqKu4VtFKiE45dAhaNGyWzp1laKvyPQl8OpDhwFwNYDOIlYSaajo9fjQWQWsv8tp9RZ1KyYAltng9PE5iNHOnIxDRERE3UIkqLBNuQanHjocJgAYIVF3EAFKVtHXl8Crnx8lAPj+7ijWQiCZVm9Gt2MCYJmZrK8Acqz+JyIionYxXuAUAOo+AsDzLacAdCQFHAdgAmDZcRWA5SKi+JiakfxV+SFsul4SmddpYcoCYDkLERFRm+jVAcJs0oH06ounrpZOOHB68L0dTXeIhhw7auhRVSHG6Mx0wRp7PYByPzVaeqwAWE7r73LwobMKKnotEmkAwjcyERFRG1AEo4V5TzvrRHkfuWGU8O6Xr8fgcBL5ku3ZJAh1F9cI7LSH33vZOuTSDkq+9tR7O+8p/E5eedxxHBSnp8dfsjtIAIT91GjpMQGwAgTO/sERqCM/jkRERF3Ht4psysElvx7BVNHCNdJTf6XTCQfZpMMZitRVRIChtNtTs1t8G3yIv3zPXjwzUUTaNZ15LLMWEOkfvH91f6s3pdsxAbCcyksB+tdqfroAMQbKP7VERETtoBcrAESAkq/IJg3e+bJ1sDNeuSqAqFOJADMli8HhFH7v5esBoOfe13lPYTv3YGaRSEOB68ZKT01zCcDlxQTAcoovBVicnoFxOP+fiIiojfRYjFAmAgxlXDi9ugOoK+VSDjKJ3jzd7uyPslhJpgEj13EJwOXHBMAKGJw+PqdiXE4BICIiolaLRkZ/72Xrke5PIO8pVwSgjuYagU57+O1jDkA2aXpu/n9XUAVUB1q9Gb2ACYAV4PZP+QLN868rERFRe1Ggk8tmF0UkmDc8mHFxwkED8AseXEZL1ME8q0DC4IzDV0Ok00fDF6fjj2NqVQTTrd6MXsAEwHISUVx0Z2LPu0+aVMF/S7oPgHit3iwiIiIKgn9HgFyiN0+HEo7g468/GGnXwGeLIupQjhEU8j7OPHo/nP6CVfCt9uTUllzCdGaxsarCcRJ2enzc0/znAADvPZbx0jLqzb94K04Uqi4cF535ySQiIuouCiBhBCN5Hzc+MQkAsD0UBBsJVj044aBBDA+lUPRYMk2dyQiAksXrDlsF1S4YCV8ARfD6C77ipicnkUxIZx7HVCGq2dRQvtDqTekFTAAst3AlACP4ic5MFSDG4UoARERErZcwgvEZHzeFCYBe+ussAni+wgjwB6/YAM17PTlqSp0t6v6///4ZvOWlawHpve7/RiRIADwxhZRrOvA4JhaJNAC5fnhq/yI+poxPl5nb6g3oeuFKACMTu68byq2ZhpsYDiYqERERUStp2PuuV6cAuEYgAvzRqw7EZ258CnumSnAd6cAAgnqVYwSFyRI+eNYWrOlLoOQrEk5vJQCA8DjmGuRLfucN7yqsuGnH5qeuffhDzy/gojsTkONKrd6sbtZpb5GONZhe3Q8j/bC21ZtCREREoV6OdUWAkq8Yzrr44Ks2wp9hFQB1DhGgULLYf00GH3zVgVD03uh/xEgnT31QQAQCZ/9Wb0mvYAJguYkoPqZmLPvUtFpcF5S4gFkAIiKiNiAA8p72bCLANUEvgA++6kDsvyaDomfZC4A6gmsENu/jg6/aiOGsC6+Hl/7Le9qZCQBVhTFGC9MFC/9aAOXp07R8mABYCevvcvChswpGcIMkowSAghdeeOGFF154ad3FtxbZlMEl9+zFVNGWg+FeEvUCGM66+MCrNsKbCKYBELUzI0C+ZDEwmOzp0X8/jPq/fM9ePDNRQNoVaBscWxd0EXG0OFkcf/hnNwAoT5+m5cMEwApSVRfW67VzCyIiorYVVQD4PfzX2TUC3yr+7LRNOOWo/TA16TEJQO1NBH7Rx1ffeQSGsy6sRc+O/gPAdMl2ZgUAAEAgYgrDBx+bbfWW9AomAFZCuJalN1W4yM5MTMExCa4EQERE1HqKYDWAXm0ECFQCp1zSwSfe8DwkHYHt4XJqam+uI8hPFvGm4w7A2S9aA98qnN79+AIA+pMOOrN8STzJ9EMtPj/yF8eOBw0ApSNfSSfp8Y/LyspgIi/Wz0O424mIiFotCv73zni4MVwKsCPX0F4CTlgFcNLzBvGdDxyNfN6DYQaA2ozrCGamPJxyxGpsfdeR8Kz27PtUEUyFCJYAnETSlc48fqmqMTIKMPBfKYxEV4KI4qI7E7v+/pQpBf5bUn0AxGv1ZhEREfW6hBGM53385PEgAdCJ589LxTECz1ecdcRqvOm4AzAzVoDDqQDUJowAxZJFwhF84pxDynP+ezT+BwAYEcx4Fjc9PolUwnTW8UtV4TgJOzM2XprMfwFAuWqalhcTACtJRKHqwnHRoXU6REREXUUBQID9s26rN6UtOEbgWcXWdx2JN56wFsW8z6UBqeWiID/jCL77waNx0sGD8K32ZOO/Wn0JB/0ppzN7AKhCVLOpbL7Q6k3pJUwArJRwSQuj+hNbmJyBMY5q0AiAF1544YUXXnhpzcWqIuka3PD4JAq+wkhwfa8SCUYVXSP4xu8fiVzGQaHEJAC1VtI1yO8t4KNnHIQzD1+Ngqc9/56MRvtvfGISe2e88iomnXMRi0QKqrh2OL1/ER9TxqUrhDt6pYRLWqy766EbtDjtqLARABERUatZBZKu4KdPTKLk9+584jgjwfJiKdfgG79/JFwFPN/2fMBFrZFwBRMjBZxz0jr8yas3oeQrkpyaUp7vf/OTUxib8ZDouGVM1UcqB4Xe/vCHnl8A7nXZAHBlMAhdSR9TM/6yjQ7EXAc3BUC4ziUREVGLqQIZ16DYy2sB1nCMQDXoB/DdDxwN+IpC0WfJNa0YkeB9ODVaxDkvPQDffs+LkUs5cI309Lz/OAXgCCCdFvyrKoxxtTA5A5jbAQBH3Oe3eKt6BhMAK0VEgXvdp/7sxBlYvV1SOQDKNzoREVELKYC0a/D0eBH/86u9AILRbwqCr5KvOPPw1bjiA0djVdrFdMFjJQAtOxPOxZmZ8XDu8Qfg8ve+GCICq73d9C+iAFwjmChY/M/de5FNOp133BIxWpx2Nv78vusBlKulafkxAbCSypktc7sGfQBcaEf16yQiIupK1gYjaVQt4QTLA55x+Gps+8RJOOeo/TEzXoTDUVhaJq4RFIo+4Ftc+YGj8Z33HQUjAkEwPYUqsgkDr9MCfwCAWLgpQMx14y/b6HD+/8rizl5JYWZr48/vu16L0w7YB4CIiKjlrCqSCYObn5wKGwF2WDntMnNMkAQYyri4/D1H4tzj12Jm2gM0WJedaCkIgvfTdMHD6rSL7/zh0Tj7yDXwbdCckwmningDwLFCJ07NUV9SOcDq7U/92YkznP+/srjmzUr7mJrxgVsd+OY6OKkz4c1YAE6rN4uIiKhXqQJJR3DT40EjwJTDBEAtxwTl10YE33nfi/GDX+/Gef/9K0znLfr6kih5lvuMFi3qOTG9J49zTlyPL739cAxnXPiW3f4bsRokKm9+YgrjUx7W9CdR6phKAFWIcTXP+f+twhHolRTvAwD2ASAiImoXUSPAAhsBNmUkuFhVvP7INfjhh16C17xwNSb3zsBThetwWgAtjGMExghmpkpQAP/wW4fh8vccyeB/HlQ7tQEgOP+/xZgAWGnsA0BERNRWokaAT40Vcck9bAQ4FyMCzypOe/4qXP2hY/DxCw7D6lwC0+NFlHwmAmh2gjDwF8HMjIdi3sMZR6zG9//gKPztWVuCKTgKBv9NRA0Apz2LL/5qLzKpTmsAGM7/B+f/twp3+EqL9wEosA8AERFRu1AFxvMWTMvPzQ37AhgB/u6sLXjgb1+Ofzj/UKzpCxIBRU/Ly7gxjCMgmMPvGoEfdvcvFjycefhq/PCDL8FVHzoGp79gFUo+5/vPV95TzJRsBwZz4fx/cP5/q3Tee6YbbN3qjL9soyNibpREGgBY9kJERNRCvlVk0w6+8uu9mPYs3E4rq20BJ9xHnq8Yzrr42zODRMDHzz8UBwwkUPQUM9Ml+BoEfomwMoCxXfcTVEb6E06QBCp6iumpEvpdwZmHr8ZVf/QS/PCPX4LXHbEaqsHUkgSbSs4pGu2/5J692DlRQso1nXWsEnE1P1lSq3cA4Pz/FmATwJUmorjoTvPUnx030/+pX/3QcZOnA9NsBEhERNRiBsB0ySLvKXKJVm9NZ4g6t6sCvgaJgL87cwv+16s34bbtY/h/1zyO2x8bw8hkCfAVknFhBEi5pjzKaxWwVvcpM8CqjX2zFCPuUcm+ACj5Cl8V/owPFH1ILoH9+xP4wMlb8P5XbMCa/iSA4Pem0HCZPwb/8xVVK3VU5T8AqCrchNHizO6Jmb3XAOD8/xbgJ60VVAUimvuXu/d3kHhEBH3wfYWw4ImIiKhVXCMYmSrhX1+3AX9ywn7wrHbg8lqtFSUC4vtt13gRX7z9GYznfXzxth2YLlqMjuYr9Y8JAydp9imINyJcI34f7Ota8qqA5r3gG6tI9CXQ5xicdNgwjlvfhxMOGcIrnzeEXMop398qm/wtlCII3qZKFkdd9CCemfKQ7KRqJUVJ+oYTOj3yybHN9/8NRg42eN9xpVZvVq9hBUALZSdHpgvZNdNwnL5WbwsREREFo9HsA7B4IoArQUBircIYwX4DSXz0NZsBAH/x2s3Ilyy+cGuQCEg4wG3bx/Gzh0aQSDnwF7nji56iULIc2loEATCccRe17wTBZyblGrz7jIOQThgUCz5e8fxhHL95AAOZ6lDDswpHgqkgDse9Fi3vKaY7cv6/AKo+oKO48EIfF93ZeS+hC/CT1yoX3ZnAe4/1Bv7lN/9m+lb9iU7sLUHAgkMiIqIWEQBFq1iXc/Gr9x2GXMKUR9xo8VTDecthE7hGxmc8iBEsdCiz5Afzxv/5msfwj997BLmBJEpcynFeRIL9N5R18eu/ehn6Uw5UFz4dICrh70s1ns0aNfYzwtUh9lVUlfT/bt+FD//oaQznEvtcvbFiVIOMIOB5k2Mbpj5+0nNRVXSrN63XsAKgVYaPtRBRfPKeq7Qw/UEIzIL/6hEREdGSMlBMl3xMlyxyCQ5OLQWRoE8AUJmr71stn/UkHKkbKZ6vKGDNJHgatVhRBUAmuW/vd89q+fcbBfwQsLHfEvNVMZb3YVURvOk75Y2vVpIZRwuTN0ytT41g61YHImwA2AL8y9YqFwQz38Zn9tygxam9cBwHyoJDIiKiVlEEpczPjpdw2X2jANBh62u3P5FKQiARXoBwDvkiLiVfw/nkLX5hHa68H+3ifxfRSg8JR4LlH7niw5JSIFydRPC134wgm3I67PgkFm7St8b8AO87roSRgxmHtgh3fKsEqwEkcMQuhTHfkMwAAPFavVlERES9TBVwXcGPHp3AjBeULnfSKXanihIDi73QvtnX/c/fwfKLhglv2D6BnRMlJJxOav6nCmMSOj2qmYJ+EwDw3mMZ97QIEwCtNHysxYUX+qL4gRanZ2CMYRUAERFR61hVJF2DW5+agmPCMmYiohaLGmTe9cw0JmY8JDpqBQWxkkhDVa95bk1xLz6mhnP/W4c9AFopnAawYcrc9JROO3BcBxxoICIiainXCIqexS1PTOHVB/UFy5UxEUBELeSIoGQVdz4zjUSysmJGJwQOAvWRyjooTt+O9x1Xwsd+kwRQbPV29SpWALTa1q3O+MC4o+LciEQaqKyKS0RERCssmmc7Ou3jR4+Ow1fl/HIiailF0FhxJO/j+scmkUwIrHZG8A8AKuLa/GRJrd4BADjiPjb/ayEmAFpJRDFysHnqz06cgeIH4qR8QGy5oScvvPDCCy+88LLiF88qMmkH335gDKqChOmgubZE1HWipf4uu28U49Me0iZYorTVx8p5XawqjGu0OL13YmbvNQCACy7ggGcLMQHQamEDjIyn39TpUYVIgn0AiIiIWkcVSBrBM2Ml3PTEJACES24REa08I0DJKn786ATEBKP/nZOVFE8yAxCYb+CIXUETdM7/bykmAFpNRLF1q/PcmuJeVb1ekhmA0wCIiIhayjWCybyPH3MaABG1kCKY/z+S93HT45NIJUxnJSRFjBZnilD8EBde6GP4WMY5LcYEQDsYOdjgfceVoHJV0AdA+MEgIiJqIc8qMhkH375/DFbBaQBE1BKeVagCl0bl/47pnGORqsJxHRSmx8dn9twAoNwEnVqHCYB2EE4DUL/0NZ3cuwuOw2kARERELaQIpgHsGC/ijh3TADgNgIhWnhFABLhue6z8v1OI+JLM+oB8GkfsUtygLsv/W48JgHYgorjozsTkXx+zC4qvSnYQgHit3iwiIqJe5ogg7yk+cdOzKHXUWTcRdQM/XIL0+scm8f0Hx5BLV5b/a3uqChFX8+Oq1v00LrzQxylg9/82wARAu6jMh7lKCzMliPB3Q0RE1EKeKjJJg5/vmMZI3ocjnAZARCvHapAE+PGj4yh5Clek1Zu0EFaSWajaGyYKv5nA1q0OR//bA4PMdhHOhxmf2XODFqf2wnEcTgMgIiJqrZRjMDrl4dL7RqFaWY6LiGg5KYLeI1aBb98/hkza6bDjj1i4SR8wP8DHLyxi5GDGnW2Cv4h2EU4DwBG7VIzzdUn3K6cBEBERtZZVQIwE828lmI9L7aej4qI2w33XnqKeI3fsmMaO8SKSndSIVFVhJGGnR/yMp98EUO55Rq3HBEA7GT7W4sILfXje1eoVBcLfDxERUSv5qsilHXz/wTFc99gkHJHOmYPbQ9KuQWdVR7cJDfddq7eDGirZoAdJ3gt6AXQQK6kcoLjtuTXFvSz/by8MMNvJheJj61Zn/K9e8mOdmfixpHIOVNksg4iIqIVcEZQ8xbWPjgPgiGk7ccOSjHeftB7Dq9KYKVkmAubJNQKb9/CuE9chl3ZQ8pX7rk0ogiakEwWLn++YRiZp4HVS4lEM1NqiA+dv8L7jSsAFrd4iimECoN2MHGygKhDnKiRSAIRrZRIREbWQZxXZtIOt945i97SPRCeV4vaItOvAcRi9LpgC2YTDCoA241uFr4qLfrEbY9M+kk4HhWyqCsd1UJgaXz997+0AJOp1Ru2hg95NPeK9x3oQUfVLX9PJvbvgOAk2AyQiImodBZBxDR7dXcC37huBgs0A241vFVMFH4xk508AwCrG85ya3U4UgBM2//vcL/bATRj4nXS8EfElmfUB+fR9R8DHDcry/zbDBEC7CZsBTv71Mbug+KpkBtgMkIiIqMWsAm4ibAYINgNsJ1aBVEJw2vOHoUXL3808iABFX9HXn8Sph60CwPd0uyg3/3t6GrsmPaScDqo4UlWIOJof99W6n8aFF/o4BZzO3GaYAGhHw8cGZTJWrlavwGaARERELearoi/l4MoHxnDzk1MwbAbYFkSCaoyUa/DSzQPQgg+Hkey8lKxCE4JTDh0GABg2AGgbAuD/3LIT057txOZ/oqq3TRR+M8Hmf+3JbfUGUANRM8ALj/xx/z/94seSHngt8pM+jDidkwIkIiLqIgIEvdIV/3Tzs/jB7zyv1VtEoShAOn7zIPr6kyh6QTM75meaMwJIyeLVR6yGZxWOEc6eaAO+Bt3+b3lyCtc+PI6BtIFnO2j6vAjU+kUH+jf4+IVFbFWn1ZtE9Tiy3K5izQDFDZsB8g8ZERFRa2gw0tyXcnDdwxO4bjuXBGwX0YD/qYcNA0lBqZPmS7eIYwS24OP4zQPIJAw8yxUA2kW09J+qwmgH/VJUFcZxkJ8aXz/tsPlfG2MCoF0FzQChvv81f2pkL1w3oRp0A+SFF1544YUXXlpzcURQ8CyXBGwzvlV4VvGKg4eAkmU5+xxKviKdS+D4zQMA0Gll5l0pOr5MFCzu2DGFZKKy9F+rj3vzvPhI9UEhn7nvvvt8XHSny/L/9sQEQLsSUdygzuRfH7ML8P4DyZwPMWwGSERE1EKlcEnAb947gpE8lwRsByJBIiaTMDjz8NVsBDgHEaDoWQwPJnH6C1YDYAPAdhCtLHLxXbsxHi79FwXXbS9c+k9nxnZJfuo/cOmFPt57LOOWNsUEQDuLumbO2M9oftyHwOWSgERERK2jAFKuwWN7CvjvO3cD4JKA7cANI9i3HLcW69dlkS9ZlrQ34YjAFC3e/4oNABSez/L/VlME7+GRvI//unMXEskOW/oP4klmAKr2q+MfP3EvLrozwdH/9sUEQDsTUWzd6kwiPW7V3ibJLADOpSEiImol3yoyaQefvXMXRvI+XFYBtJxIUNa+pi+B3znuAPjTHhIc1q4nQMFXpPsS+MDJB8IxwlUT2oBnFQLgv+/cjSdHi8i4ptOOKUZLebFWrwZQWdGM2hITAG3vAuDjLyqKyt8qVMAerURERC2lADKuwZOjRfz3nbshYBVAO4ji2DNeuBpO0qDEosk6rgTN/044aAD9aQc+m/+1XHz0/7N37kIm5XTW8UTVl3TO2MLUjdN/9ZIfY+tWBxeK3+rNouaYAGh34ZKAk3951E02P3mjZPodqPJDRURE1EKeVWRSrAJoJ44R+FZx+gtW4ZQjVqM47ZenBlDAR1At8fdnHYyEw33TDjp+9D/IIIlY/RigAlzQ6i2iOTAB0BEuAFRFYP9OrV+E8NdGRETUSqwCaF8K4GNnbIERgCMmFa4RFKc9vPpFq/HKQ4bgW2X5f4t1xeh/KufY/PiPJ//6mBux9VLD0f/2x0iyE1wACxFsyqduQ2FqHI7jsBkgERFRa7EKoP04RmCt4pWHDOGUF61GcdpjFUDIIpgm8bEztvB92iY6fvQfYuGmoOJcBVXByMGMLTsAf0mdQERx0Z3ufffd51vIZyTVB0C4tAYREVEL1VYBAKwCaBdRFYCqwueYCVxHkJ8s4ZQjgtF/y9H/llMEKzJ08Oi/wnETdmpkr/j+1yACLv3XGZgA6BTvPdbDpRf6Tn7qP+zM2F44DpcEJCIiarGoCuC/7tyFmZIGTdZavVE9Ll4FcN7xa1Eq+HB6eL67CKBWMZB18fdnbQHPHtuDZxVGgIvv2oMnRzpy9N+TdB8A+x+Tf33MLlx0p8ul/zoDEwCdIqgCSIx//MS9UPsfku4XVgEQERG1lgJIOYJnJ0p415WPB8EWT4FbTkRgFfjq249Af9bFTMGH6dGzXtcIZvYW8JEzt+AVzxuCx9H/lvM1SBb+7Mkp/PNPn0V/1u3A0X/HtTNje83M9H8CEI7+d44ePRR2qOCDJWZm+j9ZBUBERNQefAVyKQdbfz2Cm5+cggHg8c9zSxkJYpR0wuDrv38kBhIGUPTckneOEeTzPt540nr8yasPhOcreyK0CRHgEz99FiOFTuwfIp6k+wVq/2P84yfu5eh/Z2ECoJOEvQBYBUBERNReDATGAP/np89CBGCI1XqOEXhWcdYRq/HhMw5Cfm8BCad3Tn2NAQolH7mMg2/8/ouQSzkwRnouCdJuPFU4IrjlySlc+8g4BjMc/aeV1TtHwW7BKgAiIqK246kil3Jw/aMTuOrhcTgi8PnXueVcIyj5ij999Sa88aR1mBwv9kQ/gGDeP+AC+MbvH4mUa+CHc86pdRRBcnCqZPEPNz4DQDowGOPof6fjYaATXXRnAu87rtT3f+7+mMkN/71OjZYgSLR6s4iIiHqZAVC0iv6kwQMfPByDKYfVAG1Aw9J/3ypO/49f4Mb7R5DJufC6OEPjGMHMdAnf/+Nj8PojVsPnvP+2ULLBFIxP3rwTf3X1U1g9mESxo96HqjAuVO2ImZk8dPzjJ46EaY1OehE9r/OSTgS8L6wCKMSqANhyiIiIqKUsgmUBd02UcPFde2CEywK2AxHA84MA+BPnHIKEI/A8C9OlAXHCFcyMF/Gm4w7A649YjZLP4L8dWACuCGY8xX/9fBdyOReljgr+AWg4+m9jo/8M/jsOEwAdKdYLwIa9AJS9AIiIiFrNs4q+jIt//umz+NmTU+FUAJ4ft5rrCHyrOOngQXzvg0dDfYXvW7hdNB1AAKQSBlOjRZzz0gNw6buOhGfZ9K9dqCpEgHd973E8O1FCouMa/8Xm/hfCuf/v49z/TsQEQKdiFQAREVHbUQTzzkfyPj7x02c557qNOGE/gDMOX40rPnA04Cump0pdkQQQCS4Tu2ZwzksPwLff+2KICBxh0792EG/8t/XXI8ilnM7rEcLR/67BBEDHYhUAERFRO/KsYjDj4PpHgoaAhlUAbSPhVJIAV3/oGLzmhasxPVFC0jUd26vBdaTcz+AffuswXP7eF5dL/hn8t54iGKKLGv85RtB57zaO/neTTnv3URUVQDDwsZ8N+5ncNhEzJNYT5eGeiIiopQyChl99CQeP/ckRSDsGEI68tIuoKZ5V4E0X/QpX3PoM0sMpAALbQcka1xFMT5WQcA2+94dH48wjVsNqcILPs8H2ULKKhBF88pad+MurnsSqsPGfAJ0zBUBRkuygq9NjH5/8q6M/HjUkb/Vm0eLw71BHi1UB+PY/pW+VUQtm44iIiFrMAkg6BqN5D7//vSdghBP12oljBF64LN7l730x/uG3DgMA5It+R8yZFwGMEUxPFPHaF67GVR86BmcesRpFz8IIg/924WsQ/P/sqUn8803PYqA/UW781zGHA4GF47o2Pz5jCtP/CVWO/nc4JgA63fuO9bB1q9OXlH+x43t+KpmcC1W/1ZtF9P+3d+9xdpXXff+/69n73GZGoytgcPwKDo7jYptghAmXQOBXxzcVZJNKjtMkjZsCTRM3dlvXDgFG41vaOK0T221exkmdpr869sjGBkUYbCdgMDcbYjcGEmwEJL6AjDSS5nZuez+rf5xzRmekERIgaeac83m/XqMXjGZGW5o5z95rPWutBwAGXe6ucjFo64N7dPOj+xRMtAIsI2kwuUvBTNe+8cW64YoztG4o1Vw9k5mW5eR8s1YbQ567atVMG88+SV/87bP0T1+6Wnl0FVMe7ZcLlxTbpf9bbn9K++q5gvXa4D9JLleSWojZW6fGz5/U5q2B3v/exirR88z10Am2811nzlrWvKZV9bX8blgAAAwic6lUMP3Lz/+jqlmUyRSX+qIwz0yt4xpz1xtevlaPvPcCvenME1WvZqpWMwWzZZEIMGuV+zdz1+x0Q6tLibb95pn6wlU/Lfn+lgYsH1m79P8jX/+Rvvz3e7V6OO29Y0HdcysNB29Uvzp99fqbNDGRaOtmNhp7HAmAfjB+SaYJT2auXX+H16a/auXhINEKAADAUuu0AuzragWIvRYEDIDOMYFrhlJ9/sozdOtvn6U3nL5Wjfr+RECaHP+J+kmw+cGFc1MNrRsp6L2X/6Qeee8F+mevXNeqYAjLs1phkGVdpf+/f8fOBaX/vcbdzdzHJDc9dAI/aH2Ab2K/mPBEmxVHPvDNi2x45e1enc4lJUt9WQAAoLWDO1uL2v7Lp+n1p40qbx8LhuXF2790vjW3PrRbf/RX/6hb/263YiMqDKUqF4Lc9ydyjmZYZ+1fktBKSNRruZRFnXhCRb910Y/pt37uRVo9lEpi13+5crW+N5L0hv+zQ3+1Y0orh3pw91/KrDKaxrl9X529+lUXa2Ii0WZ2//sBq0Y/2dQqyxn+wN/caJWRy1SfzSUjCQAAwBLrPHBlmesrv/YSnf9jI8rclZIEWJaiu0z7d/y/9PBu3fHIHn3y/qf0w6fmpEJQUgxKrLVDHzsJgfbHH8moB+uMgbf98wjqWWz1js9lUiHoDWes00UvWa0rzj9Fa0cKklql5Ykd/2oEHJksutJgesvnHtfE305q1XChB4N/d1kSVShXVau+cebqM76mrQrabCQA+gBLR18ZC/ItfvKWBypTleL3zMJKxWZgFiwAAEsvDabpaqZLfmJUX/wXp0lq7fRyk16+DkwE7Jpp6k/v+aFu/+4e3ffoXs1kruZ0QyolSoqtygCTVErDok9f7XhfzdyVxdZRcNElr2ZSkFatKmu4FPRr61+gi35qtV57+tr5zyXwX/46lT237JjShv9/h1aUg3qy8t/VtOGVqc/s2TLzu2e9l2P/+gtLSL/5+P0FXbU+G/7At8bCqhPHfO+PmgpWWOrLAgAArSTA3tmmNp+xRp/5hRfP7xZiecujy701K6Bjqprpnif26d7v7tUDP5zR1x7Zo0IpURZdk5O1xXsDTFLuCiMFrRlKlUepUgx627mnaEU50a+fd4rKhaCRUquAs1NOTuC//HUqeu7+/oxe82ePKk1b37Cei/9NUSE1j3k1qSYvmtLL92pczuT//sFS0nfcNLE1nPQPLy3PZOGLoVS5wGszLqMVAACA5SAxaZp5AD3J2xP3uxMBHfvmMoXE1Mii/uTuH6qeRQVb2A6QBFOznuv8l67WuaeuVO6tBFAn4O/Icl+2RxHiYAf2/d/22JRWVHqy719y5SqWE2vMbpy+ev1NnRbjpb4sHD2sKv1o7LZU45dkI+974CIbWfVVBgICALB8LJgH8DbmAfSizrDA6K7oUmGRhMCzkUWXfH/Az49Cb5nv+/9sL/f9S+oM/qsy+K+fcQxgPxq/JNPERDJz7fo74uy+m1QaSiTnxQsAwDLgagV6jTxq7K+fmg/+ejJcGFAmze/Qd4J/9/1vWe5qPsNbp6Wg85aG/ccMEvz3lk4Vxy07pvTZB/f26sR/tQb/BfM8mzEP12psLEiblvqicAyQAOhXmx9yudtoM77VG7VJhYKObCYtAAA41rLoWlFJ9ZVH9+lf3PCE0mA9GjSgoxO8m7VmBRSe4S0JtuDj0ZuydvvOPd+f0eWfekzDpaCefRm7ZVZZEVSd+dDM7/70nTrl0oSp//2JBEDfGo+6/oH0yfH1VcX8oza8OlFUttRXBQAAWrLoWjmU6rMP7tUtj06pEEzNno0egMHikoJMubuu++un1MijkmC9WcljHpUWklidqoas+DGNedBV64kb+hQJgH521fpME1vDSNE+FGd232lDowU5rQAAACwX0aWhYtDln35MX9rRSgLkFOwBy1pn6J+7a/PE4/rKjh4e+idJHlxpMYRm9tap8VdM6uGtxtT//kUCoK+ZS5u0811nzloWr/aYzyikkVYAAACWB5cUQutt46ce0z3fn1VipoxbNbBsdYb+/dINT+iGb+/R6p7t+5fknqtYDl6buWn6Oqb+DwISAP1us+X6+P2FmWvP/JpqU39gK9YUaAUAAGD5iC4Vk6BmHnXdXz+p3F1B1ru9xEAfa0ZXIZhuebQ99G9FoXdbd0xRadG8Wa+ONvK3asyDtj7Uo38ZHCnGjgwEN338gfSEH5ZLc+Xs5lAcvsBrMy4zjgYEAGCZSINp71ymy09fpYnNL1ZirX5iHtaA5SF3KTHp1h1TevNfPDY/zLFnI2ZXrmI5sersxunrztqmTQrayuC/fkcFwEAw1w+n/enxV8xYll/jIQRGzgIAsLxk0bV6KNUND+7R5q2Pa7YZlUXv3eAC6CO5u0zSLY+2gn+zVutOD78+MxsaTbxZ/er0detv0sRWgv8BQRQ4SCYmEm3enA+9/29utPLwparPRaoAAABYXkqJaXJPQx/c8GP6nZ99geq5q5TwyAYslehSMKmaRb3ovz2k6UaucmrKezb6d5clmQrlutWrb5xp3HCXXr7FOPZvMFABMEg2P+QaGwsrm/Gt3qxXVSglkselviwAALBfI3etGC3o9+/cqVt3TKmUcDwgsFQ6L73cXb/8uSc0XctUTkMPB/+SXJmtPLHgtak/mPndn75Tp1yaEPwPDtLJg2bTRKKJTXHofQ9ssPLwp5U3SvKYiJ8FAACWjWBSM3cpSl/4pdP0utNG54ePATg+OsG/y7Vp4nF9/sFJjQ4XevuoTvdcxUqIWW37aGq/uHNmT13jF+cc+zc4qAAYNFs357r+gXTuurP/0huzH7IVa1PFyKkAAAAsI9GlQmKyIL3pUzv0pR1TKgQqAYDjZbHgf9VIjwf/5lFpwTxrVFfVvveWne86c1bjt0eC/8FCGnkgtU4FOGkqLU5n+mIojVzo1amceQAAACwvwaQsd3mUbvyl0/RaKgGAY+5QwX/vJ+AsV2koibN7N1ave/U2TShQ+j94qAAYSOZavT7ufNeZsyHLrvaYzygkUerllCYAAP0nupS2KwE2/gWVAMCx1rfBv3uuYjl4beam6nXn3KRNWwn+BxTp40H28fsLuurs5tB7vz4W1r5oi+99simzQi+fZwIAQF8xSd46boxKAODYOmTwn/v8a7HnmCR5VFoOnjfnVtaaJzyp9TWNb5E0zjDwAcRdY6C5aez25KSR1aWphn86FMob1KhyNCAAAMvQfDuAkwQAjraDgv9v98nOv9xlaaak0PD67C/OXbt+uzZvDdq6md3/AUULwEAz1/jtcee7zpxd1fjeWzxrcDQgAADL1Hw7gEkbGQwIHDX9G/xLkjJbeULB67Mfmrvu7L/UVQ+kBP+DjZQxpE2e6PQtPpRc+kYrDX9asVlUzFLJ+PkAAGCZoRIAOHr6O/j3XIVKiM3a9tGi/eLO72YNXb8+Y+r/YKMCANJWy/XkpcncdWf/pddnP2SjJxQkcTQgAADLEJUAwNHR58F/VFpKPGtUVzXaR/5dvy0n+AepYrS56coH0pN+Mi3OzwNoVqPEPAAAAJaj7kqAL/zSaXrdaaPKXUp4ugMOK3dXYqY8ujZt7bvg3xXSTKHd959vu1kPbzFtZeo/qADAPHNdvy1fMA8gZR4AAADLVXclwOV/sUPbv7NPibXez8G+wKG1EmWmvbVcmz/bb8G/JCmz0a6+/ycvTQj+0UGOGAsxDwAAgJ4SrJWun2vmevPpq/Xpf/5ihfZtm7EAwEKdeRlf2jGlX/ncE9pVzTRSTJT3TdaMvn88MyoAsNDi8wAaS31ZAABgcdElBWmklOpzfzupzVsfl7srmPooqAGev9ylQjDdumNKGz+1Q3vruVaU+ir4j0qKrb7/f6DvH4sjL4xFdM8D0GeSyooNPrc3lwXmAQAAsIwVgmnvTFOXn7FGf3rZj2tVOWEuAAaeu+RqVcRs/84+bZ54TC6pkIR+Cv5dSSFXSOW12TfT949D4XaAQ3CTzLVpIhk662W3hUL5Qq/PZJKlS31lAADg0BIzzTRyrauk+t+/cKpee9qo6rmrRBYAAyiLrmAmd9dbPvu4Pv/wHg0VElnYfwpAf7CmSsOFOLvnsurYOdu0yen7x6JoAcAhmGvstlRbN+cxa1ztHnOFNJX311IJAEC/yd21opRobz3Xmz61Q7c+OqVSYgwHxMDJ3ZUGk0natPVxfe5vJzVSSqW+C/49t5HVBa/u21YdO2ebrry/QPCPQyEVjGfWzh4Ojd+7wcorP8NQQAAAekNipnoWVUyD3n3BSXr3z56kNNj88WdAP4veKvm/7Ylp/Zc7ntKtj05p1VDaT5P+2zxXcchiVr+5Wpt8syRp/GL6/nFIrP44vLffXNJH31gfeu/9Y7b2hVt875N1yUpLfVkAAOCZWauhTzNTDb35rHX6n+25AFls7YwC/SaPLjOb7/f/5595TLUsarSSKuu74D9GJaXgHudWPf7ECU9ef9mc5EEyjvHGIbHy4wgsHAoYhldt8NnJXDKGAgIAsMyZpCSYpuu5Tqik+l+Xn6rXv2RU0Vu/RzEA+kWnuiW6tGnrY/rCw3tUKSRKEuu/4N+jKy2aLMlVn3vTXL7+Zj0shv7hsFjycYT2DwWsnPWyL1hSfKMacy6zRH22ngIA0FdMkktpMM02clWKid59/kl6z4W0BKB/zJf8Pz6j/3Lnk7r1u1NaMZQqurdmX7RfB/3BXSHNlBQaqu17y9zYudu1aSLR1s0E/zgsVnscuTEPGrd48pU3De099cefNkuGlNejFEIfragAAPStYCZ1twRspCUAvW1Byf8je9sl/67RStLe9e/8XPfLs6pJHuu26pSS7/nBlrnrzh7X279T0kdfWl/qK0NvYKXHs7PJE50uHyo88AallRvlmSnPJBknSgAA0ANMrWqAqU5LwC+cqte/ZGXrlABRDYDe0YyuQjBFd22a6POS/w73po2sKcS5fdtHi3rLzu9mDV2/PmPoH44UKzyevXaJ0dD4vRtUHr1RMUuUNVzG1gEAAL1iviWgEPTuC16gqy96gYLZfFAFLFe5u0ytXf+/fnxav39HV8m/vI+Pu/TchtcksTq1vfrNRza2Sv7bbbrAEWJ1x3Nz5f0FXX92c2j83g0qjXI8IAAAPSiY5C7NzjT1upet0n+66GT9fy9eQTUAlq3uXf8P3vGU/vNdT2m2mmt0qB+n/HdrHffnzcbN1W898iad/pBLW6RxJv7j2WFVx3PX7jcaeu/9Y7b6lC2+j+MBAQDoRcXEtHc203Al0XsOqAZIg/HAiCW36K7/3+/V8EhBIZjyvg7+u477e+IfWsf9tWdzLfWVofewnuN5OOB4wKGVG3xmsimzwlJfGQAAeHaSYIrRD6oGkPZPWAeOt05Yb2olAX6va9d/1XCqRt7Pgb8keVSSSpa6ssbGueYXvqiHt3DcH54zlnI8T13HA77qp24MlVGSAAAA9LD5aoByot+58AX6t+ecqNXl1qm/0aWEp0ccBy4p65pH8eUdU/pvdz2lW/5uUHb9pfngPxRctamNHPeHo4ElHM/fmAdpi/Twy40kAAAAvS8Jpix3VWu5XjBa0J9s/HFt+KlVkkRbAI653PfPn5isZrpy2z/qcw9OSmZaWUnU7Ptdf2lB8F+fvWzuulff3JnBtdRXht7G2o2jgyQAAAB9pXNcYK0ZFaPrNT+xQv/hwpP1T9ttAVl0JSQCcBR1NvSDtf77g3c8qT++/2n9cKqp4VJQsEHY9ZcI/nEssWbj6FksCTA72ZRIAgAA0KvMWg+MM9V8vi3gN159gtZUUkkLd2uB5+LAcv8vPTqlD9/dKvcvD6cqhKC8f8/2W8ijKy04wT+OFVZrHF0HJgFKwxt8bm8uC8lSXxoAAHju5tsCqplOWVPSb5x9gq6+6OT53VrJFUgE4FlwbyWQ0nbg/1ePT+u/3vmkvvzYtDKXVlYSZblrQEJ/Se5KCrlCKtWm3jQ3du52gn8cbazSOPrGPEiSHt5qQ6962W1WKF3o9ZlMsnSJrwwAADwPplYioJFH1WYzvf6frNI7z3+BXvuSUUmtgM5JBOAwDgz8J6uZ/vgbT+v37nxKs7VcI5VUZhqQcv9u1lRpuOBzey+rjp2zjeAfxwKrM46NsdtSjV+Sjbzv/p+NpeHblTdMeSbJwlJfGgAAeH5MUpqY9lVzpSa99rRR/fZ5J+q1L1kpiUQAFndg4L+nmut/fONH+h/feFo/nKyrUkmVJoPS538A96aNrC34zK5tc9eefRnBP44VVmUcO5s80VbLh8bv3aDy6I2KTVPelBRIAgAA0AeSYHKXZurPlAjYP0cAg+lwgX+xnKicBuVxkMr9u7g3bWRNIVantlfrk2+SJI1fnEs2kP8cOLZYi3FstbOXQ+P3blBp9EYpT9Rs5DJjJgAAAH3icIkAqX1qgJkoChgcubeqQDrf8kMG/u4alBl/C7T+0rmNrElidWp79ZuPbNTpD7nGtzjBP44VlmAce50kwNg33uiVkf9t8jVqVEkCAADQZxZLBLzjgpN07ouGtaLYuu2TCOhvrlZca9L89/jp2aY+8cBufezrP9KTe+oqlgY88Jda0/6T1FWoBDVr2+Yak5dLt0dpizRucakvD/2LpRfHx6aJRFs353rnLWvKa0788zC8eoPPTDZlHBEIAEC/6SQCZmuZ0jTopJGC/s3Z6/Sb55yo1ZVWIsAlxQN2iNG7Dizzl1rH+f3R3Tt13/dntXsuU1oMqgx64C9J8qgklYU0Zh4vb/zOK7dpzIO2yGXs/OPYYr3F8dOeCaBNE0n5zJ+6MVRGSQIAANDHkmCK0dXIXVk91wvWlPT2c07UFevX6oTh/bd/qgJ602JJnOlGrnu/N6s/vGunvrRjSplLpUJQMTECf0md4F+h4Pns1MbG+87dPr9RBhwHLLM4vsY8SFukh19uJAEAABgMZlJipmoWlTWi1g6lOufHhvXOA9oDXK2j35JAVcBy1gnku3f7n55t6voHdumPv7FLO2eayrKo4XLrOL84qMP9DtLZ+S94Vp29rDH+6puZ9o/jjbUVxx9JAAAABlInEdDIXfVGPt8e8BuvXqer1q/TugOqAsxEi8Ay0Snx707OTNVz3ff9WX34rp36eqfMv73bH8KAHud3SAT/WB5YT7E0SAIAADCwTFLobg9oRq2upLrg1BFdeOoK/atXrdW6oXT+40kGLI3F+vol6cuPTun2x6b0fx7aqx9MNZRlUaViQpn/IcWopEDwj2WBNRRLZ0ES4KWtJMDsZC63pNUEyN0DAID+1LnPW7sqQKrnrkYzSlnUi9ZV9CuvWK2LTxvVeS8a0UgxzH9m1t5VZmbA0dfp6Y8uFQ4I+nfONPXn/3e3vvrEtL74yD7FzFUoJyoEUwhSjJ0nN57f9jPJY65CKTELeTY73er5J/jHEmLZxNLqJAF0cSgXV90QCuVLvVmLyjOTBX4+AQAYECYpmGRmqmVRzWqutJzolNGCfvnlaxZNBkhSM7pCuzqg83VwZLz9S97esj9wp/9HM039r3bQf/cTM9pTzaQgDZUSJdYq8SfcfwbuuYrlRAqTeXXfrzTGz2PnH0uONRJLz920RaZxi8Xf+/alqdkNHrOgPJNk4bCfDwAA+opJShNTlrua0eeTASevKOhfnrlWo6VEv3bmwpMEOkgIHNrhAv7ZRtTXvjeje/9hWt/cWdUdj03PB/3FQqJSYvNtATgM96aNrCnE2T3ba5NP/6o+/PpJpv1jOWBNxPLRPiaweO29G9LhFTd6bJryLEqWHv6TAQBAPzooGVDLpWBaVUn0cz8xqledVNF5P75C575wWKPl5KDPb0aXqdUyIBuch99OiN4p6TctHvBXs6hPfnOXpuq5/uxbu/XUdFNZNZOKiYqFMB/0R2e3/8i4JNVteE0pVqe21771nY3aujmfPw4bWGKDsgaiV7TLoopj97wxrazYpiQNXp3OZeHgOzoAABgoZlJqJlfXzIBGrvJwQUOJ6cIXrzhsQkA6OCkg9fZDsbfGKTxjsC8tHvBXm1G7pxqSa76nP01MMRL0P2vurmBuoyeFOL2rFfyf/pBLW6Rxi0t9eYDU22sd+lU7CVAau/s1YWj1uy1JX+NzU02ZOCEAAABI6swMaA2ga+au3HVQQuCCU1fo1S8cVjExXXHWOqXBDpkUyLr62btbCLr/vKXiB/xP3hWYHzisr2Oq3tps/voPZnXXE9NSMP3J3+w6KOA3SaU0yCRlTPB/HmJUUgyKeWYhff9cffcHNH5JpjEPBP9YTkgAYHnaXyYVyh/41k37TwhQwshfAADQrfNksGhCIIuSSSetKqnZjAuSAv/6rHUqJKZgdtBwwQNlhxh4t1iy4Fk7IKjv/J1chw7wu+2pZkoT073fn9Xd7WD/E3+zS/UsaqqWqzGXSYkpLSUKWhjwy5nb/7y55yoUE1PIs0ZtY2Ps7O2twF8uGf+8WFaIpLB8jd2WShdH6fb2CQGVS71ZjYq5GA4IAAAOZUFCwFoBbi2LMrMFSYETVhblkspp0L961TqV09bvX3DqCv3MC4db5fTWahUYPkyC4FiaquWtJx+XGrnrf35zl+aaUWkw3ff9WX3tiWmVikGTc9l8sF8otXb3k2AqdA/vI+A/utxzFSuJZPsn/b/9OyV99KX1pb40YDEkALC8LXZCgMdUzUYuM+YCAACAI2LtLfXupEA9a1VmR0lZrT2fzV3FSqpVlVRyKcrnEwTFZP+jczAtTBZIerYpgnbr/nxQX8taJxhIUvTWn3Hf91sl/MViUGwP49u1r7E/ik+DioUgd1d6YLAvUdJ/rLhLptyG1yRM+kcvIQGA3tB1QkAyPPrnkq9Ro5pLlszXyAEAABypA04ESML+YwOb0ZVFn///6FJWz3VQjX50FYdSrSo/vwOLDgrqu3UF+J1r7pTwq31tsRPsd37h2ejY6Pyju0eFRFaohJhVt9Uaey/X+CUZk/7RC0gAoHd0MqrvvGVNefUJfx6GV2/wmclcYi4AAAA4ug58skiCLXifq1VV0Mz3Jwuez5/VHdR36w7wu/9sLJFOv7+FLMv98sY1r9ymMQ+tSf/jDPvDskfUhN7SyayO3ZaW01U3hGLlUm/OReW5c1QgAABYCkfjgZqgfrlzya2pYrkg2WQ+N/Wrjfedu51df/QaBqmht2y1XGNjQbo41q591WVZ3rzUQtGtsiKRPFvqywMAAIPHj8IbljGPLrNoq04qeLO2vfqjf/zJVvA/QfCPnkMFAHpX+1zV0tjXXxOGRv+TheTnvbo3yi3QEgAAAIDnzT1XsZwoa2Rm6fvnmrs/QL8/ehlREnrb2G1paxHelJTPuObzVizREgAAAIDnaWHJf2zM/Wpj7OztGvOgLXKZUbiBnkQCAL1vwhM9JNe4xeIHv/3PEtkXlKaJ12YyyZ7fWF4AAAAMFo+uENxGTwq+b+f22p72EX9X3l/Q9Wc3l/rygOeDBAD6R1dLgC1sCTAZPQEAAAA4rEyFUqqskcnS99co+UefYQgg+se4RY3dltbHz/lK7f5r3+CNuW1WWhGUFkzuLNgAAABYnLvL3VUop1KYjDG+qXbNGePSxVHuRvCPfsGuKPrPAS0BwcKfSVqrRtUlGQMCAQAAMM89V1pILC3J63PbanO736b//PO7KflHPyISQh9zk8z1ni+vLQ+t/aSVhhgQCAAAgLbuQX/aHT3+WuPqV/6lJLWO+NvMrj/6DgkA9LcJT7S5VbK1YEBgdaYpUyrKAQAAAAaPe65gdtCgP3n72ZAp/+hPBD8YAG4ak2ncYunae37eRla/y4qVn/fZSSnmuaSk9VJgnQcAAOhf1prwL5cNrTKvTucKyftqzT2tQX+d46WBPsYQQAwA8/kBge8778u1d1/7hjgzOa4Yd6tYSVpDXyLRPwAAQD/zmCstmBWHzGN2q3t8Q+2aM8el21uD/gj+MQCoAMBg6e7nes99a8tDySetNHypZ3Upa+YyYzYAAABAP3F3maRCxSTtjvK3NX7nldskiUF/GDQkADCITFfen3YW+9ZJAfZnktaqMeeSRZkldAQAAAD0KFMr8JdlStKCFUry+uy22tye1oR/uWnT1sCgPwwaEgAYYF1DXt7z5bXl8upPWnnkUinKazNNyVIZQwIBAAB6jnsus8Qqo/JmY3f07G2Na85s7fp3DYkGBg3BDdB1Eyh98OHXWrD/YMXKa1tDAmN7SCAAAACWPff2kL+V5tWZXObvq83t+dj8rr8kJvxjkJEAACQtuCFs2pSUf/p3r1Gev13F8lrVZ/e3BQAAAGAZ6ir3D6nc0lu9Mf1f62Ov/rKkhXOggAFGAgDoduCQwHLySauMXCpvtwWYpRJtAQAAAMuGe65giZU75f7+tsY13UP+1mfs+gMtBDLAwRYMCTy4LSDP5EqYDwAAALCE3HOZzCqjYdFyf4b8AQchgAEOaWFbQOmMa641z37LKqNrvTYjxZz5AAAAAMdbp8+/PGLyKFe41RuzlPsDR4AEAHA43TeRsbvXlJPi2yX7dyqU1zAfAAAA4Dhxd1lXn39IbvFMf1i/5p/cKolyf+AIkAAAjoxp7LZE45dkkubnA6h9bKBqMyQCAAAAjgV3lylXSFMrDcvzxu6Yd/X5u5u2yDRucYmvFFj2SAAAz4a76aoH9s8HeP+3X+dp8o7g/nqZyUkEAAAAHB3dgX95RF6dmpTro/W9T39EH379JH3+wLNHAgB4ThaeI1t6/9+9zlN/h7UTAVQEAAAAPEeLBP4u/0gjb3xU4+dPSqLPH3iOSAAAz8emiUQTm6Ls4ESAUREAAABw5BYJ/E3+kVp34D92W6otF+edZy8Azw4JAOBoIBEAAADw3BzJjj+BP3BUkAAAjqYjSwTkMiWS8foDAACDy5XL3An8geOHAAQ4FhZNBOgd5vH1VijLq1NSzDO5JzISAQAAYIC455IHlUfMkqK8um8yevxoMzY/QuAPHFsEHsCxdFAi4NuvU7F0kapTV9rQqnVem5ZilsnNWlUBAAAAfcjdJeWSJ1YeMZfkjeqtcr+jEXW9xs/eJYnAHzjGSAAAx8OmiURbN8XOqQEae3BN0WpvN7N/Z5WVazxvdJ8cEMRrEwAA9AN3l1mukKRWGZU3avIQbrE8+8P6Na+8df7jCPyB44IgAzieNk0kOn2TadwySdLY/euK0pUyu8iKldeZmbwxJ7nTHgAAAHqVyz3KFJQUzEoj8rm9u1QevV5Z/Y75wN/dtOX2ROMX5/ObJACOKYILYCnM3/AuyTrvKr3/26/zJHmHxfx8Swqj3qxJedPlat1AJWu9ZLk/AgCA5aT9fOLuspDLLLXSkLxZk2LcFaX/3oylj2j8Fa3+frlp09agrZvzJb1sYACRAACWlJvGbk+6S95G/uAH6xozP/hNs/BbCsk6K5Tl9VmqAgAAwHK0cLe/UJbnzSm35B5rzny4Hv0ejZ87JUka81QPb3UCf2DpEEgAy8VBcwLuHS2F9DwvVN5pnp+3oCogqnWUIMkAAABw/HUqFL212z/c3u3Pd7nrY8WRk//7zH984a75j6a/H1g2CB6A5WaR9oCDqgLKo/LqPilm7TN0GRwIAACOsc5AP7NUhYosSeRZo73bX/1wPWb7d/vny/y7NjcALDkCBmDZWuTGOfbgSCmtna/iyMWqTv26ksKJC1sEZPvnBQAAADxP7i5XrqCkq8R/xpvNu6T8q4XhF/3p7LtO/tH8x7PbDyxrBAlAL1ikKkBj946W0tK5nhT/vXl+nqXFUc9zqVltJQPkLldKmwAAAHgWXFJs9fVbQSGRVVbKa1PtEv/4seLICxeW+MukTZ9J2O0Hlj8CA6CntKsCTj/BupMBwx968sTm7Pd+XUp+zgqFCywtjsgSeW1Gik0pKmNmAAAAOISunv6QqlCSFSvy6pSUN3+kyuifqjFzez0r363xV8y0P8U0pkRbxG4/0EMIBoCe1WkReEvefTTgyB9MrWvM/P0VbsmK4PkVSgpdMwNyyb3ZnhlAqwAAAIPK3WXKJLMFPf3Nxoyy+p1WXnlfrO/9eiMO3bk/6Bcl/kCP4+Ef6Afupi1KNG7ZgvcvNjOgMipvVKVmXfLY1SogSVQIAADQhzrBeldpfyorj0iey7PGoXv6pVbQ//DTTok/0Pt42Af6jbvpqgdSnTztC2cGPDhSDHMXhtKqc7y272dUKF2odquAajOSXIo5CQEAAHrfwQG/BalQkooVqVXavyta8gnzfLo48rJPzPzH0V0LvsLH7y/oK49Fgn6gv/BwD/S1xWcGSAtbBczzK2ShbJXREclaswNICAAA0CPc24/1BwX8VhySz05KaWnKm9W7rbzqXtX3fr0RZ+/U+CUzC77MmKf09AP9jYd5YGC0kwGv+Ymgq85uLvitsdtGpJPLRZtakBBQOyHQVSFwwAwBF0kBAACON/fWLbjdwx+SVO7tHf4h6YCA36p77quvOe1u/fa6qQVfZuy2VE+uMH18fUbQDwwGHtyBQXWoVgHpUAmBosxGNbRaasy1ZgiYtaoEWoOERKUAAABHkbu3b6lR8tjOuxcUEkkmlUdam//VfVMqlOXN2l1WXnnfIQN+idJ+YMDxkA5AkptcOnRC4N5RSSqpcL5XVvyMV/f9jBXKF6hRk4ZXjspC6wHkoEqBzpfvJAYkkgMAAByoq4RfHlvvMlPS2dkvS2lRCok0t0dyn1KMDU+ST1ju0w3TJ7Tm1MYzBvwTm2L7FkzQDwwwHsQBLOIwCQFJ+qNdo5rdUShW7SolacGVFy3qKgUrzFcKxLz1sZ3EgCTleSbz/Q8fC5IDEgkCAEB/ad/z9nfNdQX52r+j3x3om0kxSnP7plQsy5u1e8zsLi+tKITa9Nfqyu6VJI2fS8AP4FnhQRvAEfDWWnGoGQId85UC6bmxvPJ8q+/L3fOKuV2hEIqKMWho1YhCmH8eWpAckA6uHpAkdc8cWAxJAwDA8eCHDqbne/K739fexe/+9EJZSkutTwiJNLdXyrO9KpQTz+p3m/k97kli7tVGOb9ew6c1F93Zlxb28Euijx/A4fDQDOC58XZS4KoHWg82h6oUkKSxB0ekmSClxaLrCjcrmefu5qWu5IBJ5kqSUQ2t2l89IJOyutSsHTrOXzRpAADAUXRgMH+Qdk9+eyhO1y7+jDq7/sVK8GbtHnO/R5I0tEpWnbqnPlS7R8WXJ3rn6r2H/PJX3l+QJO3p9O9L9PADeLZ4XAZwFB1QKfCAnjkxILUHDlaCVApSPZaUnuuV0fNUm4qex4KZcjc7zwrl89SoxnY1QEfrKWtB0oBlDQBwNC0WzB8gmBRjw80/YW711vtSKcZGw/QJKWtoaKWrfIIdcje/oxPoS2JnH8DRxpMygOOgnRjozBXoOFxyoNsf7RpV7e9dc2nXunVw0kAxhkN/EQAAnoMDg/lFVaPGL5k5oq/XCfLXS/MT+VvzAAj0ARxTJAAALDFfuA51Vw90XH+ImQMAACwnnZ78bh9fn3WdikOQD2BJkQAA0Bvc7ZAr1mJJAwAAjrbuYH5RBPcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYHv4fKxGMY8QkSuUAAAAASUVORK5CYII=
__ICNS_TOGGLE_DATA__

# Forcer le Finder a reconnaitre la nouvelle app (icone + double-clic)
touch "$TOGGLE_APP" 2>/dev/null
LSREG="$(find /System/Library/Frameworks/CoreServices.framework -name lsregister 2>/dev/null | head -1)"
[ -n "$LSREG" ] && "$LSREG" -f "$TOGGLE_APP" 2>/dev/null
echo "  Icone « Cabinet Kine » creee sur le Bureau (1 clic = demarrer / arreter)."

# 7) Message final + ouverture du dossier
echo ""
echo "  ============================================================"
echo "  Installation terminee."
echo ""
echo "  Le BILAN ORAL est installe : micro -> transcription locale -> resume."
echo ""
echo "  Sur le BUREAU, une icone « Cabinet Kine » a ete creee."
echo "  Un clic la DEMARRE (fenetre de logs + navigateur), un autre"
echo "  clic l'ARRETE. Une petite notification confirme a chaque fois."
echo ""
echo "  Astuce : gardez-la dans le Dock (barre du bas) pour l'avoir"
echo "  toujours sous la main -> ouvrez-la une fois, puis clic droit"
echo "  sur son icone dans le Dock > Options > Garder dans le Dock."
echo ""
echo "  Au 1er acces, acceptez l'avertissement de certificat"
echo "  (Avance > Continuer). Connectez-vous avec  admin / admin"
echo "  puis changez le mot de passe (menu « Securite »)."
echo "  ============================================================"
echo ""
open "$HOME/Desktop" 2>/dev/null
echo "  (Appuyez sur Entree pour fermer cette fenetre.)"
read -r _
